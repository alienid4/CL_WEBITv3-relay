"""儲存容量（2026-10-22）：只用已經匯進來的資料，不連任何設備。

來源：
  - RVTools 匯出的 vDatastore／vDisk／vSnapshot 分頁（source_record source='vcenter_extra:*'）
  - 已收集主機的 host_spec.storage_json（VG 總量／剩餘）

## 同一個 datastore 只算一次（去重規則）

同一個 NFS／共用 LUN 會被好幾個 vCenter 各自看到（221 實測：同一個 NFS 在 3 個 vCenter 各一列），
直接加總會重複計算。身分鍵依序取：
  1. URL（`ds:///vmfs/volumes/<uuid>/`，同一個卷宗在每個 vCenter 都一樣）
  2. 沒有 URL：vCenter（VI SDK Server）＋ Object ID
  3. 都沒有：名稱＋類型
同一卷宗的容量／已用取第一列（各 vCenter 報的是同一個卷宗，數字相同或只差即時誤差）；
VM 數、主機數、看到它的 vCenter 則合併列出。

## 排除：宣告容量不可信的卷宗

名稱符合 app_settings `storage_exclude_name_prefixes`（JSON 陣列，預設 ["ma-ds-"]）**而且**
已用＝0、VM 數＝0 的卷宗不算進總量，另列「已排除」清單（221 實測：6 個各宣告 500 TiB、完全沒用，
一加進去總量就從 1.2 PiB 變成 4.2 PiB）。規則只看名稱前綴＋確實沒在用，不猜它是什麼。

## 每日快照

每次 RVTools 匯入（以 vDatastore 的匯入日期為準）存一份各卷宗容量／已用到 storage_daily，
有 14 天以上才畫趨勢；之前畫面顯示「累積中 N 天」。

## 掛鉤：儲存設備匯入（未做）

日後陣列匯出檔（CSV／XLSX）匯進來時，存成 source_record source='storage_array:<型號>'，
在 datastores() 之外另開一組；這一版不讀。
"""
from __future__ import annotations

import json
import sqlite3
from datetime import datetime
from typing import Any

MIB_PER_TIB = 1024 * 1024
DEFAULT_THRESHOLD_PCT = 15


def _setting(conn: sqlite3.Connection, key: str, default: Any) -> Any:
    try:
        r = conn.execute("SELECT value FROM app_settings WHERE key = ?", (key,)).fetchone()
        return json.loads(r[0]) if r and r[0] else default
    except (sqlite3.OperationalError, json.JSONDecodeError, TypeError):  # 沒設定／值不是 JSON：用預設
        return default


def threshold_pct(conn: sqlite3.Connection) -> float:
    try:
        return float(_setting(conn, "storage_free_threshold_pct", DEFAULT_THRESHOLD_PCT))
    except (TypeError, ValueError):
        return DEFAULT_THRESHOLD_PCT


def _num(v: Any) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return 0.0


def _extra(conn: sqlite3.Connection, sheet: str) -> list[tuple[dict, str | None]]:
    out = []
    for r in conn.execute("SELECT payload, collected_at FROM source_record WHERE source = ?",
                          (f"vcenter_extra:{sheet}",)):
        try:
            out.append((json.loads(r["payload"]), r["collected_at"]))
        except (json.JSONDecodeError, TypeError):  # 壞掉的列不算，筆數會在 raw_rows 對不上時看得出來
            continue
    return out


def identity(rec: dict) -> str:
    """同一個 datastore 卷宗的身分鍵（規則見模組開頭）。"""
    url = (rec.get("URL") or "").strip()
    if url:
        return f"url:{url}"
    oid = (rec.get("Object ID") or "").strip()
    if oid:
        return f"oid:{(rec.get('VI SDK Server') or '').strip()}|{oid}"
    return f"name:{(rec.get('Name') or '').strip()}|{(rec.get('Type') or '').strip()}"


def datastores(conn: sqlite3.Connection) -> dict[str, Any]:
    """去重後的 datastore 卷宗＋總量。totals 就是 volumes（未排除者）的加總。"""
    prefixes = [str(p) for p in _setting(conn, "storage_exclude_name_prefixes", ["ma-ds-"]) or []]
    raw = _extra(conn, "vDatastore")
    vols: dict[str, dict] = {}
    for rec, at in raw:
        k = identity(rec)
        v = vols.get(k)
        if v is None:
            cap = _num(rec.get("Capacity MiB"))
            used = _num(rec.get("In Use MiB"))
            prov = _num(rec.get("Provisioned MiB"))
            free = _num(rec.get("Free MiB")) if rec.get("Free MiB") is not None else max(cap - used, 0)
            v = vols[k] = {
                "id": k, "name": rec.get("Name") or k, "type": rec.get("Type"),
                "capacity_mib": cap, "in_use_mib": used, "provisioned_mib": prov, "free_mib": free,
                "free_pct": round(free * 100 / cap, 1) if cap else None,
                "over_ratio": round(prov / cap, 2) if cap else None,
                "vms": 0, "hosts": 0, "vcenters": [], "rows": 0, "collected_at": at,
            }
        v["rows"] += 1
        v["vms"] += int(_num(rec.get("# VMs")))
        v["hosts"] += int(_num(rec.get("# Hosts")))
        vc = (rec.get("VI SDK Server") or "").strip()
        if vc and vc not in v["vcenters"]:
            v["vcenters"].append(vc)
    volumes, excluded = [], []
    for v in vols.values():
        bad = any(v["name"].startswith(p) for p in prefixes) and v["in_use_mib"] == 0 and v["vms"] == 0
        v["excluded"] = bad
        (excluded if bad else volumes).append(v)
    volumes.sort(key=lambda v: (v["free_pct"] if v["free_pct"] is not None else 999, v["name"]))
    excluded.sort(key=lambda v: v["name"])
    tot = {k: sum(v[k] for v in volumes) for k in ("capacity_mib", "in_use_mib", "provisioned_mib", "free_mib")}
    return {
        "raw_rows": len(raw), "volume_count": len(volumes), "excluded_count": len(excluded),
        "dup_rows": len(raw) - len(vols),
        "naive_capacity_mib": sum(_num(r.get("Capacity MiB")) for r, _ in raw),
        "excluded_capacity_mib": sum(v["capacity_mib"] for v in excluded),
        "totals": tot, "volumes": volumes, "excluded": excluded,
        "exclude_prefixes": prefixes, "threshold_pct": threshold_pct(conn),
        "as_of": max((at for _, at in raw if at), default=None),
    }


def _vm_systems(conn: sqlite3.Connection) -> dict[str, list[str]]:
    """VM UUID → 它那台機器（machine_key）登記的 APID。先用匯入時對到的資產；
    對不到（ambiguous／new）再用 VM 的主機名＋IP 算 machine_key 找。"""
    import existence
    import system_stats

    api_by_key: dict[str, set] = {}
    key_by_id: dict[int, str] = {}
    for r in conn.execute("SELECT id, asset_serial, hostname, ip, api_id, asset_status FROM hardware"):
        if system_stats.is_retired_row(r):
            continue
        k = system_stats.machine_key(r["hostname"], r["ip"], r["asset_serial"])
        key_by_id[r["id"]] = k
        if (r["api_id"] or "").strip():
            api_by_key.setdefault(k, set()).add(r["api_id"].strip())
    out: dict[str, list[str]] = {}
    for r in conn.execute("SELECT source_key, payload, resolved_hardware_id FROM source_record WHERE source = 'vcenter'"):
        try:
            p = json.loads(r["payload"])
        except (json.JSONDecodeError, TypeError):  # 壞列：這台 VM 就算「未對應系統」
            continue
        uuid = p.get("vm_uuid") or r["source_key"]
        k = key_by_id.get(r["resolved_hardware_id"]) if r["resolved_hardware_id"] else None
        apis = api_by_key.get(k or "", set())
        if not apis:
            k2 = existence.extra_key(p.get("hostname") or p.get("vm_name"), p.get("ip"))
            apis = api_by_key.get(k2, set())
        out[uuid] = sorted(apis)
    return out


def by_system(conn: sqlite3.Connection) -> dict[str, Any]:
    """各系統的 VM 磁碟配置量（vDisk Capacity）。一台 VM 只算進一個系統（APID 排序第一個），
    其他 APID 列在 also；對不到系統的 VM 自成一列「未對應系統」。列加總＝vDisk 總量。"""
    import blast_radius

    vm_api = _vm_systems(conn)
    rows: dict[str, dict] = {}
    total = 0.0
    for rec, _ in _extra(conn, "vDisk"):
        cap = _num(rec.get("Capacity MiB"))
        total += cap
        uuid = rec.get("VM UUID") or rec.get("VM")
        apis = vm_api.get(uuid, [])
        key = apis[0] if apis else ""
        row = rows.setdefault(key, {"api_id": key or None, "name": None, "capacity_mib": 0.0, "vms": set(),
                                    "disks": 0, "also": set(), "names": set()})
        row["capacity_mib"] += cap
        row["vms"].add(uuid)
        row["names"].add(rec.get("VM") or str(uuid))
        row["disks"] += 1
        row["also"].update(apis[1:])
    out = []
    for key, r in rows.items():
        out.append({"api_id": r["api_id"], "name": blast_radius._system_name(conn, key) if key else "未對應系統",
                    "capacity_mib": r["capacity_mib"], "vm_count": len(r["vms"]), "disk_count": r["disks"],
                    "vms": sorted(r["names"]), "also": sorted(r["also"])})
    out.sort(key=lambda r: -r["capacity_mib"])
    return {"rows": out, "total_mib": total}


def snapshots(conn: sqlite3.Connection, now: datetime | None = None) -> dict[str, Any]:
    """vSnapshot：每張快照的 VM、名稱、日期、天數、大小、所屬系統。"""
    now = now or datetime.now()
    vm_api = _vm_systems(conn)
    out = []
    for rec, _ in _extra(conn, "vSnapshot"):
        dt = str(rec.get("Date / time") or "")
        try:
            age = (now - datetime.strptime(dt[:19], "%Y-%m-%d %H:%M:%S")).days
        except ValueError:
            age = None
        out.append({"vm": rec.get("VM"), "name": rec.get("Name"), "date": dt or None, "age_days": age,
                    "size_mib": _num(rec.get("Size MiB (total)")) or None, "vcenter": rec.get("VI SDK Server"),
                    "api_ids": vm_api.get(rec.get("VM UUID") or "", [])})
    out.sort(key=lambda s: -(s["age_days"] or 0))
    return {"rows": out, "total_mib": sum(s["size_mib"] or 0 for s in out)}


def physical(conn: sqlite3.Connection) -> dict[str, Any]:
    """已收集實體／一般主機的磁碟（host_spec.storage_json：VG 總量／剩餘，GB）。"""
    import rack_layout

    names = {r["asset_serial"]: (r["hostname"], r["asset_name"], r["api_id"]) for r in conn.execute(
        "SELECT asset_serial, hostname, asset_name, api_id FROM hardware")}
    out = []
    for r in conn.execute("SELECT asset_serial, ip, storage_json, collected_at FROM host_spec "
                          "WHERE storage_json IS NOT NULL AND storage_json != ''"):
        try:
            s = json.loads(r["storage_json"])
        except (json.JSONDecodeError, TypeError):  # 收集回來的 JSON 壞了：跳過這台
            continue
        items = s.get("items") or []
        total = _num(s.get("total_gb")) or sum(_num(i.get("size_gb")) for i in items)
        free = sum(_num(i.get("free_gb")) for i in items)
        h, an, api = names.get(r["asset_serial"], (None, None, None))
        out.append({"asset_serial": r["asset_serial"], "name": rack_layout.display_name(h, an, r["asset_serial"]),
                    "ip": r["ip"], "api_id": api, "by": s.get("by"), "total_gb": total, "free_gb": free,
                    "free_pct": round(free * 100 / total, 1) if total else None,
                    "groups": [{"name": i.get("name"), "size_gb": _num(i.get("size_gb")), "free_gb": _num(i.get("free_gb"))}
                               for i in items], "collected_at": r["collected_at"]})
    out.sort(key=lambda x: (x["free_pct"] if x["free_pct"] is not None else 999))
    return {"rows": out, "total_gb": sum(x["total_gb"] for x in out), "free_gb": sum(x["free_gb"] for x in out)}


# ===== 每日快照（趨勢）=====

def ensure_table(conn: sqlite3.Connection) -> None:
    conn.execute(
        "CREATE TABLE IF NOT EXISTS storage_daily ("
        " snap_date TEXT NOT NULL, volume_id TEXT NOT NULL, name TEXT, type TEXT,"
        " capacity_mib REAL, in_use_mib REAL, free_mib REAL, provisioned_mib REAL,"
        " recorded_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),"
        " PRIMARY KEY (snap_date, volume_id))")


def record_snapshot(conn: sqlite3.Connection, ds: dict | None = None) -> int:
    """以這份 RVTools 的匯入日期存一份各卷宗容量（同一天只存一次，已存在不覆蓋）。回新寫入的筆數。"""
    ensure_table(conn)
    ds = ds or datastores(conn)
    if not ds["as_of"]:
        return 0
    day = str(ds["as_of"])[:10]
    n = 0
    for v in ds["volumes"]:
        cur = conn.execute(
            "INSERT OR IGNORE INTO storage_daily (snap_date, volume_id, name, type, capacity_mib, in_use_mib, "
            "free_mib, provisioned_mib) VALUES (?,?,?,?,?,?,?,?)",
            (day, v["id"], v["name"], v["type"], v["capacity_mib"], v["in_use_mib"], v["free_mib"],
             v["provisioned_mib"]))
        n += cur.rowcount
    conn.commit()
    return n


def trend(conn: sqlite3.Connection) -> dict[str, Any]:
    ensure_table(conn)
    rows = conn.execute(
        "SELECT snap_date, SUM(capacity_mib) AS cap, SUM(in_use_mib) AS used FROM storage_daily "
        "GROUP BY snap_date ORDER BY snap_date").fetchall()
    return {"days": len(rows), "min_days": 14,
            "points": [{"date": r["snap_date"], "capacity_mib": r["cap"], "in_use_mib": r["used"]} for r in rows]}


def overview(conn: sqlite3.Connection) -> dict[str, Any]:
    """畫面一次拿齊：去重後卷宗、依系統、快照、實體主機磁碟、趨勢。順便補存今天這份匯入的快照。"""
    ds = datastores(conn)
    record_snapshot(conn, ds)
    return {"datastores": ds, "by_system": by_system(conn), "snapshots": snapshots(conn),
            "physical": physical(conn), "trend": trend(conn)}
