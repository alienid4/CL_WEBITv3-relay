#!/usr/bin/env bash
# 一鍵套用 patch —— 在解開的這個資料夾裡執行：  sudo bash patch.sh
#
# 做什麼：把 files/ 底下的檔案覆蓋到已安裝的位置，備份舊檔，然後重啟服務。
# 出事怎麼辦：畫面會印出備份目錄，照著提示一行指令就能還原。
# 可以重跑：同一包重複套用不會壞，只是再備份一次。
set -uo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
APP="${WEBIT_APP:-/opt/webit3/app}"
TS="$(date +%Y%m%d_%H%M%S)"
BACKUP="${WEBIT_DATA:-/opt/webit3/data}/patch_backup_$TS"

echo "════════════════════════════════════════════════"
echo " 套用 patch： $(basename "$HERE")"
echo " 目標位置　： $APP"
echo " 時間　　　： $(date '+%F %T')"
echo "════════════════════════════════════════════════"

[ "$(id -u)" = "0" ] || { echo "!! 請用 sudo 執行： sudo bash patch.sh"; exit 1; }
[ -d "$APP" ] || { echo "!! 找不到 $APP —— 這台還沒安裝過，請先跑 setup.sh 做完整安裝"; exit 1; }
[ -d "$HERE/files" ] || { echo "!! 這包裡沒有 files/，patch 不完整"; exit 1; }

# ===== 1. 備份 =====
echo
echo "[1/4] 備份即將被覆蓋的檔案 → $BACKUP"
mkdir -p "$BACKUP"
COUNT=0
while IFS= read -r rel; do
  src="$APP/$rel"
  if [ -f "$src" ]; then
    mkdir -p "$BACKUP/$(dirname "$rel")"
    cp -p "$src" "$BACKUP/$rel"
    COUNT=$((COUNT+1))
  fi
done < <(cd "$HERE/files" && find . -type f | sed 's|^\./||')
echo "  已備份 $COUNT 個既有檔案"

# ===== 2. 覆蓋 =====
echo
echo "[2/4] 套用新檔案"
(cd "$HERE/files" && find . -type f | sed 's|^\./||') | while IFS= read -r rel; do
  mkdir -p "$APP/$(dirname "$rel")"
  cp -p "$HERE/files/$rel" "$APP/$rel"
  echo "  ✓ $rel"
done

# ===== 3. 修換行 + 權限 =====
# 檔案經 Windows 中轉會變成 CRLF，bash 會直接噴 $'\r': command not found。
# 這一步是保險，即使中間經手過 Windows 也不會壞。
echo
echo "[3/4] 修正換行符與權限"
find "$APP" -maxdepth 2 -name '*.sh' -exec sed -i 's/\r$//' {} + 2>/dev/null
find "$APP" -maxdepth 2 -name '*.sh' -exec chmod +x {} + 2>/dev/null
SVC_USER="$(stat -c %U "$APP" 2>/dev/null || echo root)"
chown -R "$SVC_USER:$SVC_USER" "$APP" 2>/dev/null
echo "  ✓ 換行符已正規化，owner 維持 $SVC_USER"

# ===== 4. 重啟並驗證 =====
echo
echo "[4/4] 重啟服務並驗證"
systemctl daemon-reload 2>/dev/null
for svc in webit3-api webit3-web; do
  systemctl restart "$svc" 2>/dev/null
done
sleep 3
OK=1
for svc in webit3-api webit3-web; do
  if systemctl is-active --quiet "$svc"; then
    echo "  ✓ $svc active"
  else
    echo "  ✗ $svc 沒起來"
    journalctl -u "$svc" -n 25 --no-pager 2>/dev/null | tail -15
    OK=0
  fi
done

echo
echo "════════════════════════════════════════════════"
if [ "$OK" = "1" ]; then
  echo "✅ patch 套用完成"
  echo "   備份在： $BACKUP"
else
  echo "!! 服務沒起來 —— 上面的 journalctl 就是原因"
  echo
  echo "   要還原成套用前的狀態："
  echo "     sudo cp -rp $BACKUP/* $APP/ && sudo systemctl restart webit3-api webit3-web"
  echo
  echo "   查不出來就把整個畫面貼回給 AI。"
fi
echo "════════════════════════════════════════════════"
[ "$OK" = "1" ]
