#!/usr/bin/env bash
# 一鍵套用 patch —— 在解開的這個資料夾裡執行：  sudo bash patch.sh
#
# 跑完就結束，不需要再手動做別的事。它會：
#   換檔 → 讀出這台的安裝設定 → 確認連接埠沒被佔 → 重新部署 → 驗證
#
# 為什麼要重新部署而不是只 restart：port、服務帳號、API 位址這些設定是寫在
# systemd unit 裡的，光換檔案不會生效。deploy.sh 是冪等的，重跑會把 unit
# 依現有設定重寫一次，該裝的早就裝好也不會重做。
# （2026-07-29 公司 198-014：只換檔就重啟，8000 埠衝突依舊，白跑一趟。）
#
# 出事怎麼辦：畫面會印出備份目錄與一行還原指令。
# 可以重跑：同一包重複套用不會壞，只是再備份一次。
set -uo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
APP="${WEBIT_APP:-/opt/webit3/app}"
DATA="${WEBIT_DATA:-/opt/webit3/data}"
RUNTIME="${WEBIT_RUNTIME:-/opt/webit3/runtime}"
TS="$(date +%Y%m%d_%H%M%S)"
BACKUP="$DATA/patch_backup_$TS"
API_UNIT=/etc/systemd/system/webit3-api.service
WEB_UNIT=/etc/systemd/system/webit3-web.service

echo "════════════════════════════════════════════════"
echo " 套用 patch： $(basename "$HERE")"
echo " 目標位置　： $APP"
echo " 時間　　　： $(date '+%F %T')"
echo "════════════════════════════════════════════════"

[ "$(id -u)" = "0" ] || { echo "!! 請用 sudo 執行： sudo bash patch.sh"; exit 1; }
[ -d "$APP" ] || { echo "!! 找不到 $APP —— 這台還沒安裝過，請先跑 setup.sh 做完整安裝"; exit 1; }
[ -d "$HERE/files" ] || { echo "!! 這包裡沒有 files/，patch 不完整"; exit 1; }

# ===== 1. 備份 =====
echo
echo "[1/5] 備份即將被覆蓋的檔案 → $BACKUP"
mkdir -p "$BACKUP"
COUNT=0
while IFS= read -r rel; do
  src="$APP/$rel"
  if [ -f "$src" ]; then
    mkdir -p "$BACKUP/$(dirname "$rel")"
    cp -p "$src" "$BACKUP/$rel"
    COUNT=$((COUNT+1))
  fi
done < <(cd "$HERE/files" && find . -type f | sed 's|^\./||')
echo "  已備份 $COUNT 個既有檔案"

# ===== 2. 覆蓋 =====
echo
echo "[2/5] 套用新檔案"
(cd "$HERE/files" && find . -type f | sed 's|^\./||') | while IFS= read -r rel; do
  mkdir -p "$APP/$(dirname "$rel")"
  cp -p "$HERE/files/$rel" "$APP/$rel"
  echo "  ✓ $rel"
done

# ===== 3. 修換行 + 權限 =====
# 檔案經 Windows 中轉會變成 CRLF，bash 會直接噴 $'\r': command not found。
echo
echo "[3/5] 修正換行符與權限"
find "$APP" -maxdepth 2 -name '*.sh' -exec sed -i 's/\r$//' {} + 2>/dev/null
find "$APP" -maxdepth 2 -name '*.sh' -exec chmod +x {} + 2>/dev/null
OWNER="$(stat -c %U "$APP" 2>/dev/null || echo root)"
chown -R "$OWNER:$OWNER" "$APP" 2>/dev/null
echo "  ✓ 換行符已正規化，owner 維持 $OWNER"

# ===== 4. 讀出這台的安裝設定，並確認連接埠 =====
echo
echo "[4/5] 讀取安裝設定"
CONF="$DATA/install.conf"
if [ -f "$CONF" ]; then
  # shellcheck disable=SC1090
  . "$CONF"
  echo "  來源： $CONF"
else
  # 舊版安裝沒有留設定檔，就從現成的 systemd unit 反推——這些值本來就寫在裡面。
  echo "  來源： 既有 systemd unit（這台是舊版安裝的，沒有 install.conf）"
  API_PORT="$(grep -oE '\-\-port +[0-9]+' "$API_UNIT" 2>/dev/null | grep -oE '[0-9]+' | head -1)"
  WEB_PORT="$(grep -oE '^Environment=PORT=[0-9]+' "$WEB_UNIT" 2>/dev/null | grep -oE '[0-9]+' | head -1)"
  API_HOST="$(grep -oE 'NUXT_PUBLIC_API_BASE=https?://[^:]+' "$WEB_UNIT" 2>/dev/null | sed 's|.*//||' | head -1)"
  SVC_USER="$(grep -oE '^User=.+' "$API_UNIT" 2>/dev/null | cut -d= -f2 | head -1)"
  NODE_BIN="$(grep -oE '^ExecStart=[^ ]+' "$WEB_UNIT" 2>/dev/null | cut -d= -f2 | head -1)"
fi
API_PORT="${API_PORT:-8000}"; WEB_PORT="${WEB_PORT:-3000}"
SVC_USER="${SVC_USER:-$OWNER}"; API_HOST="${API_HOST:-127.0.0.1}"
[ -n "${NODE_BIN:-}" ] || { [ -x "$RUNTIME/node/bin/node" ] && NODE_BIN="$RUNTIME/node/bin/node" || NODE_BIN=/usr/bin/node; }
[ -n "${PYTHON311:-}" ] || { [ -x "$RUNTIME/python311/bin/python3" ] && PYTHON311="$RUNTIME/python311/bin/python3" || PYTHON311=python3.11; }
echo "  位址 $API_HOST ｜ 後端埠 $API_PORT ｜ 前端埠 $WEB_PORT ｜ 帳號 $SVC_USER"

# 先把自己的服務停掉，再看埠有沒有被佔 —— 這樣才分得出
# 「本來就是自己佔著」（正常）跟「被別的程式佔走」（會讓後端永遠起不來）。
systemctl stop webit3-api webit3-web 2>/dev/null
sleep 1
if ss -tln 2>/dev/null | grep -qE "[:.]${API_PORT}[[:space:]]"; then
  echo
  echo "  ⚠ 後端埠 $API_PORT 被別的程式佔用（已先停掉本系統服務，仍被佔）："
  ss -tlnp 2>/dev/null | grep -E "[:.]${API_PORT}[[:space:]]" | sed 's/^/      /'
  echo "    不換埠的話，後端會一直起不來（Errno 98 address already in use）。"
  if [ -t 0 ]; then
    read -rp "  輸入新的後端埠，直接 Enter 沿用 $API_PORT： " NEWPORT
    [ -n "$NEWPORT" ] && API_PORT="$NEWPORT" && echo "  → 改用 $API_PORT"
  else
    echo "    （非互動模式，維持 $API_PORT；要換請用： sudo API_PORT=8010 bash patch.sh）"
  fi
else
  echo "  ✓ 後端埠 $API_PORT 可用"
fi

# ===== 5. 重新部署並驗證 =====
echo
echo "[5/5] 重新部署（套用設定、重寫 systemd、重啟）"
if [ -f "$APP/deploy.sh" ]; then
  export API_HOST API_PORT WEB_PORT SVC_USER PYTHON311 NODE_BIN
  bash "$APP/deploy.sh" 2>&1 | sed 's/^/  /'
  DEPLOY_RC=${PIPESTATUS[0]}
else
  echo "  !! 找不到 $APP/deploy.sh，退回只重啟服務"
  systemctl daemon-reload 2>/dev/null
  systemctl restart webit3-api webit3-web 2>/dev/null
  DEPLOY_RC=0
fi

sleep 2
OK=1
for svc in webit3-api webit3-web; do
  if systemctl is-active --quiet "$svc"; then
    echo "  ✓ $svc active"
  else
    echo "  ✗ $svc 沒起來"
    journalctl -u "$svc" -n 25 --no-pager 2>/dev/null | tail -15
    OK=0
  fi
done

# 設定留檔，下次 patch 直接沿用，不必再從 unit 反推。
mkdir -p "$DATA"
cat > "$CONF" <<CONFEOF
API_HOST=$API_HOST
API_PORT=$API_PORT
WEB_PORT=$WEB_PORT
SVC_USER=$SVC_USER
PYTHON311=$PYTHON311
NODE_BIN=$NODE_BIN
CONFEOF
chown "$SVC_USER:$SVC_USER" "$CONF" 2>/dev/null

echo
echo "════════════════════════════════════════════════"
if [ "$OK" = "1" ] && [ "${DEPLOY_RC:-0}" = "0" ]; then
  echo "✅ patch 完成，服務已在跑"
  echo "   前端： http://$API_HOST:$WEB_PORT"
  echo "   後端： http://$API_HOST:$API_PORT"
  echo "   備份： $BACKUP"
else
  echo "!! 沒有完成 —— 上面的錯誤訊息就是原因"
  echo
  echo "   要還原成套用前的狀態："
  echo "     sudo cp -rp $BACKUP/* $APP/ && sudo systemctl restart webit3-api webit3-web"
  echo
  echo "   查不出來就把整個畫面貼回給 AI。"
fi
echo "════════════════════════════════════════════════"
[ "$OK" = "1" ] && [ "${DEPLOY_RC:-0}" = "0" ]
