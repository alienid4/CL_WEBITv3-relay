"""S5：後端 REST API 層（D29 API優先設計）。

只做資料存取／整合既有模組（db／scanner／comparison_engine），不重複實作比對或掃描邏輯——
這層單純把既有函式包成 HTTP 介面，供 Nuxt3 前端（S7-S9）與之後其他模組重用（D29 note：
系統拓撲模組可直接呼叫這裡的 API 重用資料，不用重新收集）。

sort_by／order 一律經白名單檢查才拼進 SQL ORDER BY，避免使用者輸入直接串進查詢字串。
"""
from __future__ import annotations

import csv
import io
import ipaddress
import json
import os
import re
import socket
import sqlite3
import subprocess
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Iterator

from fastapi import (
    Cookie, Depends, FastAPI, File, Form, Header, HTTPException, Query, Request, Response,
    UploadFile,
)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from openpyxl import Workbook, load_workbook
from pydantic import BaseModel

import contextlib

import activity
import agent_auth
import auth
# 收集器身分（金鑰與自己的位址）集中在這裡解析——五個端點都要用，
# 各自 import 過一次容易漏掉，漏掉的那個就會走回舊的寫死預設值。
import onboard_engine
import backup
import cmdb_gateway
import golive
import scan_service
from db import (
    _now_local,  # 匯出檔名的日期（v1.70.0 起就漏 import，Excel/dump 匯出一律 500）
    create_connection_record,
    get_db_path,
    create_import_log,
    delete_connection_record,
    get_connection,
    get_connection_by_id,
    get_feature_flag,
    get_latest_import_log,
    insert_hardware,
    list_connections,
    list_import_log,
    list_feature_flags,
    mark_comparison_read,
    set_connection_enabled,
    set_feature_flag,
    update_connection_record,
    update_connection_status,
    update_hardware,
)
from excel_import import MAPPING_PATH, SHEET_CONFIG, import_excel, load_mapping

app = FastAPI(title="資產盤點模組 API")

# 本行程的啟動時間：只有真的重啟過才會變，是「新程式碼有沒有生效」最可信的證據。
# （version.json / build_info.json 都是即時讀檔，服務沒重啟時照樣顯示新版，會騙人。）
_PROCESS_STARTED_AT = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# 開發環境前端跑在 3000 埠（Nuxt3預設），可用環境變數 ASSET_API_CORS_ORIGINS 覆蓋（部署到
# 內網IP時就是靠它指定實際來源）。
#
# 預設同時放行 localhost 與 127.0.0.1 兩種寫法：這兩個在瀏覽器眼中是不同的 origin，
# 少放一個就會在開發時撞到 CORS 錯誤，而畫面只會顯示「載入失敗」，很難聯想到是位址寫法問題。
# （本機實測：這台 localhost 先解析到 IPv6 ::1，開發時改用 127.0.0.1 才連得到 dev server，
#  結果就踩到只放行 localhost 的 CORS。）
_DEFAULT_DEV_ORIGINS = "http://localhost:3000,http://127.0.0.1:3000"
_allowed_origins = [
    origin.strip()
    for origin in os.environ.get("ASSET_API_CORS_ORIGINS", _DEFAULT_DEV_ORIGINS).split(",")
    if origin.strip()
]
# 除了上面的明確白名單，再自動放行「內網同主機的前端埠」。
# 為什麼要有：deploy.sh 的 API_HOST 預設是家裡的 YOUR_SERVER_IP，CORS 白名單靠它算。
# 換一台機器部署（例如公司 10.92.198.14）若沒記得設 API_HOST/ASSET_API_CORS_ORIGINS，
# 白名單就對不上實際前端來源——後果是「跨源下載默默被擋、畫面只寫『匯出失敗』」，
# 很難聯想到是 CORS（2026-09-09 公司機器實際踩到，一般 API 走 SSR 同源沒事、唯獨
# 瀏覽器直接下載的匯出被擋）。
# 這條 regex 只放行 RFC1918 私有網段 + localhost 的「前端埠」（預設 3000，可用
# ASSET_API_CORS_WEB_PORT 覆蓋），不放行任何公網來源——內網工具，風險可接受，
# 換掉「換 IP 就靜默壞」這個反覆踩的雷。
_CORS_WEB_PORT = (os.environ.get("ASSET_API_CORS_WEB_PORT", "3000").strip() or "3000")
_allowed_origin_regex = (
    r"^http://(?:localhost|127\.0\.0\.1"
    r"|10\.\d{1,3}\.\d{1,3}\.\d{1,3}"
    r"|192\.168\.\d{1,3}\.\d{1,3}"
    r"|172\.(?:1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3})"
    r":" + re.escape(_CORS_WEB_PORT) + r"$"
)
@contextlib.contextmanager
def _middleware_db():
    """Middleware 專用的 DB 連線。

    ⚠️ **不能直接 get_connection()。** middleware 跑在 FastAPI 依賴系統之外，
    直接開連線拿到的是「預設路徑那個 DB」，不是「這個 app 實際在用的 DB」。
    兩者不同時（測試會覆寫 get_db、未來若要一個行程服務多個 DB 也一樣），
    紀錄會被安靜地寫到另一個檔案裡——**功能看起來正常，紀錄卻在別的地方**，
    是那種要出事才會發現的錯。2026-08-26 寫測試時當場踩到。

    所以走跟路由同一條路：有覆寫就用覆寫的，沒有才用預設。
    """
    factory = app.dependency_overrides.get(get_db, get_db)
    gen = factory()
    conn = next(gen)
    try:
        yield conn
    finally:
        gen.close()          # 觸發 get_db 的 finally，由它負責 close


@app.middleware("http")
async def _activity_log_middleware(request: Request, call_next):
    """記錄會改東西的請求（非 GET）。

    為什麼用 middleware 而不是跟心跳一樣掛 require_auth：**要記結果**。
    依賴在路由執行「之前」跑，拿不到狀態碼；而「誰試了什麼但失敗了」正是
    稽核最想看的一種（403/409/500 都要留）。

    為什麼只記非 GET：GET 佔九成以上流量而稽核價值低，全記會讓這張表一天長
    好幾萬列，真正要查「誰改了這台」的時候反而被淹掉。讀取類真的要留痕的地方
    已經各自有專屬表（doc_download_audit／credential_use_audit）。

    ⚠️ 不讀也不記 request body：body 裡可能有密碼與真實資料，複製一份進另一張表
    只是多開一個外洩面。而且讀了 body 會把 stream 吃掉，後面的路由就收不到了。
    """
    import time

    if request.method == "GET" or not request.url.path.startswith("/api/"):
        return await call_next(request)

    t0 = time.perf_counter()
    response = await call_next(request)
    took = int((time.perf_counter() - t0) * 1000)

    # 登入相關由各自的端點記（那裡才知道是誰、成功還失敗），這裡不要重複記一次
    if request.url.path in ("/api/auth/login", "/api/auth/logout"):
        return response

    try:
        with _middleware_db() as conn:
            session = auth.resolve_session(conn, request.cookies.get(auth.SESSION_COOKIE_NAME))
            activity.log(
                conn,
                username=session["username"] if session else None,
                ip=activity.client_ip(request),
                method=request.method,
                path=request.url.path,
                status=response.status_code,
                duration_ms=took,
            )
    except Exception:  # noqa: BLE001 - 記錄失敗不可以影響請求本身
        pass
    return response


@app.middleware("http")
async def _unhandled_error_as_json(request: Request, call_next):
    """未預期的例外一律回 JSON 500，而且**放在 CORS 內側**。

    2026-09-14 公司機按匯出失敗，瀏覽器只顯示「被 CORS 擋掉」：Starlette 對未處理例外的
    500 是在最外層產生的，**不經過 CORSMiddleware**，回應沒有 Access-Control-Allow-Origin，
    前端連錯誤內容都讀不到——真正的錯被 CORS 訊息蓋掉，人只能猜。
    這裡在 CORS 內側接住，回錯誤型別與訊息，畫面 toast 才講得出是什麼錯；
    完整 traceback 照印到服務日誌。

    註冊順序有意義：必須寫在 add_middleware(CORSMiddleware) **之前**（後加的在外層）。
    """
    try:
        return await call_next(request)
    except Exception as exc:  # noqa: BLE001 - 就是要接住所有沒被處理的例外
        import traceback

        traceback.print_exc()
        return JSONResponse(status_code=500,
                            content={"detail": f"伺服器錯誤：{type(exc).__name__}: {exc}"[:500]})


app.add_middleware(
    CORSMiddleware,
    allow_origins=_allowed_origins,
    allow_origin_regex=_allowed_origin_regex,  # 內網同主機前端埠自動放行（見上方註解）
    allow_credentials=True,  # 帶cookie（session_token）必須開這個，前端fetch才要用credentials:"include"
    allow_methods=["*"],
    allow_headers=["*"],
)

FIELD_GROUPS_PATH = Path(__file__).parent / "field_groups.json"

ALLOWED_ASSET_SORT = {
    "hostname", "ip", "device_model", "rack_no", "group_name", "api_id",
    "asset_purpose", "custodian", "usage_unit", "asset_status", "environment",
    "asset_serial",
}
ALLOWED_ISSUE_SORT = {"detected_at", "hostname", "issue_type", "is_read"}
ALLOWED_PERSONNEL_SORT = {
    "person_name", "phone", "job_desc", "belong_division", "belong_department",
    "asset_serial",
}
ALLOWED_SOFTWARE_SORT = {
    "asset_name", "hostname", "ip", "db_software", "backup_frequency", "cloud",
    "custodian", "asset_serial",
}


def get_db() -> Iterator[sqlite3.Connection]:
    conn = get_connection()
    try:
        yield conn
    finally:
        conn.close()


#: 測試階段整個關掉登入的開關（使用者 2026-09-10：「我現在測試階段，用不到登入」）。
#:
#: ⚠️ 開著 = **沒有存取控制**。任何連得到這個埠的人都能撈走全部資產與人員姓名電話。
#: 在金融業這是稽核會直接開缺失的項目，所以設計上刻意麻煩：
#:   · **預設關閉**
#:   · 只能從伺服器端打開（環境變數 `WEBIT3_DISABLE_AUTH=1`，或已登入的人在系統設定裡開）
#:   · 開著時 `/api/version` 會回 `auth_disabled: true`，前端掛一條永遠在的紅色橫幅
#:   · `deploy.sh`／`patch.sh` 不會自動打開
#:
#: 為什麼不做成登入頁上一顆按鈕：那等於「未登入的人自己就能關掉登入」，
#: 那不是開關，那是後門。
AUTH_DISABLED_ENV = "WEBIT3_DISABLE_AUTH"
AUTH_DISABLED_SETTING = "auth_disabled"


def auth_disabled(conn: sqlite3.Connection | None = None) -> bool:
    """登入是不是被關掉了。環境變數優先，其次看系統設定。"""
    if os.environ.get(AUTH_DISABLED_ENV, "").strip() in ("1", "true", "TRUE", "yes"):
        return True
    if conn is None:
        return False
    try:
        row = conn.execute(
            "SELECT value FROM app_settings WHERE key = ?", (AUTH_DISABLED_SETTING,)).fetchone()
    except sqlite3.Error:
        return False
    return bool(row) and str(row["value"]).strip() in ("1", "true", "yes")


def _anonymous_session() -> dict:
    """登入關掉時給的假 session。

    使用者名稱刻意寫成看得懂的字而不是 admin——操作紀錄裡要一眼看得出
    「這筆是在沒有登入的狀態下做的」，事後查稽核軌跡才不會以為真的有人登入過。
    """
    return {"id": 0, "username": "(未登入·登入已停用)", "user_id": 0}


def require_auth(
    request: Request,
    session_token: str | None = Cookie(default=None),
    conn: sqlite3.Connection = Depends(get_db),
) -> sqlite3.Row:
    """要保護一支端點，在路由函式簽章加上 Depends(require_auth) 即可。

    現況：除了 login／logout／version 這三支（見 test_auth_coverage.PUBLIC 白名單），
    所有 /api 端點都掛了這個依賴。

    歷史教訓：S6 當初只用它保護 /api/auth/me，其餘端點「不在這個切片範圍」而留待後續，
    結果一直沒補——前端每頁都有登入守衛，看起來很安全，但 API 全裸長達數個切片，
    任何碰得到後端埠的人都能撈走全部資產與人員姓名電話，或 PUT 改欄位對應。
    現已全數補上，並由 tests/asset_module/test_auth_coverage.py 自動涵蓋新端點防止再退化。
    新增路由請預設掛上；真要公開必須明確加進該白名單。
    """
    session = auth.resolve_session(conn, session_token)
    if session is None:
        # 測試階段可以整個關掉登入（使用者 2026-09-10：「我現在測試階段，用不到登入」）。
        #
        # ⚠️ 這是**關掉存取控制**，不是介面調整：開著的時候，任何連得到這個埠的人
        # 都能撈走全部資產與人員姓名電話。所以：
        #   · 預設關閉，只能由**伺服器端**打開（環境變數／系統設定），
        #     不是畫面上一顆按鈕——按鈕會變成「未登入的人自己就能關掉登入」
        #   · 開著時 /api/version 回 auth_disabled=true，畫面掛一條永遠在的橫幅，
        #     避免哪天忘記關
        #   · deploy.sh／patch.sh 都不會自動打開它
        if auth_disabled(conn):
            return _anonymous_session()
        raise HTTPException(401, "未登入或登入已過期")
    # 「誰在線上」的心跳。掛在這裡是因為它是**唯一保證覆蓋所有端點**的地方
    # （test_auth_coverage.py 會檢查每支新端點都掛了 require_auth）；掛在別處，
    # 新頁面漏記時不會有任何測試變紅，等到要查的時候才發現那段時間是空白的。
    # 內建 60 秒節流，不是每個 request 都寫 DB（見 activity.touch_session）。
    #
    # 整段吞例外：心跳是附加資訊，為了它讓一支正常的 API 回 500 是本末倒置。
    try:
        activity.touch_session(conn, session, request)
    except Exception:  # noqa: BLE001 - 心跳失敗不可以影響請求本身
        pass
    return session


def require_host_key(
    x_agent_key: str | None = Header(default=None),
    conn: sqlite3.Connection = Depends(get_db),
) -> str:
    """Push agent 端點專用的驗證——跟 require_auth（人的 session cookie）是不同層級，
    這裡驗的是「機器」用 header 帶的一次性核發 key。回傳驗證出的 asset_serial，
    路由函式一定要用這個回傳值，不能信任 request body 裡任何自稱的主機識別欄位
    （否則 agent 就能冒充寫別台的資料，見 agent_auth.resolve_host_key 的說明）。
    """
    asset_serial = agent_auth.resolve_host_key(conn, x_agent_key)
    if asset_serial is None:
        raise HTTPException(401, "agent key 缺失、無效或已撤銷")
    return asset_serial


class MarkReadBody(BaseModel):
    is_read: bool = True


class LoginBody(BaseModel):
    username: str
    password: str


@app.post("/api/auth/login")
def login(body: LoginBody, request: Request, response: Response,
          conn: sqlite3.Connection = Depends(get_db)):
    user = auth.authenticate(conn, body.username, body.password)
    if user is None:
        # 帳號不存在／密碼錯誤都回同一句話，不透露「帳號不存在」讓人拿去枚舉帳號
        #
        # 但**紀錄要記下他打的帳號**：連續對同一個帳號試錯是要看得出來的訊號。
        # 對外不透露 ≠ 對內不記錄，這兩件事不衝突。
        _log_auth(conn, request, body.username, "login_failed", 401)
        raise HTTPException(401, "帳號或密碼錯誤")
    token, _expires_at = auth.issue_session(conn, user["id"])
    _log_auth(conn, request, user["username"], "login", 200)
    response.set_cookie(
        key=auth.SESSION_COOKIE_NAME,
        value=token,
        httponly=True,
        samesite="lax",
        secure=False,  # 部署目標是內網IP走http（D11/D18已定案的內網簡化精神），改https要記得打開
        max_age=int(auth.SESSION_TTL.total_seconds()),
    )
    return {"username": user["username"]}


def _log_auth(conn: sqlite3.Connection, request: Request, username: str | None,
              action: str, status: int) -> None:
    """登入相關事件的紀錄。這幾支不走 middleware 的一般路徑（見那裡的說明），
    因為只有端點自己知道「是誰」以及「成功還是失敗」。"""
    try:
        activity.log(conn, username=username, ip=activity.client_ip(request),
                     method=request.method, path=request.url.path,
                     status=status, action=action)
    except Exception:  # noqa: BLE001 - 記錄失敗不可以擋住登入
        pass


@app.post("/api/auth/logout")
def logout(
    request: Request,
    response: Response,
    session_token: str | None = Cookie(default=None),
    conn: sqlite3.Connection = Depends(get_db),
):
    if session_token:
        from db import delete_session

        who = auth.resolve_session(conn, session_token)
        _log_auth(conn, request, who["username"] if who else None, "logout", 200)
        delete_session(conn, session_token)
    response.delete_cookie(auth.SESSION_COOKIE_NAME)
    return {"ok": True}


@app.get("/api/auth/me")
def me(session: sqlite3.Row = Depends(require_auth)):
    return {"username": session["username"]}


# ===== 在線人數與操作紀錄 =====
# 2026-08-26 使用者要求：「在左上角顯示在線人數，我要知道誰在用，LOG 紀錄也要」。
# 定義與取捨全部寫在 activity.py 檔頭，這裡只是薄 HTTP 層。

@app.get("/api/online")
def online_endpoint(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    return activity.online_users(conn)


@app.get("/api/activity")
def activity_list_endpoint(
    username: str | None = None,
    action: str | None = None,
    since: str | None = None,
    limit: int = 200,
    offset: int = 0,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    return activity.list_log(conn, username=username, action=action, since=since,
                             limit=limit, offset=offset)


@app.get("/api/activity/summary")
def activity_summary_endpoint(
    days: int = 7,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    if not 1 <= days <= 365:
        raise HTTPException(400, f"days 只接受 1~365，收到 {days}")
    return activity.log_summary(conn, days)


# ===== CIA(登記) × 掃描 的比對：儀表板磚塊與各個下鑽清單共用同一套判定 =====
# 儀表板每個數字都可以點進去看細項，所以「數字」跟「清單」必須用同一段邏輯算，
# 否則點進去筆數對不上，比不能點還糟。

def _latest_scan_time(conn: sqlite3.Connection) -> str | None:
    row = conn.execute("SELECT MAX(scan_time) AS t FROM scan_history").fetchone()
    return row["t"] if row else None


def _scanned_alive_rows(conn: sqlite3.Connection, scan_time: str | None) -> list[sqlite3.Row]:
    """最新一次掃描中「掃得到（存活）」的主機。scan_ok=0 是網段掃描失敗，不是主機死掉。"""
    if not scan_time:
        return []
    return conn.execute(
        "SELECT * FROM scan_history WHERE scan_time = ? AND scan_ok = 1", (scan_time,)
    ).fetchall()


def _scan_keys(scanned_rows: list[sqlite3.Row]) -> tuple[set[str], set[str]]:
    return (
        {r["ip"] for r in scanned_rows if r["ip"]},
        {r["hostname"] for r in scanned_rows if r["hostname"]},
    )


def _row_in_keys(row, ips: set[str], hostnames: set[str]) -> bool:
    """IP 或主機名稱任一對得上就算同一台（沿用 /api/scan/unregistered 既有的判定方式）。"""
    return bool(
        (row["ip"] and row["ip"] in ips) or (row["hostname"] and row["hostname"] in hostnames)
    )


def _check_sort(sort_by: str, order: str, allowed: set[str]) -> None:
    if sort_by not in allowed:
        raise HTTPException(400, f"不支援的排序欄位：{sort_by}")
    if order not in ("asc", "desc"):
        raise HTTPException(400, "order 只接受 asc 或 desc")


_COLUMN_CACHE: dict[str, set[str]] = {}


def _sortable_columns(conn: sqlite3.Connection, table: str) -> set[str]:
    """回傳該資料表**實際存在的欄位名**當排序白名單。

    為什麼不寫死一份清單：使用者的鐵則是「表格每一欄都要能排」，而畫面上的欄位
    是由 field_groups/field_meta 動態決定的（含數十個進階欄位）。寫死的白名單只涵蓋
    12 欄，點到其他欄就回 400、畫面顯示「資產資料載入失敗」——比不能排更糟。

    安全性不變：來源是 PRAGMA 的真實欄位名，使用者輸入只能「命中或不命中」，
    永遠不會有自由字串被拼進 ORDER BY。新增欄位也自動涵蓋，不用記得回來改。
    """
    if table not in _COLUMN_CACHE:
        _COLUMN_CACHE[table] = {
            r[1] for r in conn.execute(f"PRAGMA table_info({table})")
        }
    return _COLUMN_CACHE[table]


# D25：儀表板環境篩選預設「正式」，可切換包含測試/備援。HTML Mock v4三段式選單，
# key用ASCII"+"避免query string編碼問題，None代表不篩選（=全部含備援）。
ENV_FILTER_PRESETS: dict[str, list[str] | None] = {
    "正式": ["正式"],
    "正式+測試": ["正式", "測試"],
    "全部": None,
}


@app.get("/api/dashboard/stats")
def dashboard_stats(
    environment: str = "正式",
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """D25：環境篩選預設「正式」。重疊圖三區塊：僅CIA登記／重疊／僅掃描到（=漏登記候選）。"""
    if environment not in ENV_FILTER_PRESETS:
        raise HTTPException(400, f"不支援的環境篩選：{environment}")
    env_list = ENV_FILTER_PRESETS[environment]

    # 選環境時的「登記」範圍，要跟下面 total_* 同一套：**排除退役＋帳外**。
    # 2026-09-18 十項盤點第 4 條：以前這裡撈整張表，221 上「正式環境一致 1」＞「全部一致 0」
    # ——子集比全體大。那 1 台是 221 自己的 AUTO- 帳外登記：選環境時算進去、總數沒算。
    # v1.208 只把 total_* 改成排退役＋帳外，這半邊漏了。
    import manage_state as _ms0
    import system_report as _sr0
    if env_list is None:
        _env_rows = conn.execute(
            "SELECT ip, hostname, asset_serial, asset_status FROM hardware").fetchall()
    else:
        placeholders = ",".join("?" for _ in env_list)
        _env_rows = conn.execute(
            f"SELECT ip, hostname, asset_serial, asset_status FROM hardware WHERE environment IN ({placeholders})",
            env_list,
        ).fetchall()
    ica_rows = [r for r in _env_rows
                if (r["asset_status"] or "").strip() not in _ms0.RETIRED_STATUS
                and not str(r["asset_serial"] or "").startswith(_sr0.OFF_BOOK_PREFIXES)]
    ica_ips = {r["ip"] for r in ica_rows if r["ip"]}
    ica_hostnames = {r["hostname"] for r in ica_rows if r["hostname"]}

    last_scan_time = _latest_scan_time(conn)
    scanned_rows = _scanned_alive_rows(conn, last_scan_time)
    failed_segments: list[str] = []
    if last_scan_time:
        failed_segments = [
            r["segment"]
            for r in conn.execute(
                "SELECT DISTINCT segment FROM scan_history WHERE scan_time = ? AND scan_ok = 0",
                (last_scan_time,),
            ).fetchall()
        ]

    scan_ips, scan_hostnames = _scan_keys(scanned_rows)

    # 「相符」從**資產側**數：有幾台登記的資產這次掃得到。
    # 原本是從掃描側數（幾筆掃描結果對得上 CIA），再用 ica_count - overlap 反推「登記卻掃不到」——
    # 一旦一台資產被多筆掃描結果對到（同機多 IP／IP 與主機名分別命中），那個減法就會少算甚至變負數。
    # 現在每個數字都可以點進去看清單，磚塊上的數字必須跟清單筆數一致，所以改成各自獨立算：
    #   overlap   = 登記且掃得到（資產側）      -> /assets?scan_status=overlap
    #   ica_only  = 登記但掃不到（資產側）      -> /assets?scan_status=ica_only
    #   scan_only = 掃到但沒登記（掃描側）      -> /adopt（與 /api/scan/unregistered 同一套判定）
    overlap_count = sum(1 for r in ica_rows if _row_in_keys(r, scan_ips, scan_hostnames))
    ica_only_count = len(ica_rows) - overlap_count

    # ⚠️ scan_only 要對「全部」資產比，不能只對環境篩選後的子集：
    # 「掃到卻沒登記」的意思是「這台機器在網路上，但整個資產清單裡都沒有它」。
    # 一台登記為「測試」環境的機器是有登記的，只是不屬於目前檢視的環境——
    # 拿環境子集去比，會把它算成未登記，磚塊顯示 4 但點進去的 /adopt（不分環境）只有 3。
    # 數字對不上的下鑽比不能點更糟，實測踩到過。
    # ⚠️「未登記」偵測要對「全部」登記（含退役／帳外）比：一個掃到的 IP 只要在 hardware
    # 裡出現過（哪怕是退役或帳外那筆），就不算「資產庫查無此機」。所以這裡故意用廣義集。
    all_ica_rows = conn.execute("SELECT ip, hostname FROM hardware").fetchall()
    all_ica_ips = {r["ip"] for r in all_ica_rows if r["ip"]}
    all_ica_hostnames = {r["hostname"] for r in all_ica_rows if r["hostname"]}
    scan_only_count = sum(
        1 for r in scanned_rows if not _row_in_keys(r, all_ica_ips, all_ica_hostnames)
    )

    # 對帳「一致／搜不到」的「登記」universe 必須跟頭條「在管」同一套口徑：
    # **排除退役（停用/報廢/閒置）＋帳外（DYN-/VC-/AUTO-）**。否則「搜不到＝登記總數−一致」
    # 會把退役機（本來就不該回應）和帳外算進去，導致「搜不到」比「在管」還大——
    # 2026-09-17 使用者在公司機看到「搜不到 7823 > 在管 3768」，就是這個 bug。
    # 這樣 一致 + 搜不到 = 在管（registered_total），加總對得起頭條。
    import manage_state as _ms
    import system_report as _sr
    reg_rows = [
        r for r in conn.execute(
            "SELECT ip, hostname, asset_serial, asset_status FROM hardware").fetchall()
        if (r["asset_status"] or "").strip() not in _ms.RETIRED_STATUS
        and not str(r["asset_serial"] or "").startswith(_sr.OFF_BOOK_PREFIXES)
    ]
    total_ica_registered = len(reg_rows)
    total_overlap_count = sum(
        1 for r in reg_rows if _row_in_keys(r, scan_ips, scan_hostnames)
    )

    issue_counts = {"異常新增": 0, "異常消失": 0, "漏登記": 0}
    for row in conn.execute(
        "SELECT issue_type, COUNT(*) AS c FROM comparison_result WHERE is_read = 0 GROUP BY issue_type"
    ).fetchall():
        issue_counts[row["issue_type"]] = row["c"]

    return {
        "environment": environment,
        "ica_count": len(ica_rows),
        "scanned_count": len(scanned_rows),
        "overlap_count": overlap_count,
        "ica_only_count": ica_only_count,
        "scan_only_count": scan_only_count,
        # 一致率／對帳用這兩個（全站、不隨環境變動、排退役＋帳外＝跟頭條「在管」同口徑），
        # 別拿上面那組環境篩選過的去算
        "total_ica_count": total_ica_registered,
        "total_overlap_count": total_overlap_count,
        "last_scan_time": last_scan_time,
        "last_scan_ok": len(failed_segments) == 0,
        "failed_segments": failed_segments,
        "issue_counts": issue_counts,
    }


@app.get("/api/issues")
def list_issues(
    issue_type: str | None = None,
    is_read: bool | None = None,
    sort_by: str = "detected_at",
    order: str = "desc",
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    _check_sort(sort_by, order, ALLOWED_ISSUE_SORT)

    query = "SELECT * FROM comparison_result WHERE 1=1"
    params: list = []
    if issue_type is not None:
        query += " AND issue_type = ?"
        params.append(issue_type)
    if is_read is not None:
        query += " AND is_read = ?"
        params.append(int(is_read))
    query += f" ORDER BY {sort_by} {order.upper()}"

    rows = conn.execute(query, params).fetchall()
    return [dict(r) for r in rows]


class MarkReadBatchBody(BaseModel):
    ids: list[int]


@app.post("/api/issues/mark-read")
def mark_issues_read_batch(
    body: MarkReadBatchBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """批次標記已處理（失聯會越積越多，逐筆點很慢；2026-09-19）。回實際標到的筆數。"""
    ids = [int(i) for i in body.ids if isinstance(i, int) or str(i).isdigit()]
    if not ids:
        return {"marked": 0}
    marked = 0
    for iid in ids:
        if conn.execute("SELECT 1 FROM comparison_result WHERE id = ?", (iid,)).fetchone():
            mark_comparison_read(conn, iid)
            marked += 1
    return {"marked": marked}


@app.patch("/api/issues/{issue_id}")
def mark_issue_read(
    issue_id: int,
    body: MarkReadBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """標記已處理（契約已定案功能）。目前只支援標記為已讀，不支援改回未讀。"""
    if not body.is_read:
        raise HTTPException(400, "目前只支援標記已處理（is_read=true）")
    existing = conn.execute(
        "SELECT id FROM comparison_result WHERE id = ?", (issue_id,)
    ).fetchone()
    if existing is None:
        raise HTTPException(404, "查無此問題紀錄")
    mark_comparison_read(conn, issue_id)
    row = conn.execute("SELECT * FROM comparison_result WHERE id = ?", (issue_id,)).fetchone()
    return dict(row)


@app.get("/api/assets/field-groups")
def asset_field_groups(session: sqlite3.Row = Depends(require_auth)):
    """D31精神延伸：常用/進階分層來自設定檔，前端不用自己硬編欄位清單。"""
    return json.loads(FIELD_GROUPS_PATH.read_text(encoding="utf-8"))


# ⚠️ 這支一定要定義在 /api/assets/{asset_serial} 之前。
# FastAPI 依「定義順序」比對路由，先中先贏：放在參數路由後面的話，
# /api/assets/facets 會被當成「查詢序號叫 facets 的資產」而回 404，
# 前端拿不到數字又被 catch 吞掉，畫面只是靜靜地少了數字，很難查。
# （2026-07-29 實際踩到，篩選按鈕的台數一直不出現就是這個原因。）
@app.get("/api/assets/facets")
def asset_facets(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    """各平台／各類型分別有幾台，給篩選按鈕直接標在上面。

    沒有數字的話，使用者得一個一個點進去才知道哪個分類有東西、哪個是空的。

    刻意跟 list_assets 共用 asset_classify：兩邊若各算各的，按鈕上寫「5 台」
    點進去卻是 3 筆，比不顯示數字更糟。

    注意角色是多值的（一台同時聽 3306 和 80 就既是資料庫也是 Web），
    所以類型的數字加總會大於資產總數 —— 那是實情，不是重複計算的 bug。
    """
    import asset_classify

    import pipeline

    cls = asset_classify.classify_all(conn)
    by_platform: dict[str, int] = {}
    by_os: dict[str, int] = {}
    by_detail: dict[str, int] = {}
    by_role: dict[str, int] = {}
    for info in cls.values():
        p = info.get("platform") or "未知"
        by_platform[p] = by_platform.get(p, 0) + 1
        o = info.get("os_type") or pipeline.OS_UNSET
        by_os[o] = by_os.get(o, 0) + 1
        if info.get("os_detail"):
            by_detail[info["os_detail"]] = by_detail.get(info["os_detail"], 0) + 1
        for r in info.get("roles") or ["unknown"]:
            by_role[r] = by_role.get(r, 0) + 1
    # os_type／os_detail：兩層（2026-09-18，跟漏斗同一套）；platform 保留給舊連結相容
    return {"os_type": by_os, "os_order": list(pipeline.OS_ORDER),
            "os_detail": by_detail, "os_detail_order": list(asset_classify.LINUX_DETAILS),
            "platform": by_platform, "role": by_role, "total": len(cls)}


def _dismissed_keys(conn: sqlite3.Connection) -> set[tuple[str, str]]:
    """人工標記過「這組不是重複」的 (hostname, ip) key 集合。"""
    return {
        (r["hostname"], r["ip"])
        for r in conn.execute("SELECT hostname, ip FROM duplicate_dismiss").fetchall()
    }


def _duplicate_groups(conn: sqlite3.Connection) -> list[dict]:
    """找出「主機名稱與 IP 都一樣」的多筆資產——幾乎可以確定是同一台被登記了兩次。

    只認兩者都相同，是刻意保守：
      · 只有 IP 相同 → 可能是 DHCP 回收後給了別台，或真的位址衝突，都不是重複登記。
      · 只有主機名相同 → 可能是同一台換過網段，那是搬遷不是重複。
    誤報一筆重複，使用者就得花時間去比對兩台到底哪裡不一樣，寧可少報也不要亂報。

    比對時去空白、主機名不分大小寫：Excel 匯入常常帶進尾端空白或大小寫不一致，
    那種「看起來一模一樣卻被當成兩台」正是最該抓出來的情況。

    停用/報廢/閒置＝退役資產排除在外：不然「停用舊料＋使用中新料同IP」會被誤判成重複登記，
    使用者得花時間去比對兩台根本不是同一回事（見 manage_state.RETIRED_STATUS）。

    人工標記過「這組不是重複」（`duplicate_dismiss`）的組別也排除在外——使用者比機器更清楚
    哪些是同一台合法掛多個業務系統/VIP，不該每次都再跳出來煩他。

    抽成獨立函式讓 release/dismiss 兩個動作也能重跑同一份判準，在伺服器端重新驗證
    使用者操作當下這組資料是不是還跟畫面上看到的一樣（不信任前端傳來的舊快照）。
    """
    import manage_state as ms
    import vip_view

    retired_placeholders = ",".join("?" for _ in ms.RETIRED_STATUS)
    # ⚠️ ip='0.0.0.0' 是「沒有真 IP」的佔位，不能當成「同一台」的依據——兩台不同的交換器
    # 都填 0.0.0.0 不是重複（2026-09-17 抓到兩台 Cisco WS-C2960G 被誤列成重複組）。
    # [B-03] 分組直接呼叫 system_stats.machine_key（含網域處理、0.0.0.0 各算一台）。
    # 以前是 SQL `GROUP BY lower(hostname), ip`——驗收腳本只查原始碼有沒有「machine_key」字樣，
    # 被註解騙過判 PASS，實際邏輯是另一套（帶網域與不帶網域的同一台不會被列成重複）。
    import system_stats
    live = [dict(r) for r in conn.execute(
        f"SELECT * FROM hardware WHERE hostname IS NOT NULL AND length(trim(hostname)) > 0 "
        f"AND ip IS NOT NULL AND length(trim(ip)) > 0 AND trim(ip) != '0.0.0.0' "
        f"AND COALESCE(asset_status, '') NOT IN ({retired_placeholders}) ORDER BY asset_serial",
        tuple(ms.RETIRED_STATUS)).fetchall()]
    by_key: dict[str, list[dict]] = {}
    for r in live:
        by_key.setdefault(system_stats.machine_key(r["hostname"], r["ip"], None), []).append(r)
    dismissed = {system_stats.machine_key(h, i, None) for h, i in _dismissed_keys(conn)}
    groups = []
    for key, members in sorted(by_key.items(), key=lambda kv: (-len(kv[1]), kv[0])):
        if len(members) < 2 or key in dismissed:
            continue
        rows = [dict(m) for m in members]
        # 標出這組成員之間「值不一樣」的欄位：若完全一致，刪掉多的那筆即可；
        # 若有差異，就得由人判斷該留哪一筆，不能盲目合併。
        diff_fields = []
        for col in rows[0].keys():
            if col in ("id", "asset_serial", "created_at", "updated_at"):
                continue
            if col == "big_ip_vip":
                # 「無」跟空白是同一件事，不算欄位不同
                vals = {vip_view.normalize_vip(r.get(col)) for r in rows}
            else:
                vals = {("" if r.get(col) is None else str(r.get(col)).strip()) for r in rows}
            if len(vals) > 1:
                diff_fields.append(col)
        # 分三類（2026-09-14）：CIA 清冊是「每個服務／VIP 一筆」，同主機同 IP 多筆
        # 大多是一台掛多系統／多 VIP，不是重複。只有「疑似真重複」才給可少筆數。
        cls = vip_view.classify_duplicate_group(rows)
        groups.append({
            "hostname": rows[0].get("hostname"),
            "ip": rows[0].get("ip"),
            "count": len(rows),
            "identical": not diff_fields,
            "diff_fields": diff_fields,
            "kind": cls["kind"],
            "kind_label": cls["kind_label"],
            "extra_rows": cls["extra_rows"],
            "systems": cls["systems"],
            "vips": cls["vips"],
            # 給人工管理介面逐欄比較用：完整欄位，不截斷。
            "members": rows,
        })
    return groups


# 同樣必須排在 /api/assets/{asset_serial} 之前，理由見上面 facets 的說明。
@app.get("/api/assets/duplicates")
def asset_duplicates(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    import vip_view

    groups = _duplicate_groups(conn)
    return {
        "groups": groups,
        # 「多出來的筆數」＝真的清乾淨可以少掉幾筆。**只算疑似真重複**——
        # 一機多系統／VIP 分列那幾筆是真實的服務登記，刪了就丟資訊（2026-09-14）。
        "extra_rows": sum(g["extra_rows"] for g in groups),
        "by_kind": {k: sum(1 for g in groups if g["kind"] == k) for k in vip_view.DUP_KIND_ORDER},
        "kind_labels": vip_view.DUP_KIND_LABEL,
    }


class DuplicateReleaseBody(BaseModel):
    hostname: str
    ip: str
    release_serials: list[str]
    note: str | None = None


@app.post("/api/assets/duplicates/release")
def release_duplicate_serials(
    body: DuplicateReleaseBody,
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db),
):
    """人工確認「這幾個序號是同一台被重複登記」，把多出來的序號真正刪掉、還給號碼池。

    序號釋放＝直接刪除該 asset_serial 在 hardware/software/personnel 三張表的資料列
    （後兩張表對 hardware.asset_serial 有外鍵約束，必須先刪才能刪 hardware）。
    這是使用者明確要的語意：不是「報廢/停用」（那是資產生命週期狀態，序號還留在表裡，
    UNIQUE 約束會擋住之後同號的新資產進來），而是讓這個序號值真正空出來可以重用。

    這只是內部管理工具，使用者確認不需要保留刪除稽核記錄，故不做快照。

    伺服器端重新查一次目前這組（hostname, ip）真實的成員，不信任前端傳來的序號清單是不是
    還有效——避免兩個人同時操作、或畫面資料已經過期時誤刪（比照 merge_review 批次合併同樣
    的「不信任前端快照」原則）。
    """
    h, i = body.hostname.strip().lower(), body.ip.strip()
    current = {
        r["asset_serial"] for r in conn.execute(
            "SELECT asset_serial FROM hardware WHERE lower(trim(hostname)) = ? AND trim(ip) = ?",
            (h, i),
        ).fetchall()
    }
    release_set = set(body.release_serials)
    if not release_set:
        raise HTTPException(400, "沒有要釋放的序號")
    missing = release_set - current
    if missing:
        raise HTTPException(400, f"這幾個序號已經不在這組裡了，資料可能已變更，請重新整理：{'、'.join(sorted(missing))}")
    if len(release_set) >= len(current):
        raise HTTPException(400, "釋放後這組至少要保留一筆，不能全部釋放")

    for serial in release_set:
        conn.execute("DELETE FROM software WHERE asset_serial = ?", (serial,))
        conn.execute("DELETE FROM personnel WHERE asset_serial = ?", (serial,))
        conn.execute("DELETE FROM hardware WHERE asset_serial = ?", (serial,))
    conn.commit()
    return {"ok": True, "released": sorted(release_set), "remaining": len(current) - len(release_set)}


class DuplicateDismissBody(BaseModel):
    hostname: str
    ip: str
    note: str | None = None


@app.post("/api/assets/duplicates/dismiss")
def dismiss_duplicate_group(
    body: DuplicateDismissBody,
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db),
):
    """標記「這組（同主機名+IP）其實不是重複登記」，例如 DB 主機本來就會掛多個業務系統/VIP。

    之後 /api/assets/duplicates 不會再列出這組。UNIQUE(hostname, ip) 防止重複點擊堆記錄。
    """
    h, i = body.hostname.strip().lower(), body.ip.strip()
    conn.execute(
        "INSERT OR IGNORE INTO duplicate_dismiss (hostname, ip, note, dismissed_by) "
        "VALUES (?, ?, ?, ?)",
        (h, i, body.note, session["username"]),
    )
    conn.commit()
    return {"ok": True}


def _onboard_block(hw: dict) -> dict | None:
    """這台能不能納管；不能的話回原因。判準跟收集分派／批次納管同一支，畫面不另外猜。

    2026-09-15 使用者看到 SAN switch 詳細頁還掛著「一鍵納管」；2026-09-16 使用者要求
    資產查詢頁每列也要有「一鍵納管」，所以清單頁也用這一支，兩邊不會一個給按一個不給。
    """
    try:
        import onboard_eligibility

        blk = onboard_eligibility.not_onboardable(hw.get("os"), hw.get("hostname"), hw.get("ip"))
        return {"kind": blk[0], "label": blk[1], "reason": blk[2]} if blk else None
    except Exception:  # noqa: BLE001 - 判不出來就照舊顯示，不擋整頁
        return None


@app.get("/api/assets")
def list_assets(
    response: Response,
    environment: str | None = None,
    q: str | None = None,
    scan_status: str | None = None,
    filter_field: str | None = None,
    filter_value: str | None = None,
    virtual: str | None = None,
    platform: str | None = None,
    os_type: str | None = None,
    os_detail: str | None = None,
    role: str | None = None,
    canonical_os: str | None = None,
    canonical_model: str | None = None,
    location_group: str | None = None,
    os_source: str | None = None,
    environment_group: str | None = None,
    collect: str | None = None,
    source: str | None = None,
    sort_by: str = "hostname",
    order: str = "asc",
    limit: int | None = None,
    offset: int = 0,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """scan_status：讓儀表板的「兩邊相符 / 登記卻掃不到」磚塊可以點進來看是哪幾台。
    判定與 /api/dashboard/stats 共用 _row_in_keys，數字才會跟磚塊對得起來。

    environment 這裡吃單一環境值；儀表板用的是 ENV_FILTER_PRESETS（正式／正式+測試／全部），
    前端下鑽時會把 preset 展開成對應的單一環境或不帶此參數。
    """
    import manage_state as _ms
    import system_report as _sr
    # health_rank 不是資料表欄位（體檢是算出來的），SQL 排不了，改在 Python 端排。
    # 但它必須能排——天條：表格每一欄都要能點排序。沒有它，「把要看的機器排到
    # 最上面」就得自己一台一台掃，那這一欄等於白做。
    sort_health = sort_by == "health_rank"
    # 可信度（trust_score）同理：是算出來的分數，不是資料表欄位，改在 Python 端排
    sort_trust = sort_by == "trust_score"
    _check_sort("hostname" if (sort_health or sort_trust) else sort_by, order,
                ALLOWED_ASSET_SORT | _sortable_columns(conn, "hardware"))

    if scan_status is not None and scan_status not in ("overlap", "ica_only"):
        raise HTTPException(400, "scan_status 只接受 overlap（登記且掃得到）或 ica_only（登記但掃不到）")

    if os_source is not None and os_source not in ("facts", "guessed"):
        raise HTTPException(400, "os_source 只接受 facts（機器實際回報）或 guessed（掃描推測）")

    # 納管狀態。「收不到」刻意拆成三種——畫面上都是收不到，但要做的事完全不同：
    #   revoked 是刻意的結果（不要有人跑去「修」一台剛撤銷的機器）
    #   failed  才是待辦
    #   never   是還沒開始，混進 failed 會讓待辦數字灌水
    COLLECT_FILTERS = {
        "ok":      ("collect_ok = 1", ()),
        "revoked": ("collect_ok = 0 AND COALESCE(collect_error,'') LIKE '%取消納管%'", ()),
        "failed":  ("collect_ok = 0 AND COALESCE(collect_error,'') NOT LIKE '%取消納管%'", ()),
        "never":   ("collect_ok IS NULL", ()),
    }
    if collect is not None and collect not in COLLECT_FILTERS:
        raise HTTPException(
            400, "collect 只接受 ok（收得到）、revoked（人主動取消納管）、"
                 "failed（連不上）或 never（從沒試連過）")

    query = "SELECT * FROM hardware WHERE 1=1"
    params: list = []
    # 預設排除退役（停用/報廢/閒置），口徑要跟 composition()/eos_summary() 對得起來——
    # 那兩支頭條數字都已經排除退役，這裡不排除的話，點進來的筆數會比頭條數字多，
    # 使用者會以為算錯了（首頁「看全部有效資產」的連結標題就寫著「不含退役」）。
    # 例外：使用者自己用 filter_field=asset_status 明確要看某個狀態（含退役徽章本身
    # 的「另有 N 台退役」連結），這時候該尊重他要看的就是那個狀態，不能反過來擋掉。
    import manage_state as _manage_state

    if filter_field != "asset_status":
        retired_placeholders = ",".join("?" for _ in _manage_state.RETIRED_STATUS)
        query += f" AND COALESCE(asset_status, '') NOT IN ({retired_placeholders})"
        params.extend(_manage_state.RETIRED_STATUS)
    if collect is not None:
        cond, cond_params = COLLECT_FILTERS[collect]
        query += f" AND {cond}"
        params.extend(cond_params)
    # 來源篩選：registered＝正式登記（排除 DYN-/VC-/AUTO- 帳外前綴）；
    # offbook＝只看帳外（掃到/vCenter 收到、但沒登記在 CIA 上的）。
    # 讓「在管資產（只算登記）」與「另外掃到未登記 N 台」兩個頭條各自點得進正確的清單，
    # 頭條數字＝點進去的筆數（天條：加總與下鑽走同一份口徑）。
    if source == "registered":
        query += f" AND NOT {_sr.off_book_sql()}"
    elif source == "offbook":
        query += f" AND {_sr.off_book_sql()}"
    if environment is not None:
        # 同時吃「單一環境值」與儀表板用的 preset（正式／正式+測試／全部）。
        # 儀表板磚塊要能原封不動把目前的環境選擇帶進下鑽，否則點進來的筆數會跟磚塊對不上。
        if environment in ENV_FILTER_PRESETS:
            env_list = ENV_FILTER_PRESETS[environment]
            if env_list is not None:  # None＝全部，不加條件
                placeholders = ",".join("?" for _ in env_list)
                query += f" AND environment IN ({placeholders})"
                params.extend(env_list)
        else:
            query += " AND environment = ?"
            params.append(environment)
    # .strip()：使用者常從 Excel/終端機複製貼上，尾隨空白會讓搜尋直接 0 筆，
    # 看起來像「查無此主機」，其實只是多了一個空格——這是實測踩到的體感問題。
    if q and q.strip():
        query += " AND (hostname LIKE ? OR ip LIKE ? OR asset_serial LIKE ?)"
        like = f"%{q.strip()}%"
        params.extend([like, like, like])
    # 「同值篩選」：畫面上任何一個類別型的值（設備機型／群組名稱／保管者…）都要能點進來
    # 看「還有誰跟它一樣」。欄位名走真實欄位白名單，值走參數化，不會有字串拼進 SQL。
    if filter_field is not None:
        if filter_field not in _sortable_columns(conn, "hardware"):
            raise HTTPException(400, f"不支援的篩選欄位：{filter_field}")
        if filter_value in (None, ""):
            # 點「空值」也要能看——「哪些機器這欄是空的」本身就是有用的盤點問題
            query += f" AND ({filter_field} IS NULL OR {filter_field} = '')"
        elif filter_field == "asset_status" and "," in filter_value:
            # 多值篩選（如「退役」＝停用,報廢,閒置 三種狀態合看）：逗號分隔當 IN 清單。
            # ⚠️ 只限 asset_status 這種有限列舉值欄位——備註/用途說明這類自由文字欄若
            # 剛好存了含逗號的內容，會被誤拆成多值查詢，完全比對不到，寧可不支援。
            values = [v for v in filter_value.split(",") if v]
            placeholders = ",".join("?" for _ in values)
            query += f" AND {filter_field} IN ({placeholders})"
            params.extend(values)
        else:
            query += f" AND {filter_field} = ?"
            params.append(filter_value)
    # 虛擬／實體篩選：一律走正典 manage_state.is_vm_sql（跟 is_vm_value 同義，含 device_model
    # 「(VM)」標記）。以前這裡自己寫「非空且不是 0/none」，漏了 device_model 標記 → 跟儀表板
    # 差 1,188 台（2026-09-18 實測）。現在同一把尺。
    if virtual in ("yes", "no"):
        vm_true = _ms.is_vm_sql()
        query += f" AND {vm_true}" if virtual == "yes" else f" AND NOT {vm_true}"
    # OS 來源：首頁誠實揭露「幾台是機器自己報的、幾台是掃描猜的」，那兩個數字要能點進來
    # 看是哪幾台。判定必須跟 manage_state.composition() 的 has_real_os 完全同一條規則
    # （非空且不是字面 N/A），否則點進來的筆數會跟首頁對不上——那比不能點更糟。
    if os_source in ("facts", "guessed"):
        has_real_os = "(os IS NOT NULL AND length(trim(os)) > 0 AND UPPER(TRIM(os)) != 'N/A')"
        query += f" AND {has_real_os}" if os_source == "facts" else f" AND NOT {has_real_os}"
    query += f" ORDER BY {'hostname' if (sort_health or sort_trust) else sort_by} {order.upper()}"

    rows = conn.execute(query, params).fetchall()

    if scan_status is not None:
        # 掃描比對用 Python 做而不是塞進 SQL：判定是「IP 或主機名稱任一命中」，
        # 跟 /api/scan/unregistered、儀表板同一套；寫成 SQL 反而會分岔成兩套規則。
        scanned = _scanned_alive_rows(conn, _latest_scan_time(conn))
        ips, hostnames = _scan_keys(scanned)
        want_matched = scan_status == "overlap"
        rows = [r for r in rows if _row_in_keys(r, ips, hostnames) == want_matched]

    # 平台／角色篩選。兩者都在 Python 端做，理由跟 scan_status 一樣：
    # 平台判定是「真 OS > 掃描推測 > 機型」的優先序邏輯，角色來自 host_service 的
    # 監聽埠——都不是 hardware 表上的單一欄位，硬塞進 SQL 會分岔成兩套規則。
    if platform or role or os_type or os_detail:
        import asset_classify

        cls = asset_classify.classify_all(conn)
        if platform:
            wanted = {p.strip() for p in platform.split(",") if p.strip()}
            rows = [r for r in rows if cls.get(r["asset_serial"], {}).get("platform") in wanted]
        # OS 類型（大類）＋ Linux 細分（2026-09-18，跟漏斗同一套）
        if os_type:
            wanted_o = {x.strip() for x in os_type.split(",") if x.strip()}
            rows = [r for r in rows if cls.get(r["asset_serial"], {}).get("os_type") in wanted_o]
        if os_detail:
            wanted_d = {x.strip() for x in os_detail.split(",") if x.strip()}
            rows = [r for r in rows if cls.get(r["asset_serial"], {}).get("os_detail") in wanted_d]
        if role:
            wanted_r = {x.strip() for x in role.split(",") if x.strip()}
            rows = [r for r in rows
                    if wanted_r & set(cls.get(r["asset_serial"], {}).get("roles", ["unknown"]))]

    # 平台下鑽點某個 OS 版本（如「Windows Server 2022」）：跟 platform 同理，
    # 正規化是「原值 → 收斂寫法」的邏輯，不是資料庫裡的單一欄位，只能在這層過濾。
    # 只比對有真 OS 的資產——composition() 的 by_platform_os 對純推測的機器標「未知版本／(推測)」，
    # 那些沒有穩定的原始字串可比對，這裡就不硬篩，維持只看點得到來源的部分。
    if canonical_os:
        import normalize

        rows = [
            r for r in rows
            if r["os"] and normalize.normalize_os(r["os"], conn, r["device_model"])["canonical"] == canonical_os
        ]

    # EOS 頁點某個硬體型號（如「Dell PowerEdge R740」）：跟 canonical_os 同理。
    # ⚠️ 硬體型號分頁的項目其實有兩種不同來源，篩選要兩種都檢查，缺一都會篩到
    # 0 筆（2026-08-13 實際發現，兩個都是這輪才修）：
    # 1. device_model 側：normalize_model() 算出來的——之前漏傳 hint，靠 hint
    #    才解析出來的型號（如「IBM DS3524 SAN Switch」）永遠篩不到自己。
    # 2. os 側被併過來的（HW_ROUTED_PRODUCTS，例：Dell iDRAC (BMC)／Unisphere
    #    Central）：這些 canonical 其實是 normalize_os() 算出來的，不是
    #    normalize_model()，原本的篩選完全沒檢查這條路徑，這類資產點「N台→」
    #    100% 篩到 0 筆，不是個案。
    if canonical_model:
        import normalize

        def _row_matches_hw_canonical(r: sqlite3.Row) -> bool:
            if r["os"]:
                os_info = normalize.normalize_os(r["os"], conn, r["device_model"])
                if os_info["product"] in normalize.HW_ROUTED_PRODUCTS \
                        and os_info["canonical"] == canonical_model:
                    return True
            if r["device_model"]:
                model_info = normalize.normalize_model(r["device_model"], conn, _model_hint(r))
                if model_info["canonical"] == canonical_model:
                    return True
            return False

        rows = [r for r in rows if _row_matches_hw_canonical(r)]

    # 機房分組（板橋／敦南／內湖／分公司）不是資料庫裡存的值，是 location_groups.json
    # 從 physical_location 原值（01_板橋機房…）收斂出來的，所以只能在這層過濾。
    # 儀表板點「板橋 120 台」要能跳進來看是哪 120 台，用 filter_field 精確比對做不到。
    if location_group:
        import manage_state

        rows = [r for r in rows
                if manage_state.group_location(r["physical_location"]) == location_group]

    # 環境別分組同理（UAT/DEV/OA 併進「測試」）。儀表板的機房×環境別交叉表點格子時
    # 一定要用這個而不是 filter_field=environment 精確比對——「測試」那格算的是合併後
    # 的 705 台，精確比對只撈得到原值剛好是「測試」的 695 台。
    # 格子寫 705、點進去列 695，看的人只會認定系統在騙他，這張表就白做了。
    if environment_group:
        import manage_state

        rows = [r for r in rows
                if manage_state.group_environment(r["environment"]) == environment_group]

    # 分頁：不帶 limit 時行為與以前完全相同（回全部、純陣列），既有呼叫端不受影響。
    # 總筆數放在 X-Total-Count 標頭而不是包成 {items, total}：改回應結構會弄壞所有
    # 現有前端；標頭是加法，不是改法。
    import health_check

    health = health_check.evaluate_all(conn) if rows else {}
    if sort_health:
        # 排序權重：紅 > 黃 > 綠 > 沒體檢（退役）。兩個燈取最差的當主鍵，
        # 次鍵用問題數量——同樣紅燈，問題多的先看。
        weight = {"bad": 0, "warn": 1, "ok": 2}

        def hrank(r):
            h = health.get(r["id"])
            if not h:
                return (3, 0, _s_lower(r["hostname"]))
            worst = min(weight[h["machine"]], weight[h["data"]])
            return (worst, -len(h["issues"]), _s_lower(r["hostname"]))

        rows = sorted(rows, key=hrank, reverse=(order.lower() == "desc"))

    # 資料可信度（2026-09-11）：每台有幾個來源互相印證＋有沒有機器證據。規則見 trust_score.py。
    # 退役資產不評分（compute_all 只算非退役），畫面顯示「—」。
    import trust_score

    trust = trust_score.compute_all(conn) if rows else {}
    if sort_trust:
        rows = sorted(
            rows,
            key=lambda r: (trust.get(r["asset_serial"], {}).get("score", -1), _s_lower(r["hostname"])),
            reverse=(order.lower() == "desc"))

    total = len(rows)
    if limit is not None:
        if limit < 1 or limit > 1000:
            raise HTTPException(400, "limit 只接受 1–1000")
        if offset < 0:
            raise HTTPException(400, "offset 不能是負數")
        rows = rows[offset:offset + limit]
    response.headers["X-Total-Count"] = str(total)
    response.headers["Access-Control-Expose-Headers"] = "X-Total-Count"

    # 平台／角色一併回傳（加欄位是加法，不動既有結構）。分類在分頁之後才算，
    # 只算這一頁的那幾十筆，不用為了顯示兩個標籤把全表都跑一遍。
    import asset_classify

    cls = asset_classify.classify_all(conn) if rows else {}
    import onboard_exempt

    _exempt_set = onboard_exempt.active_serials(conn) if rows else set()
    # 同一台的登記筆數（項 10，2026-09-18）：資產查詢是逐筆列，看不出哪些是同一台。
    # 用正典 machine_key 算「這台共登記幾筆」，畫面每列標「同台 N 筆」，跟台詳細頁／主機清單口徑一致。
    # 只算非退役（退役是上一台，不算同台——跟別名一致）。一次撈完，不在迴圈逐台查。
    _mkcount: dict[str, int] = {}
    if rows:
        import system_stats as _ss
        for _hr in conn.execute(
                "SELECT hostname, ip, asset_serial, asset_status FROM hardware"):
            if (_hr["asset_status"] or "").strip() in _ms.RETIRED_STATUS:
                continue
            k = _ss.machine_key(_hr["hostname"], _hr["ip"], _hr["asset_serial"])
            _mkcount[k] = _mkcount.get(k, 0) + 1
    out = []
    for r in rows:
        d = dict(r)
        import system_stats as _ss2
        d["same_host_count"] = _mkcount.get(
            _ss2.machine_key(r["hostname"], r["ip"], r["asset_serial"]), 1)
        c = cls.get(r["asset_serial"], {})
        d["platform"] = c.get("platform", "未知")
        d["os_type"] = c.get("os_type")
        d["os_detail"] = c.get("os_detail")
        d["roles"] = c.get("roles", ["unknown"])
        h = health.get(r["id"])
        # 退役資產不體檢（evaluate_all 直接跳過），所以這裡可能沒有——
        # 沒有就給 None，畫面顯示「—」，不要假裝它是綠的。
        d["health_machine"] = h["machine"] if h else None
        d["health_data"] = h["data"] if h else None
        d["health_headline"] = h["headline"] if h else ""
        d["health_issues"] = h["issues"] if h else []
        # 誠實揭露、不算體檢問題：有沒有被 SSH/WinRM 直接驗證過（2026-08-25 方案A）。
        d["health_verified"] = h["verified"] if h else None
        t = trust.get(r["asset_serial"])
        d["trust_score"] = t["score"] if t else None
        d["trust_sources"] = t["sources"] if t else None      # 有／沒有／None＝不適用
        d["trust_evidence"] = t["evidence"] if t else None    # managed／alive／None
        d["trust_alive_basis"] = t["alive_basis"] if t else None   # scan／dynassets／None
        d["trust_dyn_at"] = t["dynassets_imported_at"] if t else None
        d["trust_kind"] = t["kind"] if t else None
        # 使用者 2026-08-13 要求：「未分類」清單點進來看到的逐台列表，每一台都要
        # 顯示系統推測，不能只在單筆資產詳情頁才有——不然像「N/A」這種大雜燴群組
        # 裡面明明有能猜到的資產，卻被群組彙總層級擋住看不到。
        # 能不能納管：清單頁的「一鍵納管」按鈕要用（2026-09-16）。只算這一頁的幾十筆
        d["onboard_block"] = _onboard_block(d)
        d["onboard_exempt"] = r["asset_serial"] in _exempt_set
        guess_value, guess_kind, guess_confirmed = _identity_guess(r, conn)
        d["identity_guess"] = guess_value
        d["identity_guess_kind"] = guess_kind
        d["identity_guess_confirmed"] = guess_confirmed
        out.append(d)
    return out


class BatchLookupBody(BaseModel):
    terms: list[str]


@app.post("/api/assets/batch-lookup")
def batch_lookup_assets(
    body: BatchLookupBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """值班用批次查詢（貼上多筆主機名稱/IP，一行一筆）：精確比對，不是like模糊搜尋。"""
    terms = [t.strip() for t in body.terms if t.strip()]
    if not terms:
        return []
    placeholders = ",".join("?" for _ in terms)
    rows = conn.execute(
        f"SELECT * FROM hardware WHERE hostname IN ({placeholders}) OR ip IN ({placeholders})",
        terms + terms,
    ).fetchall()
    return [dict(r) for r in rows]


@app.get("/api/personnel")
def list_personnel(
    q: str | None = None,
    sort_by: str = "person_name",
    order: str = "asc",
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    _check_sort(sort_by, order, ALLOWED_PERSONNEL_SORT | _sortable_columns(conn, "personnel"))

    query = "SELECT * FROM personnel WHERE 1=1"
    params: list = []
    if q and q.strip():
        query += " AND (person_name LIKE ? OR asset_serial LIKE ?)"
        like = f"%{q.strip()}%"
        params.extend([like, like])
    query += f" ORDER BY {sort_by} {order.upper()}"

    rows = conn.execute(query, params).fetchall()
    return [dict(r) for r in rows]


@app.get("/api/software")
def list_software(
    q: str | None = None,
    sort_by: str = "asset_name",
    order: str = "asc",
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    _check_sort(sort_by, order, ALLOWED_SOFTWARE_SORT | _sortable_columns(conn, "software"))

    query = "SELECT * FROM software WHERE 1=1"
    params: list = []
    if q and q.strip():
        query += " AND (asset_name LIKE ? OR hostname LIKE ? OR ip LIKE ?)"
        like = f"%{q.strip()}%"
        params.extend([like, like, like])
    query += f" ORDER BY {sort_by} {order.upper()}"

    rows = conn.execute(query, params).fetchall()
    return [dict(r) for r in rows]


def _vi_sdk_note(conn: sqlite3.Connection, hw: dict) -> str | None:
    """`vi_sdk_server` 空白時，回一句話說明為什麼空白；有值時回 None。

    判斷靠 source_record（source='vcenter'）——那是匯入時逐列留下的來源紀錄，
    能區分「沒被 RVTools 匯過」與「匯過但那份檔沒那一欄」。
    這兩件事的處理方式不同：前者要去確認這台到底在不在 vCenter 上，
    後者只要拿新版 RVTools 重匯一次就好。
    """
    if hw.get("vi_sdk_server"):
        return None
    row = conn.execute(
        "SELECT payload FROM source_record WHERE source = 'vcenter' "
        "AND resolved_hardware_id = ? ORDER BY id DESC LIMIT 1", (hw["id"],)
    ).fetchone()
    if row is None:
        return "這台不是從 RVTools/vCenter 匯進來的（手動建立、Excel 匯入或掃描發現），所以沒有來源管理端"
    try:
        payload = json.loads(row["payload"])
    except (TypeError, ValueError):
        payload = {}
    if "vi_sdk_server" in payload:
        return "這份 RVTools 匯出裡 VI SDK Server 欄是空的"
    return ("匯入時間早於這個功能（2026-08-28），所以沒記到來源管理端。"
            "拿同一份 RVTools 重匯一次就會補上，不需要重新匯出")


@app.get("/api/hosts")
def hosts_endpoint(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """以「台」為單位的主機清單（machine_key 去重）：一台一列，附這台的多重登記（別名）。
    台數＝首頁在管台（同母體：排退役＋帳外）。見 host_view.list_hosts。"""
    import host_view

    return host_view.list_hosts(conn)


@app.get("/api/assets/{asset_serial}")
def asset_detail(
    asset_serial: str,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """主機詳細頁：D24分層邏輯不外露給使用者（見D31）——這裡回傳全部欄位，
    常用/進階顯示由前端依 field-groups 設定檔決定，不是後端替使用者過濾資料。
    """
    hardware = conn.execute(
        "SELECT * FROM hardware WHERE asset_serial = ?", (asset_serial,)
    ).fetchone()
    if hardware is None:
        raise HTTPException(404, "查無此資產")

    personnel = conn.execute(
        "SELECT * FROM personnel WHERE asset_serial = ?", (asset_serial,)
    ).fetchall()
    software = conn.execute(
        "SELECT * FROM software WHERE asset_serial = ?", (asset_serial,)
    ).fetchall()
    # 「軟體」分頁要顯示的是真正掃到的安裝軟體清單（host_package，軟體盤點那份），
    # 不是上面舊的 software 表（那是登記的 CIA 資料庫/軟體治理欄，多半空的）。
    # 2026-09-13 使用者發現：軟體盤點顯示這台有 5xx 套件，詳細頁卻是 0——就是這裡查錯表。
    # 用 asset_serial 或 ip 對，任一對得上都算（盤點時可能只綁到其中一個）。
    packages = conn.execute(
        "SELECT name, version, arch, vendor, source, first_seen, last_seen "
        "FROM host_package WHERE gone_at IS NULL AND (asset_serial = ? OR (ip IS NOT NULL AND ip = ?)) "
        "ORDER BY name COLLATE NOCASE, version",
        (asset_serial, hardware["ip"]),
    ).fetchall()
    history: list[sqlite3.Row] = []
    if hardware["hostname"]:
        history = conn.execute(
            "SELECT * FROM comparison_result WHERE hostname = ? ORDER BY detected_at DESC",
            (hardware["hostname"],),
        ).fetchall()

    import eos
    import normalize

    hw = dict(hardware)
    # 同一台的「別名／多重登記」（2026-09-18 使用者：「一台像一個人，可以有多個外號」）。
    # CIA 清冊是「每個服務／VIP／DB 實例登記一筆」，同一台 host 常有多筆（不同序號、不同用途）。
    # 這裡把同 machine_key 的其他筆列出來，讓詳細頁看起來是「一台＋多個外號」——
    # ⚠️ 唯讀彙整，不動原始資料、不自動合併（本專案鐵律；合併是人工決定）。
    # 判準跟 system_stats.machine_key 一致：主機名+IP 相同才算同一台；缺 IP／0.0.0.0 各算一台。
    # ⚠️ 報廢／停用／閒置的登記不算同一台（2026-09-18 使用者：「報廢跟使用中不能算同一台」）——
    # IP／主機名會被回收給新機器，退役那筆是「上一台」，不是這台的外號。所以只在**同生命週期**
    # （都非退役，或都退役）內找別名，不跨退役界線。
    import manage_state as ms
    aliases: list[dict] = []
    _h = (hw.get("hostname") or "").strip()
    _ip = (hw.get("ip") or "").strip()
    _self_retired = (hw.get("asset_status") or "").strip() in ms.RETIRED_STATUS
    if _h and _ip and _ip != "0.0.0.0":
        rp = ",".join("?" for _ in ms.RETIRED_STATUS)
        # 這台非退役→別名也要非退役；這台退役→只找同為退役的（同批下線的舊機）
        cond = f"COALESCE(asset_status,'') {'IN' if _self_retired else 'NOT IN'} ({rp})"
        for r in conn.execute(
            f"SELECT asset_serial, asset_purpose, asset_name, big_ip_vip, environment, api_id, "
            f"asset_status FROM hardware WHERE lower(trim(hostname)) = lower(?) AND trim(ip) = ? "
            f"AND asset_serial != ? AND {cond} ORDER BY asset_serial",
            (_h, _ip, asset_serial, *ms.RETIRED_STATUS),
        ):
            aliases.append(dict(r))
    hw["alias_count"] = len(aliases) + 1  # 含自己，這台總共登記幾筆
    # 這台掛的入口（VIP）＋每個入口後面還有誰（2026-09-18，見 vip_view.host_vips）
    import vip_view
    try:
        vip_pools = vip_view.host_vips(conn, _h, _ip, retired=_self_retired)
    except Exception as exc:  # noqa: BLE001 - 輔助資訊，壞了不擋整頁，但要講出來
        vip_pools = {"vips": [], "misfiled": [], "basis": None, "error": str(exc)}
    # 能不能納管（2026-09-15）：儲存設備／SAN switch 等詳細頁以前還掛著「一鍵納管」。
    # 判準跟收集分派／批次納管同一支（onboard_eligibility），畫面不另外猜。
    hw["onboard_block"] = _onboard_block(hw)
    # 人工豁免（非納管設備）——詳細頁要顯示是誰標的、為什麼，並提供取消（2026-09-16）
    try:
        import onboard_exempt

        hw["onboard_exempt"] = onboard_exempt.get(conn, hw.get("asset_serial"))
    except Exception:  # noqa: BLE001
        hw["onboard_exempt"] = None
    os_eos_hit = None
    os_info = None
    if hw.get("os"):
        os_info = normalize.normalize_os(hw["os"], conn, hw.get("device_model"))
        os_eos_hit = eos.lookup_os_eos(os_info["canonical"])
    hw_eos_hit = None
    model_info = None
    if hw.get("device_model"):
        # ⚠️ 這裡之前漏傳 hint（資產名稱/資產用途），跟 eos_summary() 統計頁用的
        # 不是同一套邏輯——同一台 device_model 只填「(VM)」的資產，統計頁能靠
        # hint 解析出「HPE 3PAR 8400 storage」，這支查單一資產卻查不到，兩邊
        # 結果對不起來。使用者 2026-08-13 實際發現、補上。
        model_info = normalize.normalize_model(hw["device_model"], conn, _model_hint(hw))
        hw_eos_hit = eos.lookup_hardware_eos(model_info["canonical"])

    # 使用者 2026-08-13 要求：來源系統的 os／device_model 欄位常常空白或認不出來，
    # 而且這個系統對來源資料沒有編輯權限，改不了。這裡唯讀顯示「系統猜測」，
    # 不寫回任何欄位、也不影響上面的 os_eos／hardware_eos 查詢結果（那兩個本來
    # 就已經用了 hint，猜測欄只是把「這是猜的」這件事明講出來，讓人知道不是
    # 來源系統本身寫的）。
    os_guess = None
    if hw.get("asset_purpose") and (not hw.get("os") or not (os_info and os_info["matched"])):
        os_guess = normalize.suggest_os_canonical(hw["asset_purpose"])
    # ⚠️ 使用者 2026-08-13 再次要求：不管是規則直接對到（method="rule"/"alias"，
    # 可信）還是靠 hint 猜的（"hint"/"hint-vendor"，僅供參考），都要顯示——
    # 之前只顯示「靠猜的」，理由是「規則直接對到的已經看得到不用重複」，但這樣
    # 使用者沒辦法分辨「系統沒查到」跟「已經查到、只是覺得不用顯示」，兩種空白
    # 長一樣。confirmed 旗標讓前端用不同樣式區分兩種狀況。
    model_guess = None
    model_guess_confirmed = False
    if model_info and model_info["method"] != "unmatched" \
            and model_info["canonical"] not in normalize._HW_VM_PRODUCTS:
        model_guess = model_info["canonical"]
        model_guess_confirmed = model_info["method"] in ("rule", "alias")

    # 體檢：清單頁的兩個燈在這裡展開成逐項明細（哪一項沒過、跟什麼比、下一步做什麼）。
    # 清單只夠回答「要不要看這台」，這裡才回答「那我到底要做什麼」。
    import health_check

    health = health_check.evaluate_all(conn).get(hardware["id"])

    # 業務系統：這台的 api_id 對到哪個系統（中文名／第幾類／AP 部門負責人）。
    # 三態要分得開（見 business_system 模組）：沒填代碼＝None；有代碼但對照表查無＝found:False；
    # 查到＝found:True。第幾類走 system_stats.class_from_label（原字串「S1-…」→「第一類」），
    # 手動覆寫（sys_class_override）優先於分級表匯入的 sys_class。
    biz = None
    _api = (hw.get("api_id") or "").strip()
    if _api:
        import system_stats
        _bs = conn.execute(
            "SELECT api_id, name, ap_department, ap_owner, sys_class, sys_class_override "
            "FROM business_system WHERE api_id = ?", (_api,),
        ).fetchone()
        if _bs:
            _computed, _core = system_stats.class_from_label(_bs["sys_class"])
            _ovr = (_bs["sys_class_override"] or "").strip()
            biz = {
                "found": True, "api_id": _api, "name": _bs["name"],
                "ap_department": _bs["ap_department"], "ap_owner": _bs["ap_owner"],
                "sys_class": _ovr or _computed, "sys_class_core": _core,
            }
        else:
            biz = {"found": False, "api_id": _api, "name": None,
                   "ap_department": None, "ap_owner": None,
                   "sys_class": system_stats.CLASS_UNRATED, "sys_class_core": False}

    # 主機規格（納管後收集）：CPU／RAM／Storage(依 VG/掛載分組)／PSU(實體機瓦特+數量)。
    # storage_json／psu_json 在這裡解成物件給前端；raw_json 不外送（量大、且詳細頁用不到）。
    _hs = conn.execute("SELECT * FROM host_spec WHERE asset_serial = ?", (asset_serial,)).fetchone()
    host_spec = None
    if _hs:
        import json as _json
        host_spec = dict(_hs)
        host_spec.pop("raw_json", None)
        for _k in ("storage_json", "psu_json", "spec_json"):
            try:
                host_spec[_k] = _json.loads(host_spec[_k]) if host_spec.get(_k) else None
            except (ValueError, TypeError):
                host_spec[_k] = None

    # NIC／HBA 明細（納管後收集）：每張卡一列，含目前+額定雙速率、降速旗標。
    try:
        nics = [dict(r) for r in conn.execute(
            "SELECT * FROM asset_nic WHERE asset_serial = ? ORDER BY nic_name", (asset_serial,)).fetchall()]
        hbas = [dict(r) for r in conn.execute(
            "SELECT * FROM asset_hba WHERE asset_serial = ? ORDER BY hba_name", (asset_serial,)).fetchall()]
    except sqlite3.Error:
        nics, hbas = [], []

    return {
        "hardware": hw,
        # 同一台的其他登記（別名／多重登記，一台多個「外號」）；空＝這台只登記一筆
        "aliases": aliases,
        "vip_pools": vip_pools,
        # 業務系統對照（名稱／第幾類）：api_id 為空時為 null——畫面用它把代碼翻成看得懂的系統
        "business_system": biz,
        # 主機規格（收集）：CPU/RAM/Storage(VG分組)/PSU；沒收過為 null
        "host_spec": host_spec,
        # NIC／HBA 明細（收集）：清單，每張卡一列
        "nics": nics,
        "hbas": hbas,
        # 「這台在哪個 vCenter 上」是很常追的問題。值本身在 hw["vi_sdk_server"]，
        # 這裡回的是**空白時為什麼空白**——三種原因完全不同，但都是 NULL：
        #   · 這台不是 RVTools 匯進來的（手動建／Excel／掃描發現）
        #   · 是 RVTools 匯的，但那份匯出沒有 VI SDK Server 欄（舊版 RVTools）
        #   · 是 RVTools 匯的，且匯入時間早於這個功能（2026-08-28 之前）
        # 只顯示空白，人會讀成「查過了，沒有」——那是第四種意思，而且是假的。
        "vi_sdk_server_note": _vi_sdk_note(conn, hw),
        "personnel": [dict(r) for r in personnel],
        "software": [dict(r) for r in software],
        # 掃到的安裝軟體（軟體盤點 host_package）——「軟體」分頁顯示這個
        "packages": [dict(r) for r in packages],
        "history": [dict(r) for r in history],
        # 退役資產不體檢，這時是 None——畫面顯示「已退役，不列入體檢」，
        # 不要假裝它全綠。
        "health": health,
        # 這台的軟硬體 EOS 狀態：查不到官方資料就是 null，不是 0 或空字串——
        # 前端要能分辨「查過沒公開日期」跟「還沒查」。
        "os_eos": ({**os_eos_hit, "status": eos.eos_status(os_eos_hit.get("eos_date"))}
                   if os_eos_hit else None),
        "hardware_eos": ({**hw_eos_hit, "status": eos.eos_status(hw_eos_hit.get("eos_date"))}
                          if hw_eos_hit else None),
        "os_guess": os_guess,
        "model_guess": model_guess,
        "model_guess_confirmed": model_guess_confirmed,
    }


class OnboardBody(BaseModel):
    ip: str
    platform: str          # linux / windows
    username: str
    password: str          # ⚠️ 只用於這一次納管，處理完即丟，絕不寫任何地方


@app.post("/api/onboard")
def onboard_endpoint(
    body: OnboardBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """A：UI 一鍵納管。使用者在畫面輸入 sysctl 帳密 → 系統用它去目標機建 webit3scan。

    ⚠️ 憑證不落地是寫死的底線：body.password 只傳給引擎、用完即丟——
    不寫 DB、不寫 log、不進稽核紀錄。稽核只記帳號名、平台、成敗，不記密碼。
    """
    import manage_state
    import onboard_engine

    collector_ip = onboard_engine.resolve_collector_ip(conn)
    # 開一格進度：執行器會逐行把目標主機的輸出寫進去，畫面同時輪詢 /api/onboard/progress。
    # 這支端點本身仍然是同步的（回傳最終結果），進度只是讓等待中的人看得到在做什麼。
    onboard_engine.progress_start(body.ip)
    try:
        result = onboard_engine.onboard(
            host=body.ip, platform=body.platform,
            username=body.username, password=body.password,   # 用完即丟，下面不再引用
            collector_ip=collector_ip,
            # 建出來的帳號名要跟收集端之後拿去登入的一致，否則建完仍然連不進去
            account=manage_state.get_collect_account(conn, body.platform),
            # 帳號備註（/etc/passwd 的 GECOS）由管理者在設定頁填，不寫死在程式碼——
            # 那裡面有員工編號與姓名，而 onboard_engine.py 會進公開 relay。
            comment=onboard_engine.resolve_account_comment(conn),
        )
    finally:
        onboard_engine.progress_done(body.ip)
    # 稽核：明確只寫無憑證的欄位。body.password 到這裡就結束生命週期，不進 SQL。
    conn.execute(
        "INSERT INTO onboard_audit (target_ip, platform, login_user, trigger, "
        "triggered_by, ok, stage, message, output) VALUES (?,?,?,?,?,?,?,?,?)",
        (body.ip, body.platform, body.username, "manual", session["username"],
         1 if result.ok else 0, result.stage, result.message, result.output),
    )
    conn.commit()

    # 納管成功後：
    # 1) 「發現但沒登記」的主機要先補一筆最小資產，否則收到的 facts 無處可落。
    #    只填系統知道的（IP／掃到的主機名／預設環境），業務欄位留空給人補。
    # 2) 試連＋收 facts，讓使用者立刻看到狀態變「已納管」＋真 OS/序號進來。
    post_note = None
    if result.ok:
        try:
            import manage_state
            exists = conn.execute("SELECT 1 FROM hardware WHERE ip = ?", (body.ip,)).fetchone()
            if not exists:
                scan_hn = conn.execute(
                    "SELECT hostname FROM scan_history WHERE ip = ? AND scan_ok = 1 "
                    "ORDER BY scan_time DESC LIMIT 1", (body.ip,)).fetchone()
                insert_hardware(
                    conn, asset_serial=f"AUTO-{body.ip}", ip=body.ip,
                    hostname=(scan_hn["hostname"] if scan_hn and scan_hn["hostname"] else None),
                    environment="正式", asset_status="使用中",
                )
            # ⚠️ 只做剛納管的這一台。2026-08-28 實測：原本這兩行不帶條件，
            # 等於每納管一台就把整個機隊重測＋重收一遍——畫面上腳本早就印完
            # 「完成。」，計時器還在跑 97～120 秒，跑的全是別台的事。
            # 成本是 N²，而明天要納管的是整個網段的幾百台。
            # 全機隊刷新交給排程（refresh_collect_status 的 docstring 本來就這樣寫）。
            serial_row = conn.execute(
                "SELECT asset_serial FROM hardware WHERE ip = ?", (body.ip,)).fetchone()
            manage_state.refresh_collect_status(conn, only_ip=body.ip)
            if serial_row:
                manage_state.collect_facts_into_assets(
                    conn, only_serial=serial_row["asset_serial"])
                # 納管後自動收一輪：規格／服務／軟體／帳號（2026-09-16 使用者：
                # 「以後納管後 要自動跑一次，收集全部 是手動狀態」）。
                # **在背景跑**——納管端點本身已經要花數十秒，再同步收四樣會讓瀏覽器逾時，
                # 使用者會以為納管失敗然後再按一次。結果寫進採集紀錄（kind=post_onboard）。
                import post_onboard

                post_onboard.start(None, serial_row["asset_serial"],
                                   by=session["username"] if session else None)
        except Exception as exc:  # noqa: BLE001
            # 收集失敗不影響「納管本身已完成」這個事實，但**不可以靜默**：
            # 原本是 `pass`，於是「跑了 90 秒然後全部失敗」跟「一切正常」
            # 在畫面上長得一模一樣。至少要讓人看得到收尾這步出了事。
            post_note = f"（納管成功，但納管後的試連／收集這步失敗：{exc}）"

    message = result.message + (post_note or "")
    return {"ok": result.ok, "stage": result.stage, "message": message,
            "output": result.output}


class RevokeBody(BaseModel):
    ip: str
    platform: str          # 目前只支援 linux
    username: str
    password: str          # ⚠️ 只用於這一次，處理完即丟，絕不寫任何地方
    confirm: str           # 必須是 "YES"


@app.post("/api/onboard/revoke")
def revoke_endpoint(
    body: RevokeBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """取消納管：把這台上的收集帳號、金鑰、sudo 白名單收回來。

    ## 為什麼要打 YES

    這個動作**在目標主機上刪東西**，而且刪完之後這台就收不到資料了。
    跟「再納管一次」不對稱——納管失敗頂多沒佈成功，撤銷失敗可能刪錯東西。
    所以要一個「不會手滑」的確認：打字比按鈕難按錯。

    ## 撤銷後的狀態不是「未納管」

    `collect_ok` 設成 0 之外，`collect_error` 會寫明是**人主動撤銷**的，
    不是「連不上」。這兩件事在畫面上都顯示成「收不到」，但一個是待辦、
    一個是刻意的結果——分不出來的話，之後有人會跑去「修」一台你剛撤銷的機器。
    """
    if body.confirm != "YES":
        raise HTTPException(400, "取消納管需要輸入 YES 確認")
    import manage_state
    import onboard_engine

    onboard_engine.progress_start(body.ip)
    try:
        result = onboard_engine.revoke(
            host=body.ip, platform=body.platform,
            username=body.username, password=body.password,
            account=manage_state.get_collect_account(conn, body.platform),
        )
    finally:
        onboard_engine.progress_done(body.ip)

    # 稽核：跟納管走同一張表，trigger 標 revoke 才分得出來。
    # 「誰在什麼時候撤了哪一台」正是稽核會問的第三個問題。
    conn.execute(
        "INSERT INTO onboard_audit (target_ip, platform, login_user, trigger, "
        "triggered_by, ok, stage, message, output) VALUES (?,?,?,?,?,?,?,?,?)",
        (body.ip, body.platform, body.username, "revoke", session["username"],
         1 if result.ok else 0, result.stage, result.message, result.output),
    )
    if result.ok:
        # 撤銷成功 → 這台現在收不到，而且是**刻意**收不到。
        conn.execute(
            "UPDATE hardware SET collect_ok = 0, collect_checked_at = ?, "
            "collect_error = ? WHERE ip = ?",
            (datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
             f"已由 {session['username']} 取消納管（不是連線失敗）", body.ip),
        )
    conn.commit()
    return {"ok": result.ok, "stage": result.stage, "message": result.message,
            "output": result.output}


# ===== Push agent（2026-08-14 設計）：主機自己排程回報 disk/memory 狀態，
# collector 端完全不主動連進主機——防火牆只需要「主機 → collector 單一 port」。
# 詳見 backend/agent_scripts/README.md 的兩段式安裝流程（sysinfra 上傳＋root 排程落地）。

class AgentStageBody(BaseModel):
    asset_serial: str


@app.post("/api/agent/stage")
def agent_stage(
    body: AgentStageBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """核發一把新的 agent key，組出 Stage 1 要上傳的**資料**（呼叫端負責實際 SCP
    上傳，這支端點本身不連任何主機）。asset_serial 必須已經是 hardware 表裡的一筆
    資產——沒有資產記錄就沒地方掛這把 key。

    ⚠️ 2026-08-28：這支端點**不再交出 push_agent.sh／install.sh**。
    那兩支是程式碼，已經隨 bootstrap_watcher.sh 固定佈在目標主機的
    /opt/webit3-agent/bin/ 了。舊版把它們當成「要上傳的檔案」交出去，配上 root
    排程去 /tmp 撿東西執行，合起來就是本機提權（任何本機帳號都能讓 root 幫他裝
    任意程式）——完整說明見 agent_scripts/install.sh 開頭。

    現在投放目錄只收兩個資料檔。**如果還照舊版把腳本一起上傳，install.sh 的白名單
    會把整個任務當成攻擊跡象拒絕**，所以這裡回一個 upload_dir 講清楚要放哪、放什麼。
    """
    exists = conn.execute(
        "SELECT 1 FROM hardware WHERE asset_serial = ?", (body.asset_serial,)
    ).fetchone()
    if not exists:
        raise HTTPException(404, "找不到這筆資產，請先建立資產記錄再種 agent")

    key = agent_auth.issue_host_key(conn, body.asset_serial)
    collector_url = f"http://{onboard_engine.resolve_collector_ip(conn)}:8000"
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return {
        "asset_serial": body.asset_serial,
        "upload_dir": f"/var/lib/webit3-agent/incoming/{body.asset_serial}_{stamp}",
        "note": "兩個檔案寫完之後，最後才建一個空的 .ready 標記檔——先有 .ready "
                "會讓 root 排程撿到上傳到一半的半成品。"
                "不要上傳任何腳本：投放目錄只收資料，出現 .sh 整個任務會被拒絕。",
        "files": {
            "agent_key": key,
            "collector_url": collector_url,
        },
    }


class AgentFactsBody(BaseModel):
    metrics: list[dict]


@app.post("/api/agent/facts")
def agent_facts(
    body: AgentFactsBody,
    asset_serial: str = Depends(require_host_key),
    conn: sqlite3.Connection = Depends(get_db),
):
    """Push agent 每日回報進來的資料。asset_serial 一律用 require_host_key 驗證出來的
    那個，不信任 body 裡任何主機識別欄位——agent 只能寫自己的資料，這是防冒充的關鍵。
    """
    for m in body.metrics:
        key = m.get("key")
        if not key:
            continue
        conn.execute(
            "INSERT INTO host_metric_latest (asset_serial, metric_key, value, unit, collected_at) "
            "VALUES (?, ?, ?, ?, ?) "
            "ON CONFLICT(asset_serial, metric_key) DO UPDATE SET "
            "value = excluded.value, unit = excluded.unit, collected_at = excluded.collected_at, "
            "received_at = datetime('now','localtime')",
            (asset_serial, key, m.get("value"), m.get("unit"), m.get("collected_at")),
        )
    conn.commit()
    return {"ok": True}


class BatchProbeBody(BaseModel):
    ips: list[str]
    username: str
    passwords: list[str]   # ⚠️ 只用於這次探測，處理完即丟，絕不寫任何地方


@app.post("/api/onboard/batch-probe")
def onboard_batch_probe(
    body: BatchProbeBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """B：一批主機、同一帳號、多組候選密碼，回報「哪一組通」——不建帳號、
    不執行任何納管腳本，純粹唯讀探測（借 uname -s 這行）。

    2026-09-06 使用者的實際情境：機隊裡 root 密碼混了 A/B 兩種，不想一台
    一台手動試。這支只回「第幾組密碼對」，body.passwords 到這裡就結束
    生命週期，不進 SQL、不進稽核紀錄——跟 /api/onboard 的密碼不落地是
    同一條底線。

    ⚠️ 不落密碼不代表這支端點沒有風險：短時間對多台主機連續嘗試多組密碼，
    形狀就是密碼噴灑攻擊，可能觸發目標機的帳號鎖定（fail2ban/PAM tally）。
    數量大時前端要把這個風險講清楚，不能包裝成「安全的批次工具」。
    """
    import onboard_engine

    if not body.ips:
        raise HTTPException(400, "至少要給一台 IP")
    if not body.passwords:
        raise HTTPException(400, "至少要給一組密碼")
    if len(body.ips) > 100:
        raise HTTPException(400, "一次最多 100 台——數量再大，密碼噴灑的風險也跟著放大，分批做")

    results = onboard_engine.batch_probe_credentials(
        targets=[{"ip": ip} for ip in body.ips],
        username=body.username, passwords=body.passwords)
    matched = sum(1 for r in results if r["matched_password_index"] is not None)
    return {"total": len(results), "matched": matched, "unmatched": len(results) - matched,
            "results": results}


@app.get("/api/onboard/hint")
def onboard_hint(
    ip: str,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """納管前的平台研判——**即時探測，不信登記值**。

    為什麼不用 hardware.os：登記的 OS 可能過時、可能是假資料（實例：.101 登記成
    Ubuntu，實際 banner 是 OpenSSH_for_Windows）。拿錯平台的腳本去打，一定失敗。
    這裡即時抓 SSH banner（不需帳密），banner 自報最準；並回報跟登記值是否衝突，
    讓使用者看得到「畫面說 Ubuntu 但實測是 Windows」這種矛盾。
    """
    import fingerprint

    banner = fingerprint.grab_banner(ip, 22)
    scan = conn.execute(
        "SELECT open_ports, os_guess FROM scan_history WHERE ip = ? AND scan_ok = 1 "
        "ORDER BY scan_time DESC LIMIT 1", (ip,)).fetchone()
    ports = [int(p) for p in (scan["open_ports"] or "").split(",") if p.strip().isdigit()] \
        if scan else []
    os_guess = scan["os_guess"] if scan else None
    method = fingerprint.onboard_method(os_guess=os_guess, open_ports=ports, banner=banner)

    registered = conn.execute("SELECT os FROM hardware WHERE ip = ?", (ip,)).fetchone()
    registered_os = registered["os"] if registered else None
    # 衝突：登記說 Linux 但實測 Windows（或反過來）
    conflict = None
    if registered_os and method["method"] in ("linux", "windows"):
        reg_is_win = any(k in registered_os.lower() for k in ("windows", "microsoft"))
        detected_win = method["method"] == "windows"
        if reg_is_win != detected_win:
            conflict = f"登記為「{registered_os}」，但實測是 {'Windows' if detected_win else 'Linux'}"

    return {
        "ip": ip,
        "platform": method["method"] if method["method"] in ("linux", "windows") else "",
        "confidence": method["confidence"],
        "evidence": method["evidence"],
        "banner": banner,
        "registered_os": registered_os,
        "conflict": conflict,
    }


class CredentialBody(BaseModel):
    name: str
    kind: str = "winrm"
    username: str
    password: str          # ⚠️ 加密後才進 DB，回應永不含它
    scope: str | None = None
    note: str | None = None


@app.get("/api/credentials")
def list_credentials(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    """列出收集用憑證——**永不含密碼，連密文都不給**。"""
    import credential_store

    return credential_store.list_public(conn)


@app.post("/api/credentials")
def save_credential(
    body: CredentialBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """新增／更新收集用憑證（如 Windows WinRM 服務帳號）。

    密碼加密後才進 DB，加密金鑰另存 0600 檔案（不在 DB 裡——DB 會被備份、被複製，
    金鑰跟著走就等於沒加密）。回應只回 metadata。
    """
    import credential_store

    credential_store.save(conn, body.name, body.kind, body.username, body.password,
                          scope=body.scope, note=body.note)
    return {"ok": True, "credentials": credential_store.list_public(conn)}


@app.delete("/api/credentials/{name}")
def delete_credential(
    name: str,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import credential_store

    n = credential_store.delete(conn, name)
    if not n:
        raise HTTPException(404, "查無此憑證")
    return {"ok": True}


@app.get("/api/onboard/script")
def onboard_script(
    platform: str,
    fmt: str = "oneliner",
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """產生「在目標機本機自己跑」的一行指令，或給維運批次佈署的 Ansible playbook。

    為什麼需要這條路：遠端納管要目標機的管理員帳密，但很多情況拿不到——
    Windows 沒有維運帳號慣例、單機環境沒網域、或人就坐在那台機器前面（根本不用遠端）。
    這時給他一行可貼的指令最實際，且**完全不需要任何密碼**。
    腳本內容與遠端用的完全同一份（同一個引擎產出），不會有兩套行為分岔。

    fmt=ansible（僅 Linux）：把同一組動作翻成 playbook，交給資安／維運一次佈完整批。
    ⚠️ playbook 也是即時從收集公鑰組出來的，不是 repo 裡的靜態檔——換過金鑰之後
    靜態檔會安靜地變成錯的（佈下去每台都成功，只是收集全部連不進來）。
    AIX 沒有這個選項：Ansible 不支援 AIX，只能給可貼的腳本。
    """
    import onboard_engine

    if platform not in ("linux", "aix", "windows"):
        raise HTTPException(400, "platform 只接受 linux、aix 或 windows")
    collector_ip = onboard_engine.resolve_collector_ip(conn)
    import manage_state

    account = manage_state.get_collect_account(conn, platform)

    if fmt == "ansible":
        if platform != "linux":
            raise HTTPException(
                400, "Ansible playbook 只適用 Linux——AIX 不支援 Ansible（改用可貼的腳本），"
                     "Windows 走 WinRM 不需要在目標機建帳號")
        try:
            content = onboard_engine.build_linux_playbook(
                onboard_engine.collector_pubkey(), collector_ip, account,
                onboard_engine.resolve_account_comment(conn))
        except ValueError as exc:      # 收集金鑰還沒產生
            raise HTTPException(400, str(exc))
        return {
            "platform": platform, "fmt": "ansible",
            "filename": f"{account}_bootstrap.yml",
            "content": content,
            "note": "交給資安／維運：ansible-playbook -i <inventory> "
                    f"{account}_bootstrap.yml",
        }
    if fmt != "oneliner":
        raise HTTPException(400, "fmt 只接受 oneliner 或 ansible")

    try:
        script = onboard_engine.build_script(
            platform, onboard_engine.collector_pubkey(), collector_ip, account,
            onboard_engine.resolve_account_comment(conn))
    except ValueError as exc:      # AIX 帳號名過長、或收集金鑰還沒產生
        raise HTTPException(400, str(exc))
    # ⚠️ 2026-08-28：拿掉 base64。這支產出的是**給人貼上去執行的**指令——
    #
    # 把腳本 base64 起來，執行的人**看不懂自己在跑什麼**（違反可稽核性），
    # 同時 SOC 看到的是「有人在這台解碼一段東西餵給 root shell」，也就是投毒的樣子。
    # 純文字反而三贏：貼的人看得懂、稽核查得到、SOC 不告警。
    #
    # 用 heredoc 包起來仍然是「一段貼上去就好」，但內容全程可讀。
    if platform == "linux":
        cmd = f"sudo bash -s <<'WEBIT3_EOF'\n{script}\nWEBIT3_EOF"
        note = ("在該機器以可 sudo 的帳號貼上執行。內容是純文字，"
                "貼之前可以先看過（已經是 root 的話把開頭的 sudo 去掉）")
    elif platform == "aix":
        # AIX 未必裝 sudo（常在 /opt/freeware/bin 或改用 RBAC），所以要求以 root 登入
        cmd = f"ksh -s <<'WEBIT3_EOF'\n{script}\nWEBIT3_EOF"
        note = "在該機器以 root 執行（AIX 未必裝 sudo，所以不走 sudo）"
    else:
        # PowerShell：直接貼腳本本文到「系統管理員 PowerShell」視窗。
        # **貼上去執行的指令不受執行原則約束**（那管的是腳本檔），
        # 所以不需要 -ExecutionPolicy Bypass，也不需要先把檔案寫到 TEMP。
        cmd = script
        note = ("在該機器開「系統管理員 PowerShell」，把下面整段貼進去。"
                "不需要調整執行原則——貼上去的指令本來就不受它約束")
    return {"platform": platform, "command": cmd, "note": note}


@app.get("/api/onboard/progress")
def onboard_progress(
    ip: str,
    session: sqlite3.Row = Depends(require_auth),
):
    """納管執行中的即時進度：目標主機現在做到哪一步。

    為什麼需要（使用者 2026-08-16）：畫面原本只能顯示「已經幾秒」，而腳本本來就會
    逐行印「已建立帳號」「佈署收集公鑰」這些話——資訊一直都在，只是被 subprocess
    一次收完、等結束才回來。改成邊跑邊寫進進度表，這裡讀出來給畫面輪詢。

    ⚠️ 只回腳本的 stdout，永不含憑證（腳本本身設計上就不含機密）。
    """
    return onboard_engine.progress_of(ip)


class OnboardVerifyBody(BaseModel):
    ip: str
    platform: str          # linux / aix / windows


@app.post("/api/onboard/verify")
def onboard_verify(
    body: OnboardVerifyBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """本機執行納管指令跑完後，立刻試連驗證——不用等重新掃描、不用猜「有沒有生效」。

    使用者 2026-08-17 明確要求：「本機執行」這條路（PAM 代登、拿不到密碼那種情境）
    使用者是在系統看不到的地方跑完指令，系統原本要等下一輪「重新掃描」才會發現這台，
    完成與否完全不明顯。這支端點對單一 IP 立即試一次真收集，成功就直接看到
    hostname/os，失敗就直接看到原因——不用等、不用猜。

    跟 /api/onboard（帳密流程）不同：那支是「系統代你連進去執行納管腳本」，這支是
    「你已經自己執行過了，系統只是幫你驗證有沒有生效」，語意完全不同，所以是獨立端點。
    """
    import manage_state

    if body.platform not in ("linux", "aix", "windows"):
        raise HTTPException(400, "platform 只接受 linux、aix 或 windows")

    row = conn.execute("SELECT asset_serial FROM hardware WHERE ip = ?", (body.ip,)).fetchone()
    if row:
        asset_serial = row["asset_serial"]
    else:
        # 還沒有資產記錄（本機執行流程不像帳密流程會自動先補一筆）——
        # 驗證的前提是「這台在系統裡掛得上號」，沒有就先補到最小記錄，跟
        # /api/onboard 成功後的自動補記錄邏輯一致。
        asset_serial = f"AUTO-{body.ip}"
        conn.execute(
            "INSERT OR IGNORE INTO hardware (asset_serial, ip, environment, asset_status) "
            "VALUES (?, ?, '正式', '使用中')",
            (asset_serial, body.ip),
        )

    # 驗證的本質就是「現在馬上試連一次」，不受之前 collect_ok 的舊狀態影響——
    # 這正是使用者剛執行完腳本、還沒被任何排程重新探測過的那一刻。
    # [B-05] 成功寫整台（同一台的多筆登記一起），不只這一筆
    manage_state.mark_collect_ok(conn, asset_serial)
    conn.commit()

    result = manage_state.collect_facts_into_assets(conn, only_serial=asset_serial)
    row = conn.execute(
        "SELECT hostname, os, device_model FROM hardware WHERE asset_serial = ?", (asset_serial,)
    ).fetchone()

    if result["updated"] >= 1:
        return {
            "ok": True, "asset_serial": asset_serial,
            "hostname": row["hostname"], "os": row["os"], "device_model": row["device_model"],
        }
    error = result["failed"][0]["error"] if result["failed"] else "收不到任何欄位，原因不明"
    return {"ok": False, "asset_serial": asset_serial, "error": error}


@app.get("/api/onboard/post-collect/{asset_serial}")
def onboard_post_collect_status(
    asset_serial: str,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """納管後自動收集跑到哪了（2026-09-17 使用者：「我認為我納管後，所有的資料都要跟著變動」）。

    納管完成 ≠ 資料進來了：規格／服務／軟體／帳號是背景收的，要等幾十秒。
    以前畫面不會自己更新，使用者看到的還是「軟體 0」，會以為收集壞掉。
    這支讓畫面知道「還在收 / 收完了 / 哪一樣沒收到」，收完就自己重載。
    """
    import collect_log
    import post_onboard

    running = post_onboard.running_for(asset_serial)
    last = None
    for rec in collect_log.recent(conn, limit=50, kinds=["post_onboard"]):
        if rec.get("target") == asset_serial:
            last = rec
            break
    results = []
    if last:
        try:
            extra = json.loads(last.get("extra") or "{}")
            results = extra.get("results") or []
        except (TypeError, ValueError):
            results = []
    return {"running": running, "last": last, "results": results,
            "jobs": [{"job": j, "label": post_onboard.JOB_LABEL[j]} for j in post_onboard.JOBS]}


@app.get("/api/onboard/failures")
def onboard_failures_endpoint(
    include_resolved: bool = False,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """納管失敗清單：哪些機器試過但進不去、為什麼、要找誰（2026-09-17 使用者：
    「這些帳號納管失敗，我以後要怎麼查那些納管失敗過，他的 root 密碼可能不是預設密碼」）。

    只回**每台最後一次**的結果——一台上週失敗今天成功了就不該再出現在待處理裡。
    歷史仍在納管紀錄（onboard_audit）裡查得到。見 onboard_failures。
    """
    import onboard_failures

    return {"items": onboard_failures.current_failures(conn, include_resolved),
            "summary": onboard_failures.summary(conn)}


@app.get("/api/onboard/failures/export")
def onboard_failures_export(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """匯出納管失敗清單——拿去跟管理員要密碼的就是這張。"""
    import onboard_failures
    from urllib.parse import quote

    wb = Workbook()
    ws = wb.active
    ws.title = "納管失敗清單"
    ws.append(onboard_failures.EXPORT_HEADERS)
    for r in onboard_failures.export_rows(conn):
        ws.append(["" if v is None else v for v in r])
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    fname = f"納管失敗清單_{_now_local()[:10]}.xlsx"
    return StreamingResponse(
        buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(fname)}"})


@app.get("/api/onboard/audit")
def onboard_audit_endpoint(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    """納管稽核紀錄（不含任何憑證）。"""
    return [dict(r) for r in conn.execute(
        "SELECT * FROM onboard_audit ORDER BY id DESC LIMIT 100")]


class SegmentBody(BaseModel):
    prefix: str
    enabled: bool = True
    note: str | None = None


class SegmentEnabledBody(BaseModel):
    enabled: bool


class AutoOnboardEnabledBody(BaseModel):
    enabled: bool


@app.get("/api/auto-onboard")
def auto_onboard_state(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    """B 排程自動納管的現況：總開關、授權網段、最近的自動納管稽核。

    授權網段是這功能的安全閘門——排程只碰列在這裡且啟用的網段前綴。稽核只含帳號名/成敗，
    永不含密碼。
    """
    import auto_onboard

    return {
        "enabled": auto_onboard.is_enabled(conn),
        "segments": auto_onboard.list_segments(conn),
        "recent": auto_onboard.recent_auto_audit(conn, 50),
    }


@app.patch("/api/auto-onboard/enabled")
def auto_onboard_set_enabled(
    body: AutoOnboardEnabledBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """總開關。關閉＝排程不會自動納管任何機器（預設關閉）。

    這只擋「無人在場的排程」；就算開著，也只碰授權網段內的主機。
    """
    import auto_onboard

    auto_onboard.set_enabled(conn, body.enabled)
    return {"ok": True, "enabled": auto_onboard.is_enabled(conn)}


@app.post("/api/auto-onboard/segments")
def auto_onboard_save_segment(
    body: SegmentBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """新增／更新一個授權網段（以前綴為唯一鍵）。加進來才代表「授權排程自動納管這段」。"""
    import auto_onboard

    try:
        auto_onboard.save_segment(conn, body.prefix, body.enabled, body.note)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    return {"ok": True, "segments": auto_onboard.list_segments(conn)}


@app.patch("/api/auto-onboard/segments/{seg_id}/enabled")
def auto_onboard_toggle_segment(
    seg_id: int,
    body: SegmentEnabledBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """啟用／停用一個授權網段。停用＝排程跳過但保留設定。"""
    import auto_onboard

    if not auto_onboard.set_segment_enabled(conn, seg_id, body.enabled):
        raise HTTPException(404, "查無此授權網段")
    return {"ok": True, "segments": auto_onboard.list_segments(conn)}


@app.delete("/api/auto-onboard/segments/{seg_id}")
def auto_onboard_delete_segment(
    seg_id: int,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import auto_onboard

    if not auto_onboard.delete_segment(conn, seg_id):
        raise HTTPException(404, "查無此授權網段")
    return {"ok": True, "segments": auto_onboard.list_segments(conn)}


@app.post("/api/auto-onboard/run")
def auto_onboard_run_now(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    """手動「立即執行」一輪自動納管：試連 → 納管授權網段內未納管的 Linux → 收 facts。

    操作者在場的手動觸發，不受總開關約束，但仍受授權網段約束（沒授權就沒候選）。
    會花數秒到數十秒（每台一次試連／SSH），前端要顯示執行中三態。
    """
    import auto_onboard

    collector_ip = onboard_engine.resolve_collector_ip(conn)
    return auto_onboard.scheduled_cycle(collector_ip=collector_ip, conn=conn)


# ===== 收集入口收斂（決策 C4，2026-08-16）=====
# 使用者只做一個動作：貼網段或 IP 清單、按一下。選路（SSH／WinRM／Agent／只能匯入）
# 由系統依實際探測結果決定，不要人先自己判斷該點哪個按鈕——那個判斷本來就該系統做。

class CollectDispatchBody(BaseModel):
    targets: str          # 網段（10.99.1.0/24）、範圍（10.99.1.10-20）、單一 IP，可混用


class BatchOnboardBody(BaseModel):
    ips: list[str]
    username: str
    passwords: list[str]        # ⚠️ 只用於這次，處理完即丟，絕不寫任何地方
    unify_password: bool = False
    confirm: str = ""           # 勾了 unify_password 時必須是 "YES"（統一密碼會動正式資料）
    include_ips: list[str] = []  # 使用者確認過是測試機、要納入的未登記機器


@app.post("/api/onboard/batch-auto/preview")
def batch_auto_preview(
    body: BatchOnboardBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """先看這批會跑哪些、擋掉哪些（正式/備援）、哪些未登記要你確認——不動任何機器。

    畫面在真的按下去之前先叫這支，讓人看清楚範圍，避免手滑把正式機放進去。
    """
    import batch_onboard_service
    return batch_onboard_service.classify_targets(conn, body.ips)


@app.post("/api/onboard/batch-auto")
def batch_auto_start(
    body: BatchOnboardBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """啟動一批自動納管（背景跑，馬上回 run_id；畫面輪詢 /status）。

    ⚠️ 統一密碼會改正式機的 root 密碼、又收不回，所以勾了 unify_password 一定要
    confirm=="YES" 才放行（同「反納管」的打字確認）。
    ⚠️ body.passwords 只往 service 傳、用完即丟——不進 DB、不進 log、不進回應。
    """
    import batch_onboard_service

    if body.unify_password and body.confirm != "YES":
        raise HTTPException(400, "勾了『統一密碼成 A』就要在確認欄輸入 YES——這會改正式機密碼且收不回")
    try:
        out = batch_onboard_service.start(
            conn, body.ips, body.username, body.passwords,
            unify_password=body.unify_password, triggered_by=session["username"],
            include_ips=body.include_ips)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    return out


@app.get("/api/onboard/batch-auto/status")
def batch_auto_status(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """最近一批的進度＋逐台結果。畫面輪詢這個。"""
    import batch_onboard_service
    return batch_onboard_service.status(conn)


@app.get("/api/onboard/batch-auto/export")
def batch_auto_export(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """把最近一批的結果匯出 xlsx（留存／交資安）。**不含任何密碼**，只有『用第幾組』。"""
    import batch_onboard_service

    st = batch_onboard_service.status(conn)
    wb = Workbook()
    ws = wb.active
    ws.title = "批次納管結果"
    ws.append(["IP", "環境別", "登入", "用哪組密碼", "已納管", "統一成A", "失敗階段", "原因"])
    pw_label = {0: "A", 1: "B"}
    for r in st["results"]:
        ws.append([
            r["ip"], r["environment"] or "",
            "成功" if r["login_ok"] else "失敗",
            pw_label.get(r["password_index"], "都不對" if r["login_ok"] is not None else ""),
            "是" if r["onboarded"] else "否",
            "是" if r["password_unified"] else "",
            r["fail_stage"] or "", r["fail_reason"] or "",
        ])
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    from urllib.parse import quote
    fname = f"批次納管結果_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
    return StreamingResponse(
        buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(fname)}"},
    )


@app.post("/api/collect/dispatch")
def collect_dispatch_run(
    body: CollectDispatchBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """一個入口跑完整收集流程，回一張分得出成敗的結果表。

    會花數秒到數分鐘（每台要探測、通的還要真的連進去收），前端必須顯示執行中三態。
    憑證（WinRM）由加密憑證庫提供、用完即丟，不進回應也不進結果表。
    """
    import collect_dispatch
    import collect_log

    by = session["username"]
    target = (body.targets or "").strip()[:200]

    # 自動分批（2026-09-16 使用者：「你應該幫我自動分」「你有分批嗎?」）：
    # 超過一批的量改在**背景**跑，馬上回 run_id，畫面輪詢 /latest 看進度——
    # 同步跑會被 HTTP 逾時切斷，使用者看到的就是「收集沒有完成（跑了 0 秒）」。
    # 一批以內維持同步，行為與以往完全相同。
    try:
        count = len(collect_dispatch.parse_targets(body.targets))
    except ValueError as exc:
        collect_log.record(conn, "dispatch", target, False, str(exc), actor=by)
        raise HTTPException(400, str(exc)) from exc
    if count > collect_dispatch.BATCH_SIZE:
        try:
            started = collect_dispatch.start_background(None, body.targets, triggered_by=by)
        except RuntimeError as exc:
            raise HTTPException(409, str(exc)) from exc
        gap = collect_dispatch.batch_gap_seconds(conn)
        collect_log.record(
            conn, "dispatch", target, True,
            f"{started['total']} 台自動分成 {started['batch_total']} 批（每批最多 "
            f"{collect_dispatch.BATCH_SIZE} 台、間隔 {gap} 秒），已在背景開始",
            actor=by, extra=started)
        return {**started, "batch_size": collect_dispatch.BATCH_SIZE, "gap_seconds": gap}
    # 成功失敗都記（2026-09-15 使用者：「搜尋不到或有什麼失敗都沒有任何輸出，不知道錯在哪」）
    try:
        out = collect_dispatch.run_dispatch(conn, body.targets, triggered_by=by)
    except ValueError as exc:
        collect_log.record(conn, "dispatch", target, False, str(exc), actor=by)
        raise HTTPException(400, str(exc))
    except Exception as exc:  # noqa: BLE001 - 未預期的也要留證據再往上丟
        collect_log.record(conn, "dispatch", target, False, f"{type(exc).__name__}: {exc}",
                           actor=by, exc=exc)
        raise
    bs = out.get("by_status") or {}
    collect_log.record(
        conn, "dispatch", target, True,
        # 講清楚「探測了幾個位址」而不是「幾台」——掃一個 /24 是 254 個位址，多數是空的。
        # 使用者 2026-09-16 問「為什麼是 508，還要人工處理?」就是被這個說法誤導的。
        f"探測 {out.get('total', 0)} 個位址：已納管 {out.get('collected', 0)}、"
        f"要人工處理 {out.get('needs_action', 0)}、不納管 {out.get('not_onboardable', 0)}、"
        f"空位址（沒回應也沒登記）{out.get('empty_addresses', 0)}、"
        f"已登記但只能匯入 {bs.get('import_only', 0) - out.get('empty_addresses', 0)}",
        actor=by, extra={"run_id": out.get("run_id"), "by_status": bs,
                         "by_route": out.get("by_route")})
    return out


class DispatchGapBody(BaseModel):
    gap_seconds: int


@app.get("/api/collect/dispatch/gap")
def collect_dispatch_gap_get(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """自動分批的設定：一批幾台、批與批之間停幾秒、現在有沒有在跑。"""
    import collect_dispatch

    return {"gap_seconds": collect_dispatch.batch_gap_seconds(conn),
            "batch_size": collect_dispatch.BATCH_SIZE,
            "hard_max": collect_dispatch.HARD_MAX_TARGETS,
            "running": collect_dispatch.background_running()}


@app.put("/api/collect/dispatch/gap")
def collect_dispatch_gap_put(
    body: DispatchGapBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """批與批之間停幾秒（使用者 2026-09-16：「預設每個網段間距2分鐘」「可以設定改幾分鐘」）。

    間隔是刻意的：一次對上千台送封包對網路不客氣，也容易被 SOC 當成掃描行為。
    但要幾分鐘由使用者決定——不同公司的網路與監控容忍度差很多。
    """
    from db import set_setting

    if not 0 <= body.gap_seconds <= 3600:
        raise HTTPException(400, "間隔要在 0～3600 秒（0～60 分鐘）之間")
    set_setting(conn, "dispatch_batch_gap_seconds", str(int(body.gap_seconds)))
    return {"gap_seconds": body.gap_seconds}


@app.get("/api/collect/dispatch/latest")
def collect_dispatch_latest(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    """最近一次分派的結果。頁面重新整理／隔天回來還看得到上次跑到哪，不用重跑。"""
    import collect_dispatch

    return collect_dispatch.latest_run(conn) or {"run": None, "results": [], "total": 0,
                                                 "collected": 0, "needs_action": 0,
                                                 "by_status": {}, "by_route": {}}


class AgentPackageBody(BaseModel):
    ip: str


@app.post("/api/collect/agent-package")
def collect_agent_package(
    body: AgentPackageBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """替一台「系統進不去」的主機產 Push Agent 安裝包。

    key 綁在資產上，所以這台一定要先有資產記錄。未登記的在這裡補一筆最小資產——
    這是**人明確按下按鈕**才發生的（跟排程自動納管刻意不自動建資產不同，
    見 auto_onboard 的說明），欄位只填系統知道的，業務欄位留空給人補。
    """
    ip = (body.ip or "").strip()
    if not ip:
        raise HTTPException(400, "缺少 ip")
    row = conn.execute("SELECT asset_serial FROM hardware WHERE ip = ? LIMIT 1", (ip,)).fetchone()
    if row:
        serial = row["asset_serial"]
    else:
        scan_hn = conn.execute(
            "SELECT hostname FROM scan_history WHERE ip = ? AND scan_ok = 1 "
            "ORDER BY scan_time DESC LIMIT 1", (ip,)).fetchone()
        serial = f"AUTO-{ip}"
        insert_hardware(
            conn, asset_serial=serial, ip=ip,
            hostname=(scan_hn["hostname"] if scan_hn and scan_hn["hostname"] else None),
            environment="正式", asset_status="使用中",
        )

    scripts_dir = Path(__file__).parent / "agent_scripts"
    key = agent_auth.issue_host_key(conn, serial)
    collector_url = f"http://{onboard_engine.resolve_collector_ip(conn)}:8000"
    return {
        "ip": ip,
        "asset_serial": serial,
        "created_asset": row is None,
        "collector_url": collector_url,
        # 交給「要請人裝」的那位的東西：一支自帶全部內容的 bootstrap 腳本＋一行指令。
        # 腳本本身固定不變（好稽核／好比對版本），會變的 key 與 URL 另外帶。
        #
        # ⚠️ 2026-08-28：push_agent.sh／install.sh 不再單獨交出去——它們已經內嵌在
        # bootstrap_watcher.sh 裡，由 root 那一次佈署固定到 /opt/webit3-agent/bin/。
        # 單獨交出去只會誘導人把可執行內容放進投放目錄，那正是被修掉的提權路徑。
        "install_command": "sudo sh /tmp/bootstrap_watcher.sh",
        "files": {
            "agent_key": key,
            "collector_url": collector_url,
            "bootstrap_watcher.sh": (scripts_dir / "bootstrap_watcher.sh").read_text(
                encoding="utf-8"),
        },
    }


@app.get("/api/pipeline")
def pipeline_endpoint(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    """納管漏斗：每台機器走到哪一關、下一步要做什麼。

    使用者 2026-08-16：「300 台測試機要一台一台匯，我至少要知道哪些是我還需要處理的。」
    四態只分到「連不連得進去」；這裡把「已納管」再往後拆成事實／服務／帳號幾關，
    每台剛好落在它還沒完成的第一關（互斥窮盡，可對帳）。
    """
    import number_proof
    import pipeline

    s = pipeline.summarize(conn)
    # [B-09] 頂端 5 個關鍵數字＋ⓘ說明＋下鑽條件（數字從同一份 summary 數，跟下面的表同源）
    s["key_numbers"] = number_proof.key_numbers(conn, s)
    return s


@app.get("/api/number-proof")
def number_proof_endpoint(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    """[B-09] 數字健檢：漏斗 5 個數字的 畫面值／獨立重算值／差異／差異解釋（逐台歸因）。"""
    import number_proof

    return number_proof.health(conn)


# ===== 資料可信度評分（2026-09-11）=====
# 規則與配分在 trust_score.py（使用者拍板的錨點由測試盯著）。這裡只是薄 HTTP 層。

@app.get("/api/trust/distribution")
def trust_distribution_endpoint(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    """100 分幾台、90 分幾台…＋來源組合各幾台。每個數字都能用 /api/trust/hosts 下鑽。"""
    import trust_score

    return trust_score.distribution(conn)


@app.get("/api/trust/hosts")
def trust_hosts_endpoint(
    score: int | None = None,
    combo: str | None = None,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """某個分數（或某個來源組合）是哪幾台。跟分布表同一份計算，數字一定對得上。"""
    import trust_score

    return {"items": trust_score.hosts_with(conn, score, combo)}


@app.get("/api/trust/asset/{asset_serial}")
def trust_asset_endpoint(
    asset_serial: str,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """單台的分數拆解（資產詳細頁用）。"""
    import trust_score

    r = trust_score.compute_all(conn).get(asset_serial)
    if r is None:
        raise HTTPException(404, "查無此資產，或它是退役資產（退役資產不評分）")
    return r


@app.get("/api/manage-state")
def manage_state_endpoint(
    summary: bool = False,
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    """納管四態：未登記／未納管／已納管／失聯。互斥且窮盡，加總＝你知道的所有機器。

    跟 asset_status 是兩條獨立的軸——一台可以同時「使用中」而且「連不進去」。
    儀表板四格與資產清單的狀態欄共用這一份，數字才不會跟清單對不上。
    """
    import manage_state

    out = manage_state.summarize(conn)
    if summary:
        # 首頁只要數字：逐筆明細（上千筆）不送，頁面才不會變慢
        out = {k: v for k, v in out.items() if k != "items"}
    return out


@app.get("/api/diagnostics")
def diagnostics_endpoint(
    note: str = "",
    desensitize: bool = True,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """萬用診斷包：出問題時一個動作產出「足以判斷問題在哪」的去識別化資料。

    不綁任何單一功能——核心負責環境快照/去識別化/打包，各功能自己註冊一段
    （見 diagnostics.register）。新功能加一個函式就會自動被收進來。

    desensitize 預設 True：公司資料不出這台機器是硬規則，要關掉必須明確指定。
    """
    import diagnostics as dg
    # 確保各功能的診斷外掛都已註冊（模組載入時才會 register）
    import auto_onboard  # noqa: F401
    import identity  # noqa: F401
    import manage_state  # noqa: F401
    import normalize  # noqa: F401
    import vcenter_autoimport  # noqa: F401

    return dg.collect(conn, note=note, desensitize=desensitize)


@app.get("/api/health/summary")
def health_summary(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    """幾台完全沒問題、幾台要看、要看的卡在哪幾項。

    首頁那一句話用的就是這支。「要看」不是壞掉——它同時包含「機器有事」跟
    「資料要補」，兩者處置完全不同，所以回傳分開給 machine_bad / data_bad。
    """
    import health_check

    return health_check.summary(conn)


@app.get("/api/dashboard/composition")
def dashboard_composition(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    """全站組成統計：我的機器長什麼樣子（各平台幾台、虛實、環境、狀態）。

    這是儀表板該回答的問題——「有幾台 Windows」是統計；
    「兩邊相符／登記卻掃不到」是對帳細節，屬於小功能，不該佔戰情室頭條。
    """
    import manage_state

    return manage_state.composition(conn)


def _model_hint(r: sqlite3.Row) -> str | None:
    """給 normalize_model() 的救援線索：device_model 認不出來時，具體型號常常
    躲在資產名稱或資產用途欄位（使用者 2026-08-13 實際發現「EMC XT480」寫在
    資產用途，不是資產名稱——兩欄都不確定會落在哪個，索性都給）。"""
    parts = [r["asset_name"], r["asset_purpose"]]
    joined = " ".join(p for p in parts if p)
    return joined or None


def _identity_guess(r: sqlite3.Row, conn) -> tuple[str | None, str, bool]:
    """使用者 2026-08-13 重新設計：先前把「猜 OS」跟「猜型號」當兩件獨立的事，
    「未分類」清單只用了 OS 規則去猜，涵蓋率很差——實際上這批 os 查不到的資產，
    資產用途欄裡藏的多半根本是**型號**資訊（3PAR／EMC／IBM Storage 這些），
    不是 OS 版本，選錯規則庫，猜不到不是規則不夠多，是問錯規則。

    這裡統一成一支：os 規則猜不到，換型號規則（用同一套已經驗證過、涵蓋率高
    很多的 normalize_model() hint 機制）再猜一次。

    ⚠️ 使用者 2026-08-13 再次要求：一開始只在「靠 hint 猜到」時才顯示，
    device_model 本身規則就直接認得出來（method="rule"）時刻意不顯示，
    理由是「已經看得到了不用重複」——但使用者反應「不顯示就不知道系統到底
    有沒有判斷對，跟完全沒查是同一種空白」。改成不管是規則直接認出來的還是
    靠 hint 猜的都回傳，用第三個回傳值 confirmed 區分：True＝規則/別名字典
    直接對到（可信），False＝靠 hint 猜的（僅供參考）——由前端決定用不同
    樣式呈現，但兩種狀況都要看得到，不能因為「應該已經知道了」就悄悄跳過。

    回傳 (值, 種類, confirmed)，種類是 "os" 或 "model"，都沒有回 (None, "", False)。
    """
    import normalize

    os_val = r["os"]
    os_matched = bool(os_val) and normalize.normalize_os(os_val, conn, r["device_model"])["matched"]
    if os_matched:
        return None, "", False  # os 本身就查得到，不需要猜

    if r["asset_purpose"]:
        os_guess = normalize.suggest_os_canonical(r["asset_purpose"])
        if os_guess:
            return os_guess, "os", False  # suggest_os_canonical 定義上只做「猜」，不算確認

    if r["device_model"]:
        model_info = normalize.normalize_model(r["device_model"], conn, _model_hint(r))
        if model_info["method"] != "unmatched" \
                and model_info["canonical"] not in normalize._HW_VM_PRODUCTS:
            confirmed = model_info["method"] in ("rule", "alias")
            return model_info["canonical"], "model", confirmed

    return None, "", False


@app.get("/api/arch/vcenter")
def arch_vcenter(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    """vCenter 虛擬化架構圖資料（從 CI 圖即時算，可下鑽到 ESXi）。"""
    import arch

    return arch.vcenter_topology(conn)


@app.get("/api/arch/ftp")
def arch_ftp(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    """FTP 主機架構圖資料（成員清單人維護存 app_settings，屬性 join hardware 真資料）。"""
    import arch

    return arch.ftp_diagram(conn)


@app.get("/api/arch/vm-placement/{asset_serial}")
def arch_vm_placement(
    asset_serial: str,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """這台 VM 歸哪個 VC/cluster、跑在哪台 ESXi（資產詳細頁用）。"""
    import arch

    return arch.vm_placement(conn, asset_serial)


@app.get("/api/eos/summary")
def eos_summary(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    """軟硬體 EOS 總覽：全站有幾台的 OS／硬體已過 EOS、一年內到期、還沒查到官方日期。

    只算有效資產（排除退役）——道理跟 composition() 一樣：停用/報廢的機器沒有
    「還要不要換」的問題，混進來會讓「還有幾台要處理」這個數字失真。
    """
    import eos
    import manage_state
    import normalize

    rows = conn.execute(
        "SELECT asset_serial, hostname, os, device_model, asset_status, asset_name, asset_purpose FROM hardware"
    ).fetchall()
    # 人工歸類覆寫（使用者 2026-08-12）：有些設備技術上偵測到的 OS 沒錯（例：Palo Alto
    # Panorama／Finika 底層真的跑 CentOS/Linux），但維護權責歸網路設備組，優先於自動分類。
    overrides = {
        r["canonical"]: r["category"]
        for r in conn.execute("SELECT canonical, category FROM eos_category_override")
    }

    def bump(d, k):
        d[k] = d.get(k, 0) + 1

    # 使用者 2026-08-12：伺服器/主機 OS 跟網路設備韌體要分開，因為要找不同的人維護；
    # 規則/字典都認不出來的（裸版本號、iDRAC 這類設備類型標籤）獨立一桶「未分類」——
    # 這桶正是使用者最需要人工補資料的清單，不能悄悄混進另外兩桶假裝有分類。
    # 使用者 2026-08-13：MySQL 這類資料庫軟體常被登打人員誤填進 OS 欄位，
    # 技術上偵測到的字串沒錯，但維護權責是「軟體」不是「作業系統」——跟 host_os/firmware
    # 一樣走人工覆寫（eos_category_override），不做自動關鍵字判斷，因為「哪些字串算軟體」
    # 沒有一致規則，交給人工補比較不會誤判。
    # 使用者 2026-08-13 追加「資訊不足」：像「網路設備」「儲存設備」「客製化系統」這種
    # 登打人員填的泛用設備類型標籤，不是規則認不出來（那是「未分類」的情境），是原始
    # 資料本身就沒有可辨識的產品資訊，兩種情況分開才不會讓「未分類」清單裡混進「查也沒用」
    # 的雜訊，稀釋掉真正還有機會補資料的項目。
    BUCKETS = ("host_os", "firmware", "software", "insufficient", "other")
    by_status: dict[str, dict[str, int]] = {b: {} for b in BUCKETS}
    items: dict[str, dict[str, dict]] = {b: {} for b in BUCKETS}
    hw_by_status: dict[str, int] = {}
    hw_items: dict[str, dict] = {}
    device_models_by_canonical: dict[str, dict[str, int]] = {}  # canonical os -> {device_model: 台數}

    for r in rows:
        if (r["asset_status"] or "").strip() in manage_state.RETIRED_STATUS:
            continue
        if r["os"]:
            os_info = normalize.normalize_os(r["os"], conn, r["device_model"])
            canonical = os_info["canonical"]
            if os_info["product"] in normalize.HW_ROUTED_PRODUCTS:
                # 使用者 2026-08-13：iDRAC／Unisphere Central 這類跟硬體綁死的管理
                # 軟韌體，維護權責跟隨它管理的硬體本身，直接併進硬體側對應分類，
                # 不落在 os 側五桶的任何一桶。
                hit = eos.lookup_os_eos(canonical)
                status = eos.eos_status(hit["eos_date"]) if hit else "unknown"
                bump(hw_by_status, status)
                hw_family = overrides.get(canonical, normalize.HW_ROUTED_PRODUCTS[os_info["product"]])
                entry = hw_items.setdefault(canonical, {
                    "name": canonical, "status": status,
                    "eos_date": hit["eos_date"] if hit else None,
                    "source_url": hit["source_url"] if hit else None,
                    "confidence": hit.get("confidence") if hit else None,
                    "note": hit.get("note") if hit else None,
                    "overridden": canonical in overrides,
                    "count": 0,
                    "family": hw_family, "vendor": os_info["vendor"],
                    "model_confirmed": True,  # iDRAC/Unisphere Central 這類是 os 值直接對到具體
                                               # 產品規則，不是靠 hint 猜的，永遠算 confirmed。
                    # 使用者 2026-08-13 實際發現：這批雖然顯示在硬體型號分頁，但 canonical
                    # 其實是 normalize_os() 算出來的，不是 normalize_model()——前端如果只憑
                    # 「顯示在硬體分頁」就假設是 device_model 種類去存改名覆寫，會存錯種類、
                    # 存了但查不到（跟「N台→」篩到0筆是同一個病灶）。這裡明講真正的種類，
                    # 前端改名時要用這個而不是自己用 _origin 猜。
                    "kind": "os",
                })
                entry["count"] += 1
                continue
            bucket = overrides.get(canonical) or normalize.os_category(os_info["product"], canonical)
            hit = eos.lookup_os_eos(canonical)
            status = eos.eos_status(hit["eos_date"]) if hit else "unknown"
            bump(by_status[bucket], status)
            family, linux_distro = normalize.os_family(os_info["product"], canonical)
            # 使用者 2026-08-13 要求：「未分類」清單裡，raw OS 值認不出來時，附上
            # 系統推測（見 _identity_guess()：OS 規則猜不到就換型號規則，不是只
            # 用 OS 規則）。只在第一次建這個 canonical 的項目時算一次——⚠️ 這對
            # 「N/A」這種很多不同資產共用同一個 raw 值的群組是已知限制：只反映
            # 群組裡第一台的猜測，不代表整組都一樣。要看每一台各自的推測，
            # 點「N 台 →」進資產清單，那邊逐列都有算（list_assets 的
            # identity_guess 欄位），不會被群組彙總擋住。
            suggested = None
            if bucket == "other":
                suggested, _, _ = _identity_guess(r, conn)
            entry = items[bucket].setdefault(canonical, {
                "name": canonical, "status": status,
                "eos_date": hit["eos_date"] if hit else None,
                "source_url": hit["source_url"] if hit else None,
                "confidence": hit.get("confidence") if hit else None,
                "note": hit.get("note") if hit else None,
                "count": 0,
                "family": family, "linux_distro": linux_distro, "vendor": os_info["vendor"],
                "overridden": canonical in overrides,
                "suggested": suggested,
            })
            entry["count"] += 1
            # 使用者 2026-08-12：光看「15.7(3)M8」這種裸版本號看不出是什麼設備，
            # 規則認不出來時尤其如此——附上這個版本掛在哪些機型上，人一看機型就知道
            # 這是什麼（例：機型是 Cisco Catalyst，就知道 15.7(3)M8 是 IOS 版本）。
            if r["device_model"]:
                dm_canonical = normalize.normalize_model(r["device_model"], conn, _model_hint(r))["canonical"]
                bump(device_models_by_canonical.setdefault(canonical, {}), dm_canonical)
        if r["device_model"]:
            model_info = normalize.normalize_model(r["device_model"], conn, _model_hint(r))
            canonical = model_info["canonical"]
            hw_family, hw_vendor = normalize.hardware_family(model_info["vendor"], canonical)
            if canonical in overrides:
                hw_family = overrides[canonical]  # 人工覆寫優先於自動判斷（跟 os 側同一張表）
            # 使用者 2026-08-13：「虛擬化」（VMware/KVM/Hyper-V 虛擬機、平台不明的裸
            # 「(VM)」標記）不是實體硬體，根本沒有 EOS 這回事可查——這台機器真正該追的
            # EOS 是它的作業系統，已經算在 host_os 那邊，所以不計入頭部四格統計，避免
            # 同一台機器的「查不到」被算兩次。但使用者後續要求清單本身還是要看得到
            # （純對照用途，「這批資產裡有哪些是虛擬機」），所以項目照樣建立，只是
            # 不 bump 統計數字，也不查 EOS（虛擬機沒有查的意義，直接標未公佈）。
            hit = None if hw_family == "虛擬化" else eos.lookup_hardware_eos(canonical)
            status = eos.eos_status(hit["eos_date"]) if hit else "unknown"
            if hw_family != "虛擬化":
                bump(hw_by_status, status)
            entry = hw_items.setdefault(canonical, {
                "name": canonical, "status": status,
                "eos_date": hit["eos_date"] if hit else None,
                "source_url": hit["source_url"] if hit else None,
                "confidence": hit.get("confidence") if hit else None,
                "note": hit.get("note") if hit else None,
                "overridden": canonical in overrides,
                "count": 0,
                "family": hw_family, "vendor": hw_vendor,
                # 使用者 2026-08-13 要求：硬體型號分頁也要看得出這個型號名是規則直接從
                # device_model 讀到的（confirmed）還是靠 hint（資產名稱/資產用途）
                # 猜出來的——跟 /api/assets 的 identity_guess_confirmed 同一個精神，
                # 只是這裡是彙總層級，只記第一筆建這個 canonical 的判斷方式。
                "model_confirmed": model_info["method"] in ("rule", "alias"),
                "kind": "device_model",  # 真的是從 normalize_model() 算出來的，跟上面
                                          # HW_ROUTED_PRODUCTS 分支（kind="os"）要分清楚。
            })
            entry["count"] += 1

    for bucket in BUCKETS:
        for canonical, entry in items[bucket].items():
            models = device_models_by_canonical.get(canonical, {})
            entry["device_models"] = [
                m for m, _ in sorted(models.items(), key=lambda kv: -kv[1])
            ]

    def sort_items(d: dict) -> list[dict]:
        order = {"expired": 0, "upcoming": 1, "unknown": 2, "ok": 3}
        return sorted(d.values(), key=lambda x: (order.get(x["status"], 9), -x["count"]))

    return {
        "host_os": {"by_status": by_status["host_os"], "items": sort_items(_merge_patch_versions(items["host_os"]))},
        "firmware": {"by_status": by_status["firmware"], "items": sort_items(_merge_patch_versions(items["firmware"]))},
        "software": {"by_status": by_status["software"], "items": sort_items(_merge_patch_versions(items["software"]))},
        "insufficient": {"by_status": by_status["insufficient"], "items": sort_items(_merge_patch_versions(items["insufficient"]))},
        "other": {"by_status": by_status["other"], "items": sort_items(_merge_patch_versions(items["other"]))},
        "hardware": {"by_status": hw_by_status, "items": sort_items(hw_items)},
    }


_VERSION_TAIL = re.compile(r"^(.*\d+\.\d+)\.\d+[A-Za-z0-9()]*$")


def _merge_patch_versions(items_by_canonical: dict) -> dict:
    """把只差小版本號、EOS 查詢結果完全一樣的項目合併成一列，純顯示用途——使用者
    2026-08-13 要求：畫面上一堆「Cisco Network OS 16.12」「16.12.07」看起來很雜，
    但查到的 EOS 日期/來源根本一樣，合併方便看統計。**不動資產本身**，只是把
    eos_summary() 回傳的顯示列合併，device_models/count 都照實加總。

    只有 eos_date／source_url／confidence 三個都相同才合併，避免小版本間 EOS
    其實不一樣時被誤蓋掉（例：某小版本剛好有查到延伸支援公告，其他沒有）。
    """
    groups: dict[tuple, list[dict]] = {}
    for entry in items_by_canonical.values():
        m = _VERSION_TAIL.match(entry["name"])
        base_name = m.group(1) if m else entry["name"]
        key = (base_name, entry["eos_date"], entry.get("source_url"), entry.get("confidence"))
        groups.setdefault(key, []).append(entry)

    merged: dict[str, dict] = {}
    for (base_name, _eos_date, _source_url, _confidence), group in groups.items():
        if len(group) == 1:
            merged[group[0]["name"]] = group[0]
            continue
        combined_models: list[str] = []
        seen_models: set[str] = set()
        for g in group:
            for model in g.get("device_models") or []:
                if model not in seen_models:
                    seen_models.add(model)
                    combined_models.append(model)
        merged[base_name] = {
            **group[0],
            "name": base_name,
            "count": sum(g["count"] for g in group),
            "device_models": combined_models,
            "merged_versions": sorted({g["name"] for g in group}),
        }
    return merged


@app.get("/api/eos/export")
def export_eos_summary(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    """匯出 EOS 頁面清單，每個分類一個分頁，逐資產列出（使用者 2026-08-13 要求，
    給 OS 帳號盤點交 AP 單位統計用途，AP部門/AP負責人/SP負責人依 D27 對應：
    使用單位=AP部門、使用者=AP負責人（AP User）、保管者=SP負責人（SP保管者））。

    跟 /api/normalize/pending/export 不一樣：那支只匯出「查不到」待補的清單，用來
    回填別名。這支是逐資產列出「這台在哪個分類」，一台資產若 OS 跟設備機型分屬
    不同分類（例：OS 是「軟體」但設備機型是「硬體型號」），會各自出現在對應分頁
    ——這是判斷依據本來就不同的兩件事，不能只選一邊。
    """
    import eos
    import manage_state
    import normalize

    PAGE_ORDER = ["作業系統", "網路設備", "硬體型號", "軟體", "資訊不足", "未分類"]
    OS_BUCKET_TO_PAGE = {
        "host_os": "作業系統", "firmware": "網路設備", "software": "軟體",
        "insufficient": "資訊不足", "other": "未分類",
    }
    STATUS_LABEL = {"expired": "已過 EOS", "upcoming": "一年內到期", "ok": "尚在支援期", "unknown": "未公佈"}
    # 使用者 2026-08-13 要求：前面欄位要對齊公司既有的專案工作表單格式（項目/階段/
    # 工作項目/主機IP/負責單位/負責人/開始日/結束日/工期(天)/狀態/備註/聯繫單單號），
    # 方便直接複製貼上去用；沒有資料可填的規劃性欄位（項目/階段/開始日/結束日/
    # 工期(天)/狀態）留空給人工填，不亂塞值。「負責單位」「負責人」先帶 AP部門/
    # AP負責人（跟後面詳細欄位同一個來源，方便對照）。其他細節資訊放後面。
    TEMPLATE_COLUMNS = [
        "項目", "階段", "工作項目", "主機/IP", "負責單位", "負責人",
        "開始日", "結束日", "工期(天)", "狀態", "備註", "聯繫單單號",
    ]
    DETAIL_COLUMNS = [
        "資產狀態", "主機名稱", "IP", "作業系統", "設備機型",
        "EOS狀態", "EOS日期", "可信度", "來源", "AP部門", "AP負責人", "SP負責人",
    ]
    COLUMNS = TEMPLATE_COLUMNS + DETAIL_COLUMNS

    rows = conn.execute(
        "SELECT asset_serial, hostname, ip, os, device_model, asset_status, "
        "asset_name, asset_purpose, usage_unit, user_name, custodian FROM hardware"
    ).fetchall()
    overrides = {
        r["canonical"]: r["category"]
        for r in conn.execute("SELECT canonical, category FROM eos_category_override")
    }

    sheets: dict[str, list] = {p: [] for p in PAGE_ORDER}

    def base_row(r):
        host_ip = " / ".join(v for v in (r["hostname"], r["ip"]) if v)
        return [
            "", "", "", host_ip, r["usage_unit"] or "", r["user_name"] or "",
            "", "", "", "", "", "",
            r["asset_status"] or "", r["hostname"] or "", r["ip"] or "",
            r["os"] or "", r["device_model"] or "",
        ]

    def eos_cols(hit):
        status = eos.eos_status(hit["eos_date"]) if hit else "unknown"
        return [
            STATUS_LABEL.get(status, status),
            hit["eos_date"] if hit else "",
            hit.get("confidence") if hit else "",
            hit.get("source_url") if hit else "",
        ]

    def tail(r):
        return [r["usage_unit"] or "", r["user_name"] or "", r["custodian"] or ""]

    for r in rows:
        if (r["asset_status"] or "").strip() in manage_state.RETIRED_STATUS:
            continue
        # OS 側跟設備機型側各自獨立判斷分類跟 EOS 查詢結果——一台資產若兩邊分屬不同
        # 分類（例：OS 是「軟體」但設備機型是「硬體型號」），或兩邊 EOS 結果不同
        # （這正是這次要補的欄位重點），都不能只選一邊代表，各自輸出一列。
        if r["os"]:
            os_info = normalize.normalize_os(r["os"], conn, r["device_model"])
            canonical = os_info["canonical"]
            if os_info["product"] in normalize.HW_ROUTED_PRODUCTS:
                hw_family = overrides.get(canonical, normalize.HW_ROUTED_PRODUCTS[os_info["product"]])
                page = "網路設備" if hw_family == "網路設備" else "硬體型號"
            else:
                bucket = overrides.get(canonical) or normalize.os_category(os_info["product"], canonical)
                page = OS_BUCKET_TO_PAGE[bucket]
            hit = eos.lookup_os_eos(canonical)
            sheets[page].append(base_row(r) + eos_cols(hit) + tail(r))
        if r["device_model"]:
            model_info = normalize.normalize_model(r["device_model"], conn, _model_hint(r))
            hw_canonical = model_info["canonical"]
            hw_family, _ = normalize.hardware_family(model_info["vendor"], hw_canonical)
            if hw_canonical in overrides:
                hw_family = overrides[hw_canonical]
            page = "網路設備" if hw_family == "網路設備" else "硬體型號"
            hit = None if hw_family == "虛擬化" else eos.lookup_hardware_eos(hw_canonical)
            sheets[page].append(base_row(r) + eos_cols(hit) + tail(r))

    wb = Workbook()
    wb.remove(wb.active)
    for page in PAGE_ORDER:
        ws = wb.create_sheet(page)
        ws.append(COLUMNS)
        for row_out in sheets[page]:
            ws.append(row_out)

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    fname = f"eos_full_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
    return StreamingResponse(
        buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{fname}"'},
    )


class EosCategoryOverrideBody(BaseModel):
    canonical: str
    category: str


@app.post("/api/eos/category-override")
def upsert_eos_category_override(
    body: EosCategoryOverrideBody,
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db),
):
    """人工把某個 canonical 名稱強制指定分類，優先於自動判斷。

    給 Palo Alto Panorama／Finika 這類「技術上偵測到的 OS 沒錯，但維護權責歸網路設備組」
    的情況用——這不是名稱認錯（normalize_alias 的情境），是分類權責跟技術判斷對不上。
    os 側跟 hardware 側共用這張表、共用這支端點，category 值兩邊字彙不同（os 側是
    host_os/firmware/other；hardware 側是網路設備/主機設備/儲存設備/虛擬化/其他），
    eos_summary() 分別在各自的迴圈用各自的字彙解讀，這裡只驗證值屬於兩邊之一即可。
    """
    valid = {
        "host_os", "firmware", "software", "insufficient", "other",
        "網路設備", "主機設備", "儲存設備", "虛擬化", "其他",
    }
    if body.category not in valid:
        raise HTTPException(400, f"category 不支援這個值：{body.category}")
    conn.execute(
        "INSERT INTO eos_category_override (canonical, category, overridden_by) VALUES (?, ?, ?) "
        "ON CONFLICT(canonical) DO UPDATE SET category = excluded.category, "
        "overridden_by = excluded.overridden_by, overridden_at = datetime('now','localtime')",
        (body.canonical, body.category, session["username"]),
    )
    conn.commit()
    return {"ok": True}


@app.delete("/api/eos/category-override/{canonical}")
def delete_eos_category_override(
    canonical: str,
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db),
):
    """撤銷覆寫，改回系統自動判斷的分類。"""
    cur = conn.execute("DELETE FROM eos_category_override WHERE canonical = ?", (canonical,))
    conn.commit()
    if cur.rowcount == 0:
        raise HTTPException(404, "查無此筆覆寫")
    return {"ok": True}


@app.get("/api/normalize/pending")
def normalize_pending(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    """列出規則跟別名字典都認不出來的原始值——EOS 頁「未分類」清單的資料來源，
    也是匯出待補 Excel 的資料來源。"""
    import normalize

    return normalize.pending_values(conn)


class NormalizeAliasBody(BaseModel):
    kind: str
    raw_value: str
    canonical: str
    note: str | None = None


@app.post("/api/normalize/alias")
def upsert_normalize_alias(
    body: NormalizeAliasBody,
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db),
):
    """人工補一筆「原始值 → 標準名稱」的對應。補完立刻生效——normalize.py 的
    _load_aliases() 每次都重新查表，沒有快取，不用重啟服務。"""
    import normalize

    if body.kind not in (normalize.KIND_OS, normalize.KIND_MODEL):
        raise HTTPException(400, f"kind 只接受 {normalize.KIND_OS} 或 {normalize.KIND_MODEL}")
    if not body.canonical.strip():
        raise HTTPException(400, "標準名稱不能是空的")
    conn.execute(
        "INSERT INTO normalize_alias (kind, raw_value, canonical, note) VALUES (?, ?, ?, ?) "
        "ON CONFLICT(kind, raw_value) DO UPDATE SET canonical = excluded.canonical, note = excluded.note",
        (body.kind, body.raw_value, body.canonical.strip(), body.note),
    )
    conn.commit()
    return {"ok": True}


class CanonicalOverrideBody(BaseModel):
    kind: str
    old_canonical: str
    new_canonical: str


@app.post("/api/normalize/canonical-override")
def upsert_canonical_override(
    body: CanonicalOverrideBody,
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db),
):
    """使用者 2026-08-13 要求：不管系統目前顯示的名稱是規則確認還是靠 hint 猜的，
    都能直接改成正確名稱，改完永遠照使用者的為準——跟 /api/normalize/alias
    不一樣：alias 是「原始字串 → 標準名」，只對還沒被規則收斂掉的原始值有用；
    這支是「系統目前算出來的 canonical → 使用者確認的正確 canonical」，對任何
    已經顯示出來的名稱都能用。補完立刻生效，normalize.py 每次都重新查表。
    """
    import normalize

    if body.kind not in (normalize.KIND_OS, normalize.KIND_MODEL):
        raise HTTPException(400, f"kind 只接受 {normalize.KIND_OS} 或 {normalize.KIND_MODEL}")
    if not body.new_canonical.strip():
        raise HTTPException(400, "新名稱不能是空的")
    conn.execute(
        "INSERT INTO normalize_canonical_override (kind, old_canonical, new_canonical, overridden_by) "
        "VALUES (?, ?, ?, ?) "
        "ON CONFLICT(kind, old_canonical) DO UPDATE SET new_canonical = excluded.new_canonical, "
        "overridden_by = excluded.overridden_by, overridden_at = datetime('now','localtime')",
        (body.kind, body.old_canonical, body.new_canonical.strip(), session["username"]),
    )
    conn.commit()
    return {"ok": True}


@app.delete("/api/normalize/canonical-override/{kind}/{old_canonical}")
def delete_canonical_override(
    kind: str,
    old_canonical: str,
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db),
):
    """撤銷改名，改回系統自動判斷的名稱。"""
    cur = conn.execute(
        "DELETE FROM normalize_canonical_override WHERE kind = ? AND old_canonical = ?",
        (kind, old_canonical),
    )
    conn.commit()
    if cur.rowcount == 0:
        raise HTTPException(404, "查無此筆覆寫")
    return {"ok": True}


@app.get("/api/normalize/alias")
def list_normalize_alias(
    kind: str | None = None,
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db),
):
    """列出目前已經補過的別名，給使用者對照/複查用。"""
    if kind:
        rows = conn.execute(
            "SELECT id, kind, raw_value, canonical, note, created_at FROM normalize_alias "
            "WHERE kind = ? ORDER BY created_at DESC", (kind,),
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT id, kind, raw_value, canonical, note, created_at FROM normalize_alias "
            "ORDER BY created_at DESC",
        ).fetchall()
    return [dict(r) for r in rows]


@app.delete("/api/normalize/alias/{alias_id}")
def delete_normalize_alias(
    alias_id: int,
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db),
):
    """撤銷一筆補錯的別名。"""
    cur = conn.execute("DELETE FROM normalize_alias WHERE id = ?", (alias_id,))
    conn.commit()
    if cur.rowcount == 0:
        raise HTTPException(404, "查無此筆別名")
    return {"ok": True}


@app.get("/api/normalize/pending/export")
def export_normalize_pending(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    """匯出「查不到 EOS 的待補清單」成 Excel，讓人（或 AI）離線查證後填「標準名稱」欄，
    再用 /api/normalize/pending/import 匯入回來。兩個工作表對應 normalize_alias 的
    kind='os'／'device_model'，欄位設計成填完直接可以匯入（不用改欄名/欄序）。
    """
    import normalize

    pending = normalize.pending_values(conn)

    # os 待補清單也附「掛在哪些機型上」——跟 EOS 頁「未分類」分頁同一個線索，
    # 光看裸版本號查不出是什麼，機型是唯一能推斷的依據。
    os_device_models: dict[str, dict[str, int]] = {}
    for r in conn.execute(
        "SELECT os AS v, device_model AS m, asset_name, asset_purpose FROM hardware "
        "WHERE os IS NOT NULL AND os != ''"
    ):
        if r["m"] and not normalize.normalize_os(r["v"], conn, r["m"])["matched"]:
            bucket = os_device_models.setdefault(r["v"], {})
            # 這裡之前漏傳 hint，同一輪其他呼叫點都已經補上（2026-08-13 全面稽核）：
            # 這欄純粹是給人看的提示文字，沒有比對用途，漏了不會造成 0 筆這種功能性
            # 錯誤，但補上讓提示文字跟其他地方顯示的名稱一致。
            dm = normalize.normalize_model(r["m"], conn, _model_hint(r))["canonical"]
            bucket[dm] = bucket.get(dm, 0) + 1

    wb = Workbook()
    ws = wb.active
    ws.title = "作業系統韌體"
    ws.append(["kind", "原始值", "掛在哪些機型上", "出現次數", "標準名稱（填這欄）", "備註"])
    for item in pending[normalize.KIND_OS]:
        models = os_device_models.get(item["raw_value"], {})
        model_str = "、".join(m for m, _ in sorted(models.items(), key=lambda kv: -kv[1]))
        ws.append([normalize.KIND_OS, item["raw_value"], model_str, item["count"], "", ""])

    ws2 = wb.create_sheet("硬體型號")
    ws2.append(["kind", "原始值", "出現次數", "標準名稱（填這欄）", "備註"])
    for item in pending[normalize.KIND_MODEL]:
        ws2.append([normalize.KIND_MODEL, item["raw_value"], item["count"], "", ""])

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    fname = f"eos_pending_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
    return StreamingResponse(
        buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{fname}"'},
    )


@app.post("/api/normalize/pending/import")
def import_normalize_pending(
    file: UploadFile = File(...),
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db),
):
    """匯入補好的待補清單 Excel：逐列讀「標準名稱」欄，非空就補一筆別名；
    空白代表使用者還沒查到，正常跳過，不算錯誤（不是每一列都必須這次補完）。
    """
    import normalize

    if not file.filename or not file.filename.lower().endswith(".xlsx"):
        raise HTTPException(400, "只接受 .xlsx 檔案")

    contents = file.file.read()
    with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as tmp:
        tmp.write(contents)
        tmp_path = Path(tmp.name)

    applied = 0
    skipped = 0
    errors: list[str] = []
    try:
        try:
            wb = load_workbook(tmp_path, read_only=True, data_only=True)
        except Exception as exc:  # noqa: BLE001 - openpyxl對壞檔案的錯誤型態不一，統一攔截如實回報
            raise HTTPException(400, f"匯入失敗，請確認檔案格式：{exc}") from exc

        for ws in wb.worksheets:
            rows = ws.iter_rows(values_only=True)
            header = next(rows, None)
            if not header:
                continue
            col = {str(h).strip(): i for i, h in enumerate(header) if h is not None}
            required = {"kind", "原始值", "標準名稱（填這欄）"}
            if not required.issubset(col.keys()):
                continue  # 不是這個匯出格式產生的工作表，跳過不當錯誤
            for row in rows:
                if row is None or all(c is None for c in row):
                    continue
                kind = row[col["kind"]]
                raw_value = row[col["原始值"]]
                canonical = row[col["標準名稱（填這欄）"]]
                note = row[col["備註"]] if "備註" in col else None
                if not canonical or not str(canonical).strip():
                    skipped += 1
                    continue
                if kind not in (normalize.KIND_OS, normalize.KIND_MODEL) or not raw_value:
                    errors.append(f"這列 kind/原始值格式不對，略過：{row}")
                    continue
                conn.execute(
                    "INSERT INTO normalize_alias (kind, raw_value, canonical, note) "
                    "VALUES (?, ?, ?, ?) ON CONFLICT(kind, raw_value) DO UPDATE "
                    "SET canonical = excluded.canonical, note = excluded.note",
                    (str(kind), str(raw_value), str(canonical).strip(),
                     str(note).strip() if note else None),
                )
                applied += 1
        wb.close()  # read_only 模式的 workbook 會一直握著檔案控制代碼，Windows 上
        # 不先關掉就刪暫存檔會噴 PermissionError（檔案仍被本行程佔用）——2026-08-12 實測踩到。
        conn.commit()
    finally:
        tmp_path.unlink(missing_ok=True)

    return {"applied": applied, "skipped": skipped, "errors": errors}


@app.post("/api/manage-state/collect")
def manage_state_collect(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    """對已納管的機器收 facts 並寫回資產（真 OS／序號／機型）。"""
    import manage_state

    return manage_state.collect_facts_into_assets(conn)


@app.post("/api/manage-state/refresh")
def manage_state_refresh(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    """手動觸發「試連所有已登記主機」。會花數秒到數十秒（每台一次 SSH）。"""
    import manage_state

    return manage_state.refresh_collect_status(conn)


class AssetUpdateBody(BaseModel):
    fields: dict


class ExemptBody(BaseModel):
    serials: list[str]
    reason: str
    kind: str | None = None


@app.post("/api/onboard-exempt")
def add_onboard_exempt(
    body: ExemptBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """標記為非納管設備（客製化系統／Oracle／廠商維護等）。原因必填。見 onboard_exempt。"""
    import onboard_exempt

    try:
        return onboard_exempt.add(conn, body.serials, body.reason, body.kind,
                                  session["username"] if session else None)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


class ExemptRemoveBody(BaseModel):
    serials: list[str]


@app.post("/api/onboard-exempt/remove")
def remove_onboard_exempt(
    body: ExemptRemoveBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """取消豁免：這台又要納管了。軟刪，紀錄留著。"""
    import onboard_exempt

    return {"removed": onboard_exempt.remove(conn, body.serials,
                                             session["username"] if session else None)}


@app.get("/api/onboard-exempt")
def list_onboard_exempt(
    include_removed: bool = False,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """目前被豁免的清單（誰標的、為什麼）。"""
    import onboard_exempt

    return {"items": onboard_exempt.list_all(conn, include_removed), "kinds": list(onboard_exempt.KINDS)}


class BatchStatusBody(BaseModel):
    serials: list[str]
    status: str
    reason: str
    scope: str = "single"      # [B-08] single＝只這幾筆（某服務下線）／machine＝整台


class ScopePreviewBody(BaseModel):
    serials: list[str]
    scope: str = "machine"


@app.post("/api/assets/scope-preview")
def asset_scope_preview(
    body: ScopePreviewBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """[B-08] 動作前預覽：「這個動作會改到這 N 筆」。scope=machine 展開成整台。"""
    import manage_state
    if body.scope not in ("single", "machine"):
        raise HTTPException(400, "scope 只能是 single 或 machine")
    serials = ([s for s in dict.fromkeys(body.serials) if s] if body.scope == "single"
               else manage_state.expand_to_machines(conn, body.serials))
    rows = manage_state.preview_rows(conn, serials)
    return {"scope": body.scope, "count": len(rows), "rows": rows}


@app.post("/api/assets/batch-status")
def batch_asset_status(
    body: BatchStatusBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """一次把多台資產改成停用／報廢／閒置（或改回使用中），每台記一筆 CIA 待異動。
    使用者 2026-09-15：「我有抓到一些設備已下線，我要怎麼變更」。原因必填。見 cia_pending。"""
    import cia_pending

    try:
        return cia_pending.batch_set_status(conn, body.serials, body.status, body.reason,
                                            session["username"] if session else None, scope=body.scope)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@app.get("/api/cia-pending")
def cia_pending_list(
    include_synced: bool = False,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """系統裡改了、CIA 清冊還沒改的東西（預設只列還沒同步的）。"""
    import cia_pending

    items = cia_pending.list_changes(conn, include_synced)
    return {"items": items, "open": sum(1 for i in items if not i["synced_at"])}


class CiaSyncedBody(BaseModel):
    ids: list[int]


@app.post("/api/cia-pending/synced")
def cia_pending_synced(
    body: CiaSyncedBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """使用者回報 CIA 清冊已改好。只標記、不刪（稽核軌跡）。"""
    import cia_pending

    return {"marked": cia_pending.mark_synced(conn, body.ids, session["username"] if session else None)}


@app.get("/api/cia-pending/export")
def cia_pending_export(
    include_synced: bool = False,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """CIA 待異動匯出 Excel，拿去改 CIA 清冊用。"""
    import cia_pending
    from urllib.parse import quote

    wb = Workbook()
    ws = wb.active
    ws.title = "CIA待異動"
    ws.append(cia_pending.EXPORT_HEADERS)
    for r in cia_pending.export_rows(conn, include_synced):
        ws.append(["" if v is None else v for v in r])
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    fname = f"CIA待異動_{_now_local()[:10]}.xlsx"
    return StreamingResponse(
        buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(fname)}"})


@app.put("/api/assets/{asset_serial}")
def update_asset(
    asset_serial: str,
    body: AssetUpdateBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """修改一台資產的欄位。

    在這之前系統**完全沒有編輯功能**——資料一旦進來就只能靠重新匯入 Excel 覆蓋，
    連打錯一個字都要重跑匯入。盤點系統的資料本來就會被持續修正，這是必要缺口。

    只接受 hardware 真實存在的欄位（擋掉亂塞）；asset_serial 是主鍵不給改
    （改序號等於換一台，會弄丟 personnel/software 的關聯）。空字串一律存成 NULL，
    否則「空」會有 '' 和 NULL 兩種寫法，篩選和排序就會分岔。
    """
    if conn.execute("SELECT 1 FROM hardware WHERE asset_serial = ?", (asset_serial,)).fetchone() is None:
        raise HTTPException(404, "查無此資產")

    cols = _sortable_columns(conn, "hardware")
    unknown = [k for k in body.fields if k not in cols]
    if unknown:
        raise HTTPException(400, f"不支援的欄位：{', '.join(sorted(unknown))}")

    cleaned = {k: (None if v == "" else v) for k, v in body.fields.items()}
    # 資產狀態改了要記「CIA 待異動」（2026-09-15）：CIA 清冊重匯會把系統裡改的蓋回去
    old_status = None
    if "asset_status" in cleaned:
        _row = conn.execute("SELECT asset_status FROM hardware WHERE asset_serial = ?",
                            (asset_serial,)).fetchone()
        if _row is None:
            # 序號不存在（已刪/打錯）→ 回 404，不要讓 fetchone()[0] 噴 TypeError→500
            raise HTTPException(404, f"查無此資產：{asset_serial}")
        old_status = _row[0]
    changed = update_hardware(conn, asset_serial, cleaned)
    if changed and "asset_status" in cleaned:
        import cia_pending

        cia_pending.record(conn, asset_serial, "asset_status", old_status, cleaned["asset_status"],
                           "資產詳細頁編輯", session["username"] if session else None)
    # 只有「人動過」才更新 manual_updated_at。updated_at 每次自動匯入都會被刷新
    # （dynassets_import 會寫），拿它當「有沒有人在維護」的指標，跑一次匯入就全部變新鮮，
    # 那個數字是假的（2026-08-15 自我檢查發現）。這欄是資料品質新鮮度的唯一依據。
    if changed:
        conn.execute(
            "UPDATE hardware SET manual_updated_at = ? WHERE asset_serial = ?",
            (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), asset_serial),
        )
        conn.commit()
    row = conn.execute("SELECT * FROM hardware WHERE asset_serial = ?", (asset_serial,)).fetchone()
    return {"updated_fields": changed and len(cleaned) or 0, "hardware": dict(row)}


class ProvisionInfo(BaseModel):
    """申請單來源資訊。source=direct（IT 自建）時整包可以不給。"""
    source: str = "direct"
    request_no: str | None = None
    applicant_unit: str | None = None
    applicant: str | None = None
    unit_manager: str | None = None
    form_date: str | None = None
    change_kind: str | None = None
    raw_fields: dict | None = None


class AssetCreateBody(BaseModel):
    fields: dict
    provision: ProvisionInfo | None = None


# 新資產的預設狀態：還沒過上線檢查前不是「使用中」。
# 刻意選一個不在 manage_state.RETIRED_STATUS 裡的新值——那組是「退役」語意（停用/報廢/
# 閒置），待上線是「還沒開始用」，兩者混在一起會讓報表把新機器算成退役。
PENDING_GOLIVE_STATUS = "待上線"


@app.post("/api/assets/manual")
def create_asset_manual(
    body: AssetCreateBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """手動新增一筆資產（CIA 資產清單欄位為主，見 field_mapping.json「硬體」）。

    在這之前系統唯一的建立資產方式是批次匯入（Excel/RVTools/dynassets）——臨時要
    單獨掛一台機器（例如先裝 Push Agent 才發現主機還沒登記），沒有比重跑整份匯入
    更輕的路可走。欄位規則跟 update_asset 共用（白名單、空字串轉 NULL）；
    asset_serial 必填且要唯一（跟批次匯入的 upsert 不同：手動新增遇到重複序號直接
    擋下，不靜默覆蓋既有資產）。

    2026-08-15 起這裡同時是「主機及網路異動需求單」的轉錄入口（provision）。兩種來源
    合併成同一支 API、同一份欄位：申請單位還沒有系統帳號，短期只能填 Word 交給 IT
    承辦人轉錄；等哪天開放讓他們自己上系統填，也只是「同一頁換一個人來填」，不用重做。
    送出後資產是「待上線」，要過上線前檢查表才會變成「使用中」（見 golive.py）。
    """
    asset_serial = str(body.fields.get("asset_serial") or "").strip()
    if not asset_serial:
        raise HTTPException(400, "資產序號必填")
    # 帳外前綴（DYN-/VC-/AUTO-）是系統給「掃到/vCenter 但沒登記」的資產用的——人工新增的
    # 是正式登記，用到這些前綴會被全站統計當成帳外（不計在管台），是資料錯。擋下（2026-09-19）。
    import system_report as _sr_new
    if _sr_new.is_off_book(asset_serial):
        raise HTTPException(
            400, f"資產序號不可用系統保留前綴 {'/'.join(_sr_new.OFF_BOOK_PREFIXES)}開頭"
                 "（那是給掃描/vCenter 帳外資產用的，人工登記請用正式序號）")
    if conn.execute("SELECT 1 FROM hardware WHERE asset_serial = ?", (asset_serial,)).fetchone():
        raise HTTPException(409, f"資產序號 {asset_serial} 已存在")

    cols = _sortable_columns(conn, "hardware")
    unknown = [k for k in body.fields if k not in cols]
    if unknown:
        raise HTTPException(400, f"不支援的欄位：{', '.join(sorted(unknown))}")

    # 只擋「使用中」的撞號——已停用/報廢/閒置的資產，IP 合法可能被重新分配，
    # 連這種正常情境都擋死只會逼使用者硬改資料才過得了關，防呆變成擋路。
    ip = str(body.fields.get("ip") or "").strip()
    if ip:
        conflict = conn.execute(
            "SELECT asset_serial, hostname FROM hardware WHERE ip = ? AND asset_status = '使用中'",
            (ip,),
        ).fetchone()
        if conflict:
            raise HTTPException(
                409,
                f"IP {ip} 已經被使用中的資產 {conflict['asset_serial']}"
                f"（{conflict['hostname'] or '未填主機名稱'}）使用，請確認是不是同一台",
            )

    cleaned = {k: (None if v == "" else v) for k, v in body.fields.items() if k != "id"}
    cleaned["asset_serial"] = asset_serial
    # 沒指定狀態就是「待上線」；使用者自己選了狀態就尊重他（例如補登記一台早就在跑的機器）
    if not cleaned.get("asset_status"):
        cleaned["asset_status"] = PENDING_GOLIVE_STATUS
    insert_hardware(conn, **cleaned)

    p = body.provision or ProvisionInfo()
    if p.source == "form" and not (p.request_no or "").strip():
        raise HTTPException(400, "依申請單轉錄時，單據編號必填")
    conn.execute(
        "INSERT INTO provision_request "
        "(asset_serial, source, request_no, applicant_unit, applicant, unit_manager, "
        " form_date, change_kind, raw_fields, created_by, created_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (
            asset_serial, p.source, p.request_no, p.applicant_unit, p.applicant,
            p.unit_manager, p.form_date, p.change_kind,
            json.dumps(p.raw_fields, ensure_ascii=False) if p.raw_fields else None,
            session["username"],
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        ),
    )
    conn.commit()

    # 一併開一份上線檢查表，並先跑一次 auto 判定（機器測得到的先填好，人只處理剩下的）
    golive.ensure_check(conn, asset_serial)
    golive.refresh_auto_results(conn, asset_serial)

    row = conn.execute("SELECT * FROM hardware WHERE asset_serial = ?", (asset_serial,)).fetchone()
    return {"hardware": dict(row), "golive": golive.get_check_detail(conn, asset_serial)}


# 選單值上限：欄位現有值的「種類數」在這個範圍內才當成選單（避免選錯字），超過代表
# 這欄本質上是自由填寫（型號/用途/機櫃號這類），硬做成選單只會塞爆下拉選單。
_MANUAL_OPTIONS_MAX_DISTINCT = 30


@app.get("/api/assets/manual/field-options")
def manual_field_options(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """手動新增表單用：哪些欄位該做成選單，選項是什麼——從現有資料算，不寫死。

    判斷依據：這欄「現有資料的種類數」夠少（<=30）就代表是類別型欄位（處別/部門/
    環境別這種），做成選單讓使用者選、不能亂打；種類數太多（型號/用途/IP 這種近乎
    每筆都不同）維持自由輸入，選單塞不下也沒意義。門檻是資料驅動的，欄位新增/資料
    累積了自然會跟著變，不用另外維護一份清單。

    保管者／使用者是人名，例外處理：不用 hardware 表自己的歷史值當選項（那份本來就
    可能有錯字——同一個人被打成兩三種寫法，選單只是把錯字原封不動搬進選項，防呆
    等於沒防），改用 personnel 表（人員維護，Excel「人員」分頁匯入的那份）的
    person_name 當唯一真相來源，且不受種類數上限限制（人員名冊本來就可能超過 30 人）。
    """
    _PERSON_NAME_FIELDS = ("custodian", "user_name")

    fields = [
        f for f in _table_columns(conn, "hardware")
        if f not in ("id", "asset_serial", *_PERSON_NAME_FIELDS)
    ]
    options: dict[str, list[str]] = {}
    for field in fields:
        rows = conn.execute(
            f"SELECT DISTINCT {field} FROM hardware "
            f"WHERE {field} IS NOT NULL AND TRIM({field}) != '' "
            f"ORDER BY {field} LIMIT {_MANUAL_OPTIONS_MAX_DISTINCT + 1}"
        ).fetchall()
        values = [str(r[0]) for r in rows]
        if 1 <= len(values) <= _MANUAL_OPTIONS_MAX_DISTINCT:
            options[field] = values

    person_rows = conn.execute(
        "SELECT DISTINCT person_name FROM personnel "
        "WHERE person_name IS NOT NULL AND TRIM(person_name) != '' ORDER BY person_name"
    ).fetchall()
    person_names = [str(r[0]) for r in person_rows]
    if person_names:
        for field in _PERSON_NAME_FIELDS:
            options[field] = person_names
    return options


# ===== 單據檔案室（既有 Word 表單的歸檔與索引）=====

def _doc_archive_dir() -> Path:
    d = get_db_path().parent / "doc_archive"
    d.mkdir(parents=True, exist_ok=True)
    return d


@app.post("/api/documents/import")
def documents_import(
    files: list[UploadFile] = File(...),
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """批次歸檔既有的 Word 單據（.doc／.docx 都吃）。

    只抽識別欄位建索引、把原檔存起來，**不解析表格內容**（見 doc_import.py 檔頭）。
    一份檔案失敗不能讓整批中斷——那會逼使用者一次次試錯找出是哪一份有問題。
    """
    import doc_import

    ok, failed = [], []
    for f in files:
        name = Path(f.filename or "doc").name
        try:
            with tempfile.NamedTemporaryFile(delete=False, suffix=Path(name).suffix) as tmp:
                tmp.write(f.file.read())
                tmp_path = Path(tmp.name)
            try:
                ok.append(doc_import.import_document(
                    conn, tmp_path, _doc_archive_dir(), session["username"],
                    original_name=name, refresh=False,
                ))
            finally:
                tmp_path.unlink(missing_ok=True)
        except Exception as e:  # noqa: BLE001 - 逐份回報，不讓一顆壞蘋果毀掉整批
            failed.append({"file_name": name, "error": str(e)})
    # 整批做完才算一次「每個 IP 現行的是哪一張」——逐份跑是 O(N²) 的全表掃描。
    doc_import.refresh_current_flags(conn)
    return {
        "imported": len(ok), "failed": len(failed), "results": ok, "errors": failed,
        "auto_bound": sum(1 for r in ok if r["bind_confidence"] == "auto"),
        "need_review": sum(1 for r in ok if r["bind_confidence"] == "review"),
    }


@app.get("/api/documents")
def documents_list(
    confidence: str | None = Query(None),
    q: str | None = Query(None),
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """單據清單／搜尋。q 連 Word 內文一起搜——使用者以前要找一筆資料得把每份檔案
    打開來看，只搜檔名和單號等於沒解決那個問題。命中會附上片段。"""
    import doc_import

    return {
        "documents": doc_import.list_documents(conn, confidence, q),
        "summary": doc_import.summary(conn),
    }


@app.get("/api/documents/{doc_id}/download")
def documents_download(
    doc_id: int,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """下載原始 Word。索引查到了卻打不開原檔，等於沒歸檔。"""
    row = conn.execute("SELECT * FROM doc_archive WHERE id = ?", (doc_id,)).fetchone()
    if row is None:
        raise HTTPException(404, "找不到這份單據")
    path = Path(row["file_path"])
    if not path.exists():
        raise HTTPException(410, f"索引還在，但原始檔不見了：{row['file_name']}")
    # 全文檢索那份已遮掉帳密，但原始 Word 沒有（那是稽核證據，不能改）。
    # 既然一定要能下載，至少留下「誰在什麼時候看了哪一份」。
    conn.execute(
        "INSERT INTO doc_download_audit (doc_id, file_name, username, downloaded_at) "
        "VALUES (?, ?, ?, ?)",
        (doc_id, row["file_name"], session["username"],
         datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
    )
    conn.commit()
    return FileResponse(path, filename=row["file_name"])


class DocReviewBody(BaseModel):
    values: dict[str, str] | None = None


@app.post("/api/documents/{doc_id}/review")
def documents_review(
    doc_id: int,
    body: DocReviewBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """人工審核：確認或修正抽出來的規格值（CPU／記憶體／硬碟／OS 版本）。

    使用者 2026-08-15 要求的關卡。自由填寫欄抓歪不會報錯，唯一有效的防線就是有人看過；
    沒審過的值標成 pending，不參與任何比對，避免「沒人看過的數字被當成事實」。
    """
    import doc_import

    try:
        return doc_import.review_document(conn, doc_id, body.values, session["username"])
    except ValueError as e:
        raise HTTPException(404, str(e))


class DocBindBody(BaseModel):
    asset_serial: str | None = None


@app.post("/api/documents/{doc_id}/bind")
def documents_bind(
    doc_id: int,
    body: DocBindBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import doc_import

    try:
        doc_import.bind_document(conn, doc_id, body.asset_serial)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"ok": True}


@app.get("/api/assets/{asset_serial}/documents")
def asset_documents(
    asset_serial: str,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """這台資產的單據史（申請單、上線檢查表），含兩種單互相對應的關聯。"""
    import doc_import

    return {
        "documents": doc_import.documents_of_asset(conn, asset_serial),
        # 一台機器常有多張單（新增→異動→異動）：「當初申請多少」跟「現在應該多少」
        # 是兩個問題，時間軸兩個都答得出來
        "timeline": doc_import.asset_timeline(conn, asset_serial),
    }


# ===== 網段配置表 =====
# 來源是公司的「總分公司網段配置表」Excel。三個用途：IP 配置的三層選單、
# 掃描範圍的依據（弱掃說明的排除註記）、資料品質涵蓋率的分母。

@app.get("/api/segments")
def segments_list(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import segments

    return {"segments": segments.list_segments(conn)}


@app.get("/api/segments/tree")
def segments_tree(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """機房 → 環境 → 網段，給新增資產的 IP 選單用。"""
    import segments

    return {"tree": segments.tree(conn)}


@app.get("/api/segments/scan-candidates")
def segments_scan_candidates(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """該掃哪些網段／哪些被註記排除。資料品質頁「涵蓋率 0%」的下一步就是看這個。"""
    import segments

    return segments.scan_candidates(conn)


@app.get("/api/segments/ips")
def segments_ips(
    cidr: str = Query(...),
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """這段裡已登記的 IP 與建議可用的下一個。"""
    import segments

    try:
        return segments.segment_ips(conn, cidr)
    except ValueError as e:
        raise HTTPException(400, str(e))


@app.get("/api/segments/export-template")
def segments_export_template(session: sqlite3.Row = Depends(require_auth)):
    """空白範本（表頭＋一筆範例）。2026-08-25 使用者提出的通則：有匯入就要有配對的
    匯出範本，不然新使用者不知道要填什麼——這是「匯入網段配置表」旁邊那顆
    「⬇ 下載空白範本」的資料來源，緊鄰上傳按鈕（不是放頁首、不是放另一頁）。
    """
    import segments

    headers, example = segments.export_template_rows()
    wb = Workbook()
    ws = wb.active
    ws.title = "網段配置表範本"
    ws.append(headers)
    ws.append(example)
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    from urllib.parse import quote

    fname = "網段配置表_空白範本.xlsx"
    return StreamingResponse(
        buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(fname)}"},
    )


@app.get("/api/segments/export")
def segments_export(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """匯出目前系統裡的網段清單（可直接再匯入）。

    2026-08-26 使用者：「我是有匯入，我沒有匯出嗎？」——原本只有空白範本，
    資料進得去出不來，就沒辦法拿系統的清單去跟 Excel 對帳、也沒辦法把在系統裡
    修好的版本交回去。
    """
    import segments

    headers, rows = segments.export_current_rows(conn)
    wb = Workbook()
    ws = wb.active
    ws.title = "網段配置表"
    ws.append(headers)
    for r in rows:
        ws.append(r)
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    from urllib.parse import quote

    fname = f"網段配置表_{datetime.now().strftime('%Y%m%d')}.xlsx"
    return StreamingResponse(
        buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(fname)}"},
    )


@app.post("/api/segments/import")
def segments_import(
    file: UploadFile = File(...),
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """匯入網段配置表（Excel 為主，也吃 Tab 分隔文字檔）。

    **整批取代**：Excel 是這份清單的唯一真相，段被刪掉就該從系統消失。
    解析失敗（一格兩段、IP 範圍）的列照樣入庫並列進警告——靜默丟掉網段，
    之後不會有人發現，而「系統裡沒有這段」跟「這段不存在」是兩件事。
    """
    import segments

    name = Path(file.filename or "segments.xlsx").name
    if Path(name).suffix.lower() not in (".xlsx", ".xlsm", ".txt", ".tsv", ".csv"):
        raise HTTPException(400, "只接受 Excel（.xlsx）或 Tab 分隔文字檔")
    with tempfile.NamedTemporaryFile(delete=False, suffix=Path(name).suffix) as tmp:
        tmp.write(file.file.read())
        tmp_path = Path(tmp.name)
    try:
        summary = segments.import_segments(conn, tmp_path)
    except ValueError as e:
        raise HTTPException(400, str(e))
    finally:
        tmp_path.unlink(missing_ok=True)
    return {"file": name, **summary}


@app.get("/api/data-quality")
def data_quality_summary(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """資料品質量測：盤點清單到底準不準，用查得到來源的數字講。

    只對「有機器事實可以對照」的維度給正確率；保管者/用途/CIA 這種人為判斷欄位
    給填寫率與新鮮度，並在畫面上講清楚衡量的不是對錯——硬給正確率是在編數字。
    """
    import data_quality

    return data_quality.measure(conn)


@app.get("/api/data-quality/single-person-names")
def data_quality_single_names(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """只出現一次的人名——打錯字的高風險候選（2026-09-17 使用者：人名改可搜尋新增後，
    要有地方定期檢查是不是有人打錯字新增了近似名）。跨 使用者/保管者/人員名冊 統計，
    出現一次的列出來給人看（可能是真的只管一台，也可能是「李太明」打成「李太名」）。

    ⚠️ 路由要排在 /api/data-quality/{dim_key} 之前，否則 single-person-names 會被吃成 dim_key。"""
    rows = conn.execute(
        """WITH names AS (
               SELECT TRIM(user_name) AS n FROM hardware WHERE TRIM(COALESCE(user_name,'')) <> ''
               UNION ALL SELECT TRIM(custodian) FROM hardware WHERE TRIM(COALESCE(custodian,'')) <> ''
               UNION ALL SELECT TRIM(person_name) FROM personnel WHERE TRIM(COALESCE(person_name,'')) <> ''
           )
           SELECT n, COUNT(*) AS c FROM names GROUP BY n HAVING c = 1 ORDER BY n"""
    ).fetchall()
    return {"names": [r["n"] for r in rows], "total": len(rows)}


@app.get("/api/data-quality/field-fill")
def data_quality_field_fill(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """各欄位填充率（升冪，最低在前）＝「待補資料」清單：欄位先立好、機器後補，
    這裡一眼看出哪些欄位收得最少、該去補（呼應機房搬遷的欄位先立）。
    ⚠️ 路由要排在 /api/data-quality/{dim_key} 之前，否則會被吃成 dim_key。"""
    import hardware_master
    fields = hardware_master.field_dictionary(conn)
    fields.sort(key=lambda f: (f["fill_rate"] if f["fill_rate"] is not None else 1.0, f["column"]))
    total = conn.execute("SELECT COUNT(*) FROM hardware").fetchone()[0]
    return {"fields": fields, "total_rows": total}


@app.get("/api/data-quality/{dim_key}")
def data_quality_offenders(
    dim_key: str,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """某維度不合格的是哪幾台。數字一定要能下鑽，不然沒有行動意義。"""
    import data_quality

    return {"items": data_quality.list_offenders(conn, dim_key)}


# ===== 資產生命週期：申請單 → 上線前檢查 → 基線回檢 =====
# 模型見 golive.py 檔頭。這區的端點都圍著「一台資產一份檢查表」轉。

def _attachment_dir() -> Path:
    """簽核用的申請單掃描檔落地位置。放 DATA 底下跟 DB 同一層，
    才會被既有的每日備份（backup.py 備 DATA）一起帶走。"""
    d = get_db_path().parent / "provision_attachments"
    d.mkdir(parents=True, exist_ok=True)
    return d


@app.get("/api/assets/{asset_serial}/provision")
def get_provision(
    asset_serial: str,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """這台資產的申請單資訊（沒有就回 null，直接新增的資產也算沒有紙本單）。"""
    row = conn.execute(
        "SELECT * FROM provision_request WHERE asset_serial = ? ORDER BY id DESC LIMIT 1",
        (asset_serial,),
    ).fetchone()
    if row is None:
        return {"provision": None}
    d = dict(row)
    if d.get("raw_fields"):
        try:
            d["raw_fields"] = json.loads(d["raw_fields"])
        except ValueError:
            pass  # 存進去的不是合法 JSON 就原字串回去，不要讓整頁掛掉
    return {"provision": d}


@app.post("/api/assets/{asset_serial}/provision-attachment")
def upload_provision_attachment(
    asset_serial: str,
    file: UploadFile = File(...),
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """上傳簽核用的申請單（Word/PDF 掃描檔）。存原始檔，不解析。

    刻意不做 Word 解析自動建資產：那種表是巢狀表格＋□/☑ 符號，版面一動就抓歪，
    而且抓錯不會報錯，是「安靜把錯資料寫進盤點清單」——比沒有還糟。
    """
    row = conn.execute(
        "SELECT id FROM provision_request WHERE asset_serial = ? ORDER BY id DESC LIMIT 1",
        (asset_serial,),
    ).fetchone()
    if row is None:
        raise HTTPException(404, f"{asset_serial} 沒有申請單紀錄")

    name = Path(file.filename or "attachment").name
    if Path(name).suffix.lower() not in (".doc", ".docx", ".pdf", ".png", ".jpg", ".jpeg"):
        raise HTTPException(400, "只接受 Word／PDF／圖片掃描檔")
    # 檔名帶 asset_serial 與流水號，避免不同資產的同名檔互相覆蓋
    safe = f"{asset_serial}_{row['id']}_{name}"
    path = _attachment_dir() / safe
    path.write_bytes(file.file.read())

    conn.execute(
        "UPDATE provision_request SET attachment_name = ?, attachment_path = ? WHERE id = ?",
        (name, str(path), row["id"]),
    )
    conn.commit()
    return {"attachment_name": name}


@app.get("/api/assets/{asset_serial}/provision-attachment-file")
def download_provision_attachment(
    asset_serial: str,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """下載申請單的簽核掃描檔。存了卻打不開等於沒存（2026-08-15 自我檢查補上）。"""
    row = conn.execute(
        "SELECT attachment_name, attachment_path FROM provision_request "
        "WHERE asset_serial = ? AND attachment_path IS NOT NULL ORDER BY id DESC LIMIT 1",
        (asset_serial,),
    ).fetchone()
    if row is None:
        raise HTTPException(404, "這台資產沒有申請單附件")
    path = Path(row["attachment_path"])
    if not path.exists():
        raise HTTPException(410, f"紀錄還在，但原始檔不見了：{row['attachment_name']}")
    return FileResponse(path, filename=row["attachment_name"])


@app.get("/api/golive")
def golive_list(
    status: str = Query("open"),
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """上線檢查表清單（預設看還沒過的——那才是待辦）。"""
    rows = conn.execute(
        "SELECT g.*, h.hostname, h.ip, h.os, h.asset_status, h.asset_name "
        "FROM golive_check g LEFT JOIN hardware h ON h.asset_serial = g.asset_serial "
        "WHERE g.status = ? ORDER BY g.started_at DESC",
        (status,),
    ).fetchall()
    out = []
    for r in rows:
        detail = golive.get_check_detail(conn, r["asset_serial"])
        out.append({**dict(r), "total": detail["total"], "done": detail["done"]})
    return {"checks": out}


@app.get("/api/golive/{asset_serial}")
def golive_detail(
    asset_serial: str,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    if conn.execute(
        "SELECT 1 FROM hardware WHERE asset_serial = ?", (asset_serial,)
    ).fetchone() is None:
        raise HTTPException(404, f"找不到資產 {asset_serial}")
    golive.refresh_auto_results(conn, asset_serial)
    return golive.get_check_detail(conn, asset_serial)


class GoliveItemBody(BaseModel):
    item_key: str
    verdict: str


@app.post("/api/golive/{asset_serial}/item")
def golive_set_item(
    asset_serial: str,
    body: GoliveItemBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    try:
        golive.set_item_verdict(conn, asset_serial, body.item_key, body.verdict,
                                session["username"])
    except ValueError as e:
        raise HTTPException(400, str(e))
    return golive.get_check_detail(conn, asset_serial)


@app.post("/api/golive/{asset_serial}/pass")
def golive_pass(
    asset_serial: str,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """全部項目處理完才准通過；通過同時把資產轉「使用中」並把 auto 項存成基線。"""
    try:
        return golive.pass_check(conn, asset_serial, session["username"])
    except ValueError as e:
        raise HTTPException(400, str(e))


@app.get("/api/drift")
def drift_list(
    status: str = Query("open"),
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """基線失效清單：上線時刻意設定成這樣、現在不一樣了的項目。"""
    return {"drifts": golive.list_drift(conn, status if status != "all" else None)}


class DriftDispositionBody(BaseModel):
    status: str
    note: str | None = None


@app.post("/api/drift/{drift_id}/disposition")
def drift_disposition(
    drift_id: int,
    body: DriftDispositionBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """標記處置。沿用帳號盤點 finding_disposition 的精神：標過的下次回檢還記得，
    不要每天重新亮一次同一條紅燈；但 ack 只是「我知道了」，不代表基線改了——
    機器恢復成基線時仍然會自動轉 fixed。"""
    if body.status not in ("open", "ack", "fixed"):
        raise HTTPException(400, f"不支援的處置狀態：{body.status}")
    n = conn.execute(
        "UPDATE baseline_drift SET status = ?, note = ?, decided_by = ?, decided_at = ? "
        "WHERE id = ?",
        (body.status, body.note, session["username"],
         datetime.now().strftime("%Y-%m-%d %H:%M:%S"), drift_id),
    ).rowcount
    conn.commit()
    if not n:
        raise HTTPException(404, "找不到這筆基線失效紀錄")
    return {"ok": True}


@app.post("/api/drift/recheck")
def drift_recheck(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """手動觸發回檢。平常掛在每日掃描之後自動跑（見 scan_service）。"""
    return golive.run_drift_check(conn)


@app.get("/api/assets/manual/field-groups")
def manual_field_groups(session: sqlite3.Row = Depends(require_auth)):
    """手動新增表單的欄位分組（見 manual_form_groups.json）——29 個欄位攤平成一片沒人填得下去。

    注意跟 field_groups.json 不是同一回事：那份是「資產查詢頁先顯示哪些欄位」的常用/進階
    分層，這份是「新增表單怎麼分段排版」。兩者的分法本來就不同，不要合併。

    也獨立於 field_mapping.json：那份是「Excel 標題 → 欄位名」，匯入/匯出都靠它，
    分組硬塞進去要改 value 的型別，會一次打壞 excel_import、匯出表頭與匯入設定頁。
    這裡回傳的 key 是資料庫欄位名，前端拿去對 field_mapping 算出來的欄位清單即可。

    設定檔壞掉/讀不到不讓整頁掛掉：回空清單，前端會退回原本的單一格子排版。
    """
    path = Path(__file__).parent / "manual_form_groups.json"
    try:
        return {"groups": json.loads(path.read_text(encoding="utf-8"))["groups"]}
    except (OSError, ValueError, KeyError):
        return {"groups": []}


@app.get("/api/os-catalog")
def os_catalog(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """手動新增表單的作業系統欄位：分層選單（大類 → 發行版／產品 → 版本），不能亂打。

    OS 原始字串種類太多（正式環境 250+ 種），沒辦法像其他欄位一樣直接攤平成一個選單；
    但也不用另外維護一份分類表——直接復用既有、已經測過的 normalize_os()／os_family()
    （EOS 頁、儀表板平台統計都在用同一套），對現有資料裡每個不同的 os 字串分類一次，
    照 (大類, 發行版) 分組，組內選項是算好的 canonical 字串（使用者選到的就是標準名，
    不會把舊資料的雜亂寫法帶進新資產）。認不出來的字串歸進「其他／未分類」，不會憑空消失。
    """
    import normalize

    rows = conn.execute(
        "SELECT DISTINCT os FROM hardware WHERE os IS NOT NULL AND TRIM(os) != ''"
    ).fetchall()

    tree: dict[str, dict[str, set[str]]] = {}
    for r in rows:
        raw = r["os"]
        result = normalize.normalize_os(raw, conn)
        canonical = result["canonical"] or str(raw).strip()
        product = result["product"]
        family, linux_distro = normalize.os_family(product, canonical)
        distro_key = linux_distro if family == "Linux" else (product or "未分類")
        tree.setdefault(family, {}).setdefault(distro_key, set()).add(canonical)

    return {
        family: {distro: sorted(versions) for distro, versions in sorted(distros.items())}
        for family, distros in sorted(tree.items())
    }


NO_IMPORT_SENTINEL = "不匯入"


def _table_columns(conn: sqlite3.Connection, table: str) -> set[str]:
    return {row["name"] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()}


@app.get("/api/import/last")
def import_last(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    row = get_latest_import_log(conn)
    return dict(row) if row else None


@app.get("/api/import/field-mapping")
def import_field_mapping(session: sqlite3.Row = Depends(require_auth)):
    """D14精神：欄位對應可調整、不寫死。回傳目前的field_mapping.json內容。"""
    return load_mapping()


class FieldMappingBody(BaseModel):
    mapping: dict[str, dict[str, str]]


@app.put("/api/import/field-mapping")
def update_import_field_mapping(
    body: FieldMappingBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """value為「不匯入」的項目不寫入設定檔（等於移除對應）；其餘value要對得上目標資料表
    的實際欄位名稱（PRAGMA table_info動態查，不寫死欄位清單，schema改了這裡自動跟上）。

    _comment說明欄位：load_mapping()讀取時會把它拿掉（不是真的分頁對應資料），這裡存檔
    要把原本檔案裡的_comment原封放回去，不然存一次設定檔裡給後人看的說明文字就消失了。
    """
    cleaned: dict[str, dict[str, str]] = {}
    for sheet, columns in body.mapping.items():
        if sheet not in SHEET_CONFIG:
            raise HTTPException(400, f"不支援的分頁：{sheet}")
        valid_columns = _table_columns(conn, SHEET_CONFIG[sheet]["table"])
        cleaned[sheet] = {}
        for excel_header, system_field in columns.items():
            if system_field == NO_IMPORT_SENTINEL:
                continue
            if system_field not in valid_columns:
                raise HTTPException(
                    400, f"{sheet}分頁「{excel_header}」對應到不存在的欄位：{system_field}"
                )
            cleaned[sheet][excel_header] = system_field

    existing_raw = json.loads(MAPPING_PATH.read_text(encoding="utf-8"))
    to_write = {}
    if "_comment" in existing_raw:
        to_write["_comment"] = existing_raw["_comment"]
    to_write.update(cleaned)

    MAPPING_PATH.write_text(
        json.dumps(to_write, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return cleaned


@app.post("/api/import/excel")
def import_excel_upload(
    file: UploadFile = File(...),
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """故意用sync def（不是async def）：UploadFile.file是同步可讀的SpooledTemporaryFile，
    sync路由可以直接讀，不需要await。

    ⚠️ 原本這裡寫著「FastAPI 會把 get_db 依賴跟 sync 路由排進同一個 threadpool worker
    執行緒」——那個假設是錯的，並行時兩者可能落在不同 worker，會炸
    sqlite3「不同執行緒不能共用連線」。真正的修正在 db.get_connection()
    （check_same_thread=False），不是靠 sync/async 的寫法去賭執行緒。
    """
    if not file.filename or not file.filename.lower().endswith(".xlsx"):
        raise HTTPException(400, "只接受 .xlsx 檔案")

    contents = file.file.read()
    # 原始檔留一份（只留最新的），之後「匯出原始檔」才有東西可以給。
    # 存檔失敗不該讓匯入整個失敗——資料已經進去了，少一份存檔是小事，
    # 但要留下痕跡，不能讓人以為有存到。
    try:
        import import_export

        import_export.save_original("cia_excel", file.filename or "upload", contents)
    except Exception as exc:  # noqa: BLE001
        print(f"[import] 原始檔保存失敗（cia_excel，不影響匯入）：{exc}")

    with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as tmp:
        tmp.write(contents)
        tmp_path = Path(tmp.name)

    try:
        try:
            summary = import_excel(tmp_path, conn)
        except Exception as exc:  # noqa: BLE001 - openpyxl對壞檔案的錯誤型態不一，統一攔截如實回報
            raise HTTPException(400, f"匯入失敗，請確認檔案格式：{exc}") from exc
    finally:
        tmp_path.unlink(missing_ok=True)

    create_import_log(
        conn,
        imported_by=session["username"],
        hardware_count=summary["sheets"].get("硬體", {}).get("inserted", 0)
        + summary["sheets"].get("硬體", {}).get("updated", 0),
        personnel_count=summary["sheets"].get("人員", {}).get("inserted", 0)
        + summary["sheets"].get("人員", {}).get("updated", 0),
        software_count=summary["sheets"].get("軟體", {}).get("inserted", 0)
        + summary["sheets"].get("軟體", {}).get("updated", 0),
        error_count=len(summary["errors"]),
        source="cia_excel", file_name=file.filename,
    )
    return summary


RVTOOLS_LAST_DATA_AT = "rvtools_last_data_at"   # 上次成功匯入的那份檔案的「資料時間」


@app.post("/api/import/rvtools")
def import_rvtools_upload(
    file: UploadFile = File(...),
    data_at: str | None = Form(None),
    force: bool = Form(False),
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """S19 VC 採集器：吃一份 RVTools 匯出的 vCenter 盤點（vInfo 分頁）。

    每台 VM 走身分解析：對到既有資產就更新機器事實（不碰業務欄位），新的建成 VC- 資產，
    判不準的進人工審核佇列（不自動合併）。真實 vCenter 資料，非假資料。

    ## 時序保護（data_at / force）

    匯入是「後蓋前」，沒有時間概念——不小心傳了一份舊的匯出檔，裡面的 os／is_vm
    就會直接蓋掉比較新的值，而且系統沒有欄位變更歷史，蓋掉就救不回來
    （只能翻每日備份，超過保留天數就沒了）。

    所以這裡收 data_at（前端帶上傳檔案的最後修改時間），跟上次成功匯入的時間比：
    比上次舊就先擋下來、回報兩邊時間讓人確認，確定要覆蓋才帶 force=true 再送一次。
    沒帶 data_at 就照舊直接匯（例如 curl 手動呼叫），不強制。
    """
    import rvtools_import
    from db import get_setting, set_setting

    if not file.filename or not file.filename.lower().endswith(".xlsx"):
        raise HTTPException(400, "只接受 RVTools 匯出的 .xlsx 檔案")

    prev_at = get_setting(conn, RVTOOLS_LAST_DATA_AT, "") or ""
    if data_at and prev_at and not force and data_at < prev_at:
        # 用 409 而不是 400：這不是「檔案有問題」，是「請你確認一下」，
        # 前端要據此跳確認框而不是當成錯誤紅字。
        raise HTTPException(
            409,
            {
                "code": "stale_import",
                "message": "這份檔案的資料時間比系統現有的舊，直接匯入會用舊資料覆蓋新的。",
                "incoming_data_at": data_at,
                "current_data_at": prev_at,
                "hint": "確定要覆蓋就再送一次並帶 force=true。",
            },
        )

    contents = file.file.read()
    # 原始檔留一份（只留最新的），之後「匯出原始檔」才有東西可以給。
    # 存檔失敗不該讓匯入整個失敗——資料已經進去了，少一份存檔是小事，
    # 但要留下痕跡，不能讓人以為有存到。
    try:
        import import_export

        import_export.save_original("rvtools", file.filename or "upload", contents)
    except Exception as exc:  # noqa: BLE001
        print(f"[import] 原始檔保存失敗（rvtools，不影響匯入）：{exc}")

    with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as tmp:
        tmp.write(contents)
        tmp_path = Path(tmp.name)
    try:
        try:
            summary = rvtools_import.import_rvtools(tmp_path, conn)
        except ValueError as exc:
            # 「這份檔不對」——使用者自己就能判斷、能修（例如根本沒有 vInfo 分頁）
            raise HTTPException(400, f"匯入失敗，這份檔看起來不是 RVTools 匯出：{exc}") from exc
        except Exception as exc:  # noqa: BLE001
            # 其他例外是**我們自己的 bug**，不是使用者的檔案有問題。
            # 2026-08-20 踩過：五個貨真價實的 RVTools 匯出檔全部收到
            # 「請確認是 RVTools 匯出的檔：Object of type datetime is not JSON serializable」
            # ——訊息把責任推給使用者，害人去反覆檢查根本沒問題的檔案。
            # 分不出來就不要亂猜原因，如實說是系統的錯，並把錯誤原文給出來。
            raise HTTPException(
                500,
                f"匯入時系統發生錯誤（不是你的檔案有問題，請把這段訊息回報）："
                f"{type(exc).__name__}: {exc}",
            ) from exc
    finally:
        tmp_path.unlink(missing_ok=True)

    create_import_log(
        conn, imported_by=session["username"],
        hardware_count=summary["inserted"] + summary["updated"],
        personnel_count=0, software_count=0, error_count=len(summary["errors"]),
        source="rvtools", file_name=file.filename,
        # 這份是「哪天從 vCenter 匯出的」，不是「哪天匯進系統」。取不到就存 None，
        # 不拿匯入時間頂替——「不知道多舊」跟「是今天的」是完全不同的兩句話。
        exported_at=rvtools_import.export_time_from_filename(file.filename),
    )

    # 記下這份的資料時間，供下次比對。強制覆蓋舊資料時不要往回退，
    # 否則之後每一份新檔都會被拿來跟這個舊時間比，保護就失效了。
    if data_at and (not prev_at or data_at > prev_at):
        set_setting(conn, RVTOOLS_LAST_DATA_AT, data_at)
    summary["data_at"] = data_at or None
    summary["previous_data_at"] = prev_at or None
    return summary


@app.get("/api/import/log")
def list_import_log_endpoint(
    source: str | None = None, limit: int = 20,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """最近的匯入紀錄——2026-08-19 使用者原話「要有紀錄表讓我查」：一次要匯好幾份
    RVTools檔案時，需要看得出哪些已經匯過（檔名+時間），不用憑記憶判斷。
    source 篩選：rvtools/cia_excel/dynassets/scan_import；不帶就全部混著回。
    """
    if limit < 1 or limit > 100:
        raise HTTPException(400, "limit 只接受 1–100")
    return [dict(r) for r in list_import_log(conn, source=source, limit=limit)]


@app.get("/api/import/dynassets/export-template")
def dynassets_export_template(session: sqlite3.Row = Depends(require_auth)):
    """空白範本——同 segments 那支的理由。查證時發現的落差：畫面文案只講
    「需含 IP 欄」，但實際上還吃主機名／MAC／OS，範本要把全部欄位列出來，
    不能讓人以為只填 IP 就夠。
    """
    import dynassets_import

    headers, example = dynassets_import.export_template_rows()
    wb = Workbook()
    ws = wb.active
    ws.title = "存活清單範本"
    ws.append(headers)
    ws.append(example)
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    from urllib.parse import quote

    fname = "存活清單_空白範本.xlsx"
    return StreamingResponse(
        buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(fname)}"},
    )


@app.get("/api/import/{source}/export-template")
def import_export_template(source: str, session: sqlite3.Row = Depends(require_auth)):
    """其餘匯入的範例檔（系統類別／業務系統對照表／RVTools／CIA）。
    2026-09-10 使用者：「每一個都要範例檔案，不然 USER 不會知道要匯入什麼資料」。
    範例列以「範例」開頭，原封不動匯回來會被略過，見 import_templates。"""
    import import_templates
    from urllib.parse import quote

    try:
        fname, data = import_templates.build(source)
    except KeyError:
        raise HTTPException(404, f"沒有這種匯入的範例檔：{source}") from None
    return StreamingResponse(
        io.BytesIO(data),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(fname)}"},
    )


# ===== 每一種匯入都配一個匯出（2026-09-09）=====
# 使用者：「Dynaset 有匯入但沒有匯出的功能……我要選原始檔、Excel 的匯出，
# 跟 dump 格式的匯出。也要有 dump 格式的匯入」，並補「rvtools、CIA 資產清冊都要」。
#
# 三種格式回答的是**不同的問題**，不是同一份東西的三種包裝：
#   原始檔 = 當初送進來的那個檔（可能有系統看不懂而丟掉的欄位）
#   Excel  = 現在系統裡是什麼（正規化之後的）
#   dump   = 整包搬到另一台
# 混為一談會讓人以為匯出的 Excel 可以拿去跟來源系統對帳。
#
# ⚠️ dump 目前**不加密**（使用者 2026-09-09：「先不加密」）。裡面是完整的
# 資產／存活清單，畫面上要明講這件事，不要讓人當備份寄出去。


@app.get("/api/import/{source}/export/original")
def export_original(
    source: str,
    session: sqlite3.Row = Depends(require_auth),
):
    """把當初上傳的那個檔原樣送回去。

    **沒有就回 404 並說清楚為什麼**——這個功能上線之前的匯入沒有留原始檔
    （舊流程處理完就把暫存檔刪了）。這種時候不可以拿重新產生的檔頂替：
    那會讓人拿它去跟來源系統對帳，對不起來卻找不到原因。
    """
    import import_export

    try:
        path = import_export.original_for(source)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    if path is None:
        raise HTTPException(404, "這個來源沒有留原始檔——可能是還沒匯入過，"
                                 "或那次匯入早於「保留原始檔」這個功能上線之前")
    from urllib.parse import quote

    return StreamingResponse(
        io.BytesIO(path.read_bytes()),
        media_type="application/octet-stream",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(path.name)}"},
    )


@app.get("/api/import/{source}/export/excel")
def export_excel(
    source: str,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """現在資料庫裡這個來源的內容，做成 Excel。"""
    import import_export

    try:
        headers, rows = import_export.export_rows(conn, source)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE

    def _xl(v):
        # Excel 不收控制字元（\x00-\x08、\x0b…），openpyxl 遇到直接丟例外→整份匯出 500。
        # 從別的系統複製貼上的資料常夾帶，拿掉不影響可讀性（原始檔匯出不經過這裡，照原樣）。
        if v is None:
            return ""
        return ILLEGAL_CHARACTERS_RE.sub("", v) if isinstance(v, str) else v

    wb = Workbook()
    ws = wb.active
    ws.title = import_export.SOURCES[source].label[:31]
    ws.append([_xl(h) for h in headers])
    for r in rows:
        ws.append([_xl(v) for v in r])
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    from urllib.parse import quote

    fname = f"{import_export.SOURCES[source].label}_{_now_local()[:10]}.xlsx"
    return StreamingResponse(
        buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(fname)}"},
    )


@app.get("/api/import/{source}/export/dump")
def export_dump(
    source: str,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """整包搬家用的格式（gzip 過的 JSON）。**目前不加密。**"""
    import import_export

    try:
        data = import_export.build_dump(conn, source)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    from urllib.parse import quote

    fname = f"{source}_{_now_local()[:10].replace('-', '')}.webit3dump"
    return StreamingResponse(
        io.BytesIO(data),
        media_type="application/gzip",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(fname)}"},
    )


@app.get("/api/import/sources")
def list_import_sources(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """每個來源現在有什麼可以匯出——**畫面要靠這個決定按鈕能不能按**。

    「按了才發現沒有」跟「一開始就看得出沒有」差很多：前者會讓人以為系統壞了。
    """
    import import_export

    out = []
    for key, src in import_export.SOURCES.items():
        try:
            orig = import_export.original_for(key)
        except ValueError:
            orig = None
        try:
            _, rows = import_export.export_rows(conn, key)
            n = len(rows)
        except Exception:  # noqa: BLE001 - 單一來源壞掉不該讓整頁掛掉
            n = 0
        out.append({
            "key": key, "label": src.label, "row_count": n,
            "origin": src.origin,
            "has_original": orig is not None,
            "original_name": orig.name if orig else None,
            "original_size": orig.stat().st_size if orig else None,
        })
    return {"sources": out}


class DumpImportResult(BaseModel):
    source: str
    row_count: int
    headers: list[str]


@app.post("/api/import/dump/preview")
def import_dump_preview(
    file: UploadFile = File(...),
    session: sqlite3.Row = Depends(require_auth),
):
    """先看這個 dump 是什麼，**不寫入任何東西**。

    為什麼一定要有這一步：dump 匯入會覆蓋現有資料，而檔名看不出裡面是哪個
    來源、幾筆、什麼時候匯出的。讓人先看一眼再按，比事後還原便宜得多。
    """
    import import_export

    try:
        body = import_export.read_dump(file.file.read())
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    return {"source": body.get("source"), "row_count": body.get("row_count"),
            "headers": body.get("headers", [])[:50],
            "label": import_export.SOURCES.get(body.get("source"), None)
            and import_export.SOURCES[body["source"]].label}


# ===== 1-4 分佈統計（2026-09-10）=====
# 使用者要一頁「系統(APID) × 環境／機房」：預設前 10 大、其餘展開，
# 點一個系統下鑽到機房，再分 AP／DB。
#
# ⚠️ 三層的證據強度不同，回傳結構刻意讓畫面沒辦法混為一談：
#   系統／環境／機房 = 登記資料
#   AP／DB          = **推論**，而且 221 實測只推得出 7%（4444 台推不出來）
# 所以 roles 一定連「未分類」一起回，role_basis 明寫「推論」。
# 把 93% 藏起來畫成漂亮的圓餅圖，比不做這個功能更糟。


class AuthDisabledBody(BaseModel):
    enabled: bool
    confirm: str | None = None


@app.get("/api/admin/auth-disabled")
def get_auth_disabled(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """登入有沒有被關掉，以及是**哪一種方式**關的。

    分開回報 env 與設定：環境變數蓋過設定，畫面上如果只給一個開關卻關不掉
    （因為是 env 開的），使用者會以為按鈕壞了。
    """
    import os as _os

    return {
        "disabled": auth_disabled(conn),
        "by_env": _os.environ.get(AUTH_DISABLED_ENV, "").strip() in ("1", "true", "TRUE", "yes"),
        "env_name": AUTH_DISABLED_ENV,
    }


@app.put("/api/admin/auth-disabled")
def set_auth_disabled(
    body: AuthDisabledBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """開關「停用登入」。

    ⚠️ 打開＝**這台機器上的資料對所有連得到的人公開**。所以打開時要打字確認，
    關掉不用——**讓安全的方向比較好走**是刻意的。

    只有已登入的人能打開（這支掛了 require_auth）：如果沒有這個限制，
    就會變成「未登入的人自己把登入關掉」，那是後門不是開關。
    """
    if body.enabled and (body.confirm or "").strip() != "DISABLE-LOGIN":
        raise HTTPException(400, '要停用登入必須輸入「DISABLE-LOGIN」確認（防手滑），已取消。')
    conn.execute(
        "INSERT INTO app_settings (key, value) VALUES (?, ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (AUTH_DISABLED_SETTING, "1" if body.enabled else "0"))
    conn.commit()
    # 這件事一定要進操作紀錄——事後查「那段時間為什麼沒有登入紀錄」時，
    # 要找得到是誰、什麼時候關的
    try:
        activity.log(conn, username=session["username"], ip=None, method="PUT",
                     path="/api/admin/auth-disabled", status=200, duration_ms=0,
                     action=("停用登入" if body.enabled else "恢復登入"))
    except Exception:  # noqa: BLE001 - 記錄失敗不該讓設定失敗
        pass
    return {"ok": True, "disabled": auth_disabled(conn)}


NAV_LAYOUT_SETTING = "nav_layout"


def _can_edit_nav(session: sqlite3.Row, conn: sqlite3.Connection) -> bool:
    """選單順序限管理員改。判定：登入開著時只有 admin 帳號能改；
    登入停用（測試階段）時沒有真實身分可分辨，放行（本來就是單人在測）。"""
    return session["username"] == "admin" or auth_disabled(conn)


@app.get("/api/nav-layout")
def get_nav_layout(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    """全站共用的選單順序（存 app_settings）。沒設過回 null＝前端用內建預設。
    can_edit 告訴前端這個人能不能改（決定要不要顯示「選單編輯」）。"""
    row = conn.execute(
        "SELECT value FROM app_settings WHERE key = ?", (NAV_LAYOUT_SETTING,)).fetchone()
    layout = None
    if row and row["value"]:
        try:
            layout = json.loads(row["value"])
        except (ValueError, TypeError):
            layout = None
    return {"layout": layout, "can_edit": _can_edit_nav(session, conn)}


class NavLayoutBody(BaseModel):
    layout: list | None = None     # None／空＝清除覆寫、回到內建預設


@app.put("/api/nav-layout")
def set_nav_layout(
    body: NavLayoutBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """存全站選單順序（限管理員）。傳空＝清除、回到內建預設。"""
    if not _can_edit_nav(session, conn):
        raise HTTPException(403, "只有管理員（admin 帳號）能改選單順序")
    if not body.layout:
        conn.execute("DELETE FROM app_settings WHERE key = ?", (NAV_LAYOUT_SETTING,))
    else:
        conn.execute(
            "INSERT INTO app_settings (key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            (NAV_LAYOUT_SETTING, json.dumps(body.layout, ensure_ascii=False)))
    conn.commit()
    try:
        activity.log(conn, username=session["username"], ip=None, method="PUT",
                     path="/api/nav-layout", status=200, duration_ms=0,
                     action=("清除選單順序（回預設）" if not body.layout else "調整選單順序"))
    except Exception:  # noqa: BLE001
        pass
    return {"ok": True}


@app.get("/api/stats/systems")
def stats_systems(
    limit: int = 10,
    kind: str | None = None,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """業務系統 × 環境。

    limit<=0 代表全部（畫面上的「更多」）。
    kind：`infra` 只回基礎設施、`ap` 只回業務系統、不帶就全部
    （使用者 2026-09-10：「基礎跟 AP 系統要分開」）。
    """
    import system_stats

    if kind is not None and kind not in (system_stats.KIND_INFRA, system_stats.KIND_AP):
        raise HTTPException(400, f"kind 只能是 {system_stats.KIND_INFRA} 或 {system_stats.KIND_AP}")
    out = system_stats.by_system(conn, limit=None if limit <= 0 else limit, kind=kind)
    # 人工搬過的系統要能被畫面說明——不然使用者看到「虛擬化平台」在基礎設施那頁，
    # 下次有人問「這不是 N- 開頭嗎」就沒人答得出來
    out["kind_overrides"] = system_stats.kind_overrides()
    return out


class SystemClassBody(BaseModel):
    api_id: str
    sys_class: str = ""     # 第一類/第二類/第三類；空字串或「未分級」＝清除覆寫


@app.put("/api/systems/class")
def set_system_class_endpoint(
    body: SystemClassBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """手動改一個業務系統的分級——分級表沒涵蓋（未分級）或判錯時用。
    分級表重匯不會沖掉；傳空＝清除覆寫回到分級表判定。"""
    import business_system

    try:
        return business_system.set_system_class(conn, body.api_id, body.sys_class)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@app.get("/api/stats/systems/{api_id}")
def stats_system_drilldown(
    api_id: str,
    env: str | None = None,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """一個系統的下鑽：機房 × 環境，加上 AP／DB 推論。

    帶 `env` 就只算那個環境——對應畫面上點某一格數字的行為
    （使用者 2026-09-10：「譬如我點 207，這 207 機房各占多少」）。
    傳合併後的環境名（測試已含 UAT／DEV）。
    """
    import system_stats

    try:
        return system_stats.drilldown(conn, api_id, env=env)
    except ValueError as exc:
        raise HTTPException(404, str(exc)) from exc


@app.get("/api/stats/systems/{api_id}/assets")
def stats_cell_assets(
    api_id: str,
    env: str | None = None,
    location: str | None = None,
    role: str | None = None,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """交叉表某一格是哪幾台（使用者 2026-09-10：「板橋機房 DB 有 18 台，
    點進去要知道是哪 18 台」）。

    不能直接連資產查詢頁——**角色不是資料庫欄位**，是算出來的，
    那頁沒辦法用它篩選，硬連過去會篩出不同的一批，數字對不起來。
    """
    import system_stats

    items = system_stats.assets_in_cell(conn, api_id, env=env, location=location, role=role)
    return {"api_id": api_id, "env": env, "location": location, "role": role,
            "count": len(items), "items": items}


@app.get("/api/stats/lookup")
def stats_lookup(
    q: str,
    limit: int = 20,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """輸入主機名／IP／資產編號，回答「它屬於哪個系統」。

    下鑽的反方向（使用者 2026-09-10：「SEC01 是哪個 APID，我怎麼找不到」）。
    """
    import system_stats

    items = system_stats.lookup_host(conn, q, limit=limit)
    return {"query": q, "count": len(items), "items": items}


@app.get("/api/stats/vip-entries")
def stats_vip_entries(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """入口（VIP）清單：每個 VIP 後面幾台、影響幾個系統。
    來源是 CIA 登記的 VIP 欄，**未經 F5 驗證**（VIP 會浮動）。見 vip_view。"""
    import vip_view

    return vip_view.entries(conn)


@app.get("/api/stats/vip-entries/detail")
def stats_vip_entry_detail(
    value: str,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """一個入口後面是哪幾台、各掛哪些系統。"""
    import vip_view

    try:
        return vip_view.entry_detail(conn, value)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    except LookupError as exc:
        raise HTTPException(404, str(exc)) from exc


@app.get("/api/stats/role-coverage")
def stats_role_coverage(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """AP／DB 推論的整體涵蓋率——**這個數字要放在畫面上**。

    使用者要看的是「這個分類可不可信」，不是一張看起來分好了的圖。
    """
    import system_stats

    return system_stats.role_coverage(conn)


@app.get("/api/business-systems")
def list_business_systems(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """業務系統對照表 ＋ 對帳數字。

    只回「已匯入 N 筆」沒有用——人要知道的是**還有多少台查不到系統名稱**，
    以及那是「對照表缺代碼」還是「機器沒填 api_id」。兩者要補的地方不同。
    """
    import business_system

    return {"systems": business_system.list_all(conn),
            "coverage": business_system.coverage(conn)}


@app.get("/api/business-systems/class-count")
def business_system_class_count(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """匯入頁「系統類別對照表」那列的目前筆數：已分級幾個系統／對照表共幾個。
    2026-09-14 使用者：「明明寫成功 89 筆，但是目前筆數沒有」——那格原本寫死「—」。"""
    rated = conn.execute(
        "SELECT COUNT(*) FROM business_system WHERE sys_class IS NOT NULL "
        "AND length(trim(sys_class)) > 0").fetchone()[0]
    total = conn.execute("SELECT COUNT(*) FROM business_system").fetchone()[0]
    return {"rated": rated, "total": total}


@app.post("/api/business-systems/import-class")
def import_business_system_class(
    file: UploadFile = File(...),
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """匯入系統類別（第一／二／三類）——**只更新類別，其他欄位不碰**。

    跟 /api/business-systems/import 分開：那支會整列覆寫，拿只有類別的檔案去匯，
    AP 部門與負責人會被清空。詳見 business_system.import_class_file。
    """
    import business_system

    fn = (file.filename or "").lower()
    if not fn.endswith((".xlsx", ".csv")):
        raise HTTPException(400, "只接受 .xlsx 或 .csv（第一列是表頭）")
    contents = file.file.read()
    suffix = ".csv" if fn.endswith(".csv") else ".xlsx"
    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
        tmp.write(contents)
        tmp_path = Path(tmp.name)
    try:
        try:
            return business_system.import_class_file(tmp_path, conn)
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc
    finally:
        tmp_path.unlink(missing_ok=True)


@app.post("/api/business-systems/import")
def import_business_systems(
    file: UploadFile = File(...),
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """匯入 api_id → 系統名稱／AP 部門／AP 負責人 的對照表（.xlsx）。

    在這之前系統名稱是拿同一個 api_id 底下 MIN(asset_name) 湊的——
    「隨便挑一台機器的名字當系統名」，猜對是運氣。

    以 api_id 為鍵 upsert：對照表會重匯（改名、加新系統），重匯要更新同一筆
    而不是長出重複。欄名不寫死（決策 D14），可接受多種寫法。
    """
    import business_system

    fname = (file.filename or "").lower()
    ext = ".csv" if fname.endswith(".csv") else ".xlsx" if fname.endswith(".xlsx") else None
    if ext is None:
        raise HTTPException(400, "只接受 .xlsx 或 .csv（第一列是表頭）")
    contents = file.file.read()
    # 原始檔留一份（只留最新的），之後「匯出原始檔」才有東西可以給。
    # 存檔失敗不該讓匯入整個失敗——資料已經進去了，少一份存檔是小事。
    try:
        import import_export

        import_export.save_original("business_system", file.filename or f"upload{ext}", contents)
    except Exception as exc:  # noqa: BLE001
        print(f"[import] 原始檔保存失敗（business_system，不影響匯入）：{exc}")
    with tempfile.NamedTemporaryFile(suffix=ext, delete=False) as tmp:
        tmp.write(contents)
        tmp_path = Path(tmp.name)
    try:
        try:
            return business_system.import_file(tmp_path, conn)
        except Exception as exc:  # noqa: BLE001 - 壞檔／欄位對不上統一如實回報
            raise HTTPException(400, f"匯入失敗：{exc}") from exc
    finally:
        tmp_path.unlink(missing_ok=True)


@app.post("/api/import/dynassets")
def import_dynassets_upload(
    file: UploadFile = File(...),
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """dynassets 匯入：吃「存活掃描＋CMDB」清單（.csv／.xlsx），跟 CIA 登記對帳。

    每列走身分解析：對到既有資產就更新機器事實（不碰業務欄位）、掃到但沒登記的建成
    DYN- 資產（＝漏登記／帳外資產）、判不準的進人工審核佇列（不自動合併）。
    dynassets 是每次重新產生的存活快照，不做 RVTools 那種時序保護。
    """
    import dynassets_import

    fn = (file.filename or "").lower()
    if not (fn.endswith(".csv") or fn.endswith(".xlsx")):
        raise HTTPException(400, "只接受 dynassets 的 .csv 或 .xlsx 檔案")
    suffix = ".xlsx" if fn.endswith(".xlsx") else ".csv"

    contents = file.file.read()
    # 原始檔留一份（只留最新的），之後「匯出原始檔」才有東西可以給。
    # 存檔失敗不該讓匯入整個失敗——資料已經進去了，少一份存檔是小事，
    # 但要留下痕跡，不能讓人以為有存到。
    try:
        import import_export

        import_export.save_original("dynassets", file.filename or "upload", contents)
    except Exception as exc:  # noqa: BLE001
        print(f"[import] 原始檔保存失敗（dynassets，不影響匯入）：{exc}")

    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
        tmp.write(contents)
        tmp_path = Path(tmp.name)
    try:
        try:
            summary = dynassets_import.import_dynassets(tmp_path, conn)
        except Exception as exc:  # noqa: BLE001 - 壞檔/非dynassets格式統一如實回報
            raise HTTPException(400, f"匯入失敗，請確認是 dynassets 存活清單：{exc}") from exc
    finally:
        tmp_path.unlink(missing_ok=True)

    create_import_log(
        conn, imported_by=session["username"],
        hardware_count=summary["inserted"] + summary["updated"],
        personnel_count=0, software_count=0, error_count=len(summary["errors"]),
        source="dynassets", file_name=file.filename,
    )
    return summary


# ===== 網段存活掃描（手動新增資產的第二種入口：整段掃、勾選要納入哪些）=====
# 只認 nmap TCP connect（-sT，不用 root）打 22/445——這兩個 port 對得上「這台機器
# 收得到 SSH 或 SMB」，是我們實際會去操作的存活定義，不是任意 ping 存活就算。
# 只掃內網私有網段，避免被拿去對外部位址做連接埠掃描。

_SCAN_PORTS = "22,445"
_SCAN_MAX_HOSTS = 1024


def _assert_private_network(network: "ipaddress.IPv4Network | ipaddress.IPv6Network") -> None:
    if not network.is_private:
        raise HTTPException(400, "只能掃內網私有網段（10/8、172.16/12、192.168/16）")


class ScanDiscoverBody(BaseModel):
    cidr: str


@app.post("/api/assets/scan/discover")
def scan_discover(
    body: ScanDiscoverBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """網段存活掃描：回傳掃到的主機清單（機器事實而已），不寫資料庫。
    使用者從結果裡勾選要納入的主機，再呼叫 /api/assets/scan/import 才真的建資產。
    """
    try:
        network = ipaddress.ip_network(body.cidr.strip(), strict=False)
    except ValueError:
        raise HTTPException(400, "不是合法的網段格式（例：192.168.1.0/24 或單一 IP）")
    _assert_private_network(network)
    if network.num_addresses > _SCAN_MAX_HOSTS:
        raise HTTPException(400, f"網段太大（上限 {_SCAN_MAX_HOSTS} 個位址），請縮小範圍")

    try:
        proc = subprocess.run(
            ["nmap", "-sT", "-p", _SCAN_PORTS, "--open", "-oG", "-", str(network)],
            capture_output=True, text=True, timeout=120,
        )
    except FileNotFoundError:
        raise HTTPException(500, "系統未安裝 nmap，無法掃描")
    except subprocess.TimeoutExpired:
        raise HTTPException(504, "掃描逾時，請縮小網段範圍再試")

    existing = {
        r["ip"]: r["asset_serial"]
        for r in conn.execute("SELECT ip, asset_serial FROM hardware WHERE ip IS NOT NULL")
    }
    found = []
    for line in proc.stdout.splitlines():
        m = re.match(r"Host:\s+(\S+)\s+\(([^)]*)\)\s+Ports:\s+(.*?)(?:\s+Ignored State:|$)", line)
        if not m:
            continue
        ip, rdns, ports_str = m.groups()
        open_ports = [p.split("/")[0] for p in ports_str.split(",") if "/open/" in p]
        if not open_ports:
            continue
        hostname = rdns or None
        if not hostname:
            try:
                hostname = socket.gethostbyaddr(ip)[0]
            except (socket.herror, socket.gaierror, OSError):
                hostname = None
        found.append({
            "ip": ip, "hostname": hostname, "open_ports": open_ports,
            "already_registered": ip in existing,
            "existing_asset_serial": existing.get(ip),
        })
    return {"cidr": str(network), "found": found}


class ScanHostItem(BaseModel):
    ip: str
    hostname: str | None = None


class ScanImportBody(BaseModel):
    hosts: list[ScanHostItem]


@app.post("/api/assets/scan/import")
def scan_import(
    body: ScanImportBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """把使用者勾選的掃描結果納入資產清單。只有機器事實（IP/Hostname），沒有業務
    欄位——借道既有 dynassets 匯入管道（identity 解析／DYN- 序號／source_record
    都直接沿用），不重造一套規則。業務欄位事後用 PUT /api/assets/{serial} 補。
    """
    if not body.hosts:
        raise HTTPException(400, "沒有選擇任何主機")

    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".csv", delete=False, newline="", encoding="utf-8"
    ) as tmp:
        writer = csv.writer(tmp)
        writer.writerow(["IP", "Hostname"])
        for h in body.hosts:
            writer.writerow([h.ip, h.hostname or ""])
        tmp_path = Path(tmp.name)

    import dynassets_import
    try:
        summary = dynassets_import.import_dynassets(tmp_path, conn)
    finally:
        tmp_path.unlink(missing_ok=True)

    create_import_log(
        conn, imported_by=session["username"],
        hardware_count=summary["inserted"] + summary["updated"],
        personnel_count=0, software_count=0, error_count=len(summary["errors"]),
        source="scan_import",
    )
    return summary


# ===== 清空盤點資料（危險操作，打 ClearALL 才執行）=====

# 像 GitHub 刪 repo 那樣，要手動打這個字串才會清——防手滑。
_RESET_CONFIRM = "ClearALL"

# 只清「盤點／採集資料」。明確白名單，絕不誤清帳號/憑證/連線/設定。
# 用 defer_foreign_keys 把外鍵檢查延到 commit，全清後就一致，刪除順序不必講究。
#
# ⚠️ `onboard_audit` **刻意不在這裡**（2026-09-09 使用者問出來的）：
#
#   清空之後目標主機上的收集帳號與金鑰**還在**，是這套系統自己忘了它做過。
#   後果不只是畫面變空——「取消納管」按鈕靠這張表才會出現，紀錄沒了就再也
#   沒辦法從畫面把那些帳號收回來，它們變成沒人認領的孤兒帳號。
#   而且「誰在什麼時候、在哪台建了帳號」是**稽核軌跡**，金融業要留。
#
#   判準就是這段註解自己寫的那句：清的是「盤點／採集資料」，
#   不清「帳號／憑證／連線／設定」。納管紀錄記的是**我們對外做過的動作**，
#   屬於後者。清空再重匯之後，只要 IP 對得回來，納管狀態會自己回來。
#
# ⚠️ **順序有意義**（2026-09-09 公司機實測炸掉才知道）：子表要排在父表前面。
#   原本靠 `PRAGMA defer_foreign_keys=ON` 讓順序不重要，但**那行沒有生效**——
#   defer 只在「交易進行中」有效，而那行 PRAGMA 跑在第一個 DELETE 之前，
#   當下還沒有交易。結果外鍵當場就檢查，`DELETE FROM hardware` 直接爆
#   `FOREIGN KEY constraint failed`，整支端點回 500，畫面只顯示
#   「清空失敗，請稍後再試」——使用者完全看不出是哪裡卡住。
#
#   真正的兇手是 `ci_node`（5529 筆）指向 `hardware`，卻沒被加進這份名單。
#   那張表是後來做 CI 圖譜時新增的，加表的人沒想到清空這件事——
#   **這種漏法一定會再發生**，所以下面那條測試會掃整個 schema 擋住它
#   （`test_reset_inventory_api.py::test_任何指向清空名單的表都必須自己也在名單裡`）。
_RESET_TABLES = (
    # CI 圖譜（衍生資料，指向 hardware）——一定要排在 hardware 前面
    "ci_edge", "ci_node",
    "host_api_key", "host_metric_latest",
    "merge_review", "source_record",
    "finding_disposition", "account_finding", "account_collect_runs", "host_account",
    "service_collect_runs", "host_service",
    "software_collect_runs", "package_change", "host_package",
    "comparison_result", "scan_history", "scan_runs",
    "system_deps", "systems",
    "duplicate_dismiss",
    "software", "personnel", "hardware",
    "import_log",
)

#: 清空**絕不能**碰的表。列出來是為了讓它成為一條會被測試盯著的規則，
#: 而不是「希望以後沒人手滑加回去」。
_RESET_NEVER = ("onboard_audit", "users", "app_settings", "collector_credential")


class ResetConfirm(BaseModel):
    confirm: str


@app.post("/api/admin/reset-inventory")
def reset_inventory(
    body: ResetConfirm,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """清空所有盤點／採集資料，回到「有設定、無資料」的空白，供重新匯入。

    ⚠️ 破壞性且不可逆（只能靠備份還原）。必須 confirm == "ClearALL" 才執行。
    清：資產/人員/軟體、來源紀錄、待審、帳號盤點、服務、掃描、業務系統、匯入紀錄。
    不動：登入帳號(users)、憑證庫(collect_credential)、連線設定、授權網段、
         功能開關、系統設定(app_settings)、正規化別名。
    """
    if body.confirm != _RESET_CONFIRM:
        raise HTTPException(400, f'要清空必須輸入「{_RESET_CONFIRM}」確認（防手滑），已取消。')
    deleted: dict[str, int] = {}
    try:
        for t in _RESET_TABLES:
            deleted[t] = conn.execute(f"DELETE FROM {t}").rowcount
        conn.commit()
    except sqlite3.IntegrityError as exc:
        # 外鍵擋住＝有表指向正要清的表，卻不在名單裡。
        # **一定要把是哪一張講出來**：原本這裡直接 500，畫面只顯示「清空失敗，
        # 請稍後再試」，查了很久才知道是 ci_node（2026-09-09）。
        conn.rollback()
        done = [t for t in _RESET_TABLES if t in deleted]
        stuck = _RESET_TABLES[len(done)] if len(done) < len(_RESET_TABLES) else "（未知）"
        raise HTTPException(
            500,
            f"清空在「{stuck}」這一步被外鍵擋住，已全部復原（一筆都沒刪）。"
            f"原因是有別的表指向它、但沒被列入清空範圍。"
            f"請把這句話回報給開發：{exc}") from exc
    except sqlite3.Error as exc:
        conn.rollback()
        raise HTTPException(500, f"清空失敗，已全部復原（一筆都沒刪）：{exc}") from exc
    return {"ok": True, "cleared": deleted, "total_rows": sum(deleted.values()),
            "by": session["username"]}


@app.get("/api/merge-reviews")
def list_merge_reviews(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    """待人工判定的合併案（身分解析判不準的）。空＝沒有懸而未決的。

    這些是「同 IP 但不同 UUID」這種不敢自動合併的案子——攤開來讓人決定，
    不要藏著，否則等於資料默默對不上卻沒人知道。
    """
    rows = conn.execute(
        "SELECT mr.id, mr.reason, mr.candidates, mr.status, mr.created_at, "
        "sr.source, sr.payload FROM merge_review mr "
        "JOIN source_record sr ON sr.id = mr.source_record_id "
        "WHERE mr.status = 'open' ORDER BY mr.id DESC LIMIT 200").fetchall()
    out = []
    for r in rows:
        d = dict(r)
        try:
            d["candidates"] = json.loads(d["candidates"]) if d["candidates"] else []
            d["payload"] = json.loads(d["payload"]) if d["payload"] else {}
        except (ValueError, TypeError):
            pass
        out.append(d)
    return out


def _short_host(name: str | None) -> str:
    """FQDN 取第一段並轉大寫。

    vCenter 回報的是 FQDN（srv-abc-1234.corp.example.com），CIA 的 Excel 是人填的短名
    且慣例全大寫（SRV-ABC-1234）。兩邊指同一台機器，卻因為一個有網域後綴、一個沒有，
    在身分解析時對不上而全部落到人工審核。切掉網域再統一大小寫才比得出來。
    """
    return (name or "").strip().split(".")[0].upper()


# 可自動合併的判定規則：短名與 IP 同時相符。
# 為什麼這個組合敢自動合併：
#   · 主機名相符 → 指向同一台的可能性高，但主機名可能重複（dev/prod 同名）
#   · IP 相符   → 也高，但 IP 會被回收再指派
#   兩者「同時」相符，還要落在同一筆既有資產上，才算數。任一項不符就不碰，留給人看。
# 這不是最強識別碼（vm_uuid），所以仍然要人按一次確認鈕，只是不必逐筆按 494 次。
def _s_lower(v) -> str:
    return "" if v is None else str(v).strip().lower()


_AUTO_RULE = "short_name_and_ip"
# 第二條規則：vCenter 帶 vm_uuid、資產那邊還沒填 → 合併就是在補身分證號。
# 判定與守衛全部在 merge_autoresolve.plan()，這裡不重寫一份，否則兩邊會走鐘。
_UUID_RULE = "vcenter_uuid_backfill"


def _scan_auto_matchable(conn: sqlite3.Connection) -> list[dict]:
    """掃出「切掉網域後主機名與 IP 同時相符」的待審案，回傳配對結果。

    每次都重新從資料庫算，不信任前端傳來的 id 清單——避免畫面上看到的候選
    與實際執行時的資料已經不同（例如中間有人改了資產）。
    """
    hw = conn.execute(
        "SELECT id, asset_serial, hostname, ip FROM hardware "
        "WHERE hostname IS NOT NULL AND length(trim(hostname)) > 0 "
        "AND ip IS NOT NULL AND length(trim(ip)) > 0"
    ).fetchall()
    # (短名, IP) -> 既有資產。同鍵有多筆就整組排除：那代表既有資料本身重複，
    # 亂挑一筆合併會把資料釘在錯的那台上。
    index: dict[tuple[str, str], list[sqlite3.Row]] = {}
    for r in hw:
        index.setdefault((_short_host(r["hostname"]), (r["ip"] or "").strip()), []).append(r)

    rows = conn.execute(
        "SELECT mr.id, mr.reason, sr.id AS sr_id, sr.payload FROM merge_review mr "
        "JOIN source_record sr ON sr.id = mr.source_record_id "
        "WHERE mr.status = 'open'"
    ).fetchall()

    out = []
    for r in rows:
        try:
            d = json.loads(r["payload"]) if r["payload"] else {}
        except (ValueError, TypeError):
            continue
        h = (d.get("hostname") or "").strip()
        ip = (d.get("ip") or "").strip()
        if not h or not ip:
            continue
        hits = index.get((_short_host(h), ip)) or []
        if len(hits) != 1:      # 0 筆＝對不上；>1 筆＝既有資料重複，都不自動處理
            continue
        target = hits[0]
        out.append({
            "review_id": r["id"],
            "source_record_id": r["sr_id"],
            "incoming_hostname": h,
            "incoming_ip": ip,
            "target_id": target["id"],
            "target_serial": target["asset_serial"],
            "target_hostname": target["hostname"],
            "payload": d,
        })
    return out


@app.get("/api/merge-reviews/auto-matchable")
def merge_reviews_auto_matchable(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    """待審案裡有多少可以用「短名＋IP 同時相符」自動配對。

    1,004 筆待審一筆筆看是做不完的，而其中大半只是「vCenter 給 FQDN、Excel 填短名」
    這一個原因。先算出可安全批次處理的數量，剩下的才值得花人力逐筆判斷。
    """
    total_open = conn.execute(
        "SELECT COUNT(*) FROM merge_review WHERE status = 'open'"
    ).fetchone()[0]
    m = _scan_auto_matchable(conn)

    # 第二條規則（2026-08-24）：實查 221 發現 3333 筆待審裡有 2140 筆的證據其實比
    # 這條短名規則更強——vCenter 帶著 vm_uuid，而資產那邊 uuid 是空的。畫面上兩條
    # 規則各自列出「可解幾筆／幾台」與樣本，讓人分開判斷、分開執行。
    import merge_autoresolve

    up = merge_autoresolve.plan(conn)
    uuid_rule = {
        "rule": _UUID_RULE,
        "rule_label": "vCenter 有 vm_uuid、資產這邊還沒填（合併＝補上身分證號）",
        "matchable": len(up["resolvable"]),
        # 「幾筆」跟「幾台」是兩個數字：重複匯入讓同一台被記了好幾筆待審核，
        # 只講筆數會讓人以為要判斷 2140 次。
        "distinct_assets": up["distinct_assets"],
        "skipped": up["skipped"],
        "samples": [
            {
                "incoming_hostname": x["source_hostname"],
                "incoming_ip": x["source_ip"],
                "target_serial": x["asset_serial"],
                "target_hostname": x["asset_hostname"],
                "target_ip": x["asset_ip"],
                "vm_uuid": x["vm_uuid"],
                "matched_on": x["matched_on"],
            }
            for x in up["resolvable"][:10]
        ],
    }

    return {
        "total_open": total_open,
        "matchable": len(m),
        "remaining": total_open - len(m),
        "rule": _AUTO_RULE,
        "rule_label": "切掉網域後主機名與 IP 同時相符",
        "uuid_rule": uuid_rule,
        # 給畫面看幾筆長什麼樣，確認規則沒抓錯再按執行
        "samples": [
            {
                "incoming_hostname": x["incoming_hostname"],
                "incoming_ip": x["incoming_ip"],
                "target_serial": x["target_serial"],
                "target_hostname": x["target_hostname"],
            }
            for x in m[:10]
        ],
    }


class BatchMergeBody(BaseModel):
    rule: str


@app.post("/api/merge-reviews/batch-merge")
def merge_reviews_batch_merge(
    body: BatchMergeBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """把可自動配對的待審案一次併進既有資產。

    只接受預先定義好的規則名稱，不接受前端傳 id 清單——後者等於把「要合併哪些」
    的決定權交給畫面，一旦畫面算錯就會把資料併到錯的機器上，而合併錯不會噴錯、很難救。

    合併時**只寫機器事實**（os／vm_uuid／is_vm／hostname），業務欄位（用途、保管者、
    機房、盤點單位）一律不動——那些是人維護的，vCenter 不知道也無權覆蓋。
    """
    if body.rule == _UUID_RULE:
        import merge_autoresolve

        return merge_autoresolve.apply(conn, session["username"])

    if body.rule != _AUTO_RULE:
        raise HTTPException(400, f"不支援的規則：{body.rule}")

    matches = _scan_auto_matchable(conn)
    FACTS = ("os", "vm_uuid", "is_vm")
    merged = 0
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    for m in matches:
        d = m["payload"]
        setters = {k: d[k] for k in FACTS if d.get(k) not in (None, "")}
        if setters:
            assigns = ", ".join(f"{k} = ?" for k in setters)
            conn.execute(
                f"UPDATE hardware SET {assigns}, updated_at = ? WHERE id = ?",
                (*setters.values(), now, m["target_id"]),
            )
        # 來源紀錄回填解析結果，之後查得出這筆是靠哪條規則併上去的
        conn.execute(
            "UPDATE source_record SET resolved_status = 'matched', resolved_hardware_id = ?, "
            "resolved_rule = ?, resolved_confidence = ? WHERE id = ?",
            (m["target_id"], f"batch:{_AUTO_RULE}", 0.9, m["source_record_id"]),
        )
        conn.execute(
            "UPDATE merge_review SET status = 'merged', decided_by = ?, decided_at = ? "
            "WHERE id = ? AND status = 'open'",
            (session["username"], now, m["review_id"]),
        )
        merged += 1
    conn.commit()

    remaining = conn.execute(
        "SELECT COUNT(*) FROM merge_review WHERE status = 'open'"
    ).fetchone()[0]
    return {"merged": merged, "remaining_open": remaining, "rule": _AUTO_RULE}


class VcAutoImportBody(BaseModel):
    enabled: bool
    dir: str = ""
    max_age_hours: int = 36


@app.get("/api/vcenter-autoimport")
def vcenter_autoimport_status(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    """VC 自動匯入（方案 B）現況：設定＋鮮度燈（今晚的匯出到底有沒有進來）。"""
    import vcenter_autoimport

    return vcenter_autoimport.health(conn)


@app.put("/api/vcenter-autoimport")
def vcenter_autoimport_save(
    body: VcAutoImportBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """設定監看資料夾＋開關＋逾時門檻。開了之後排程器每輪會看資料夾有沒有新檔。"""
    import vcenter_autoimport

    vcenter_autoimport.set_config(conn, body.enabled, body.dir, body.max_age_hours)
    return vcenter_autoimport.health(conn)


@app.post("/api/vcenter-autoimport/run")
def vcenter_autoimport_run(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    """手動「立即抓一次」：找監看資料夾最新且寫完的 RVTools 檔，比上次新才匯。"""
    import vcenter_autoimport

    return vcenter_autoimport.pickup(conn)


def _serialize_connection(row: sqlite3.Row) -> dict:
    """密碼write-only：HTTP回應一律不帶password欄位本身，只給has_password布林值讓畫面
    知道「這筆有沒有設定過密碼」，不洩漏內容（S10 done_when明訂）。
    """
    d = dict(row)
    has_password = bool(d.pop("password", None))
    d["has_password"] = has_password
    return d


class ConnectionBody(BaseModel):
    name: str
    connection_type: str | None = None
    target: str
    port: int | None = None
    username: str | None = None
    password: str | None = None


@app.get("/api/connections")
def list_connections_endpoint(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    return [_serialize_connection(r) for r in list_connections(conn)]


@app.get("/api/connections/suggest-segments")
def suggest_segments(
    fmt: str = Query("json", pattern="^(json|txt)$"),
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """從既有資產的 IP 反推該掃描哪些網段，並對上機房。

    fmt=txt 回純文字的 segments.txt，直接餵給外部掃描機的 scan_segments.py。
    那台連不到這裡的資料庫（正是要外部掃描的原因），清單只能由人搬過去。

    為什麼要有這支：資產清單是匯入進來的（幾千筆），但掃描目標得一個一個手動建，
    只要漏建，那個網段的機器就全部變成「失聯」——看起來像機器出事，其實只是沒去掃。
    網段資訊本來就藏在資產的 IP 裡，不該再要人另外整理一份網段表。

    每個網段會標出資產分布在哪些機房。同一網段對到多個機房時一併回報：
    那要嘛是真的跨機房共用，要嘛是資產的機房欄位填錯——後者正是盤點系統該抓的問題。
    """
    import manage_state

    existing = set()
    for c in conn.execute("SELECT target FROM connections").fetchall():
        t = (c["target"] or "").strip()
        if t:
            existing.add(t)

    segs: dict[str, dict] = {}
    bad_ip = 0
    for r in conn.execute(
        "SELECT ip, physical_location FROM hardware WHERE ip IS NOT NULL AND ip != ''"
    ).fetchall():
        parts = (r["ip"] or "").strip().split(".")
        if len(parts) != 4 or not all(p.isdigit() and 0 <= int(p) <= 255 for p in parts):
            bad_ip += 1
            continue
        cidr = ".".join(parts[:3]) + ".0/24"
        s = segs.setdefault(cidr, {"cidr": cidr, "hosts": 0, "locations": {}})
        s["hosts"] += 1
        loc = manage_state.group_location(r["physical_location"])
        s["locations"][loc] = s["locations"].get(loc, 0) + 1

    out = []
    for s in segs.values():
        locs = sorted(s["locations"].items(), key=lambda kv: -kv[1])
        main_loc = locs[0][0] if locs else "未填"
        out.append({
            "cidr": s["cidr"],
            "hosts": s["hosts"],
            "main_location": main_loc,
            "locations": dict(locs),
            "mixed": len(locs) > 1,
            "already": s["cidr"] in existing,
            # 建議的連線名稱：帶上機房，之後在清單裡一眼看得出這條是掃哪裡的
            "suggest_name": f"{main_loc} {s['cidr']}",
        })
    out.sort(key=lambda x: -x["hosts"])

    if fmt == "txt":
        # 只放整行註解、不放行尾註解：scan_segments.py 的 load_segments 只跳過整行 #，
        # 行尾註解會讓整行解析失敗被略過——那會變成「檔案看起來有 129 段、實際掃 0 段」。
        # 機房資訊是給人看的，UI 上就有，不必塞進要餵給機器的檔。
        covered = sum(s["hosts"] for s in out)
        lines = [
            "# 網段掃描清單 —— 由戰情室依現有資產 IP 反推（每筆取前三段成 /24）",
            f"# 產生時間：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            f"# 網段數：{len(out)}　涵蓋資產：{covered} 台",
        ]
        if bad_ip:
            # 這些資產不屬於任何網段，掃描永遠看不到它們。不講的話，
            # 掃完發現「還有機器沒出現」會回頭懷疑掃描器，其實是資料本身有問題。
            lines.append(
                f"# ⚠ 另有 {bad_ip} 筆資產的 IP 格式不正確，未納入任何網段——"
                "掃描不會涵蓋它們，請在系統裡修正後重新下載"
            )
        lines += [
            "#",
            "# 一行一個網段，# 開頭為註解。要增減網段直接改這個檔即可。",
            "",
        ]
        lines += [s["cidr"] for s in out]
        # 檔名固定 segments.txt，不加時間戳：mmap.sh 只認這個檔名，
        # 帶戳記就得人工改名，漏改會變成「找不到網段清單」而中止。
        # 產生時間寫在檔頭註解裡，要區分版本看那裡。
        return Response(
            content="\n".join(lines) + "\n",
            media_type="text/plain; charset=utf-8",
            headers={"Content-Disposition": 'attachment; filename="segments.txt"'},
        )

    return {"segments": out, "bad_ip_count": bad_ip, "existing_count": len(existing)}


class SegmentBatchBody(BaseModel):
    cidrs: list[str]


@app.post("/api/connections/batch-segments")
def batch_create_segments(
    body: SegmentBatchBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """把選定的網段一次建成掃描來源。已存在的略過，重複點不會長出一堆重複設定。"""
    import manage_state

    existing = {
        (c["target"] or "").strip()
        for c in conn.execute("SELECT target FROM connections").fetchall()
    }

    # 先算好每個網段的主要機房，名稱才帶得出「板橋 10.92.198.0/24」
    loc_of: dict[str, str] = {}
    counter: dict[str, dict[str, int]] = {}
    for r in conn.execute(
        "SELECT ip, physical_location FROM hardware WHERE ip IS NOT NULL AND ip != ''"
    ).fetchall():
        parts = (r["ip"] or "").strip().split(".")
        if len(parts) != 4 or not all(p.isdigit() for p in parts):
            continue
        cidr = ".".join(parts[:3]) + ".0/24"
        loc = manage_state.group_location(r["physical_location"])
        counter.setdefault(cidr, {})
        counter[cidr][loc] = counter[cidr].get(loc, 0) + 1
    for cidr, d in counter.items():
        loc_of[cidr] = max(d.items(), key=lambda kv: kv[1])[0]

    created, skipped = [], []
    for cidr in body.cidrs:
        cidr = (cidr or "").strip()
        if not cidr:
            continue
        if cidr in existing:
            skipped.append(cidr)
            continue
        name = f"{loc_of.get(cidr, '未知')} {cidr}"
        create_connection_record(conn, name, "網路掃描", cidr, None, None, None)
        existing.add(cidr)
        created.append({"cidr": cidr, "name": name})
    return {"created": created, "skipped": skipped}


@app.post("/api/connections")
def create_connection_endpoint(
    body: ConnectionBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    new_id = create_connection_record(
        conn, body.name, body.connection_type, body.target, body.port, body.username, body.password
    )
    return _serialize_connection(get_connection_by_id(conn, new_id))


@app.put("/api/connections/{connection_id}")
def update_connection_endpoint(
    connection_id: int,
    body: ConnectionBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    if get_connection_by_id(conn, connection_id) is None:
        raise HTTPException(404, "查無此連線設定")
    # 密碼write-only的另一半：留空（None或空字串）代表「這次不變更密碼」，不是「清空密碼」。
    password_to_set = body.password if body.password else None
    update_connection_record(
        conn,
        connection_id,
        body.name,
        body.connection_type,
        body.target,
        body.port,
        body.username,
        password_to_set,
    )
    return _serialize_connection(get_connection_by_id(conn, connection_id))


class ConnectionEnabledBody(BaseModel):
    enabled: bool


@app.patch("/api/connections/{connection_id}/enabled")
def set_connection_enabled_endpoint(
    connection_id: int,
    body: ConnectionEnabledBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """來源啟用／停用。停用的來源排程掃描會直接跳過，不會被算成「掃描失敗」。

    存在的理由：有些來源現階段本來就連不到（例如 CMDB Gateway 在家裡碰不到公司內網）。
    沒有開關的話它每次掃描都失敗、每次都把「掃描不完整」點亮——常態性的假警報
    會讓真正的掃描問題沒人看見。
    """
    if get_connection_by_id(conn, connection_id) is None:
        raise HTTPException(404, "查無此連線設定")
    set_connection_enabled(conn, connection_id, body.enabled)
    return _serialize_connection(get_connection_by_id(conn, connection_id))


class ConnectionScanTimeBody(BaseModel):
    scan_time: str | None = None     # "HH:MM"；空／None＝清掉，回到跟全域排程一起掃


@app.patch("/api/connections/{connection_id}/scan-time")
def set_connection_scan_time_endpoint(
    connection_id: int,
    body: ConnectionScanTimeBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """設這個網段自己的每日排程時間（HH:MM）。設了就在那個時間單獨掃這一段；
    留空＝清掉、回到跟全域排程一起掃。讓公司多個測試網段可以錯開時間、不擠在同一時刻。"""
    import db as _db
    if get_connection_by_id(conn, connection_id) is None:
        raise HTTPException(404, "查無此連線設定")
    t = (body.scan_time or "").strip()
    if t:
        import re as _re
        if not _re.fullmatch(r"([01]?\d|2[0-3]):[0-5]\d", t):
            raise HTTPException(400, "時間格式要是 HH:MM（24 小時制），例如 03:30")
    _db.set_connection_scan_time(conn, connection_id, t or None)
    return _serialize_connection(get_connection_by_id(conn, connection_id))


@app.delete("/api/connections/{connection_id}")
def delete_connection_endpoint(
    connection_id: int,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    if get_connection_by_id(conn, connection_id) is None:
        raise HTTPException(404, "查無此連線設定")
    delete_connection_record(conn, connection_id)
    return {"ok": True}


@app.post("/api/connections/{connection_id}/test")
def test_connection_endpoint(
    connection_id: int,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """D15「重新檢查」按鈕：真的做一次TCP連線測試，不是硬編一個假狀態。這個階段還沒有
    真實vCenter/SNMP協定整合（S3的ScanSource還是mock，接上真實協定是之後的工作），但
    port通不通得起來是真訊號，比起顯示假的「已連線」更誠實，符合D31精神。
    """
    row = get_connection_by_id(conn, connection_id)
    if row is None:
        raise HTTPException(404, "查無此連線設定")
    if not row["port"]:
        raise HTTPException(400, "這筆連線沒有設定Port，無法測試")
    try:
        with socket.create_connection((row["target"], row["port"]), timeout=3):
            status = "綠"
    except OSError:
        status = "紅"
    update_connection_status(conn, connection_id, status)
    return _serialize_connection(get_connection_by_id(conn, connection_id))


# ===== S14 備份健康儀表 =====
# 目的是讓工程師/助理不用進命令列就能看狀態、手動備份。備份這件事最糟的失敗模式是
# 「以為有備份，還原時才發現壞的」，所以這裡不只顯示「有沒有跑過」，而是實際去驗證。

@app.get("/api/backup/status")
def backup_status_endpoint(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    """燈號 + 明細。會實際開檔跑 integrity_check，不是只看檔案存不存在。"""
    return backup.health(conn=conn)


class OffsiteBody(BaseModel):
    dir: str = ""


@app.put("/api/backup/offsite")
def backup_set_offsite(
    body: OffsiteBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """設定異地備份目錄（畫面可設，不用改 systemd 環境變數再重啟）。

    這裡只存路徑；路徑本身要指到「真正獨立的儲存」才算異地——例如掛載另一台機器
    （222）的 /ai_backup。留空＝清掉異地（回黃燈）。存完立刻回最新健康狀態讓畫面看變化。
    """
    from db import set_setting

    set_setting(conn, backup.OFFSITE_SETTING_KEY, (body.dir or "").strip())
    return backup.health(conn=conn)


@app.post("/api/backup/run")
def backup_run_endpoint(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    """手動觸發一次備份（安全快照 + 完整性驗證 + 異地複製 + 清理過期）。

    刻意用 sync def：跟 import_excel_upload 同理，備份是 I/O 密集的阻塞操作，
    交給 FastAPI 的 threadpool 跑，不要卡住 event loop。
    """
    db_path = get_db_path()
    result = backup.run_backup(
        db_path, backup.get_backup_dir(db_path), datetime.now(), backup.get_offsite_dir(conn)
    )
    payload = {
        "ok": result.ok,
        "path": str(result.path) if result.path else None,
        "size_bytes": result.size_bytes,
        "integrity_ok": result.integrity_ok,
        "integrity_detail": result.integrity_detail,
        "offsite_path": str(result.offsite_path) if result.offsite_path else None,
        "offsite_error": result.offsite_error,
        "pruned_count": len(result.pruned),
        "took_seconds": result.took_seconds,
        "error": result.error,
    }
    if not result.ok:
        # 用 200 回失敗細節而不是丟 500：前端要能把「為什麼失敗」原樣顯示給使用者，
        # 500 只會變成一句「伺服器錯誤」，等於把診斷資訊丟掉。
        payload["message"] = f"備份失敗：{result.error}"
    return payload


@app.get("/api/backup/list")
def backup_list_endpoint(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    """本地與異地的備份檔清單（新到舊）。"""
    db_path = get_db_path()
    offsite = backup.get_offsite_dir(conn)
    return {
        "local": backup.list_backups(backup.get_backup_dir(db_path)),
        "offsite": backup.list_backups(offsite) if offsite else [],
    }


@app.get("/api/backup/dump")
def backup_dump_endpoint(
    fmt: str = "binary",
    split_mb: int = 0,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """匯出全部資料庫，供備份／搬機使用。跟 /api/backup/run（存到伺服器本機/異地）不同，
    這支是**直接下載到使用者瀏覽器**，兩種格式讓使用者自己選：

    fmt=binary（預設）：跟 backup.snapshot() 同一套 VACUUM INTO，二進位 .db 檔，
      跟既有系統/任何 SQLite 工具都能直接讀，不會被誤貼到聊天室/網頁（2026-08-18
      實際發生過 RVTools 資料被貼到公開分享碼網站，這支刻意提供二進位選項）。
    fmt=sql：純文字 SQL dump（用 sqlite3 內建的 iterdump()，不шell out），
      體積小、人可讀，但也因為是文字，複製貼上風險比二進位檔案高，使用者自己權衡。

    這支只匯出。還原是獨立端點 /api/backup/restore（2026-08-19 拍板方案B新增），
    刻意不跟這支共用——風險層級不同，還原會覆蓋正式資料。
    """
    import tempfile

    if fmt not in ("binary", "sql"):
        raise HTTPException(400, "fmt 只接受 binary 或 sql")
    if split_mb < 0 or split_mb > 100:
        raise HTTPException(400, "split_mb 需在 0（不分割）到 100 之間")

    db_path = get_db_path()
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    # ⚠️ 原本這裡有一條「不分割的 SQL 走串流」的捷徑，它會**繞過下面的加密**。
    # 決策 SEC5 之後匯出一律加密，而加密需要完整內容（沒辦法邊產邊加密），
    # 所以這條捷徑拿掉。代價是大檔要整份進記憶體一次——目前 45MB 級距可接受，
    # 真的長到吃不消要改成「分塊各自加密」，那是另一個設計。

    # 產出 dump 位元組（分割一定要拿到完整內容才能切）
    if fmt == "sql":
        content = "".join(line + "\n" for line in conn.iterdump()).encode("utf-8")
        base_name = f"asset_dump_{stamp}.sql"
    else:
        with tempfile.TemporaryDirectory() as tmp:
            dest = Path(tmp) / f"asset_dump_{stamp}.db"
            backup.snapshot(db_path, dest)
            ok, msg = backup.verify_integrity(dest)
            if not ok:
                raise HTTPException(500, f"匯出後完整性檢查失敗，拒絕提供下載：{msg}")
            # 讀進記憶體再回傳（見下）：回應送出「後」才讀檔時暫存目錄已被清掉。
            content = dest.read_bytes()
        base_name = f"asset_dump_{stamp}.db"

    # ===== 加密（決策 SEC5）=====
    # 這支是**會離開這台機器**的匯出（下載→email）。檔案裡有全公司主機清單、IP、
    # 主機名、帳號名、業務系統歸屬——寄錯人或信箱被入侵就是整份資產清冊外流。
    #
    # 所以一律加密，不留「不加密」選項（使用者 2026-09-08 拍板）。
    # 存在伺服器上的本機／異地備份不受影響，維持不加密——備份的意義是出事能還原，
    # 那份如果也加密，私鑰沒了連自己都救不回來。
    #
    # 加密順便把體積壓下來：實測 45MB 的庫 gzip 後 4.1MB（9%），
    # 100MB 那台會變 9-10MB，一封信寄得完，多半連 split_mb 都用不到。
    import export_crypto

    # 2026-09-18 使用者改成開關、預設關（見 export_crypto.ENCRYPT_SETTING）。
    if export_crypto.encryption_enabled(conn):
        recipient = export_crypto.get_recipient_public(conn)
        if recipient is None:
            raise HTTPException(
                400,
                "已開啟「匯出時加密」，但還沒設定收件人公鑰，無法匯出。"
                "請到系統設定貼上收件端（221）的公鑰，或把「匯出時加密」關掉。")
        content = export_crypto.encrypt(content, recipient)
        base_name += ".enc"
    else:
        # 不加密：留一筆紀錄，事後查得到誰在什麼時候拿走了整份資料
        try:
            activity.log(conn, username=session["username"], ip=None, method="GET",
                         path=f"/api/backup/dump 未加密匯出 fmt={fmt} size={len(content)}",
                         status=200, action="export_plain")
        except Exception:  # noqa: BLE001 - 紀錄失敗不擋下載，但會在伺服器 log 看到
            print("[export] 未加密匯出紀錄寫入失敗")

    if split_mb == 0:
        return Response(
            content, media_type="application/octet-stream",
            headers={"Content-Disposition": f'attachment; filename="{base_name}"'},
        )

    # 分割：切成 split_mb 一片，打包成 zip（附併回說明）。
    # 用途：dump 太大、要當 email 附件寄（附件常限 10MB）。下載走區網不受此限，
    # 所以整包 zip 一次下載沒問題；解壓後每片 ≤split_mb，逐片寄信。
    import io
    import zipfile

    chunk = split_mb * 1024 * 1024
    parts = [content[i:i + chunk] for i in range(0, len(content), chunk)] or [b""]
    n = len(parts)
    readme = (
        f"這是分割檔，需「併回原檔」才能使用。共 {n} 片，每片 ≤{split_mb}MB。\n"
        f"檔案：{base_name}.001 … {base_name}.{n:03d}\n\n"
        f"【併回】\n"
        f"Windows（cmd，注意順序）：\n"
        f"  copy /b " + "+".join(f"{base_name}.{i:03d}" for i in range(1, n + 1)) + f" {base_name}\n"
        f"Linux / Mac：\n"
        f"  cat {base_name}.* > {base_name}\n\n"
        f"【併回後怎麼用】\n"
        + ("  .db → 系統設定→資料庫還原 上傳，或用任何 SQLite 工具開。\n"
           if fmt == "binary"
           else "  .sql → sqlite3 新檔.db < " + base_name + "\n")
        + "\n每片可分別當 email 附件寄；收到後放同一資料夾再依上面併回。\n"
    )
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for i, part in enumerate(parts, 1):
            zf.writestr(f"{base_name}.{i:03d}", part)
        zf.writestr("如何併檔.txt", readme)
    zip_name = f"{base_name}_split{split_mb}MB.zip"
    return Response(
        buf.getvalue(), media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{zip_name}"'},
    )


@app.get("/api/export-key")
def export_key_status(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """這台在加密匯出這件事上是什麼角色（決策 SEC5）。

    兩個角色，一台可以同時是（但實務上不會）：
      · **收件端**：持私鑰，解得開別人寄來的匯出。公鑰顯示給人複製。
      · **來源端**：存了收件人公鑰，匯出時用它加密。自己解不開自己的匯出。
    """
    import export_crypto

    priv_path = Path(export_crypto.private_key_path())
    has_private = priv_path.exists()
    out = {
        "is_recipient": has_private,
        "private_key_path": str(priv_path),
        "my_public_key": None,
        "my_fingerprint": None,
        "recipient_fingerprint": None,
        "encryption_enabled": export_crypto.encryption_enabled(conn),
        "can_export": not export_crypto.encryption_enabled(conn),
    }
    if has_private:
        pub = export_crypto.public_key_of()
        out["my_public_key"] = pub.hex()
        out["my_fingerprint"] = export_crypto.fingerprint_hex(pub)
    recipient = export_crypto.get_recipient_public(conn)
    if recipient is not None:
        out["recipient_fingerprint"] = export_crypto.fingerprint_hex(recipient)
        out["can_export"] = True
    return out


class ExportEncryptBody(BaseModel):
    enabled: bool


@app.put("/api/export-key/encryption")
def export_key_encryption(
    body: ExportEncryptBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """開／關「匯出時加密」。預設關（2026-09-18 使用者）。"""
    import export_crypto
    return {"encryption_enabled": export_crypto.set_encryption_enabled(conn, body.enabled)}


@app.post("/api/export-key/generate")
def export_key_generate(
    session: sqlite3.Row = Depends(require_auth),
):
    """在收件端產生金鑰對。私鑰落地 0600，公鑰回傳給人複製到來源端。

    ⚠️ 已經有私鑰就**拒絕**，不覆蓋——覆蓋之後過去所有加密匯出永遠打不開，
    而且是無聲的（畫面顯示成功，要還原時才發現）。真的要換金鑰，
    人得自己去刪掉那個檔，那一步逼他先想清楚舊備份怎麼辦。
    """
    import export_crypto

    try:
        return export_crypto.generate_keypair()
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


class RecipientKeyBody(BaseModel):
    public_key: str


@app.put("/api/export-key/recipient")
def export_key_set_recipient(
    body: RecipientKeyBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """在來源端設定收件人公鑰。公鑰不需要保密，直接貼上即可。

    存之前先驗格式——貼錯（貼到指紋、貼到 SSH 公鑰）如果留到匯出當下才爆，
    那時候人已經在等檔案了。
    """
    import export_crypto

    try:
        return export_crypto.set_recipient_public(conn, body.public_key)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@app.post("/api/backup/restore")
def backup_restore_endpoint(
    file: UploadFile = File(...),
    session: sqlite3.Row = Depends(require_auth),
):
    """整庫覆蓋還原（2026-08-19 拍板方案B：簡單覆蓋＋前端單一確認框，開關預設關）。

    刻意不用 `Depends(get_db)`——這支要整檔替換掉資料庫本體，不能借用一條可能還開著
    讀取交易的連線；讓 backup.restore() 自己開短命連線做驗證，本體替換用檔案系統層級的
    os.replace()。前端是否顯示這個功能由 feature_flags 的 'restore' 開關決定
    （查 GET /api/feature-flags），這支本身不重複檢查開關——已登入使用者手動點開開關、
    走到這支端點，就是已經確認過要做這件事。
    """
    fn = (file.filename or "").lower()
    if not (fn.endswith(".db") or fn.endswith(".enc")):
        raise HTTPException(
            400, "只接受 .db（未加密）或 .enc（加密匯出）。"
                 "如果手上是分割檔（.001/.002…），請先照「如何併檔.txt」併回原檔。")

    contents = file.file.read()
    if not contents:
        raise HTTPException(400, "上傳的檔案是空的（0 bytes）")

    # 加密檔要先解開。解不開的三種原因（不是加密檔／不是給這台的／內容壞了）
    # 在 export_crypto 各自有明確訊息——那三件事要做的處理完全不同。
    import export_crypto

    if export_crypto.looks_encrypted(contents):
        try:
            contents = export_crypto.decrypt(contents)
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc
    try:
        return backup.restore(contents, get_db_path())
    except ValueError as exc:
        # 「你給的檔案不對」——使用者自己就能修
        raise HTTPException(400, str(exc)) from exc
    except backup.RestoreFailed as exc:
        # 伺服器端出錯，但已經寫成人看得懂、且講明資料有沒有被動到的訊息
        raise HTTPException(500, str(exc)) from exc
    except Exception as exc:  # noqa: BLE001
        # 最後一道網。沒有這段，任何沒預期到的例外都會變成 FastAPI 的裸 500
        # `{"detail":"Internal Server Error"}`，使用者在一個**不可逆**的操作上
        # 只看得到「失敗」兩個字——2026-08-19 回報的就是這個。
        raise HTTPException(
            500,
            f"還原時發生未預期的錯誤：{type(exc).__name__}: {exc}。"
            f"若失敗發生在覆蓋開始前，正式資料庫未被更動；"
            f"請檢查伺服器紀錄，或用 backups/ 目錄裡的存證備份還原。",
        ) from exc


# ===== 系統組月報（2026-08-21）=====
# 薄 HTTP 層，邏輯都在 system_report.py。使用者每月要把三張表貼進部門報告，
# 原本是人工統計的——他的原話：「以後我就 COPY 畫面，不用再自己統計」。

@app.get("/api/reports/system-group")
def report_system_group(
    period: str | None = None,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """當下即時算的整份報告。帶 period 只影響備註的取用範圍，數字一律是即時的
    ——要看某個月的定稿數字請走 /snapshots/{period}，兩者刻意分開，
    免得有人以為畫面上的數字就是當月存檔的那份。"""
    import system_report

    return system_report.build(conn, period)


class ReportNoteBody(BaseModel):
    row_key: str
    note: str
    period: str | None = None


@app.put("/api/reports/system-group/note")
def report_system_group_note(
    body: ReportNoteBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import system_report

    system_report.set_note(conn, body.row_key, body.note, session["username"], body.period)
    return {"ok": True}


@app.get("/api/reports/system-group/drill")
def report_drill(
    table: str,
    platform: str | None = None,
    status: str | None = None,
    bucket: str | None = None,
    retired: bool = False,
    location: str | None = None,
    service: str | None = None,
    vcenter: str | None = None,
    cluster: str | None = None,
    version: str | None = None,
    os_canonical: str | None = None,
    registered_only: bool = False,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """任何一格數字點下去要看的清單。

    使用者 2026-08-21：「你每個數字我都要可以追」。這支跟加總走**同一份**計算
    （system_report 的 classify_assets / _vhosts），所以格子上的數字跟這裡回的
    筆數必然一致——不一致的話那張報表就不能用了。

    每一列都帶 `reason`：不只列得出是哪幾台，還講得出為什麼是這一台。
    """
    import system_report

    if table == "platform":
        return system_report.drill_platform(
            conn, platform=platform, status=status, bucket=bucket, retired=retired,
            os_canonical=os_canonical, registered_only=registered_only)
    if table in ("cluster", "virtualization"):
        return system_report.drill_cluster(
            conn, location=location, service=service, vcenter=vcenter, cluster=cluster,
            version=version)
    raise HTTPException(400, "table 只接受 platform / cluster / virtualization")


@app.get("/api/reports/system-group/snapshots")
def report_snapshots(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import system_report

    return system_report.list_snapshots(conn)


class ReportSnapshotBody(BaseModel):
    period: str


@app.post("/api/reports/system-group/snapshots")
def report_snapshot_save(
    body: ReportSnapshotBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """存當月定稿。同月重存＝覆蓋（同月本來就只該有一份定稿）。"""
    import re as _re

    import system_report

    if not _re.fullmatch(r"\d{4}-\d{2}", body.period or ""):
        raise HTTPException(400, "period 格式須為 YYYY-MM")
    sid = system_report.save_snapshot(conn, body.period, session["username"])
    return {"id": sid, "period": body.period}


@app.get("/api/reports/system-group/snapshots/{period}")
def report_snapshot_get(
    period: str,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import system_report

    snap = system_report.get_snapshot(conn, period)
    if snap is None:
        raise HTTPException(404, f"沒有 {period} 的存檔")
    return snap


# ===== 部門報告圖表頁：頁A（各環境實體機分布）／頁B（主機系統總覽）=====
# 薄 HTTP 層，邏輯都在 system_report.py。跟系統組月報同一套規矩：加總與下鑽
# 走同一份計算，格子上的數字要能追（2026-08-25 使用者提供簡報頁後定案的計畫）。

@app.get("/api/reports/physical-distribution")
def report_physical_distribution(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    import system_report

    return system_report.physical_distribution(conn)


@app.get("/api/reports/physical-distribution/drill")
def report_physical_distribution_drill(
    room: str | None = None,
    branch: str | None = None,
    excluded_model: str | None = None,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import system_report

    return system_report.drill_physical(
        conn, room=room, branch=branch, excluded_model=excluded_model)


@app.get("/api/reports/system-overview")
def report_system_overview(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    import system_report

    return system_report.system_overview(conn)


@app.get("/api/reports/system-overview/drill")
def report_system_overview_drill(
    bucket: str | None = None,
    api_id: str | None = None,
    room: str | None = None,
    category: str | None = None,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import system_report

    if bucket is not None and bucket not in ("core", "noncore", "test", "uncategorized"):
        raise HTTPException(400, "bucket 只接受 core／noncore／test／uncategorized")
    return system_report.drill_system_overview(
        conn, bucket=bucket, api_id=api_id, room=room, category=category)


@app.get("/api/reports/system-category/template")
def report_system_category_template(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    """177 個業務系統的空白對照表，xlsx 下載——依台數大到小排序，
    使用者填前幾十個就涵蓋大部分機器，不必一次填完（計畫檔已定案）。

    表頭刻意跟匯入端點認的欄位同名（api_id/分類），保證原封不動填完再上傳就對得起來
    （跟 /api/export 保證 round-trip 的道理一樣）。
    """
    import system_report

    rows = system_report.system_category_template(conn)
    cat_defs = system_report._cfg().get("system_categories") or []
    wb = Workbook()
    ws = wb.active
    ws.title = "業務系統分類"
    ws.append(["api_id", "系統名稱", "目前台數", "分類（填法見『分類代碼表』分頁，共19項）"])
    for r in rows:
        ws.append([r["api_id"], r["name"], r["count"], r["category"]])

    ws2 = wb.create_sheet("分類代碼表")
    ws2.append(["分類名稱", "屬於"])
    for c in cat_defs:
        ws2.append([c["name"], c.get("group", "")])

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    from urllib.parse import quote

    fname = f"業務系統分類範本_{datetime.now().strftime('%Y%m%d')}.xlsx"
    return StreamingResponse(
        buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        # 中文檔名不能直接塞進 Content-Disposition（HTTP header 只能是 latin-1），
        # 要用 RFC 5987 的 filename* 編碼——同 /api/export 等既有端點的做法。
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(fname)}"},
    )


@app.post("/api/reports/system-category/import")
def report_system_category_import(
    file: UploadFile = File(...),
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """讀回填好的對照表。跟 /api/import/excel 同一個理由用 sync def（UploadFile.file
    是同步可讀的 SpooledTemporaryFile）。

    只認第一欄 api_id、第四欄分類（表頭文字不驗，位置驗——使用者可能把說明文字
    改掉，但欄位順序是匯出範本固定的，改順序才會出錯，那本來就該報錯）。
    """
    import system_report

    if not file.filename or not file.filename.lower().endswith(".xlsx"):
        raise HTTPException(400, "只接受 .xlsx 檔案（用上面『下載範本』那份填）")

    try:
        wb = load_workbook(io.BytesIO(file.file.read()), data_only=True)
    except Exception as exc:  # noqa: BLE001 - openpyxl對壞檔案的錯誤型態不一，統一攔截如實回報
        raise HTTPException(400, f"檔案讀不開：{exc}") from exc

    ws = wb.active
    mapping: dict[str, str] = {}
    for row in ws.iter_rows(min_row=2, values_only=True):
        if not row or not row[0]:
            continue
        api_id = str(row[0]).strip()
        cat = str(row[3]).strip() if len(row) > 3 and row[3] else ""
        mapping[api_id] = cat

    result = system_report.import_system_category(conn, mapping)
    return result


# ===== 主機分類作業（逐台的部門報告分類）=====
# 為什麼要獨立一頁：報表頁B/頁C 的三桶（核心交易／非核心／測試）與分色全部靠
# hardware.system_category，而 2026-08-26 盤點的結果是 2740 台裡有 452 台管理員
# 那份 Excel 根本沒涵蓋。這 452 台只能人工判斷 —— 沒有一個「哪些還沒分、剩幾台」
# 的畫面，它們會永遠停在未分類，報表就永遠有一塊灰的。
#
# ⚠️ 這套分類**跟 CIA 資訊資產清冊無關**，是專門為了產出那三張部門報告而存在的
# 獨立分類（使用者 2026-08-26 指正）。不要拿清冊的環境別來對帳。
#
# 薄 HTTP 層，邏輯全在 system_report.py。

@app.get("/api/classify/summary")
def classify_summary_endpoint(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import system_report

    return system_report.classify_summary(conn)


@app.get("/api/classify")
def classify_list_endpoint(
    only: str | None = None,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """`only`＝unclassified／classified，省略回全部。"""
    import system_report

    if only not in (None, "", "unclassified", "classified"):
        raise HTTPException(400, f"only 參數只接受 unclassified／classified，收到「{only}」")
    return {"rows": system_report.classify_rows(conn, only or None)}


class ClassifySetBody(BaseModel):
    asset_serials: list[str]
    category: str | None = None   # None／空字串＝清掉分類


@app.put("/api/classify")
def classify_set_endpoint(
    body: ClassifySetBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import system_report

    try:
        return system_report.set_asset_categories(
            conn, body.asset_serials, body.category, session["username"])
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@app.post("/api/classify/seed")
def classify_seed_endpoint(
    file: UploadFile = File(...),
    commit: bool = Form(False),
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """用外部盤點表批次帶入分類。**預設乾跑（commit=false）只回試算結果。**

    只讀「主機名稱」與「分類」兩欄，其餘欄位一律忽略 —— 使用者 2026-08-26 明確
    指示：類別、主機名稱以《資訊資產清冊》為準，來源表只有分類可以參考。

    欄位用**表頭文字**找（不是固定位置）：這份表是別人維護的，欄位順序會變，
    位置寫死會在某次他們插一欄之後安靜地把整欄資料對錯。找不到表頭就報錯，
    不猜。
    """
    import system_report

    if not file.filename or not file.filename.lower().endswith(".xlsx"):
        raise HTTPException(400, "只接受 .xlsx 檔案")

    try:
        wb = load_workbook(io.BytesIO(file.file.read()), data_only=True)
    except Exception as exc:  # noqa: BLE001 - openpyxl對壞檔案的錯誤型態不一，統一攔截如實回報
        raise HTTPException(400, f"檔案讀不開：{exc}") from exc

    ws = wb.active
    header = [str(c or "").strip() for c in next(ws.iter_rows(min_row=1, max_row=1, values_only=True), ())]
    try:
        i_host = header.index("主機名稱")
        i_cat = header.index("分類")
    except ValueError as exc:
        raise HTTPException(
            400,
            f"找不到必要欄位。需要「主機名稱」與「分類」兩個表頭，這份檔的表頭是：{header}",
        ) from exc

    rows = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        if not row or len(row) <= max(i_host, i_cat):
            continue
        rows.append({"hostname": row[i_host], "category": row[i_cat]})

    return system_report.seed_categories_from_rows(conn, rows, dry_run=not commit)


# ===== CI 圖譜（MICS 切片1：影響範圍查詢的地基）=====
# 薄 HTTP 層，邏輯都在 ci_graph.py。rebuild() 同步跑（資料量數百~數千節點，純 DB
# 運算不碰網路，不用像 scan_service 那樣起背景執行緒）——但仍照 scan_runs 的慣例留
# running 狀態擋同時觸發兩次，避免兩個請求並發時互相踩。
#
# run 記錄（開 running 列、成功寫 counts、失敗寫 error）在 ci_graph.run_rebuild()，
# 不寫在這裡：每天凌晨的排程要做完全一樣的事，兩邊各寫一份必然漂走。

@app.post("/api/ci/rebuild")
def ci_rebuild_endpoint(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import ci_graph

    try:
        return ci_graph.run_rebuild(conn, "manual", session["username"])
    except ci_graph.RebuildInProgress as exc:
        raise HTTPException(409, "已有一次重建正在進行，請稍候") from exc
    except Exception as exc:  # noqa: BLE001 - 失敗已由 run_rebuild 記進 ci_graph_runs
        raise HTTPException(500, f"重建失敗：{exc}") from exc


class CiScheduleBody(BaseModel):
    enabled: bool
    time: str


@app.get("/api/ci/schedule")
def ci_schedule_get_endpoint(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import ci_graph

    return ci_graph.get_schedule(conn)


@app.put("/api/ci/schedule")
def ci_schedule_put_endpoint(
    body: CiScheduleBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import ci_graph

    try:
        ci_graph.set_schedule(conn, body.enabled, body.time)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    return ci_graph.get_schedule(conn)


@app.get("/api/ci/rebuild/status")
def ci_rebuild_status_endpoint(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    row = conn.execute("SELECT * FROM ci_graph_runs ORDER BY id DESC LIMIT 1").fetchone()
    return dict(row) if row else None


# ===== 影響範圍查詢（MICS 切片2：Blast Radius，殺手級功能）=====
# 薄 HTTP 層，邏輯都在 blast_radius.py。三種問法（陌生IP研判/事故爆炸半徑/計畫性停機）
# 共用同一顆引擎，只差 mode 參數，見 blast_radius.py 模組開頭說明。

@app.get("/api/blast/systems")
def blast_systems_endpoint(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """瀏覽清單：全庫5148節點畫成一張圖是看不出結構的毛球，2026-08-19 使用者拍板
    用瀏覽清單當「不知道要查什麼名字」時的入口，不做全部關聯圖。"""
    import blast_radius
    return blast_radius.list_business_systems(conn)


@app.get("/api/blast/resolve")
def blast_resolve_endpoint(
    q: str, port: int | None = None,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import blast_radius
    return blast_radius.resolve(conn, q, port)


@app.get("/api/blast/impact")
def blast_impact_endpoint(
    node_id: str, depth: int = 6, mode: str = "incident", only_evidence: bool = False,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import blast_radius
    try:
        return blast_radius.impact(conn, node_id, depth=depth, mode=mode, only_evidence=only_evidence)
    except ValueError as exc:
        raise HTTPException(404, str(exc)) from exc


@app.get("/api/blast/graph")
def blast_graph_endpoint(
    node_id: str, depth: int = 3, direction: str = "dependents",
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import blast_radius
    return blast_radius.graph_elements(conn, node_id, depth, direction)


# ===== 計畫性停機評估存證快照（MICS 切片3）=====
# mode=planned 版面按下「存快照」時把當下 impact() 整包結果存證——見 blast_radius.py
# save_snapshot() docstring：圖會變，要拿得出「當初評估說不影響」是哪次算出來的。

class BlastSnapshotBody(BaseModel):
    node_id: str
    reason: str | None = None
    depth: int = 6
    # 2026-08-20 拍板：檢查清單（方案A）要能從事故模式存證，不是只有計畫性停機——
    # mode 只是存證動機的標籤（畫面上顯示用），底層一律算 incident 那份 dependents，
    # 見 save_snapshot()。
    mode: str = "incident"


@app.post("/api/blast/snapshot")
def blast_snapshot_create_endpoint(
    body: BlastSnapshotBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import blast_radius
    try:
        return blast_radius.save_snapshot(
            conn, body.node_id, body.mode, body.reason, session["username"], depth=body.depth,
        )
    except ValueError as exc:
        raise HTTPException(404, str(exc)) from exc


@app.get("/api/blast/snapshots")
def blast_snapshot_list_endpoint(
    node_id: str | None = None,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import blast_radius
    return blast_radius.list_snapshots(conn, node_id)


@app.get("/api/blast/snapshot/{snapshot_id}")
def blast_snapshot_get_endpoint(
    snapshot_id: int,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import blast_radius
    snap = blast_radius.get_snapshot(conn, snapshot_id)
    if not snap:
        raise HTTPException(404, "查無此快照")
    return snap


def _blast_result_to_csv(conn: sqlite3.Connection, node_id: str, label: str, result: dict, header_rows: list) -> str:
    """impact() 結果轉 CSV，快照跟即時查詢共用這支。2026-08-19 使用者原話：
    「拿到這張圖第一件事就是把聯絡資料匯出來，散給每個人去盤點」——所以：
    - 受影響節點要顯示人看得懂的名字（label），不是內部 node_id
    - 應通知要帶部門，不然收到清單的人不知道找哪個單位對口
    - 查不到負責人的資產另外列一段，不能讓「不知道」悄悄從匯出檔裡消失
    """
    import blast_radius

    labels = {node_id: label}
    for h in result["dependents"]:
        labels[h["node_id"]] = blast_radius.label_for_node(conn, h["node_id"])

    buf = io.StringIO()
    writer = csv.writer(buf)
    for row in header_rows:
        writer.writerow(row)
    writer.writerow(["查詢節點", node_id, label])
    writer.writerow([])
    writer.writerow(["受影響節點", "距離", "關係", "可信度"])
    for h in result["dependents"]:
        writer.writerow([labels.get(h["node_id"], h["node_id"]), h["depth"], h["edge_type"] or "", h["confidence"]])
    writer.writerow([])
    writer.writerow(["應通知", "部門", "電話", "角色/代理人"])
    for n in result["summary"]["notify"]:
        writer.writerow([
            n.get("name"), n.get("department") or "", n.get("phone") or "",
            n.get("role") or n.get("proxy") or "",
        ])
    if result["summary"]["unknown_owner"]:
        writer.writerow([])
        writer.writerow(["查不到負責人的資產", "資產序號"])
        for u in result["summary"]["unknown_owner"]:
            writer.writerow([u["label"], u["asset_serial"]])
    return "﻿" + buf.getvalue()  # BOM：Excel 開 UTF-8 CSV 中文不亂碼


@app.get("/api/blast/snapshot/{snapshot_id}/csv")
def blast_snapshot_csv_endpoint(
    snapshot_id: int,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import blast_radius
    snap = blast_radius.get_snapshot(conn, snapshot_id)
    if not snap:
        raise HTTPException(404, "查無此快照")

    content = _blast_result_to_csv(
        conn, snap["node_id"], snap["result"]["label"], snap["result"],
        header_rows=[
            ["快照ID", snap["id"]], ["原因", snap["reason"] or ""],
            ["查詢人", snap["asked_by"]], ["查詢時間", snap["asked_at"]],
        ],
    )
    from urllib.parse import quote
    fname = f"停機影響評估_{snap['id']}_{snap['asked_at'][:10]}.csv"
    return Response(
        content=content, media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(fname)}"},
    )


@app.get("/api/blast/impact/csv")
def blast_impact_csv_endpoint(
    node_id: str, depth: int = 6, mode: str = "incident", only_evidence: bool = False,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """即時查詢直接匯出 CSV，不用先存快照——事故當下要的是「馬上把清單發出去」，
    不是「先存證再匯出」（存證是 mode=planned 才需要的流程，事故爆炸半徑不用）。
    """
    import blast_radius
    try:
        result = blast_radius.impact(conn, node_id, depth=depth, mode=mode, only_evidence=only_evidence)
    except ValueError as exc:
        raise HTTPException(404, str(exc)) from exc

    content = _blast_result_to_csv(
        conn, node_id, result["label"], result,
        header_rows=[
            ["查詢時間", datetime.now().strftime("%Y-%m-%d %H:%M:%S")],
            ["查詢人", session["username"]],
        ],
    )
    from urllib.parse import quote
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    fname = f"影響範圍_{result['label']}_{stamp}.csv"
    return Response(
        content=content, media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(fname)}"},
    )


# ===== 檢查清單（2026-08-20 拍板方案A）=====
# 事故當下要的是派工清單，不是查詢結果——攤平成「一列一個（主機,聯絡人）配對」，
# 給一個連結，全隊登入都看同一份，改狀態/寫備註就地存。見 blast_radius.py 說明。

class ChecklistCreateBody(BaseModel):
    snapshot_id: int


@app.post("/api/blast/checklist")
def blast_checklist_create_endpoint(
    body: ChecklistCreateBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import blast_radius
    try:
        return blast_radius.create_checklist(conn, body.snapshot_id)
    except ValueError as exc:
        raise HTTPException(404, str(exc)) from exc


@app.get("/api/blast/checklist/{snapshot_id}")
def blast_checklist_list_endpoint(
    snapshot_id: int,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import blast_radius
    return blast_radius.list_checklist(conn, snapshot_id)


class ChecklistItemUpdateBody(BaseModel):
    status: str | None = None
    note: str | None = None


@app.put("/api/blast/checklist/item/{item_id}")
def blast_checklist_item_update_endpoint(
    item_id: int, body: ChecklistItemUpdateBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import blast_radius
    try:
        return blast_radius.update_checklist_item(conn, item_id, body.status, body.note, session["username"])
    except ValueError as exc:
        raise HTTPException(404, str(exc)) from exc


@app.get("/api/feature-flags")
def list_feature_flags_endpoint(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    """D28：只列出 schema 種好的可切換模組（不含「系統設定」本身，見 schema.sql 註解）。"""
    return [dict(r) for r in list_feature_flags(conn)]


class FeatureFlagBody(BaseModel):
    enabled: bool


@app.put("/api/feature-flags/{module_key}")
def update_feature_flag_endpoint(
    module_key: str,
    body: FeatureFlagBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    if get_feature_flag(conn, module_key) is None:
        raise HTTPException(404, "查無此功能模組")
    set_feature_flag(conn, module_key, body.enabled)
    return dict(get_feature_flag(conn, module_key))


# ============ 掃描：手動重掃 + 排程設定 ============
@app.post("/api/scan/run")
def scan_run_endpoint(session: sqlite3.Row = Depends(require_auth)):
    """手動重掃：背景執行，馬上回覆，前端輪詢 /api/scan/status 取四態。"""
    if not scan_service.start_scan("manual"):
        raise HTTPException(409, "已有一次掃描正在進行，請稍候")
    return {"started": True}


@app.get("/api/scan/status")
def scan_status_endpoint(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    return scan_service.latest_status(conn)


@app.get("/api/scan/schedule")
def scan_schedule_get_endpoint(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    return scan_service.get_schedule(conn)


class ScheduleBody(BaseModel):
    enabled: bool
    mode: str            # daily / interval / weekly
    time: str            # HH:MM（daily／weekly 用）
    interval_hours: int  # interval 用
    weekday: int | None = None   # weekly 用：0=週一 … 6=週日


@app.put("/api/scan/schedule")
def scan_schedule_put_endpoint(
    body: ScheduleBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    try:
        scan_service.set_schedule(conn, body.enabled, body.mode, body.time, body.interval_hours,
                                  body.weekday)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    return scan_service.get_schedule(conn)


# ===== 掃描範圍（以網段配置表為準）=====
# 使用者 2026-09-16 問「你要怎麼知道要掃描那些網段」。答案是網段配置表，
# 但它一直沒接上掃描排程（connections 是空的）——這是失聯 8062 台的真因。
# 使用者決定：「全部，但可以由我來選」→ 這裡回全部網段並標明資安建議，不替他過濾。


@app.get("/api/stats/onboard-matrix")
def onboard_matrix_endpoint(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """OS × 環境 的納管狀態交叉表（2026-09-16 使用者：「OS 為列、環境為欄，格子放納管」）。

    吃的是漏斗那份**已經照主機算**的資料，數字才不會跟漏斗頁對不起來。見 onboard_matrix。
    """
    import onboard_matrix

    m = onboard_matrix.build(conn)
    # 比率在後端算，前端不要自己再算一次——分母要不要含退役／豁免是規則，不是版面
    for os_type in m["rows"]:
        for col in m["cols"]:
            c = m["cells"][os_type][col["key"]]
            c["coverage"] = onboard_matrix.coverage(c)
        m["row_totals"][os_type]["coverage"] = onboard_matrix.coverage(m["row_totals"][os_type])
    for col in m["cols"]:
        m["col_totals"][col["key"]]["coverage"] = onboard_matrix.coverage(m["col_totals"][col["key"]])
    m["grand"]["coverage"] = onboard_matrix.coverage(m["grand"])
    return m


@app.get("/api/stats/onboard-matrix/export")
def onboard_matrix_export(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """交叉表匯出 Excel。"""
    import onboard_matrix
    from urllib.parse import quote

    wb = Workbook()
    ws = wb.active
    ws.title = "OS×環境納管狀態"
    ws.append(onboard_matrix.EXPORT_HEADERS)
    for r in onboard_matrix.export_rows(conn):
        ws.append(["" if v is None else v for v in r])
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    fname = f"OS環境納管狀態_{_now_local()[:10]}.xlsx"
    return StreamingResponse(
        buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(fname)}"})


@app.get("/api/scan/scope")
def scan_scope_get(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """列出全部網段，標明是否已納入掃描、資安是否建議排除、展開後幾個位址。"""
    import scan_scope

    return scan_scope.list_scope(conn)


class ScanScopeBody(BaseModel):
    segment_ids: list[int]


@app.put("/api/scan/scope")
def scan_scope_put(
    body: ScanScopeBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """把勾選的網段同步成掃描來源。沒勾的停用（不刪，保留上次掃描時間）。"""
    import scan_scope

    # 操作紀錄由中介層統一記（每個 PUT 都會進 activity_log），這裡不重複記
    return scan_scope.apply_scope(conn, body.segment_ids,
                                  session["username"] if session else None)


class ScanScopePolicyBody(BaseModel):
    # 全部選填：只送要改的欄位，其餘沿用現有規則（set_policy 會 merge）
    mode: str | None = None                       # rule｜manual
    categories: list[str] | None = None           # 收哪些類別（SERVER/UAT-SERVER/OA/NETWORK…）
    environments: list[str] | None = None         # 收哪些環境（正式/測試）
    respect_recommended_exclude: bool | None = None
    force_in: list[str] | None = None             # 強制納入的 CIDR
    force_out: list[str] | None = None            # 強制排除的 CIDR


@app.put("/api/scan/scope/policy")
def scan_scope_policy_put(
    body: ScanScopePolicyBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """存掃描範圍規則（收哪些類別×環境＋個別覆寫），存完立刻同步成掃描來源。
    回整份 list_scope，前端拿去刷新（規則、逐段在/不在＋原因、in_sync）。"""
    import scan_scope

    patch = {k: v for k, v in body.model_dump().items() if v is not None}
    scan_scope.set_policy(conn, patch)
    return scan_scope.list_scope(conn)


@app.post("/api/scan/scope/apply")
def scan_scope_apply(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """把目前規則重新算一遍、同步成掃描來源（規則沒改、只想讓實際來源對齊規則時用）。"""
    import scan_scope

    scan_scope.apply_policy(conn)
    return scan_scope.list_scope(conn)


# ============ 納入管理（把掃到的主機登記成資產）============
@app.get("/api/cmdb/pull")
def cmdb_pull_endpoint(
    group: str | None = None,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """從 CMDB Gateway 拉資料：回筆數、看到的欄位名（用來對應到我們的欄位）、樣本。
    連不到/認證失敗回 502，錯誤原因如實帶出（不假裝成功）。"""
    try:
        items = cmdb_gateway.fetch_group(conn, group)
    except ConnectionError as exc:
        raise HTTPException(502, str(exc)) from exc
    return {
        "group": group,
        "count": len(items),
        "fields": cmdb_gateway.seen_fields(items),
        "sample": items[:20],
    }


# 帳外資產（DYN-/VC-/AUTO- 開頭）的判定跟首頁／部門報告頁同一條規則，
# 這裡不重寫一份，見 system_report.OFF_BOOK_PREFIXES 的說明。
_EXPORT_OFF_BOOK_PREFIXES = {"DYN": "DYN-", "VC": "VC-", "AUTO": "AUTO-"}


def _export_source_of(asset_serial: str | None) -> str:
    s = asset_serial or ""
    for label, prefix in _EXPORT_OFF_BOOK_PREFIXES.items():
        if s.startswith(prefix):
            return label
    return "CIA"


@app.get("/api/export")
def export_assets_endpoint(
    include_off_book: bool = False,
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db),
):
    """匯出資產（硬體/人員/軟體三分頁 xlsx）——對應資料匯入，有進就有出。

    表頭優先用「匯入對應表(field_mapping.json)的標題」，保證匯出的檔案能原封不動再匯入
    （round-trip）；欄位依 field_meta 分類排序，讓同一類欄位在表上相鄰、好填。

    2026-08-25 使用者：「要交出新的 CIA 資產清單，也是要完全準確」，並提出一個
    設計問題——系統裡有 CIA 登記的，也有 DYN-/VC-/AUTO- 開頭的帳外資產（存活清單
    掃到／vCenter 收到／納管流程建立，實際存在但沒登記）。回交給資產清單維護單位
    時，帳外那批要不要一起交，兩種答案意思完全不同（「更新你們的清單」vs
    「這是我實際盤到的，含你們沒有的 N 台」），這件事要使用者拍板，不是我自己決定。

    做法是把決定權交給匯出當下：預設**只匯出 CIA 登記的**（跟這支端點原本名字
    「匯出資產」被理解成「回交清單」最貼近，也是比較保守的預設——不會平白把
    內部帳外資產序號送給外部維護單位）；`include_off_book=true` 才把 DYN-/VC-/AUTO-
    也含進去。硬體分頁一律多一欄「來源」，即使沒勾選帳外也仍然加這一欄
    （值必然全是 CIA），讓兩種模式的檔案結構一致，不會勾不勾選就多一欄少一欄。
    """
    base = Path(__file__).parent
    meta_all = json.loads((base / "field_meta.json").read_text(encoding="utf-8"))
    fields_meta = meta_all.get("fields", {})
    cat_order = [c["key"] for c in meta_all.get("categories", [])]
    mapping = json.loads((base / "field_mapping.json").read_text(encoding="utf-8"))

    def _cat_rank(col: str) -> int:
        cat = fields_meta.get(col, {}).get("category")
        return cat_order.index(cat) if cat in cat_order else len(cat_order)

    # 帳外資產清單先算一次、三個分頁共用：人員/軟體表沒有自己的「這台是不是帳外」
    # 判定依據，要靠 asset_serial 回頭查 hardware 才知道——算一次避免三份查詢各判各的。
    off_book_serials = {
        r["asset_serial"] for r in conn.execute("SELECT asset_serial FROM hardware")
        if _export_source_of(r["asset_serial"]) != "CIA"
    }

    wb = Workbook()
    first = True
    for table, sheet in (("hardware", "硬體"), ("personnel", "人員"), ("software", "軟體")):
        ws = wb.active if first else wb.create_sheet(sheet)
        if first:
            ws.title = sheet
            first = False
        # 反轉匯入對應表：db欄位 -> 匯入期待的標題（確保 round-trip）。
        # 用 setdefault 保留「第一個出現的標題」當正式標題：field_mapping 允許一個db欄位
        # 掛多個標題別名（例如 api_id 同時吃 "API ID" 與 "AP ID"），若用 {v:k} 推導式會
        # last-wins，匯出表頭會被別名蓋掉、隨設定檔行序漂移。
        rev: dict[str, str] = {}
        for header, column in mapping.get(sheet, {}).items():
            if header != "_comment":
                rev.setdefault(column, header)
        orig = [r[1] for r in conn.execute(f"PRAGMA table_info({table})")]
        skip = {"id", "created_at", "updated_at"}
        orig = [c for c in orig if c not in skip]
        cols = sorted(orig, key=lambda c: (_cat_rank(c), orig.index(c)))
        # 表頭：先用匯入標題(可 round-trip)，退回 field_meta 中文 label，再退回欄名。
        # 「來源」欄只加在硬體分頁——人員/軟體是靠 asset_serial 掛在硬體底下的附屬資料，
        # 沒有獨立的「這筆是不是帳外」意義，重複加同一欄只是雜訊。
        headers = [rev.get(c) or fields_meta.get(c, {}).get("label", c) for c in cols]
        if table == "hardware":
            headers.append("來源")
        ws.append(headers)
        for row in conn.execute(f"SELECT {', '.join(cols)} FROM {table}"):
            if not include_off_book and row["asset_serial"] in off_book_serials:
                continue
            values = [row[c] for c in cols]
            if table == "hardware":
                values.append(_export_source_of(row["asset_serial"]))
            ws.append(values)
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    from urllib.parse import quote as _quote_export

    suffix = "含帳外" if include_off_book else "CIA"
    fname = f"assets_export_{suffix}_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
    return StreamingResponse(
        buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{_quote_export(fname)}"},
    )


@app.get("/api/field-meta")
def field_meta_endpoint(session: sqlite3.Row = Depends(require_auth)):
    """欄位中繼資料（分類×兩層），前端據此把納入管理表單分區、標 tech/biz。
    路徑刻意不放 /api/assets/ 底下——會被 /api/assets/{asset_serial} 這條 path 參數路由吃掉。"""
    return json.loads((Path(__file__).parent / "field_meta.json").read_text(encoding="utf-8"))


@app.get("/api/scan/unregistered")
def unregistered_endpoint(
    session: sqlite3.Row = Depends(require_auth), conn: sqlite3.Connection = Depends(get_db)
):
    """最新一次掃到、但 hardware(CIA) 未登記的主機——納入管理的候選清單。"""
    row = conn.execute("SELECT MAX(scan_time) AS t FROM scan_history WHERE scan_ok = 1").fetchone()
    t = row["t"] if row else None
    if not t:
        return []
    scanned = conn.execute(
        "SELECT ip, hostname, device_model, is_vm, segment, "
        "mac, mac_vendor, open_ports, ttl, os_guess "
        "FROM scan_history WHERE scan_time = ? AND scan_ok = 1",
        (t,),
    ).fetchall()
    out = []
    for r in scanned:
        if not r["ip"] and not r["hostname"]:
            continue
        matched = conn.execute(
            "SELECT 1 FROM hardware WHERE (ip IS NOT NULL AND ip = ?) OR (hostname IS NOT NULL AND hostname = ?)",
            (r["ip"], r["hostname"]),
        ).fetchone()
        if matched is None:
            out.append(dict(r))
    return out


@app.get("/api/scan/results")
def scan_results_endpoint(
    registered: str | None = None,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """最新一次掃描「掃得到（存活）」的主機，每筆標註是否已在 CIA 登記。

    給儀表板的「本次掃描 / 本次掃到存活」磚塊下鑽用。/api/scan/unregistered 只回未登記的
    那一半（納入管理專用），這支回全部並附 registered 旗標，才能對得上磚塊上的總數。

    registered：不帶=全部；yes=已登記；no=未登記（等同 unregistered 那份）。
    """
    if registered is not None and registered not in ("yes", "no"):
        raise HTTPException(400, "registered 只接受 yes 或 no")

    scan_time = _latest_scan_time(conn)
    scanned = _scanned_alive_rows(conn, scan_time)
    if not scanned:
        return {"scan_time": scan_time, "items": []}

    ica_rows = conn.execute("SELECT ip, hostname FROM hardware").fetchall()
    ica_ips = {r["ip"] for r in ica_rows if r["ip"]}
    ica_hostnames = {r["hostname"] for r in ica_rows if r["hostname"]}

    items = []
    for r in scanned:
        if not r["ip"] and not r["hostname"]:
            continue
        is_registered = _row_in_keys(r, ica_ips, ica_hostnames)
        if registered == "yes" and not is_registered:
            continue
        if registered == "no" and is_registered:
            continue
        item = dict(r)
        item["registered"] = is_registered
        # 已登記的話一併帶出資產序號，前端才能直接連到那台的詳細頁
        if is_registered:
            hw = conn.execute(
                "SELECT asset_serial FROM hardware WHERE (ip IS NOT NULL AND ip = ?) "
                "OR (hostname IS NOT NULL AND hostname = ?) LIMIT 1",
                (r["ip"], r["hostname"]),
            ).fetchone()
            item["asset_serial"] = hw["asset_serial"] if hw else None
        items.append(item)

    return {"scan_time": scan_time, "items": items}


class AdoptBody(BaseModel):
    fields: dict


@app.post("/api/assets/adopt")
def adopt_endpoint(
    body: AdoptBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """把一台掃到的主機登記成受管資產（technical 前端已帶入、business 使用者填）。"""
    f = {k: v for k, v in body.fields.items() if v not in (None, "")}
    ip = f.get("ip")
    if not ip:
        raise HTTPException(400, "缺少 IP，無法納入管理")
    if conn.execute("SELECT 1 FROM hardware WHERE ip = ?", (ip,)).fetchone():
        raise HTTPException(409, f"{ip} 已納入管理")
    if not f.get("asset_serial"):
        f["asset_serial"] = f"ADOPT-{ip}"   # 沒公司資產序號時先給暫用值，之後可改
    # 資產狀態沒填就預設「使用中」，不要留空。
    # 理由：這台會出現在納管候選清單，正是因為**掃描掃到它活著**——我們明明知道它在跑，
    # 畫面卻顯示「未知」是錯的資訊，不是保守。留空還會讓狀態排序整片沉到最後。
    # （使用者實際反映：納管進來的 6 台全顯示「未知」。）
    if not f.get("asset_status"):
        f["asset_status"] = "使用中"
    cols = {r[1] for r in conn.execute("PRAGMA table_info(hardware)")}
    f = {k: v for k, v in f.items() if k in cols}
    new_id = insert_hardware(conn, **f)

    # 納管當下就撤銷這台的「漏登記」，不要等下一次掃描。
    # 實際踩到（2026-07-19）：使用者納管 5 台之後，儀表板仍顯示「漏登記 6 筆」，
    # 但實際只有 1 台沒登記——因為撤銷只發生在掃描後的重比對。中間這段時間畫面在說謊，
    # 而「剛做完的動作沒有反映在畫面上」是最容易讓人失去信任的一種。
    retracted = conn.execute(
        "UPDATE comparison_result SET is_read = 1, handled_at = datetime('now','localtime') "
        "WHERE issue_type = '漏登記' AND is_read = 0 AND ("
        "  (ip IS NOT NULL AND ip = ?) OR (hostname IS NOT NULL AND hostname != '' AND hostname = ?)"
        ")",
        (ip, f.get("hostname") or ""),
    ).rowcount
    conn.commit()
    return {"id": new_id, "asset_serial": f["asset_serial"], "retracted_issues": retracted}


@app.get("/api/version")
def version_endpoint():
    """版本 + git commit + 服務啟動時間——讓使用者一眼確認「跑的是不是新版」。

    git_commit 直接問 git（服務就跑在 git 工作區上），不再依賴部署時 stamp 的
    build_info.json。理由是實際踩過的坑：stamp 檔由部署腳本寫、版號是每次請求即時讀檔，
    所以「檔案換了但服務沒重啟」時版號照樣跳成新版，看起來部署成功，實際跑的還是舊程式
    （2026-07-18 換 0.6.0 時就是這樣，最後靠 systemd 啟動時間才抓到）。

    started_at 是「本行程的啟動時間」——只有真的重啟過才會變，才是新程式碼有沒有生效的
    可信證據。dirty=true 代表工作區有未提交的改動（就地開發時很常見，不是錯誤）。
    """
    info = {"version": "?", "git_commit": None, "dirty": None,
            "started_at": _PROCESS_STARTED_AT, "built_at": None,
            # 登入被關掉時要讓畫面知道——前端靠這個掛紅色橫幅。
            # 放在 version（唯一免登入的端點）而不是別處：登入關掉時前端第一支
            # 打得到的就是它，而且它本來就每頁都會呼叫。
            "auth_disabled": auth_disabled()}
    here = Path(__file__).parent
    try:
        info["version"] = json.loads(
            (here / "version.json").read_text(encoding="utf-8")
        ).get("version", "?")
    except Exception:  # noqa: BLE001
        pass
    try:
        r = subprocess.run(["git", "rev-parse", "--short", "HEAD"], cwd=here,
                           capture_output=True, encoding="utf-8", timeout=5)
        if r.returncode == 0:
            info["git_commit"] = r.stdout.strip()
            d = subprocess.run(["git", "status", "--porcelain"], cwd=here,
                               capture_output=True, encoding="utf-8", timeout=5)
            info["dirty"] = bool(d.stdout.strip()) if d.returncode == 0 else None
    except Exception:  # noqa: BLE001
        pass
    if info["git_commit"] is None:
        # 沒有 git 的環境（例如打包部署到別台）才退回 stamp 檔
        try:
            info.update(json.loads((here / "build_info.json").read_text(encoding="utf-8")))
        except Exception:  # noqa: BLE001
            pass
    return info


# ===== M2 系統聯通圖 =====
class SystemBody(BaseModel):
    id: str
    label: str
    category: str | None = None
    domain: str | None = None
    health: str = "ok"
    is_spof: bool = False
    note: str | None = None


class SystemUpdateBody(BaseModel):
    label: str | None = None
    category: str | None = None
    domain: str | None = None
    health: str | None = None
    is_spof: bool | None = None
    note: str | None = None


class DepBody(BaseModel):
    source: str
    target: str
    dep_type: str | None = None


_HEALTH = {"ok", "warn", "err"}
_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,32}$")


@app.get("/api/topology")
def get_topology(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """M2 圖資料：一次回 systems + deps，前端餵 Cytoscape。全新建、人維護（戰情室重寫模型）。

    改為需登入（原本讀免登入）：這張圖含系統依賴與 SPOF 標記，等於直接告訴人「打哪一台
    全部會倒」，是最不該公開的資料；頁面本來就在登入牆後，公開讀沒有帶來任何好處。
    健康檢查請改用 /api/version（deploy.sh 用的就是它）。
    """
    import manage_state

    systems = [dict(r) for r in conn.execute("SELECT * FROM systems ORDER BY category, label").fetchall()]
    deps = [dict(r) for r in conn.execute("SELECT * FROM system_deps ORDER BY id").fetchall()]

    # M1↔M2 接起來：系統健康度由關聯主機的實際納管狀態推導，取代人手動標。
    # 沒有關聯主機的系統維持人工值，但明確標成 manual——把「某人半年前填的 ok」
    # 跟「剛剛確認過是 ok」混在一起，等於讓人相信一個沒有根據的綠燈。
    health = manage_state.system_health(conn)
    for s in systems:
        h = health.get(s["id"], {})
        s["health"] = h.get("health", s["health"])
        s["health_source"] = h.get("health_source", "manual")
        s["hosts"] = h.get("hosts", [])
    return {"systems": systems, "deps": deps}


@app.post("/api/systems")
def create_system(
    body: SystemBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    if not _ID_RE.match(body.id):
        raise HTTPException(400, "系統代碼只能是英數字/底線/減號，1-32 字")
    if body.health not in _HEALTH:
        raise HTTPException(400, "健康度必須是 ok/warn/err")
    if conn.execute("SELECT 1 FROM systems WHERE id = ?", (body.id,)).fetchone():
        raise HTTPException(409, f"系統代碼「{body.id}」已存在")
    conn.execute(
        "INSERT INTO systems (id, label, category, domain, health, is_spof, note) VALUES (?,?,?,?,?,?,?)",
        (body.id, body.label, body.category, body.domain, body.health, int(body.is_spof), body.note),
    )
    conn.commit()
    return {"id": body.id}


@app.put("/api/systems/{system_id}")
def update_system(
    system_id: str,
    body: SystemUpdateBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    if conn.execute("SELECT 1 FROM systems WHERE id = ?", (system_id,)).fetchone() is None:
        raise HTTPException(404, "查無此系統")
    fields = body.model_dump(exclude_none=True)
    if fields.get("health") and fields["health"] not in _HEALTH:
        raise HTTPException(400, "健康度必須是 ok/warn/err")
    if "is_spof" in fields:
        fields["is_spof"] = int(fields["is_spof"])
    if not fields:
        return {"id": system_id, "updated": 0}
    sets = ", ".join(f"{k} = ?" for k in fields)
    conn.execute(
        f"UPDATE systems SET {sets}, updated_at = datetime('now','localtime') WHERE id = ?",
        [*fields.values(), system_id],
    )
    conn.commit()
    return {"id": system_id, "updated": len(fields)}


@app.delete("/api/systems/{system_id}")
def delete_system(
    system_id: str,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    if conn.execute("SELECT 1 FROM systems WHERE id = ?", (system_id,)).fetchone() is None:
        raise HTTPException(404, "查無此系統")
    # 連帶刪掉相關依賴（schema 有 ON DELETE CASCADE，但 SQLite 預設不強制外鍵，這裡明確刪）
    conn.execute("DELETE FROM system_deps WHERE source = ? OR target = ?", (system_id, system_id))
    conn.execute("DELETE FROM systems WHERE id = ?", (system_id,))
    conn.commit()
    return {"id": system_id, "deleted": True}


@app.post("/api/deps")
def create_dep(
    body: DepBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    if body.source == body.target:
        raise HTTPException(400, "系統不能依賴自己")
    for sid in (body.source, body.target):
        if conn.execute("SELECT 1 FROM systems WHERE id = ?", (sid,)).fetchone() is None:
            raise HTTPException(400, f"系統「{sid}」不存在")
    if conn.execute(
        "SELECT 1 FROM system_deps WHERE source = ? AND target = ?", (body.source, body.target)
    ).fetchone():
        raise HTTPException(409, "這條依賴已存在")
    cur = conn.execute(
        "INSERT INTO system_deps (source, target, dep_type) VALUES (?,?,?)",
        (body.source, body.target, body.dep_type),
    )
    conn.commit()
    return {"id": cur.lastrowid}


@app.delete("/api/deps/{dep_id}")
def delete_dep(
    dep_id: int,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    if conn.execute("SELECT 1 FROM system_deps WHERE id = ?", (dep_id,)).fetchone() is None:
        raise HTTPException(404, "查無此依賴")
    conn.execute("DELETE FROM system_deps WHERE id = ?", (dep_id,))
    conn.commit()
    return {"id": dep_id, "deleted": True}


@app.get("/api/search")
def global_search(
    q: str,
    limit: int = 8,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """全域搜尋：一個框找遍資產／服務／業務系統／未登記的掃描結果。

    設計取捨：
    - **分組回傳而不是混成一串**：使用者搜「3306」時，「哪台在聽 3306」跟
      「哪台資產叫 3306」是完全不同的東西，混在一起只會讓人多按一次才找到。
    - **每組限量**：搜尋框是導航用的，不是報表。要看全部就點該組的「看全部」，
      帶著同一個關鍵字跳到對應的清單頁（連結由前端組，後端只回關鍵字命中）。
    - **掃到但未登記的主機也要出現**：那正是「這個 IP 是什麼」最常被問的時候，
      如果只搜已登記資產，答案會是「查無此項」——但它明明就在網路上。
    """
    import search_terms

    kw = (q or "").strip()
    if not kw:
        return {"query": "", "groups": []}
    if limit < 1 or limit > 50:
        raise HTTPException(400, "limit 只接受 1–50")

    # 2026-08-27 使用者的批評：「全文代表 DB 我都可以查，不是我說一個案例多一個
    # 功能，沒說就查不到」。以前這裡是寫死九個欄位，等於「我事先想到的清單」。
    #
    # 現在分兩層：
    #   · 既有的專屬分組（資產／服務／業務系統／機櫃／人員／軟體／單據）——
    #     它們的標題與連結是人工設計過的，導航體驗好，保留
    #   · 通用掃表（search_terms.scan）——掃過所有該掃的表的所有文字欄位，
    #     補上「沒被寫死到的東西完全看不見」這個洞
    parsed = search_terms.parse_query(kw)
    # 既有分組仍是單一 like，但改用「展開後的第一個詞」當代表；
    # 多關鍵字與同義詞的完整效果由通用組負責，兩者在畫面上分開顯示，
    # 不會讓人以為某一組漏了東西。
    like = f"%{parsed[0]['match'][0] if parsed else kw}%"

    groups = []

    # 一併 JOIN 業務系統：搜到一台機器之後，最常接著要問的就是「它屬於哪個系統」
    # （使用者 2026-09-10：「SEC01 是哪個 APID，我怎麼找不到」）。
    # 用 LEFT JOIN 而不是另外查一次——沒對到系統的機器仍然要出現在結果裡。
    #
    # 主機名比對加 lower()：真實資料裡 `sec01` 是小寫，人會打 `SEC01`。
    # SQLite 的 LIKE 對純 ASCII 本來就不分大小寫，但寫出來是為了不依賴那個預設值
    # （`hardware.hostname` 沒有 COLLATE NOCASE，別處已經因此吃過虧）。
    assets = conn.execute(
        "SELECT h.asset_serial, h.hostname, h.ip, h.device_model, h.environment, "
        "       h.asset_purpose, h.api_id, b.name AS system_name "
        "FROM hardware h LEFT JOIN business_system b ON b.api_id = h.api_id "
        "WHERE lower(COALESCE(h.hostname,'')) LIKE lower(?) OR h.ip LIKE ? "
        "   OR lower(COALESCE(h.asset_serial,'')) LIKE lower(?) "
        "   OR h.device_model LIKE ? OR h.asset_purpose LIKE ? OR h.custodian LIKE ? "
        "ORDER BY h.hostname LIMIT ?",
        (like, like, like, like, like, like, limit + 1),
    ).fetchall()
    if assets:
        groups.append({
            "key": "assets", "label": "資產",
            "items": [{
                "title": r["hostname"] or r["asset_serial"],
                # 「這台屬於哪個系統」要看得到（使用者 2026-09-10：
                # 「SEC01 是哪個 APID，我怎麼找不到」）。本來只有 IP／機型／環境，
                # 搜到之後還是答不出他真正要問的那件事。
                # 「這台屬於哪個系統」要看得到——本來只有 IP／機型／環境，
                # 搜到之後還是答不出他真正要問的那件事。
                # 有 api_id 卻沒有名稱時顯示代碼本身，不要整段消失：
                # 那代表「對照表少了這個代碼」，是另一種要補的東西。
                "subtitle": " · ".join(x for x in (
                    r["ip"],
                    (r["system_name"] or r["api_id"]) if r["api_id"] else None,
                    r["device_model"], r["environment"]) if x),
                "to": f"/assets/{r['asset_serial']}",
            } for r in assets[:limit]],
            "more": len(assets) > limit,
            "more_to": f"/assets?q={kw}",
        })

    # 服務：搜埠號、行程名、服務名都要中。數字就當埠號精準比，
    # 不然搜 "22" 會把 8022、2222 全撈進來，最想要的那筆反而被淹掉。
    if kw.isdigit():
        svc_rows = conn.execute(
            "SELECT hs.ip, hs.port, hs.process, hs.service_guess, hs.exposure, "
            "hs.asset_serial, h.hostname FROM host_service hs "
            "LEFT JOIN hardware h ON h.asset_serial = hs.asset_serial "
            "WHERE hs.gone_at IS NULL AND hs.port = ? ORDER BY hs.ip LIMIT ?",
            (int(kw), limit + 1),
        ).fetchall()
    else:
        svc_rows = conn.execute(
            "SELECT hs.ip, hs.port, hs.process, hs.service_guess, hs.exposure, "
            "hs.asset_serial, h.hostname FROM host_service hs "
            "LEFT JOIN hardware h ON h.asset_serial = hs.asset_serial "
            "WHERE hs.gone_at IS NULL AND (hs.process LIKE ? OR hs.service_guess LIKE ?) "
            "ORDER BY hs.ip LIMIT ?",
            (like, like, limit + 1),
        ).fetchall()
    if svc_rows:
        groups.append({
            "key": "services", "label": "服務",
            "items": [{
                "title": f"{r['service_guess'] or '未知服務'} · {r['port']}",
                "subtitle": f"{r['hostname'] or r['ip']}"
                            f"{'（僅本機）' if r['exposure'] == 'localhost' else ''}",
                "to": f"/services?port={r['port']}",
            } for r in svc_rows[:limit]],
            "more": len(svc_rows) > limit,
            "more_to": f"/services?port={kw}" if kw.isdigit() else "/services",
        })

    # 「業務系統」合併兩個來源，使用者不需要知道底下分開存：
    # (a) topology.vue 的 systems 表——人工維護的拓樸圖，舊資料
    # (b) hardware.api_id——MICS/blast 用的那份真相（177個真實業務系統代碼），
    #     2026-08-19 使用者反映搜代碼（如「N-218」）或系統名（如「STO 交易管理系統」）
    #     都搜不到，因為這裡原本只查 (a)，根本沒查 hardware.api_id。
    systems = conn.execute(
        "SELECT id, label, category, domain FROM systems "
        "WHERE id LIKE ? OR label LIKE ? OR category LIKE ? OR domain LIKE ? "
        "ORDER BY label LIMIT ?",
        (like, like, like, like, limit + 1),
    ).fetchall()
    biz_rows = conn.execute(
        "SELECT api_id, MIN(asset_name) AS name, COUNT(*) AS cnt FROM hardware "
        "WHERE api_id IS NOT NULL AND api_id != '' AND (api_id LIKE ? OR asset_name LIKE ?) "
        "GROUP BY api_id ORDER BY api_id LIMIT ?",
        (like, like, limit + 1),
    ).fetchall()
    system_items = [{
        "title": r["label"],
        "subtitle": " · ".join(x for x in (r["category"], r["domain"]) if x),
        # 帶 system id：topology 頁會自動選中這個節點，不然搜到系統名字進去
        # 只看到一整張沒有重點標記的圖，等於白搜。
        "to": f"/topology?system={r['id']}",
    } for r in systems]
    biz_items = [{
        "title": r["name"] or r["api_id"],
        "subtitle": f"{r['api_id']} · {r['cnt']} 台主機",
        "to": f"/assets?filter_field=api_id&filter_value={r['api_id']}",
    } for r in biz_rows]
    all_system_items = system_items + biz_items
    if all_system_items:
        groups.append({
            "key": "systems", "label": "業務系統",
            "items": all_system_items[:limit],
            "more": len(all_system_items) > limit,
            "more_to": "/topology",
        })

    # 機櫃：CI圖譜有 rack:{機房}#{櫃號} 節點（真的有依賴邊，不只是位置標籤）——
    # 2026-08-19 使用者反映連機櫃都要找得到，搜到直接帶去 /blast 查「這櫃掉電
    # 會波及誰」，比只列出同機櫃資產清單更有用。
    rack_rows = conn.execute(
        "SELECT physical_location, rack_no, COUNT(*) AS cnt FROM hardware "
        "WHERE physical_location IS NOT NULL AND physical_location != '' "
        "AND rack_no IS NOT NULL AND rack_no != '' "
        "AND (physical_location LIKE ? OR rack_no LIKE ? "
        "OR (physical_location || '/' || rack_no) LIKE ?) "
        "GROUP BY physical_location, rack_no ORDER BY physical_location, rack_no LIMIT ?",
        (like, like, like, limit + 1),
    ).fetchall()
    if rack_rows:
        from urllib.parse import quote as _quote
        groups.append({
            "key": "racks", "label": "機櫃",
            "items": [{
                "title": f"{r['physical_location']} / {r['rack_no']}",
                "subtitle": f"{r['cnt']} 台主機 · 查這櫃掉電會波及誰",
                "to": "/blast?mode=incident&q="
                      + _quote(f"rack:{r['physical_location']}#{r['rack_no']}"),
            } for r in rack_rows[:limit]],
            "more": len(rack_rows) > limit,
            "more_to": "/segments",
        })

    # 人員：2026-08-19 使用者反映「不只業務系統跟機櫃，是全部都要能全文搜」——
    # personnel 是獨立表，搜資產時的 custodian 只涵蓋 hardware.custodian 這個
    # 欄位，找不到用 personnel.person_name 登記的人。點進去帶去他名下的資產清單。
    people = conn.execute(
        "SELECT DISTINCT person_name, phone, belong_division, belong_department "
        "FROM personnel WHERE person_name IS NOT NULL AND person_name != '' "
        "AND (person_name LIKE ? OR phone LIKE ? OR job_desc LIKE ?) "
        "ORDER BY person_name LIMIT ?",
        (like, like, like, limit + 1),
    ).fetchall()
    if people:
        groups.append({
            "key": "people", "label": "人員",
            "items": [{
                "title": r["person_name"],
                "subtitle": " · ".join(
                    x for x in (r["belong_division"], r["belong_department"], r["phone"]) if x
                ),
                "to": f"/assets?filter_field=custodian&filter_value={r['person_name']}",
            } for r in people[:limit]],
            "more": len(people) > limit,
            "more_to": f"/assets?q={kw}",
        })

    # 軟體/資料庫盤點：跟資產是分開的表，搜資產名稱找不到裝在上面的軟體/DB名稱。
    soft = conn.execute(
        "SELECT asset_name, hostname, ip, db_software, asset_serial FROM software "
        "WHERE asset_name LIKE ? OR db_software LIKE ? OR hostname LIKE ? "
        "ORDER BY asset_name LIMIT ?",
        (like, like, like, limit + 1),
    ).fetchall()
    if soft:
        groups.append({
            "key": "software", "label": "軟體／資料庫",
            "items": [{
                "title": r["asset_name"] or r["db_software"] or "（未命名）",
                "subtitle": " · ".join(x for x in (r["db_software"], r["hostname"] or r["ip"]) if x),
                "to": f"/assets/{r['asset_serial']}" if r["asset_serial"] else f"/assets?q={kw}",
            } for r in soft[:limit]],
            "more": len(soft) > limit,
            "more_to": f"/assets?q={kw}",
        })

    # 掃到但沒登記的主機——「這個 IP 是什麼」最常就是在問這種
    scan_time = _latest_scan_time(conn)
    if scan_time:
        known_ips = {r["ip"] for r in conn.execute(
            "SELECT ip FROM hardware WHERE ip IS NOT NULL AND ip != ''")}
        unreg = [r for r in conn.execute(
            "SELECT ip, hostname, os_guess, mac_vendor FROM scan_history "
            "WHERE scan_time = ? AND scan_ok = 1 AND (ip LIKE ? OR hostname LIKE ?) "
            "ORDER BY ip LIMIT ?", (scan_time, like, like, limit + 10))
            if r["ip"] not in known_ips]
        if unreg:
            groups.append({
                "key": "unregistered", "label": "掃到但未登記",
                "items": [{
                    "title": r["ip"],
                    "subtitle": " · ".join(x for x in (r["hostname"], r["os_guess"],
                                                       r["mac_vendor"]) if x) or "無其他線索",
                    "to": "/adopt",
                } for r in unreg[:limit]],
                "more": len(unreg) > limit,
                "more_to": "/adopt",
            })

    # 單據檔案室：連 Word 內文一起搜。使用者原話是「以前要找相關資料，我要翻所有的
    # Word 檔」——全域搜尋不涵蓋單據的話，那個痛點只解決了一半。
    if conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='doc_archive'"
    ).fetchone():
        import doc_import

        docs = conn.execute(
            "SELECT id, file_name, doc_type, request_no, ref_request_no, form_date, "
            "hostname, ip, asset_serial, full_text FROM doc_archive "
            "WHERE full_text LIKE ? OR file_name LIKE ? OR request_no LIKE ? "
            "OR ref_request_no LIKE ? OR hostname LIKE ? OR ip LIKE ? "
            "ORDER BY form_date DESC LIMIT ?",
            (like, like, like, like, like, like, limit + 1),
        ).fetchall()
        if docs:
            groups.append({
                "key": "documents", "label": "單據（Word 內文）",
                "items": [{
                    "title": (r["request_no"] or r["ref_request_no"] or r["file_name"])
                             + f"　{r['hostname'] or ''}".rstrip(),
                    # 命中片段直接顯示，使用者不用開檔就知道是不是要找的那份
                    "subtitle": doc_import.snippet(r["full_text"] or "", kw)
                                or " · ".join(x for x in (r["form_date"], r["ip"]) if x),
                    "to": f"/documents?q={kw}",
                } for r in docs[:limit]],
                "more": len(docs) > limit,
                "more_to": f"/documents?q={kw}",
            })

    # ===== 通用掃表 =====
    #
    # 上面那些分組是「人工設計過的入口」，這一段是「保證沒有東西是看不見的」。
    # 已經有專屬分組的表就不重複列（但仍算進總數，不然畫面數字對不起來）。
    tables = search_terms.searchable_tables(conn)
    CURATED = frozenset({"hardware", "host_service", "systems", "personnel",
                         "software", "doc_archive", "scan_history"})
    scanned = search_terms.scan(conn, parsed, tables, skip_tables=CURATED)
    if scanned["groups"]:
        # 沒有 /search 這頁，通用命中不給死連結（點了會 404）。
        # 認得出家的就導過去：ci_node（叢集/ESXi/datastore）→ 架構圖；其餘留空不可點。
        def _generic_to(table: str) -> str:
            return "/architecture" if table == "ci_node" else ""

        groups.append({
            "key": "other", "label": "其他命中（通用掃表）",
            "items": [{
                "title": f"{g['table']}（{g['count']} 筆）",
                "subtitle": "；".join(
                    f"{s0['title']}〔{'、'.join(m['field'] for m in s0['matched'][:2])}〕"
                    for s0 in g["samples"][:2]),
                "to": _generic_to(g["table"]),
            } for g in scanned["groups"][:limit]],
            "more": False,
            "more_to": "",
        })

    # ===== 讓數字說得出來源 =====
    #
    # 這三個欄位是為了回答「為什麼查不到」。搜「測試區 vc」得 0 筆時，人要能看出
    # 是哪一個字完全沒命中，而不是兩個字都對但沒交集。
    # 「查不到」跟「沒有這個東西」是兩件事——這是這個專案的底線之一。
    return {
        "query": kw,
        "groups": groups,
        # 每個關鍵字展開成哪些詞（同義詞不可以安靜地擴大範圍）
        "terms": [{"term": p["term"], "match": p["match"],
                   "hits": scanned["term_hits"].get(p["term"], 0)} for p in parsed],
        # 這次搜了哪些表——沒列出來的表就是沒搜，人才知道結果的涵蓋範圍
        "searched_tables": [t for t, _ in tables],
        "excluded_tables": sorted(search_terms.EXCLUDE_TABLES),
        "total_hits": scanned["total"],
    }


# ===== M2 第一片：服務盤點（一台主機看得出什麼服務）=====

ALLOWED_SERVICE_SORT = {
    "ip", "hostname", "port", "proto", "exposure", "process", "service_guess",
    "guess_source", "last_seen", "first_seen", "asset_serial",
}


@app.get("/api/services")
def list_services_endpoint(
    ip: str | None = None,
    asset_serial: str | None = None,
    port: int | None = None,
    exposure: str | None = None,
    include_gone: bool = False,
    include_infra: bool = True,
    sort_by: str = "ip",
    order: str = "asc",
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """服務清單。預設不含已消失的，含基礎服務（SSH/NTP…，前端可一鍵收合）。

    排序在後端做（欄位走白名單、方向只認 asc/desc），跟 /api/assets 同一套；
    這張表可能上千列，前端排序只會排到目前拿到的那批。
    """
    import service_inventory

    rows = service_inventory.list_services(
        conn, ip=ip, asset_serial=asset_serial,
        include_gone=include_gone, include_infra=include_infra,
    )
    if port is not None:
        rows = [r for r in rows if r["port"] == port]
    if exposure:
        rows = [r for r in rows if r["exposure"] == exposure]

    key = sort_by if sort_by in ALLOWED_SERVICE_SORT else "ip"
    reverse = order == "desc"

    def sort_val(r):
        v = r.get(key)
        if v is None or v == "":
            return (1, "")           # 空值一律排最後，不隨 asc/desc 翻面
        if key == "ip" and isinstance(v, str) and v.count(".") == 3:
            try:
                return (0, tuple(int(p) for p in v.split(".")))
            except ValueError:
                return (0, v)
        return (0, v if not isinstance(v, str) else v.lower())

    try:
        rows.sort(key=sort_val, reverse=reverse)
    except TypeError:
        rows.sort(key=lambda r: (r.get(key) is None, str(r.get(key) or "")), reverse=reverse)

    return {"items": rows, "summary": service_inventory.service_summary(conn)}


@app.get("/api/services/summary")
def services_summary_endpoint(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import service_inventory

    return service_inventory.service_summary(conn)


# ===== SAN switch 收集（Brocade，2026-09-13）=====
# A 版：帳密由前端當場帶進來、只在記憶體、**不儲存任何憑證**；只跑唯讀白名單指令
# （見 san_collector.READONLY_COMMANDS），不動 switch 設定＝不踩 SOC。只落「結果」供盤點/統計。
class SanCollectBody(BaseModel):
    ip: str
    username: str
    password: str


@app.get("/api/san/switches")
def san_switches_endpoint(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import san_collector

    items = san_collector.list_switches(conn)
    done = sum(1 for i in items if i["collected"])
    return {"items": items, "total": len(items), "collected": done}


@app.get("/api/system/collector-selfcheck")
def collector_selfcheck_endpoint(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """收集端環境自我檢查：在後端行程內驗 paramiko 能不能真的用（SAN 收集／納管都靠它）。

    就在後端行程裡跑，看到的 paramiko＝實際收集會用到的那個（含被同名空目錄蓋掉的情況），
    而且會回「sys.path 上所有叫 paramiko 的東西」——位置直接顯示在畫面，不用叫人跑指令。
    """
    import collect_log
    import collector_env

    try:
        out = collector_env.selfcheck()
    except Exception as exc:  # noqa: BLE001 - 檢查本身壞掉也要留證據（2026-09-15 公司機就是這樣，紀錄 0 筆）
        collect_log.record(conn, "selfcheck", None, False, f"自我檢查本身失敗：{type(exc).__name__}: {exc}",
                           actor=session["username"] if session else None, exc=exc)
        raise
    # 只記「不好」的：每次開頁都會檢查，好的也記會把真正有用的紀錄淹掉
    if not out.get("ok"):
        collect_log.record(conn, "selfcheck", None, False, out.get("reason") or "自我檢查不通過",
                           actor=session["username"] if session else None,
                           extra={"selfcheck": out})
    return out


@app.post("/api/system/collector-selfheal")
def collector_selfheal_endpoint(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """一鍵修復：把蓋住 paramiko 的空目錄**改名備份**（不刪除），再驗一次。

    2026-09-15：公司機套了 v1.174.0 還是壞的——patch 只掃兩個固定位置，空目錄不在那。
    每查一次就重出一包 patch 太慢，所以讓畫面自己修得動。真套件（有 __init__.py）不碰。
    """
    import collect_log
    import collector_env

    out = collector_env.selfheal()
    collect_log.record(conn, "selfheal", None, bool(out.get("ok")), out.get("message") or "",
                       actor=session["username"] if session else None,
                       extra={"renamed": out.get("renamed"), "failed": out.get("failed"),
                              "before": out.get("before"), "after": out.get("after")})
    return out


@app.get("/api/system/collect-log")
def collect_log_list(
    limit: int = 50,
    kind: str | None = None,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """收集紀錄：每次 SAN 收集／自我檢查不通過／一鍵修復，連同當下完整環境（不含密碼）。
    2026-09-15 使用者：「修復至少 5 次，做個收集 LOG 或分析的」。見 collect_log。"""
    import collect_log

    kinds = [k.strip() for k in (kind or "").split(",") if k.strip()] or None
    return {"items": collect_log.recent(conn, limit=max(1, min(limit, 500)), kinds=kinds)}


@app.get("/api/system/collect-log/export")
def collect_log_export(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """整份收集分析檔（純文字），給使用者一次下載、整份交給開發者——不用再來回截圖猜。"""
    import collect_log
    from urllib.parse import quote

    fname = f"收集分析_{_now_local()[:10]}.txt"
    return Response(
        content=collect_log.export_text(conn).encode("utf-8"),
        media_type="text/plain; charset=utf-8",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(fname)}"},
    )


@app.get("/api/san/offline-guide")
def san_offline_guide_endpoint(session: sqlite3.Row = Depends(require_auth)):
    """離線匯入的步驟與標準唯讀指令清單（畫面一鍵複製用；與線上收集同一份）。"""
    import san_collector

    return san_collector.offline_guide()


class SshProbeBody(BaseModel):
    ip: str
    port: int = 22


@app.post("/api/tools/ssh-probe")
def ssh_probe_endpoint(
    body: SshProbeBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """SSH 測連線：同一台 IP 用新版與隔離的舊版 SSH 各試一次握手，**不登入**。見 ssh_probe。"""
    import collect_log
    import ssh_probe

    try:
        out = ssh_probe.run(body.ip, body.port)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    ok = out["modern"]["code"] == 0 or out["legacy"].get("code") == 0
    collect_log.record(conn, "ssh_probe", out["ip"], ok, out["verdict"],
                       actor=session["username"] if session else None,
                       extra={"port": out["port"], "modern": out["modern"], "legacy": out["legacy"]})
    return out


class AliveCheckBody(BaseModel):
    ip: str


@app.post("/api/tools/alive-check")
def alive_check_endpoint(
    body: AliveCheckBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """偵測存活：ICMP＋TCP 22/445/3389/5985 各試一次，只回報不改資料。見 host_ping。

    使用者 2026-09-16：「多一個 PING 按鈕動作，我可確認是否存活」，
    接著改名——「其他 port 也去測，所以不能說 PING，應該是『偵測存活』」。
    """
    import collect_log
    import host_ping

    try:
        out = host_ping.check(body.ip)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    collect_log.record(conn, "alive_check", out["ip"], bool(out["alive"]),
                       f"{out['verdict']}（{out['evidence']}）",
                       actor=session["username"] if session else None,
                       extra={"icmp": {k: v for k, v in out["icmp"].items() if k != "output"},
                              "tcp": out["tcp"]})
    return out


class AliveBatchBody(BaseModel):
    serials: list[str] | None = None
    ips: list[str] | None = None
    scope: str = ""


@app.post("/api/tools/alive-check/batch")
def alive_check_batch(
    body: AliveBatchBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """批次偵測存活，並存成一份報告。

    使用者 2026-09-16：「偵測後要 PO 報告」「每次偵測後要畫面狀態報告，不然只有沒有回應 很虛」。
    失聯 8062 台逐台按不可能，但**只對資產庫裡登記的 IP 偵測**——不展開網段、不探未知位址，
    這是維運確認，不是掃描。一次上限 host_ping.MAX_BATCH 台。
    """
    import collect_log
    import host_ping

    started = _now_local()
    targets: list[dict] = []
    seen: set[str] = set()
    if body.serials:
        ph = ",".join("?" for _ in body.serials)
        rows = conn.execute(
            f"SELECT asset_serial, hostname, ip FROM hardware WHERE asset_serial IN ({ph})",
            tuple(body.serials)).fetchall()
        for r in rows:
            if r["ip"] and r["ip"] not in seen:
                seen.add(r["ip"])
                targets.append({"asset_serial": r["asset_serial"], "hostname": r["hostname"], "ip": r["ip"]})
    for ip in body.ips or []:
        ip = (ip or "").strip()
        if not ip or ip in seen:
            continue
        r = conn.execute("SELECT asset_serial, hostname FROM hardware WHERE ip = ?", (ip,)).fetchone()
        seen.add(ip)
        targets.append({"asset_serial": r["asset_serial"] if r else None,
                        "hostname": r["hostname"] if r else None, "ip": ip})
    if not targets:
        raise HTTPException(400, "沒有可偵測的對象（勾選的資產都沒有登記 IP）")
    if len(targets) > host_ping.MAX_BATCH:
        raise HTTPException(
            400, f"一次最多偵測 {host_ping.MAX_BATCH} 台，這次選了 {len(targets)} 台——"
                 f"請分批（還有 {len(targets) - host_ping.MAX_BATCH} 台）")

    results = host_ping.check_many(targets)
    summary = host_ping.summarize_batch(results)
    run_id = host_ping.save_run(conn, results, body.scope or "", 
                                session["username"] if session else None, started)
    collect_log.record(
        conn, "alive_check", None, summary["no_response"] == 0,
        f"批次偵測 {summary['total']} 台：活著 {summary['alive']}、"
        f"沒有回應 {summary['no_response']}、無法判斷 {summary['unknown']}",
        actor=session["username"] if session else None,
        extra={"run_id": run_id, "scope": body.scope, "summary": summary})
    return {"run_id": run_id, "summary": summary, "items": results}


@app.get("/api/tools/alive-check/runs")
def alive_check_runs(
    limit: int = 20,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """過去的偵測報告清單。"""
    import host_ping

    return {"items": host_ping.list_runs(conn, limit)}


@app.get("/api/tools/alive-check/runs/{run_id}")
def alive_check_run_detail(
    run_id: int,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import host_ping

    run = host_ping.get_run(conn, run_id)
    if run is None:
        raise HTTPException(404, "查無這份偵測報告")
    return run


@app.get("/api/tools/alive-check/runs/{run_id}/export")
def alive_check_run_export(
    run_id: int,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """偵測報告匯出 Excel。"""
    import host_ping
    from urllib.parse import quote

    rows = host_ping.export_rows(conn, run_id)
    if not rows:
        raise HTTPException(404, "查無這份偵測報告")
    wb = Workbook()
    ws = wb.active
    ws.title = "偵測存活報告"
    ws.append(host_ping.EXPORT_HEADERS)
    for r in rows:
        ws.append(["" if v is None else v for v in r])
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    fname = f"偵測存活報告_{run_id}_{_now_local()[:10]}.xlsx"
    return StreamingResponse(
        buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(fname)}"})


@app.post("/api/san/collect")
def san_collect_endpoint(
    body: SanCollectBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import san_collector

    if not (body.ip and body.username and body.password):
        raise HTTPException(400, "IP／帳號／密碼都要填")
    import collect_log
    import onboard_engine

    by = session["username"] if session else None
    # 每一次都記下當下環境（成功也記）：失敗時才有「同一台行程上次成功是什麼樣子」可以比
    try:
        inv = san_collector.collect(body.ip, body.username, body.password)
    except RuntimeError as exc:
        collect_log.record(conn, "san_collect", body.ip, False, str(exc), actor=by, exc=exc,
                           extra={"connect_traceback": onboard_engine.last_connect_trace(body.ip)})
        raise HTTPException(502, str(exc))
    except Exception as exc:  # noqa: BLE001 - 未預期的也要留證據再往上丟
        collect_log.record(conn, "san_collect", body.ip, False, f"{type(exc).__name__}: {exc}",
                           actor=by, exc=exc,
                           extra={"connect_traceback": onboard_engine.last_connect_trace(body.ip)})
        raise
    result = san_collector.store(conn, body.ip, inv, by)
    san_collector.reconcile_hba_san(conn)   # 新收的 SAN 資料 → 反查補所有主機 HBA 的 fabric/zone
    raw = inv.get("_raw") or {}
    san_collector.archive(conn, body.ip, "online_collect",
                          "\n".join(f"### {k}\n{v}" for k, v in raw.items()), True,
                          recognized=raw.keys(), by=by)
    collect_log.record(conn, "san_collect", body.ip, True,
                       f"收集成功：WWPN {result.get('wwpn_count')} 筆", actor=by)
    return {"ok": True, **result}


class SanImportBody(BaseModel):
    ip: str
    transcript: str
    #: IP 防呆被擋下後，使用者確認「就是要匯到這個 IP」時才帶 true
    force: bool = False


@app.post("/api/san/import")
def san_import_endpoint(
    body: SanImportBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """離線匯入：防火牆還沒開通時，貼上自己在 switch 跑的唯讀指令畫面 → 同一支 parser 判讀後入庫。
    完全不連線、不需要帳密。"""
    import san_collector
    import san_parse

    import collect_log

    if not body.ip or not body.transcript.strip():
        raise HTTPException(400, "IP 和貼上的內容都要填")
    by = session["username"] if session else None
    outs = san_collector.split_transcript(body.transcript)
    # 照標準清單比對：缺哪幾個要講出來（2026-09-15 使用者要格式統一）
    bases = [c.split()[0] for c in san_collector.READONLY_COMMANDS]
    missing = [c for c in bases if c not in outs]
    parse_ok = bool(outs.get("switchshow") or outs.get("nscamshow") or outs.get("alishow"))
    # 原文整段先存（成功失敗都存、每次都留）——使用者：「通通都要記錄，哪一天用得到不知道」
    archive_id = san_collector.archive(conn, body.ip, "offline_import", body.transcript, parse_ok,
                                       recognized=outs.keys(), missing=missing, by=by)
    if not parse_ok:
        msg = ("找不到 switchshow／nscamshow／alishow 等指令的輸出——"
               "請照畫面上的指令清單跑，把『整段畫面』貼上（要含提示字元＋指令那一行）")
        collect_log.record(conn, "san_import", body.ip, False, msg, actor=by,
                           extra={"recognized": sorted(outs), "missing": missing,
                                  "transcript_lines": len(body.transcript.splitlines()),
                                  "archive_id": archive_id})
        raise HTTPException(400, msg + f"（原文已存檔 #{archive_id}，修好解析後可重新判讀，不用重收）")
    # IP 防呆（2026-09-15 使用者要）：switch 自己在 fabricshow 回報的管理 IP 跟填的 IP 不同，
    # 很可能是把 A 台的畫面匯進 B 台。先擋下來問人；原文上面已經存檔，不會丟。
    import san_parse

    sw_name = san_parse.parse_switchshow(outs.get("switchshow", ""))[0].get("switchName")
    reported_ip = san_parse.local_mgmt_ip(outs.get("fabricshow", ""), sw_name)
    entered_ip = body.ip.strip()
    if reported_ip is None:
        ip_check = "unverified"      # 沒跑 fabricshow 或認不出自己這台：照常匯入，但講清楚沒驗
    elif reported_ip == entered_ip:
        ip_check = "match"
    else:
        ip_check = "mismatch_forced" if body.force else "mismatch"
    if ip_check == "mismatch":
        msg = (f"IP 對不上：這份畫面是 switch「{sw_name or '?'}」自己回報的 {reported_ip}，"
               f"你填的是 {entered_ip}。可能貼錯台了——確定要匯入到 {entered_ip} 嗎？")
        collect_log.record(conn, "san_import", entered_ip, False, msg, actor=by,
                           extra={"reported_ip": reported_ip, "switch_name": sw_name,
                                  "archive_id": archive_id, "ip_check": ip_check})
        raise HTTPException(409, msg)
    inv = san_collector._parse_outputs(outs)   # 一併保留原始輸出（raw_json）
    result = san_collector.store(conn, body.ip, inv, by)
    san_collector.reconcile_hba_san(conn)   # 匯入的 SAN 資料 → 反查補主機 HBA
    min_missing = [c for c in san_collector.MIN_REQUIRED if c not in outs]
    collect_log.record(
        conn, "san_import", body.ip, True,
        f"離線匯入：認到 {len(outs)} 個指令、WWPN {result.get('wwpn_count')} 筆"
        + (f"；缺 {'、'.join(missing)}" if missing else "")
        + ("；⚠️ IP 不符但使用者確認強制匯入" if ip_check == "mismatch_forced" else "")
        + ("；IP 無法驗證（沒有 fabricshow）" if ip_check == "unverified" else ""),
        actor=by, extra={"recognized": sorted(outs), "missing": missing, "min_missing": min_missing,
                         "archive_id": archive_id, "ip_check": ip_check, "reported_ip": reported_ip})
    return {"ok": True, "imported_cmds": sorted(outs), "missing_cmds": missing,
            "min_missing": min_missing, "archive_id": archive_id,
            "ip_check": ip_check, "reported_ip": reported_ip, **result}


@app.get("/api/san/switches/{ip}/archive")
def san_switch_archive_endpoint(
    ip: str,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """這台 switch 每一次離線匯入／線上收集的原文存檔（新到舊，只增不改）。"""
    import san_collector

    return {"items": san_collector.list_archive(conn, ip)}


@app.get("/api/san/archive/{archive_id}/text")
def san_archive_text_endpoint(
    archive_id: int,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """下載某一次的原文（純文字，原樣）。"""
    import san_collector
    from urllib.parse import quote

    r = san_collector.get_archive(conn, archive_id)
    if not r:
        raise HTTPException(404, "查無此存檔")
    fname = f"SAN_{r['ip']}_{r['created_at'][:10]}_#{r['id']}.txt"
    return Response(content=(r["content"] or "").encode("utf-8"),
                    media_type="text/plain; charset=utf-8",
                    headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(fname)}"})


@app.get("/api/san/switches/{ip}")
def san_switch_detail_endpoint(
    ip: str,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    row = conn.execute("SELECT * FROM san_switch WHERE ip = ?", (ip,)).fetchone()
    if not row:
        raise HTTPException(404, "這台還沒收集過")
    d = dict(row)
    d["data"] = json.loads(d.pop("data_json") or "{}")
    return d


# ===== 主機硬體規格收集（已納管，2026-09-13）=====
@app.post("/api/host-spec/collect")
def host_spec_collect_endpoint(
    asset_serial: str | None = None,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """對已納管主機收 CPU/RAM/Storage/PSU＋NIC/HBA（AIX/Linux；Windows 待補）。
    用收集金鑰、唯讀、不用打密碼。傳 asset_serial＝只收這一台（詳細頁「收集規格」用）。"""
    import host_spec_collector
    return host_spec_collector.run_collection(conn, trigger="manual", only_serial=asset_serial)


@app.get("/api/host-spec/summary")
def host_spec_summary_endpoint(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    try:
        n = conn.execute("SELECT COUNT(*) FROM host_spec").fetchone()[0]
        last = conn.execute("SELECT MAX(collected_at) FROM host_spec").fetchone()[0]
    except Exception:  # noqa: BLE001
        n, last = 0, None
    return {"collected": n, "last": last}


# ===== 機房搬遷盤點表匯出（2026-09-13）=====
@app.get("/api/relocation/locations")
def relocation_locations_endpoint(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import relocation_export
    return {"items": relocation_export.locations(conn)}


@app.post("/api/relocation/import")
def relocation_import_endpoint(
    file: UploadFile = File(...),
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """匯入現場填回的 Master → 逐欄跟系統對帳 → 回一份校對版（綠同/紅異/藍補）＋差異列進CIA待異動。
    只讀不寫回資料庫。"""
    import relocation_import
    from urllib.parse import quote

    try:
        raw = file.file.read()
        buf, summary = relocation_import.reconcile(conn, raw)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    except Exception as exc:  # noqa: BLE001 — openpyxl 對壞檔的例外型態不一
        raise HTTPException(400, f"讀不了這個檔：{exc}")
    fname = f"機房搬遷盤點表_校對版_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
    return StreamingResponse(
        buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(fname)}",
                 "X-Same": str(summary["same"]), "X-Diff": str(summary["diff"]),
                 "X-Filled": str(summary["filled"]), "X-Unknown": str(summary["unknown_serial"])},
    )


@app.get("/api/relocation/export")
def relocation_export_endpoint(
    location: str | None = None,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """把現有資料預填成搬遷 Master 的 4 張表（Server Master/LAN/FC SAN/Power）並下載。"""
    import relocation_export
    from urllib.parse import quote

    buf, n = relocation_export.build(conn, location)
    tag = (location or "全部").replace("/", "_")
    fname = f"機房搬遷盤點表_{tag}_{datetime.now().strftime('%Y%m%d')}.xlsx"
    return StreamingResponse(
        buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(fname)}",
                 "X-Row-Count": str(n)},
    )


# ===== HMC 收集（IBM Power／AIX／IBM i，2026-09-13）=====
# 同 SAN 的 A 版安全模式：帳密當場帶入、只在記憶體、不儲存；只跑唯讀查詢指令（見 hmc_collector）。
class HmcCollectBody(BaseModel):
    ip: str
    username: str
    password: str


@app.get("/api/hmc/consoles")
def hmc_consoles_endpoint(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import hmc_collector

    items = hmc_collector.list_consoles(conn)
    done = sum(1 for i in items if i.get("collected"))
    return {"items": items, "total": len(items), "collected": done}


@app.post("/api/hmc/collect")
def hmc_collect_endpoint(
    body: HmcCollectBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import hmc_collector

    if not (body.ip and body.username and body.password):
        raise HTTPException(400, "IP／帳號／密碼都要填")
    try:
        inv = hmc_collector.collect(body.ip, body.username, body.password)
    except RuntimeError as exc:
        raise HTTPException(502, str(exc))
    by = session["username"] if session else None
    return {"ok": True, **hmc_collector.store(conn, body.ip, inv, by)}


@app.get("/api/hmc/consoles/{ip}")
def hmc_console_detail_endpoint(
    ip: str,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    row = conn.execute("SELECT * FROM hmc_console WHERE ip = ?", (ip,)).fetchone()
    if not row:
        raise HTTPException(404, "這台還沒收集過")
    d = dict(row)
    d["data"] = json.loads(d.pop("data_json") or "{}")
    return d


# ===== 軟體盤點（2026-09-11）=====
# 邏輯全在 software_inventory；這裡只是薄 HTTP 層。

@app.get("/api/software/summary")
def software_summary_endpoint(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import software_inventory

    return software_inventory.software_summary(conn)


# ⚠️ 不能用 /api/software：那個路徑早就是 CIA 清冊「系統軟體」分頁的清單（本檔前段），
# FastAPI 先註冊先贏，這裡同路徑會被靜默蓋掉——v1.92 就是這樣讓 2-10 整頁白掉。
@app.get("/api/software/packages")
def software_list_endpoint(
    q: str | None = None,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """依軟體名稱彙總（幾個版本、幾台）。排序在前端做——彙總後筆數不多。"""
    import software_inventory

    return {"items": software_inventory.list_software(conn, q),
            "summary": software_inventory.software_summary(conn)}


@app.get("/api/software/versions")
def software_versions_endpoint(
    name: str,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import software_inventory

    return {"items": software_inventory.software_versions(conn, name)}


@app.get("/api/software/hosts")
def software_hosts_endpoint(
    name: str,
    version: str | None = None,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import software_inventory

    return {"items": software_inventory.software_hosts(conn, name, version)}


@app.get("/api/software/by-host")
def software_by_host_endpoint(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import software_inventory

    return {"items": software_inventory.hosts_overview(conn)}


@app.get("/api/software/host")
def software_host_endpoint(
    ip: str,
    include_gone: bool = False,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import software_inventory

    return {"items": software_inventory.host_packages(conn, ip, include_gone)}


@app.get("/api/software/changes")
def software_changes_endpoint(
    days: int = 30,
    ip: str | None = None,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import software_inventory

    return {"items": software_inventory.list_changes(conn, days, ip)}


@app.post("/api/software/collect")
def software_collect_endpoint(
    asset_serial: str | None = None,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """對已納管主機收一輪軟體清單（可指定單台）。同步執行、會真的連出去。"""
    import software_inventory

    return software_inventory.collect_software(conn, only_serial=asset_serial,
                                               trigger="manual")


@app.post("/api/services/collect")
def collect_services_endpoint(
    asset_serial: str | None = None,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """對已納管主機收一輪服務（可指定單台）。

    ⚠️ 這是同步執行、會真的連出去——大批主機時前端要顯示執行中三態（async-feedback 規範）。
    收不到行程名（沒 root）不算失敗：埠是拿得到的，那已經是主要價值。
    """
    import service_inventory

    try:
        return service_inventory.collect_services(
            conn, only_serial=asset_serial, trigger="manual"
        )
    except Exception as exc:  # noqa: BLE001 - 失敗原因原樣回給畫面，不吞成一句「失敗」
        raise HTTPException(500, f"服務採集失敗：{exc}") from exc


# ===== 帳號盤點（稽核導向）=====

ALLOWED_ACCOUNT_SORT = {
    "ip", "hostname", "username", "uid", "kind", "gecos", "last_login", "pw_last_change",
    "pw_max_days", "pw_status", "is_sudoer", "authorized_keys", "asset_serial",
}


@app.get("/api/accounts")
def list_accounts_endpoint(
    ip: str | None = None,
    asset_serial: str | None = None,
    kind: str | None = None,
    sudoer_only: bool = False,
    hide_builtin: bool = False,
    include_gone: bool = False,
    sort_by: str = "ip",
    order: str = "asc",
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import account_inventory

    rows = account_inventory.list_accounts(
        conn, ip=ip, asset_serial=asset_serial, kind=kind,
        include_gone=include_gone, sudoer_only=sudoer_only,
    )

    # 「拉掉內建帳號」：只藏乾淨的系統/內建帳號，被稽核點名的一律留著——
    # 把有 finding 的內建帳號藏起來，正好會蓋掉 UID 0 後門這種最該看的東西。
    # 藏了幾個會回報，不靜默丟（靜默截斷會讓人以為「就這些帳號」）。
    hidden_builtin = 0
    if hide_builtin:
        # 只有「實質違規(fail)」才讓內建帳號留下。不能用全部 finding——
        # 沒 root 時每個帳號都有一堆 unknown(查不到)，那會讓每個帳號都被保護、
        # 篩選器一個都藏不掉（真機 306 條 unknown 就是這情形）。
        # unknown 是「這欄沒查到」不是「這帳號有問題」，不該撐住整列。
        flagged = {(f["ip"], f["username"])
                   for f in account_inventory.latest_findings(conn)
                   if f["verdict"] == "fail"}
        kept = []
        for r in rows:
            if r.get("is_builtin") and (r["ip"], r["username"]) not in flagged:
                hidden_builtin += 1
                continue
            kept.append(r)
        rows = kept

    key = sort_by if sort_by in ALLOWED_ACCOUNT_SORT else "ip"
    reverse = order == "desc"

    def sv(r):
        v = r.get(key)
        if v is None or v == "":
            return (1, "")
        if key == "ip" and isinstance(v, str) and v.count(".") == 3:
            try:
                return (0, tuple(int(p) for p in v.split(".")))
            except ValueError:
                return (0, v)
        return (0, v if not isinstance(v, str) else v.lower())

    try:
        rows.sort(key=sv, reverse=reverse)
    except TypeError:
        rows.sort(key=lambda r: (r.get(key) is None, str(r.get(key) or "")), reverse=reverse)
    return {"items": rows, "summary": account_inventory.audit_summary(conn),
            "hidden_builtin": hidden_builtin}


@app.get("/api/accounts/findings")
def account_findings_endpoint(
    severity: str | None = None,
    rule_id: str | None = None,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """稽核發現。這是這個模組真正的產出——清單只是中間產物。"""
    import account_inventory
    import account_rules

    return {
        "items": account_inventory.latest_findings(conn, severity=severity, rule_id=rule_id),
        "summary": account_inventory.audit_summary(conn),
        "rules": [{"id": r["id"], "label": r["label"], "severity": r["severity"],
                   "law": r["law"]} for r in account_rules.RULES],
        "thresholds": account_rules.get_thresholds(conn),
    }


@app.get("/api/accounts/findings/export")
def export_findings(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """把稽核發現匯出成 Excel——稽核當天要交的是可存檔的證據表，不是叫人看畫面。

    每條含：風險/項目/帳號/帳號備註/主機/IP/判定/處置狀態/例外到期/覆核人/覆核時間/
    手動備註/法規依據。含處置狀態＝這份報告本身就是稽核軌跡。
    """
    import account_inventory

    findings = account_inventory.latest_findings(conn)
    sev_label = {"high": "高", "medium": "中", "low": "低"}
    status_label = {"open": "待處理", "ack": "已確認", "exception": "核准例外", "fixed": "已修復"}

    wb = Workbook()
    ws = wb.active
    ws.title = "帳號稽核發現"
    ws.append(["風險", "項目", "帳號", "帳號備註", "主機", "IP", "判定",
               "處置狀態", "例外到期", "覆核人", "覆核時間", "手動備註", "法規依據"])
    for f in findings:
        ws.append([
            "查不到" if f.get("verdict") == "unknown" else sev_label.get(f.get("severity"), ""),
            f.get("label"), f.get("username"), f.get("gecos"),
            f.get("hostname") or "", f.get("ip"), f.get("detail"),
            status_label.get(f.get("status"), f.get("status")),
            f.get("exempt_until") or "", f.get("decided_by") or "", f.get("decided_at") or "",
            f.get("note") or "", f.get("law"),
        ])
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    fname = f"帳號稽核發現_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
    from urllib.parse import quote
    return StreamingResponse(
        buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(fname)}"},
    )


@app.get("/api/accounts/matrix/export")
def export_matrix(
    cols: list[str] = Query(default=[]),
    kind: str | None = None,
    hide_builtin: bool = False,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """合規表匯出：使用者自選欄位，資料最小化給稽核看。

    只吐勾選的欄位——稽核不需要看到 UID、shell、金鑰把數這些內部細節，
    給越少越好。狀態欄的計算走 account_inventory.MATRIX_EXPORT_COLS（與前端同源）。
    """
    import account_inventory

    valid = account_inventory.MATRIX_EXPORT_COLS
    chosen = [c for c in cols if c in valid]
    if not chosen:
        raise HTTPException(400, "至少要選一個有效欄位")

    rows = account_inventory.list_accounts(conn, kind=kind or None)
    if hide_builtin:
        flagged = {(f["ip"], f["username"])
                   for f in account_inventory.latest_findings(conn) if f["verdict"] == "fail"}
        rows = [r for r in rows
                if not (r.get("is_builtin") and (r["ip"], r["username"]) not in flagged)]

    wb = Workbook()
    ws = wb.active
    ws.title = "帳號合規表"
    ws.append([valid[c][0] for c in chosen])
    for r in rows:
        ws.append([valid[c][1](r) for c in chosen])
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    fname = f"帳號合規表_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
    from urllib.parse import quote
    return StreamingResponse(
        buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(fname)}"},
    )


# ===== 收集金鑰：檢視與匯入 =====
# 在此之前金鑰只有一條路：deploy.sh 產一把新的。公司若已經有一把佈遍全機隊的
# 金鑰（例如巡檢用的），匯入它就省掉重新納管每一台。

class CollectorKeyBody(BaseModel):
    # 三選一的來源：貼上私鑰，或指定主機上既有的檔案路徑
    private_key: str | None = None
    public_key: str | None = None      # 留空就從私鑰導出
    from_path: str | None = None       # 私鑰不經過網路的那條路
    confirm: str                       # 必須是 "REPLACE"


@app.get("/api/collector-key")
def get_collector_key(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """現況：指紋、公鑰、換掉會影響幾台。**不回傳私鑰。**

    「會影響幾台」是這頁最重要的數字——沒有它，換金鑰看起來只是改個設定，
    實際上是讓那些主機的收集當場失效（它們 authorized_keys 裡是舊公鑰）。
    """
    import collector_key
    from db import get_setting

    st = collector_key.status(conn)
    st["last_import"] = get_setting(conn, "collector_key_last_import", None)
    return st


@app.post("/api/collector-key/import")
def import_collector_key(
    body: CollectorKeyBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """匯入收集金鑰。要打 REPLACE 確認。

    為什麼要打字確認：這個動作會讓**已經在運作的東西停止運作**——所有已納管主機
    的收集會當場失效，除非匯入的正是它們認得的那把。跟取消納管同一個道理，
    按鈕太容易誤觸。

    ⚠️ 私鑰進來就寫檔，**不回傳、不寫 log、不進稽核紀錄**。
    稽核只記「誰在什麼時候換了金鑰、新舊指紋各是什麼」——指紋是公開資訊，
    足以追溯且洩漏不出東西。
    """
    import collector_key

    if body.confirm != "REPLACE":
        raise HTTPException(400, "匯入金鑰會讓所有已納管主機的收集失效，請輸入 REPLACE 確認")
    try:
        if body.from_path:
            result = collector_key.adopt_from_path(
                conn, body.from_path, session["username"])
        elif body.private_key:
            result = collector_key.import_key(
                conn, body.private_key, body.public_key, session["username"])
        else:
            raise HTTPException(400, "要嘛貼上私鑰，要嘛給主機上的檔案路徑")
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc

    result["status"] = collector_key.status(conn)
    result["next_step"] = (
        "金鑰已換。**如果這不是原本那把**，已納管主機的收集會失效——"
        "請到「納入管理」重新納管，或確認目標主機的 authorized_keys 裡是這把新公鑰。"
        if result["changed"] else
        "指紋跟原本一樣——這就是同一把金鑰，已納管主機不受影響。")
    return result


# ===== 月報匯出（2026-09-07 規格、2026-09-08 動工）=====
# 系統只匯出「raw data ＋提示詞」成一個檔，人拿去給核准的 GPT 打「請分析」。
# **這裡沒有任何 AI 呼叫**——分析要的是判斷力，寫死規則做不到；而把 LLM 接進來
# 會多一條對外連線與一個資安關卡。匯出一個檔給人自己貼，成本最低、責任最清楚。

def _default_ym() -> str:
    return datetime.now().strftime("%Y-%m")


@app.get("/api/monthly-report/preview")
def monthly_report_preview(
    ym: str | None = None,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """畫面用：這個月能產出什麼、哪些構面有資料、哪些是外部來源。

    先讓人看得到「這份會長什麼樣」再決定要不要產——尤其是「🔌 保留（外部來源）」
    那三段，第一次看到的人會以為是我們漏做的。
    """
    import monthly_report

    ym = ym or _default_ym()
    payload = monthly_report.collect(conn)
    return {
        "year_month": ym,
        "generated_at": payload["generated_at"],
        "sections": [
            {k: v for k, v in sec.items() if k != "data"}   # 明細不進預覽，太大
            for sec in payload["sections"]
        ],
        "external_source": monthly_report.EXTERNAL_SOURCE,
        "snapshot": monthly_report.get_snapshot(conn, ym),
        "previous": monthly_report.get_snapshot(
            conn, monthly_report.previous_month(ym)),
    }


@app.get("/api/monthly-report/export")
def monthly_report_export(
    ym: str | None = None,
    freeze: bool = True,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """下載那一個檔（Markdown）。預設同時凍結當月快照。

    `freeze=false` 用於「我只是想看看」——不留下快照，才不會把還沒補完的資料
    當成當月結算凍結起來。
    """
    import monthly_report

    ym = ym or _default_ym()
    prev = monthly_report.get_snapshot(conn, monthly_report.previous_month(ym))
    md = monthly_report.render_markdown(conn, ym, session["username"], previous=prev)
    if freeze:
        monthly_report.freeze(conn, ym, session["username"])

    from urllib.parse import quote
    fname = f"月報原始資料_{ym}.md"
    return StreamingResponse(
        io.BytesIO(md.encode("utf-8")),
        media_type="text/markdown; charset=utf-8",
        headers={
            "Content-Disposition": f"attachment; filename*=UTF-8''{quote(fname)}",
            "Access-Control-Expose-Headers": "Content-Disposition",
        },
    )


@app.get("/api/monthly-report/snapshots")
def monthly_report_snapshots(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """歷次凍結的快照。跨月比較都用這份，不要拿「現在的資料」去比上個月——
    資料每天在補，那樣比出來的差異分不清是「真的變好」還是「資料變全」。"""
    import monthly_report

    return {"snapshots": monthly_report.list_snapshots(conn)}


@app.get("/api/accounts/export")
def export_accounts(
    fmt: str = "standard",
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """帳號盤點匯出，兩種格式（使用者 2026-08-28 指定）。

    · `standard`：公司現行的 18 欄格式，可以直接交出去
    · `full`：系統知道的全部欄位，給自己人查用

    ⚠️ `type_id` 只自動填確定的四種（1 最高權限／2 系統預設／5 我們的收集帳號／
    7 人員使用）。3 程式運行、4 資料庫運行、6 Anchor·APPM 從 /etc/passwd 分不出來
    ——使用者明講目前沒有邏輯、要人工判斷，所以**留空讓人在 Excel 裡填**。
    填一個看起來對的值，代價是稽核文件上的假資料，而且沒有人會發現。

    回應標頭 `X-Export-Summary` 帶「還差多少才完整」的數字，讓呼叫端顯示出來——
    只給一個檔案而不講「其中 N 筆的類型要人工填」，人會以為它是完整的。
    """
    import json as _json

    import account_export

    if fmt not in ("standard", "full"):
        raise HTTPException(400, "fmt 只接受 standard（公司標準格式）或 full（全匯出）")

    # 2026-09-18 起跟資料匯入頁的「帳號盤點」匯出同一份（account_audit.export_xlsx）：
    # 值仍來自 account_export（18 欄、type 只填 1／2／5／7），再加上沿用上次人工 type、
    # 保留使用者檔案的欄、跟上次比較。兩個地方按出來的檔案一模一樣，不會有兩套。
    import account_audit

    buf, res = account_audit.export_xlsx(conn, "standard" if fmt == "standard" else "all")
    summary = {
        "rows": len(res["rows"]),
        "unclassified_type": res["unclassified_type"],
        "type_carried": res["type_carried"],
        "rows_without_system_name": (res.get("summary") or {}).get("rows_without_system_name", 0),
    }
    label = "帳號盤點" if fmt == "standard" else "帳號全匯出"
    fname = f"{label}_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
    from urllib.parse import quote
    return StreamingResponse(
        buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={
            "Content-Disposition": f"attachment; filename*=UTF-8''{quote(fname)}",
            "X-Export-Summary": quote(_json.dumps(summary, ensure_ascii=False)),
            "Access-Control-Expose-Headers": "X-Export-Summary, Content-Disposition",
        },
    )


@app.post("/api/accounts/collect")
def collect_accounts_endpoint(
    asset_serial: str | None = None,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import account_inventory

    try:
        return account_inventory.collect_accounts(
            conn, only_serial=asset_serial, trigger="manual")
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(500, f"帳號採集失敗：{exc}") from exc


class CollectAccountBody(BaseModel):
    account: str
    collector_ip: str | None = None      # 空字串＝清掉設定、退回自動偵測
    # 收集帳號在 /etc/passwd 的備註欄。空字串＝清掉、退回中性預設。
    # ⚠️ 實際值（員工編號-姓名_部門_系統）存 DB 不進版控——這個檔會進公開 relay。
    account_comment: str | None = None


# 允許的收集身分：唯讀預設 + 已知標準管理帳號。不開放任意字串——
# 收集身分決定拿多大權限，不該讓它變成打字就能指定任意帳號的欄位。
def _allowed_collect_accounts() -> set[str]:
    import account_collector

    return {"webit3scan"} | set(account_collector.STD_MGMT_ACCOUNTS.keys())


@app.get("/api/accounts/collect-config")
def get_collect_config(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """目前的遠端收集身分，以及切成管理帳號時要先做的授權動作。

    webit3 用自己的金鑰、但以設定的身分登入——所以切成 sysinfra 前，要先把
    webit3 收集公鑰授權進各機的 sysinfra/.ssh/authorized_keys（一次性、可撤）。
    這裡回傳那把公鑰與現成指令，讓使用者用既有管道（巡檢 ansible）佈下去。
    """
    import manage_state

    current = manage_state.get_collect_account(conn)
    # 走同一支解析函式：沒有金鑰就當場產一把，不要叫人去命令列跑腳本
    # （使用者 2026-08-16 指正：這是畫面功能的前提，不該依賴一次人工動作）
    try:
        pubkey = onboard_engine.collector_pubkey()
    except ValueError as exc:
        pubkey = f"（{exc}）"
    collector_ip = onboard_engine.resolve_collector_ip(conn)
    from db import get_setting

    ip_setting = (get_setting(conn, onboard_engine.COLLECTOR_IP_SETTING, "") or "").strip()
    return {
        "account": current,
        # 收集器自己的位址：會被寫進目標主機 authorized_keys 的 from= 來源限制。
        # 填錯不會報錯，只會讓金鑰永遠被拒而納管顯示成功——所以畫面要看得到它是誰、
        # 從哪來的（畫面設定／環境變數／自動偵測）。
        "collector_ip": collector_ip,
        "collector_ip_source": ("畫面設定" if ip_setting
                                else "環境變數" if os.environ.get("ASSET_COLLECTOR_IP")
                                else "自動偵測"),
        "collector_ip_detected": onboard_engine.detect_collector_ip(),
        "options": [
            {"value": "webit3scan", "label": "webit3scan（唯讀最小權限）",
             "note": "看不到需 root 的欄位（密碼效期、sudo 明細、authorized_keys）"},
            {"value": "sysinfra", "label": "sysinfra（標準管理帳號，完整資料）",
             "note": "NOPASSWD:ALL，sudo -n 全通；需先授權收集公鑰進 sysinfra"},
        ],
        "pubkey": pubkey,
        # 收集帳號在 /etc/passwd 的備註欄。實際值存 DB 不進版控（含員工編號與姓名）。
        "account_comment": onboard_engine.resolve_account_comment(conn),
        "provision_hint": (
            "切成 sysinfra 前，先在各主機把上面這把公鑰加進 "
            "~sysinfra/.ssh/authorized_keys（用巡檢 ansible 一次佈完）。"
            "webit3 不持有 sysinfra 私鑰，授權隨時可撤（移掉該行即失效）。"
        ),
    }


@app.put("/api/accounts/collect-config")
def set_collect_config(
    body: CollectAccountBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    from db import set_setting

    if body.account not in _allowed_collect_accounts():
        raise HTTPException(
            400, f"不支援的收集身分：{body.account}（只接受 "
                 f"{', '.join(sorted(_allowed_collect_accounts()))}）")
    set_setting(conn, "collect_ssh_account", body.account)

    # 帳號備註（/etc/passwd 的 GECOS）。**實際值不進版控**——使用者要填的是
    # 「員工編號-姓名_部門_系統」，裡面有個資，而納管引擎的原始碼會進公開 relay。
    # 空字串＝清掉，退回中性預設（不是把空值當成「設成空的」）。
    if body.account_comment is not None:
        val = body.account_comment.strip()
        if val:
            try:
                onboard_engine.sanitize_account_comment(val)
            except ValueError as exc:
                raise HTTPException(400, str(exc))
        set_setting(conn, onboard_engine.ACCOUNT_COMMENT_SETTING, val)

    if body.collector_ip is not None:
        val = body.collector_ip.strip()
        if val:
            try:
                onboard_engine.validate_collector_ip(val)
            except ValueError as exc:
                raise HTTPException(400, str(exc))
        # 空字串＝清掉，退回自動偵測（不是把空值當成「設成空的」）
        set_setting(conn, onboard_engine.COLLECTOR_IP_SETTING, val)
    return {"account": body.account,
            "collector_ip": onboard_engine.resolve_collector_ip(conn),
            "account_comment": onboard_engine.resolve_account_comment(conn)}


# ===== 盤點主機清單：每種盤點都先回答「是哪幾台」（2026-09-16）=====
# 使用者：「我只知道四台? 不知道哪四台，應該是先列出哪幾台，我再進去點後才是那一台的全部資訊」
# ——並補「**每個盤點都是這概念**」。服務／軟體／EOS 共用同一支，見 inventory_hosts。


@app.get("/api/inventory/{kind}/hosts")
def inventory_hosts_endpoint(
    kind: str,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """某一種盤點實際收到資料的主機清單。kind：service／software／eos。"""
    import inventory_hosts

    if kind == "eos":
        items = inventory_hosts.eos_hosts(conn)
    elif kind in inventory_hosts.KINDS:
        items = inventory_hosts.hosts(conn, kind)
    else:
        raise HTTPException(404, f"沒有這種盤點：{kind}")
    return {"items": items, "total": len(items)}


@app.get("/api/inventory/{kind}/hosts/export")
def inventory_hosts_export(
    kind: str,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """主機清單匯出 Excel（使用者：「沒匯出功能，不方便找 IP」）。"""
    import inventory_hosts
    from urllib.parse import quote

    if kind == "eos":
        headers, rows, title = inventory_hosts.EOS_HEADERS, inventory_hosts.eos_export_rows(conn), "EOS"
    elif kind in inventory_hosts.KINDS:
        headers = inventory_hosts.headers(kind)
        rows = inventory_hosts.export_rows(conn, kind)
        title = inventory_hosts.KINDS[kind]["label"]
    else:
        raise HTTPException(404, f"沒有這種盤點：{kind}")

    wb = Workbook()
    ws = wb.active
    ws.title = f"{title}盤點主機清單"[:31]
    ws.append(headers)
    for r in rows:
        ws.append(["" if v is None else v for v in r])
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    fname = f"{title}盤點主機清單_{_now_local()[:10]}.xlsx"
    return StreamingResponse(
        buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(fname)}"})


@app.get("/api/accounts/inventoried-hosts")
def account_inventoried_hosts(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """**盤點到哪幾台**，每台幾個帳號、幾個稽核發現（2026-09-16 使用者：
    「我只知道四台? 不知道哪四台，應該是先列出哪幾台，我再進去點後才是那一台的全部帳號資訊」）。"""
    import account_inventory

    hosts = account_inventory.inventoried_hosts(conn)
    return {"items": hosts, "total": len(hosts)}


@app.get("/api/accounts/by-username")
def accounts_by_username(
    username: str,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """這個帳號存在於哪幾台（2026-09-17 使用者：「帳號 我想要找 例如 webit3 有哪幾台有這帳號」）。

    跟「主機→帳號」相反的問法，實務上同樣重要：停用離職者帳號、確認服務帳號佈到哪些機器。
    回傳帶部門與窗口——下一步就是去找人。
    """
    import account_inventory

    items = account_inventory.hosts_with_account(conn, username)
    return {"username": username, "items": items, "total": len(items)}


@app.get("/api/accounts/by-username/export")
def accounts_by_username_export(
    username: str,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """反查結果匯出 Excel——拿去給窗口對的就是這張。"""
    import account_inventory
    from urllib.parse import quote

    wb = Workbook()
    ws = wb.active
    ws.title = f"{username}"[:31] or "帳號反查"
    ws.append(account_inventory.ACCOUNT_HOSTS_HEADERS)
    for r in account_inventory.account_hosts_export_rows(conn, username):
        ws.append(["" if v is None else v for v in r])
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    fname = f"帳號反查_{username}_{_now_local()[:10]}.xlsx"
    return StreamingResponse(
        buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(fname)}"})


@app.get("/api/accounts/inventoried-hosts/export")
def account_inventoried_hosts_export(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """主機清單匯出 Excel（使用者：「沒匯出功能，不方便找 IP」）。"""
    import account_inventory
    from urllib.parse import quote

    wb = Workbook()
    ws = wb.active
    ws.title = "帳號盤點主機清單"
    ws.append(account_inventory.HOST_EXPORT_HEADERS)
    for r in account_inventory.hosts_export_rows(conn):
        ws.append(["" if v is None else v for v in r])
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    fname = f"帳號盤點主機清單_{_now_local()[:10]}.xlsx"
    return StreamingResponse(
        buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(fname)}"})


@app.get("/api/accounts/hosts")
def list_account_hosts(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """可收集的主機清單＋是否已排除。給排除管理與健檢選單用。"""
    import account_inventory

    return {"hosts": account_inventory.list_collectable_hosts(conn)}


class DispositionBody(BaseModel):
    ip: str
    username: str
    rule_id: str
    status: str
    note: str | None = None
    exempt_until: str | None = None


@app.put("/api/accounts/findings/disposition")
def set_finding_disposition_endpoint(
    body: DispositionBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """設一條稽核發現的處置狀態（待處理/已確認/核准例外/已修復）。跨盤點持久。

    decided_by 記登入者——稽核要能查「這條例外是誰、何時核准的」。
    """
    import account_inventory

    try:
        return account_inventory.set_finding_disposition(
            conn, body.ip, body.username, body.rule_id, body.status,
            note=body.note, exempt_until=body.exempt_until,
            decided_by=session["username"])
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


class AccountNoteBody(BaseModel):
    ip: str
    username: str
    note: str = ""


@app.put("/api/accounts/note")
def set_account_note_endpoint(
    body: AccountNoteBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """設某帳號的「手動備註」——稽核人員自己輸入的註記（跟 gecos 自動備註是兩回事）。"""
    import account_inventory

    try:
        return account_inventory.set_account_note(conn, body.ip, body.username, body.note)
    except ValueError as exc:
        raise HTTPException(404, str(exc)) from exc


class AccountKindBody(BaseModel):
    ip: str
    username: str
    kind: str = ""     # 空字串＝清掉覆寫、回到程式判定


@app.put("/api/accounts/kind")
def set_account_kind_endpoint(
    body: AccountKindBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """手動改某帳號的類型——程式判錯時用（例如 CBoss 被判成內建帳號、實際是服務帳號）。
    收集不覆寫；傳空字串＝清掉覆寫回到程式判定。"""
    import account_inventory

    try:
        return account_inventory.set_account_kind(conn, body.ip, body.username, body.kind)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


class ExcludeBody(BaseModel):
    asset_serial: str
    exclude: bool


@app.put("/api/accounts/exclude")
def set_account_exclude(
    body: ExcludeBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """把一台主機排除／納回帳號稽核。排除時清掉它的舊帳號與稽核資料。"""
    import account_inventory

    if conn.execute("SELECT 1 FROM hardware WHERE asset_serial = ?",
                    (body.asset_serial,)).fetchone() is None:
        raise HTTPException(404, "查無此資產")
    return account_inventory.set_host_excluded(conn, body.asset_serial, body.exclude)


@app.get("/api/accounts/diagnose")
def diagnose_account_host(
    asset_serial: str,
    desensitize: bool = True,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """逐主機收集健檢：即時跑每條收集指令，回報為什麼收不到。

    給公司多 OS 上線 debug 用。安全：不含任何原始輸出內容（見 collect_probe），
    再走 diagnostics 的去識別化＋殘留掃描閘門，可安全匯出貼給開發者。
    desensitize 預設 True——真實資料不出這台機器是硬規則。
    """
    import collect_probe
    import diagnostics as dg
    import manage_state

    row = conn.execute(
        "SELECT ip FROM hardware WHERE asset_serial = ?", (asset_serial,)
    ).fetchone()
    if not row or not row["ip"]:
        raise HTTPException(404, "查無此資產或它沒有 IP")

    account = manage_state.get_collect_account(conn)
    try:
        report = collect_probe.probe(
            row["ip"], account, manage_state.COLLECTOR_KEY_DEFAULT,
            local_ips=manage_state.local_ips())
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(500, f"健檢執行失敗：{exc}") from exc

    if desensitize:
        d = dg.Desensitizer(enabled=True)
        report = d.walk(report)
        residual = dg.residual_scan(json.dumps(report, ensure_ascii=False))
        report["_desensitized"] = True
        report["_residual_scan"] = residual or "通過（未發現未遮蔽的位址）"
        # 殘留掃描沒過就不給——真實位址不出這台機器
        if residual:
            raise HTTPException(
                500, f"健檢輸出殘留掃描未通過，已擋下不外送：{residual[:3]}")
    return report


@app.get("/api/accounts/sudo-rules")
def account_sudo_rules(session: sqlite3.Row = Depends(require_auth)):
    """收集帳號要拿到密碼/sudo/金鑰資訊所需的 sudo 白名單。

    刻意做成「給你看、你自己決定要不要佈」而不是自動佈署：
    這是擴權動作，且會改動所有已納管主機的 sudoers。
    白名單本身不含 `cat /etc/shadow`——chage -l／passwd -S 拿得到同樣的稽核結論
    卻不吐密碼雜湊，能用小權限達成就不該要大的。
    """
    import account_collector

    return {
        "rules": account_collector.SUDO_RULES,
        "note": "存成 /etc/sudoers.d/webit3scan-audit（chmod 440），"
                "並用 visudo -cf 驗證後才生效。不含 /etc/shadow，不會洩漏密碼雜湊。",
    }


@app.on_event("startup")
def _start_scheduler():
    # 只在正式服務啟動時開排程器（webit3-api.service 設 ASSET_SCHEDULER=1）；
    # 測試/開發匯入 app 時不啟動，避免背景亂掃。
    if os.environ.get("ASSET_SCHEDULER") == "1":
        scan_service.start_scheduler()
        # 清掉超過保留期的操作紀錄。跟排程器同一個條件：只有正式服務會做，
        # 測試匯入 app 時不要動任何人的資料。
        try:
            conn = get_connection()
            try:
                n = activity.purge_old(conn)
                if n:
                    print(f"[activity] 清掉 {n} 筆超過 {activity.RETAIN_DAYS} 天的操作紀錄")
            finally:
                conn.close()
        except Exception as exc:  # noqa: BLE001 - 清理失敗不可以擋住服務啟動
            print(f"[activity] 清理舊紀錄失敗（不影響服務）：{exc}")


# ===== 報表列印：來源對照表（CIA／DY／vCenter）=====
# 2026-09-18 使用者：「給我一張 IP/hostname × DY/CIA 表，欄位我自己選，我要拿去
# Excel 跑樞紐分析」。所以這裡**不做分析、不預先過濾**，只吐乾淨的一台一列原始資料。

@app.get("/api/reports/host-sources")
def host_sources_endpoint(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """來源對照表：一台一列，含小計。小計要對得回首頁與分佈統計，不然這張表就是第三套數字。"""
    import host_sources

    items = host_sources.rows(conn)
    return {
        "items": items,
        "summary": host_sources.summary(items),
        "columns": [{"key": k, "label": v} for k, v in host_sources.COLUMNS.items()],
        "default_columns": list(host_sources.DEFAULT_COLUMNS),
    }


@app.get("/api/reports/host-sources/export")
def host_sources_export(
    cols: list[str] = Query(default=[]),
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """匯出 Excel。沒指定欄位就用預設那組，不要讓人拿到一個空檔案還不知道為什麼。"""
    import host_sources

    chosen = [c for c in cols if c in host_sources.COLUMNS] or list(host_sources.DEFAULT_COLUMNS)
    items = host_sources.rows(conn)

    wb = Workbook()
    ws = wb.active
    ws.title = "來源對照表"
    ws.append([host_sources.COLUMNS[c] for c in chosen])
    for r in items:
        row = []
        for c in chosen:
            v = r.get(c)
            # 布林在 Excel 裡顯示成 TRUE/FALSE 不好做樞紐，改成看得懂又好篩的字
            row.append(("是" if v else "") if isinstance(v, bool) else v)
        ws.append(row)
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    fname = f"來源對照表_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
    from urllib.parse import quote
    return StreamingResponse(
        buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition":
                 f"attachment; filename*=UTF-8''{quote(fname)}"},
    )


@app.get("/api/reports/hardware-master/export")
def hardware_master_export(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """資產主檔（全欄位＋來源＋machine_key＋同台筆數）＋欄位說明，一個 xlsx 兩個分頁。

    2026-09-18 使用者問「這表格系統能直接產嗎」——原本是一次性腳本產的，改成系統功能。
    """
    import hardware_master

    buf = hardware_master.export_xlsx(conn)
    fname = f"WEBIT3_資產主檔_hardware_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
    from urllib.parse import quote
    return StreamingResponse(
        buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(fname)}"},
    )


# ===== OS 類型人工指定（2026-09-18）=====
# 使用者：「如果少數錯誤，我可以手動編輯 OS 類型搬移」。另存一張表，重匯 CIA 不會蓋掉
#（改資產的 OS 欄會被 excel_import._upsert 覆寫）。見 os_override.py。

class OsTypeOverrideBody(BaseModel):
    hostname: str | None = None
    ip: str | None = None
    asset_serial: str | None = None
    os_type: str
    auto_os_type: str | None = None
    reason: str | None = None


@app.get("/api/os-type-overrides")
def os_type_overrides_list(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """目前有效的人工指定，外加可選類別。"""
    import os_override
    return {"items": os_override.list_active(conn), "choices": os_override.choices()}


@app.put("/api/os-type-overrides")
def os_type_override_set(
    body: OsTypeOverrideBody,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import os_override
    try:
        return os_override.set_override(conn, body.hostname, body.ip, body.asset_serial,
                                        body.os_type, body.auto_os_type, body.reason,
                                        session["username"])
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@app.delete("/api/os-type-overrides")
def os_type_override_clear(
    hostname: str | None = None,
    ip: str | None = None,
    asset_serial: str | None = None,
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """恢復自動判斷（軟刪除，紀錄保留）。"""
    import os_override
    n = os_override.clear(conn, hostname, ip, asset_serial, session["username"])
    return {"ok": True, "cleared": n}


# ===== 帳號盤點：匯入上次盤點／範例／匯出本次（2026-09-18）=====
# 使用者：「上次盤點的，在匯入的地方做一個帳號盤點匯入／範例／及盤點後的匯出」
# 「帳號盤點格式是用這個為準，其他的類似 sudo 等算內部管理用，匯出可選標準 A-R，跟全部兩種」。
# 見 account_audit.py。

def _xlsx_response(buf, fname: str):
    from urllib.parse import quote
    return StreamingResponse(
        buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(fname)}"})


@app.get("/api/account-audit/template")
def account_audit_template(session: sqlite3.Row = Depends(require_auth)):
    import account_audit
    return _xlsx_response(account_audit.template_xlsx(), "帳號盤點_範例.xlsx")


@app.get("/api/account-audit/status")
def account_audit_status(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """最近匯入的上次盤點批次、歷史、類型代碼對照。"""
    import account_audit
    b = account_audit.latest_batch(conn)
    return {"latest": b, "history": account_audit.history(conn),
            "type_table": [{"code": c, "info": i} for c, i in account_audit.TYPE_TABLE],
            "standard_default": account_audit.STANDARD_DEFAULT}


@app.post("/api/account-audit/import")
async def account_audit_import(
    file: UploadFile = File(...),
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    import account_audit
    data = await file.read()
    try:
        out = account_audit.import_file(conn, data, file.filename or "upload", session["username"])
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    # 原始檔留一份（跟其他來源一樣在端點存，模組本身不碰磁碟——否則測試會寫進正式的原始檔目錄）。
    # dump 匯回不算原始檔，不覆蓋。
    fname = (file.filename or "upload.xlsx")
    if not fname.lower().endswith(".webit3dump") and data[:2] != b"\x1f\x8b":
        import import_export
        try:
            import_export.save_original("account_audit", fname, data)
        except OSError as exc:
            out["original_saved"] = False
            out["original_error"] = str(exc)
    return out


@app.get("/api/account-audit/export")
def account_audit_export(
    mode: str = "standard",
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """mode=standard：A～R（照最後匯入的表頭）＋比較分頁；mode=all：加內部管理欄與比較欄。"""
    import account_audit
    if mode not in ("standard", "all"):
        raise HTTPException(400, "mode 只接受 standard 或 all")
    buf, _res = account_audit.export_xlsx(conn, mode)
    tag = "標準A-R" if mode == "standard" else "全部"
    return _xlsx_response(buf, f"帳號盤點_{tag}_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx")



@app.get("/api/accounts/search-explain")
def accounts_search_explain(
    q: str = "",
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """合規表搜尋 0 筆時的說明：這個詞在資產庫對得到幾台、幾台還沒收集帳號（2026-09-18）。"""
    import account_inventory
    return account_inventory.explain_search(conn, q)


@app.get("/api/accounts/coverage")
def accounts_coverage(
    session: sqlite3.Row = Depends(require_auth),
    conn: sqlite3.Connection = Depends(get_db),
):
    """帳號收集涵蓋率（2026-09-18 十項盤點第 9 條）。

    221 上收到帳號的只有 1 台（它自己），在管 3,116 台——合規表、帳號盤點看起來像
    「全公司只有 33 個帳號」，畫面卻沒講這件事。「沒有資料」跟「資料很少」要分得開。
    在管的母體跟首頁「在管」同一套（host_view：排退役＋帳外、machine_key 去重）。
    """
    import host_view

    hv = host_view.list_hosts(conn)
    managed_ips = {(h.get("ip") or "").strip() for h in hv["hosts"] if h.get("ip")}
    got = {r[0] for r in conn.execute(
        "SELECT DISTINCT ip FROM host_account WHERE gone_at IS NULL") if r[0]}
    in_managed = len(got & managed_ips)
    return {
        "managed_hosts": hv["total_hosts"],
        "collected_hosts": len(got),
        "collected_managed": in_managed,
        "collected_outside": len(got) - in_managed,   # 收到了但不在在管清單（帳外／未登記）
        "pct": round(in_managed / hv["total_hosts"] * 100, 2) if hv["total_hosts"] else None,
    }
