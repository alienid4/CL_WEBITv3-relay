<script setup lang="ts">
// 選單編輯（2026-09-11）：全站共用一份順序、限管理員改。拖拉項目在群之間搬、
// 群可上下移＋改名＋新增＋刪空群，存到 app_settings 的 nav_layout。
// 選單資料（label/icon）來自 composables/useNav.ts（跟外殼同一份，不漂移）。
const { apiFetch } = useApi()

interface EItem { to: string; label: string; icon?: string }
interface EGroup { id: string; label: string; icon?: string; to?: string; items: EItem[] }
// 存的項目可以是純路由字串（舊版），或 { to, label }（新版：帶自訂名稱）。兩種都要吃。
type SavedItem = string | { to: string; label?: string }
interface SavedGroup { id?: string; label: string; icon?: string; to?: string; items: SavedItem[] }
function itemTo(e: SavedItem) { return typeof e === 'string' ? e : e.to }
function itemLabel(e: SavedItem) { return typeof e === 'string' ? undefined : e.label }

const groups = ref<EGroup[]>([])
const canEdit = ref(false)
const loading = ref(true)
const saving = ref(false)
const msg = ref('')

const CAT = navCatalog()
function toEItem(routeTo: string): EItem | null {
  const c = CAT[routeTo]
  if (!c || !c.to || c.adminOnly) return null   // 選單編輯本身不列進去給人搬
  return { to: c.to, label: c.label, icon: c.icon }
}
function fromDefault(): EGroup[] {
  return defaultGroups().map((g, i) => ({
    id: `g${i}`, label: g.label, icon: g.icon, to: g.to,
    items: g.items.map((it) => it.to && toEItem(it.to)).filter(Boolean) as EItem[],
  }))
}

const savedRaw = ref<SavedGroup[] | null>(null)
async function load() {
  loading.value = true
  try {
    const r = await apiFetch<{ layout: SavedGroup[] | null; can_edit: boolean }>('/api/nav-layout')
    canEdit.value = !!r.can_edit
    savedRaw.value = r.layout
    if (r.layout && r.layout.length) {
      const placed = new Set<string>()
      const gs: EGroup[] = r.layout.map((sg, i) => {
        const items = (sg.items || []).map((e) => {
          const base = toEItem(itemTo(e))
          if (!base) return null
          const lbl = itemLabel(e)
          return lbl ? { ...base, label: lbl } : base
        }).filter(Boolean) as EItem[]
        items.forEach((it) => placed.add(it.to))
        if (sg.to) placed.add(sg.to)
        return { id: sg.id || `g${i}`, label: sg.label, icon: sg.icon || '▸', to: sg.to || '', items }
      })
      // 內建有、存的版面沒放到的（新加功能）補回同名群，不讓它消失
      for (const dg of fromDefault()) {
        for (const it of dg.items) {
          if (placed.has(it.to)) continue
          let g = gs.find((x) => x.label === dg.label)
          if (!g) { g = { id: `g${gs.length}`, label: dg.label, icon: dg.icon, to: '', items: [] }; gs.push(g) }
          g.items.push(it)
        }
      }
      groups.value = gs
    } else {
      groups.value = fromDefault()
    }
  } finally {
    loading.value = false
  }
}
onMounted(load)

// ---- 拖拉：項目在群之間搬 ----
const drag = ref<{ gi: number; ii: number } | null>(null)
function onDragStart(gi: number, ii: number) { drag.value = { gi, ii } }
function onDragEnd() { drag.value = null }
function moveTo(targetGi: number, targetIi: number | null) {
  const d = drag.value
  if (!d) return
  const item = groups.value[d.gi].items[d.ii]
  if (!item) return
  groups.value[d.gi].items.splice(d.ii, 1)
  const dest = groups.value[targetGi].items
  // 同群往後搬時，移除後索引會前移一格
  let idx = targetIi === null ? dest.length : targetIi
  if (d.gi === targetGi && d.ii < idx) idx -= 1
  dest.splice(idx, 0, item)
  drag.value = null
}

// ---- 群：上下移／新增／改名／刪空群 ----
function moveGroup(gi: number, dir: -1 | 1) {
  const j = gi + dir
  if (j < 0 || j >= groups.value.length) return
  const arr = groups.value
  ;[arr[gi], arr[j]] = [arr[j], arr[gi]]
}
function addGroup() {
  groups.value.push({ id: `g${Date.now()}`, label: '新群組', icon: '▸', to: '', items: [] })
}
function delGroup(gi: number) {
  if (groups.value[gi].items.length) { msg.value = '群組裡還有項目，先把項目拖到別群再刪'; return }
  groups.value.splice(gi, 1)
}

async function save() {
  saving.value = true
  msg.value = ''
  try {
    const payload: SavedGroup[] = groups.value.map((g) => ({
      id: g.id, label: g.label.trim() || '未命名', icon: g.icon, to: g.to || '',
      // 名稱有改（跟內建不同）就存 {to,label}；沒改就存純路由，讓程式端改名時能自動跟上
      items: g.items.map((i) => (i.label.trim() && i.label !== CAT[i.to]?.label
        ? { to: i.to, label: i.label.trim() } : i.to)),
    }))
    await apiFetch('/api/nav-layout', { method: 'PUT', body: { layout: payload } })
    msg.value = '已儲存——重新整理任一頁就會看到新順序（全站共用）'
  } catch (e: any) {
    msg.value = `儲存失敗：${e?.data?.detail || '未知錯誤'}`
  } finally {
    saving.value = false
  }
}
// 匯出／匯入（2026-09-20 使用者：221 跟公司機選單順序不同，「我要抓什麼回來才會同步」）。
// 選單順序存在各台自己的資料庫、不隨 patch 走；整庫備份雖然含這份設定，但為了搬選單
// 去覆蓋整個資料庫太超過，所以給一個只搬選單的檔。
function exportLayout() {
  const base = (useRuntimeConfig().public as any).apiBase || ''
  window.open(base + '/api/nav-layout/export', '_blank')
}
const importFile = ref<HTMLInputElement | null>(null)
async function onImportFile(ev: Event) {
  const f = (ev.target as HTMLInputElement).files?.[0]
  if (!f) return
  saving.value = true
  msg.value = ''
  try {
    const body = JSON.parse(await f.text())
    const r = await apiFetch<{ groups: number; items: number; note: string }>(
      '/api/nav-layout/import', { method: 'POST', body })
    await load()
    msg.value = `${r.note}——重新整理任一頁就會看到（全站共用）`
  } catch (e: any) {
    msg.value = `匯入失敗：${e?.data?.detail || e?.message || '檔案不是有效的選單設定'}`
  } finally {
    saving.value = false
    if (importFile.value) importFile.value.value = ''   // 同一個檔要能再選一次
  }
}

// ===== 新分類（2026-10-23）：套用前先備份目前版面（最近 5 版），可還原上一版 =====
type Tab = 'edit' | 'apply' | 'map'
const tab = ref<Tab>('edit')
interface Backup { at: string; by: string | null; reason: string | null; groups: number; is_default: boolean }
const backups = ref<Backup[]>([])
async function loadBackups() {
  try { backups.value = await apiFetch<Backup[]>('/api/nav-layout/backups') } catch (e: any) {
    msg.value = `備份清單讀不到：${e?.data?.detail || e?.message || '未知錯誤'}`
  }
}
onMounted(loadBackups)
async function applyNew() {
  if (!window.confirm('套用新分類？\n目前的選單版面會先備份（可按「還原上一版」取回），然後全站改用新的 9 群分類。')) return
  saving.value = true
  try {
    const r = await apiFetch<{ backed_up: boolean }>('/api/nav-layout/apply-default', { method: 'POST' })
    await load(); await loadBackups()
    msg.value = r.backed_up ? '已套用新分類（舊版面已備份）——重新整理任一頁就會看到' : '已套用新分類（原本就是內建預設）'
  } catch (e: any) {
    msg.value = `失敗：${e?.data?.detail || e?.message || '未知錯誤'}`
  } finally { saving.value = false }
}
async function restorePrev() {
  if (!backups.value.length) return
  const b = backups.value[0]
  if (!window.confirm(`還原到 ${b.at} 的版面（${b.is_default ? '內建預設' : `${b.groups} 群`}）？\n目前的版面也會先存一份。`)) return
  saving.value = true
  try {
    await apiFetch('/api/nav-layout/restore', { method: 'POST' })
    await load(); await loadBackups()
    msg.value = `已還原 ${b.at} 的版面——重新整理任一頁就會看到`
  } catch (e: any) {
    msg.value = `失敗：${e?.data?.detail || e?.message || '未知錯誤'}`
  } finally { saving.value = false }
}
const bkRows = computed(() => backups.value.map((b, i) => ({ ...b, no: i + 1, kind: b.is_default ? '內建預設' : `自訂 ${b.groups} 群` })))
const { sortKey: bKey, sortDir: bDir, toggle: bToggle, sorted: bSorted } = useSort(bkRows, 'no')

// ===== 新舊選單編號對照 =====
const mapRows = computed(() => {
  const oldN = oldNumbering()
  const newN = newNumbering()
  const curGroups = mergeNav(savedRaw.value)
  const curN: Record<string, string> = {}
  curGroups.forEach((g, gi) => g.items.forEach((it, ii) => { if (it.to) curN[it.to] = `${gi + 1}-${ii + 1}` }))
  if (savedRaw.value) savedRaw.value.forEach((g, gi) => { if (g.to && !curN[g.to]) curN[g.to] = String(gi + 1) })
  const groupOf: Record<string, string> = {}
  defaultGroups().forEach(g => g.items.forEach(it => { if (it.to) groupOf[it.to] = g.label }))
  const cat = navCatalog()
  return Object.keys(cat).map((to) => ({ label: cat[to].label, to, old_no: oldN[to] ?? '（新）', cur_no: curN[to] ?? '', new_no: newN[to] ?? '', new_group: groupOf[to] ?? '' }))
    .sort((a, b) => (a.new_no || '').localeCompare(b.new_no || '', 'zh-Hant', { numeric: true }))
    .map((r, i) => ({ ...r, no: i + 1, changed: r.old_no !== r.new_no ? '有變' : '' }))
})
const { sortKey: mKey, sortDir: mDir, toggle: mToggle, sorted: mSorted } = useSort(mapRows, 'no')
const changedCount = computed(() => mapRows.value.filter(r => r.changed).length)
async function exportMapping() {
  try {
    const blob = await apiFetch<Blob>('/api/nav-layout/mapping.xlsx', { method: 'POST', body: { rows: mapRows.value }, responseType: 'blob' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = `新舊選單編號對照_${new Date().toISOString().slice(0, 10)}.xlsx`
    a.click()
    setTimeout(() => URL.revokeObjectURL(a.href), 2000)
  } catch (e: any) {
    msg.value = `匯出失敗：${e?.data?.detail || e?.message || '未知錯誤'}`
  }
}

async function resetDefault() {
  saving.value = true
  msg.value = ''
  try {
    await apiFetch('/api/nav-layout', { method: 'PUT', body: { layout: null } })
    groups.value = fromDefault()
    msg.value = '已回復內建預設順序'
  } catch (e: any) {
    msg.value = `失敗：${e?.data?.detail || '未知錯誤'}`
  } finally {
    saving.value = false
  }
}
</script>

<template>
  <div class="ne">
    <div class="section-divider">選單編輯</div>
    <p class="lead">拖拉項目在群組之間搬；群組可上下移、改名、新增
      <InfoNote>選單順序存在<b>這一台自己的資料庫</b>，不隨程式更新（patch）走——所以兩台機器會各自不同。
        要同步就在排好的那台按「匯出設定」，到另一台按「匯入設定」。整庫備份本來就含這份設定，
        但為了搬選單去還原整個資料庫太超過，所以另給這個只搬選單的檔。<br><br>
        這是<b>全站共用一份順序</b>，你改了大家（含手機、其他人）看到的選單都會變。編號（2-1、3-7…）會依你排的順序自動重算。改完按「儲存」，重新整理就生效；不滿意按「回復預設」。</InfoNote>
    </p>

    <div class="tabs" role="tablist">
      <button class="tab" :class="{ active: tab === 'edit' }" @click="tab = 'edit'">編輯順序</button>
      <button class="tab" :class="{ active: tab === 'apply' }" @click="tab = 'apply'">新分類與備份</button>
      <button class="tab" :class="{ active: tab === 'map' }" @click="tab = 'map'">新舊編號對照（{{ changedCount }} 項有變）</button>
    </div>

    <div v-if="tab === 'apply'" class="panelx">
      <p class="lead">
        目前：<b>{{ savedRaw ? `自訂版面（${savedRaw.length} 群）` : '內建分類' }}</b>
        <InfoNote>新的 9 群分類（今日／查詢／系統與影響／機房與容量／納管與收集／盤點與合規／資料品質／報告／系統管理）是內建預設。
          存過自訂版面的機器照舊顯示自訂版面，不會被新版程式蓋掉；要換成新分類請按「套用新分類」。套用前會自動備份目前版面（留最近 5 版），
          不滿意按「還原上一版」。兩個按鈕都只有管理員能按，都會記進操作紀錄。</InfoNote>
      </p>
      <div class="bar">
        <button class="btn primary" :disabled="saving || !canEdit" @click="applyNew">套用新分類</button>
        <button class="btn" :disabled="saving || !canEdit || !backups.length" @click="restorePrev">還原上一版</button>
        <span v-if="!canEdit" class="muted">（只有管理員能按）</span>
        <span v-if="msg" class="msg">{{ msg }}</span>
      </div>
      <table class="tbl">
        <thead><tr>
          <SortTh k="no" :active="bKey" :dir="bDir" @sort="bToggle">項次</SortTh>
          <SortTh k="at" :active="bKey" :dir="bDir" @sort="bToggle">備份時間</SortTh>
          <SortTh k="by" :active="bKey" :dir="bDir" @sort="bToggle">操作人</SortTh>
          <SortTh k="kind" :active="bKey" :dir="bDir" @sort="bToggle">內容</SortTh>
          <SortTh k="reason" :active="bKey" :dir="bDir" @sort="bToggle">原因</SortTh>
        </tr></thead>
        <tbody>
          <tr v-for="b in bSorted" :key="b.at + b.no"><td>B{{ b.no }}</td><td>{{ b.at }}</td><td>{{ b.by || '—' }}</td><td>{{ b.kind }}</td><td>{{ b.reason || '—' }}</td></tr>
          <tr v-if="!bSorted.length"><td colspan="5" class="muted">還沒有備份</td></tr>
        </tbody>
      </table>
    </div>

    <div v-if="tab === 'map'" class="panelx">
      <div class="bar">
        <button class="btn" @click="exportMapping">匯出 xlsx</button>
        <span class="muted">舊編號＝重整前的內建選單；目前畫面＝這台現在顯示的（有自訂版面就是自訂的）；新編號＝新的 9 群分類。</span>
      </div>
      <table class="tbl">
        <thead><tr>
          <SortTh k="no" :active="mKey" :dir="mDir" @sort="mToggle">項次</SortTh>
          <SortTh k="label" :active="mKey" :dir="mDir" @sort="mToggle">功能</SortTh>
          <SortTh k="old_no" :active="mKey" :dir="mDir" @sort="mToggle">舊編號</SortTh>
          <SortTh k="cur_no" :active="mKey" :dir="mDir" @sort="mToggle">目前畫面</SortTh>
          <SortTh k="new_no" :active="mKey" :dir="mDir" @sort="mToggle">新編號</SortTh>
          <SortTh k="new_group" :active="mKey" :dir="mDir" @sort="mToggle">新群組</SortTh>
          <SortTh k="changed" :active="mKey" :dir="mDir" @sort="mToggle">變動</SortTh>
          <SortTh k="to" :active="mKey" :dir="mDir" @sort="mToggle">路徑</SortTh>
        </tr></thead>
        <tbody>
          <tr v-for="r in mSorted" :key="r.to"><td>M{{ r.no }}</td><td>{{ r.label }}</td><td class="mono">{{ r.old_no }}</td>
            <td class="mono">{{ r.cur_no }}</td><td class="mono"><b>{{ r.new_no }}</b></td><td>{{ r.new_group }}</td><td>{{ r.changed }}</td><td><code>{{ r.to }}</code></td></tr>
        </tbody>
      </table>
    </div>

    <template v-if="tab === 'edit'">
    <div v-if="loading" class="muted">載入中…</div>

    <div v-else-if="!canEdit" class="notadmin">
      只有管理員（<code>admin</code> 帳號）能編輯選單。你目前不是管理員，這頁是唯讀。
    </div>

    <template v-else>
      <div class="bar">
        <button class="btn primary" :disabled="saving" @click="save">儲存</button>
        <button class="btn" :disabled="saving" @click="resetDefault">回復預設</button>
        <button class="btn" :disabled="saving" @click="addGroup">＋ 新增群組</button>
        <span class="sep" />
        <button class="btn" :disabled="saving" title="把這台的選單設定存成一個檔，拿到另一台匯入"
                @click="exportLayout">匯出設定</button>
        <button class="btn" :disabled="saving" title="匯入另一台匯出的選單設定（會覆蓋這台目前的順序）"
                @click="importFile?.click()">匯入設定</button>
        <input ref="importFile" type="file" accept="application/json,.json" hidden @change="onImportFile" />
        <span v-if="msg" class="msg">{{ msg }}</span>
      </div>

      <div class="groups">
        <div v-for="(g, gi) in groups" :key="g.id" class="group">
          <div class="ghead">
            <span class="gno">{{ gi + 1 }}</span>
            <input v-model="g.label" class="gname" />
            <span class="spacer" />
            <button class="mini" title="上移" :disabled="gi === 0" @click="moveGroup(gi, -1)">↑</button>
            <button class="mini" title="下移" :disabled="gi === groups.length - 1" @click="moveGroup(gi, 1)">↓</button>
            <button class="mini danger" title="刪除（需先清空）" @click="delGroup(gi)">✕</button>
          </div>
          <ul class="items" @dragover.prevent @drop="moveTo(gi, null)">
            <li v-for="(it, ii) in g.items" :key="it.to" class="item"
                @dragover.prevent.stop @drop.stop="moveTo(gi, ii)">
              <span class="grip" draggable="true" title="拖我搬動"
                    @dragstart="onDragStart(gi, ii)" @dragend="onDragEnd">⋮⋮</span>
              <span class="ino">{{ gi + 1 }}-{{ ii + 1 }}</span>
              <span class="iic">{{ it.icon }}</span>
              <input v-model="it.label" class="ilabel" title="選單顯示的名稱（可改）" />
              <code class="ito">{{ it.to }}</code>
            </li>
            <li v-if="!g.items.length" class="empty">（把項目拖到這裡）</li>
          </ul>
        </div>
      </div>
    </template>
    </template>
  </div>
</template>

<style scoped>
.tabs { display: flex; gap: 4px; margin: 0 0 12px; border-bottom: 1px solid var(--border); flex-wrap: wrap; }
.tab { padding: 8px 16px; cursor: pointer; font-size: 14px; color: var(--muted); background: none; border: 0; border-bottom: 2px solid transparent; margin-bottom: -1px; font-family: inherit; }
.tab.active { color: var(--brand-dark); border-bottom-color: var(--brand); font-weight: 600; }
.panelx { background: var(--card); border: 1px solid var(--border); border-radius: var(--radius); padding: 14px 16px; }
.tbl { width: 100%; border-collapse: collapse; font-size: 12.5px; margin-top: 8px; }
.tbl th { text-align: left; font-size: 12px; color: var(--ink-aux); padding: 6px 8px; border-bottom: 1px solid var(--border); background: var(--sub); }
.tbl td { padding: 6px 8px; border-bottom: 1px solid var(--line); color: var(--ink-soft); }
.mono { font-family: var(--disp); }
.ne { max-width: 760px; }
.lead { font-size: 13px; color: var(--ink-soft); margin: 0 0 14px; }
.bar { display: flex; align-items: center; gap: 10px; margin-bottom: 14px; flex-wrap: wrap; }
.btn { font-family: inherit; font-size: 13px; padding: 7px 14px; cursor: pointer;
  border: 1px solid var(--border-strong); background: var(--card); color: var(--ink); border-radius: 6px; }
.btn.primary { background: var(--brand); color: #fff; border-color: var(--brand); }
.btn:disabled { opacity: .5; cursor: default; }
.msg { font-size: 12px; color: var(--brand-dark); }
.notadmin { padding: 16px; border: 1px solid var(--border); border-radius: 8px;
  background: var(--sub); color: var(--ink-soft); font-size: 13px; }
.groups { display: flex; flex-direction: column; gap: 12px; }
.group { border: 1px solid var(--border); border-radius: 8px; background: var(--card); overflow: hidden; }
.ghead { display: flex; align-items: center; gap: 8px; padding: 8px 10px; background: var(--sub);
  border-bottom: 1px solid var(--border); }
.gno { font-size: 12px; color: var(--ink-aux); min-width: 16px; }
.gname { font-family: inherit; font-size: 14px; font-weight: 600; padding: 4px 8px; flex: 0 1 auto;
  border: 1px solid var(--border-strong); border-radius: 6px; background: var(--card); color: var(--ink); }
.spacer { flex: 1; }
.mini { font-family: inherit; font-size: 12px; width: 26px; height: 26px; cursor: pointer;
  border: 1px solid var(--border-strong); background: var(--card); color: var(--ink); border-radius: 6px; }
.mini.danger { color: var(--bad); border-color: var(--bad); }
.mini:disabled { opacity: .4; cursor: default; }
.items { list-style: none; margin: 0; padding: 6px; min-height: 40px; }
.item { display: flex; align-items: center; gap: 8px; padding: 7px 8px; font-size: 13px;
  border: 1px solid var(--border); border-radius: 6px; margin-bottom: 6px; background: var(--card); }
.item:hover { border-color: var(--border-strong); }
.grip { color: var(--ink-aux); cursor: grab; user-select: none; padding: 0 2px; }
.ino { font-size: 11px; color: var(--ink-aux); min-width: 30px; }
.iic { width: 18px; text-align: center; }
.ilabel { font-family: inherit; font-size: 13px; padding: 4px 8px; flex: 1; min-width: 80px;
  border: 1px solid var(--border); border-radius: 6px; background: var(--card); color: var(--ink); }
.ilabel:focus { border-color: var(--brand); outline: none; }
.ito { font-size: 11px; color: var(--ink-aux); }
.empty { font-size: 12px; color: var(--ink-aux); padding: 10px; text-align: center; }
</style>
