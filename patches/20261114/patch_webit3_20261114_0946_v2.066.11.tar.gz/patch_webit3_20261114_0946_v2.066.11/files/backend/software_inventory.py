"""軟體盤點的寫入層：把 software_collector 收到的套件落進 host_package，並記錄異動。

跟 service_inventory 同一個模式（對已納管的機器逐台收、消失標 gone_at 不刪），
多一件事：**每一輪跟上一輪比，新裝／移除寫進 package_change**。

## 「裝過」只能從第一次盤點開始算（使用者 2026-09-11 拍板：從現在開始記錄）

一台主機**第一次**被收到時，它身上所有套件都是「本來就在」，不是「剛裝的」。
那一輪不寫任何異動——否則第一次盤點會噴出幾千筆假的「新增」，
真正的新裝被淹沒。第一次盤點以前發生過什麼，一律是「不知道」。

## 為什麼 key 含版本

同一個套件可以同時裝好幾個版本（kernel 就是：新舊核心並存，開機可選）。
key 用 (ip, 名稱, 架構, 版本)，升級就會記成「舊版移除＋新版新增」兩筆，
畫面上照名稱排在一起就看得出是升級。

## 收集失敗不能被當成「軟體被移除」

rpm 機器不可能零套件。收到 0 個、或輸出沒有 SRC= 行 → 當失敗，**不動這台的任何資料**。
不然 SSH 抖一下，隔天報表就會出現「這台 800 個套件全部被移除」。
這台的資料停在上一輪，畫面靠 last_seen 看得出來它舊了。
"""
from __future__ import annotations

from db import _now_local

UNSUPPORTED = "unsupported"


def _resolve_targets(conn, only_serial: str | None = None) -> list[dict]:
    """要收哪些主機：已納管（collect_ok=1）且有 IP 的資產。同服務盤點。"""
    import manage_state

    sql, params = manage_state.collect_targets_sql(
        conn, only_serial,
        "SELECT asset_serial, ip FROM hardware "
        "WHERE ip IS NOT NULL AND ip != '' AND collect_ok = 1")
    import machine_scope

    # 同一個 IP 只收一次（2026-10-16）：同一台有多筆登記時以前每筆各收一次，
    # 「收到 N 筆」變成 N×登記數，資料列的序號還會被最後一次改寫。見 machine_scope。
    rows, _vm = manage_state.drop_vmware_targets(conn, [dict(r) for r in conn.execute(sql, params).fetchall()])  # 天條
    return machine_scope.dedupe_targets(rows, only_serial)


def upsert_packages(conn, ip: str, asset_serial: str | None, packages: list[dict],
                    source: str, run_id: int | None = None, mark_gone: bool = True) -> dict:
    """寫入一台主機這一輪的套件，回傳 {added, removed, unchanged, baseline}。

    baseline=True 表示這台是第一次盤點：資料照寫，但不記異動（見檔頭）。
    """
    now = _now_local()
    baseline = conn.execute(
        "SELECT 1 FROM host_package WHERE ip = ? LIMIT 1", (ip,)).fetchone() is None

    existing = {
        (r["name"], r["arch"], r["version"]): r
        for r in conn.execute(
            "SELECT id, name, arch, version, gone_at FROM host_package WHERE ip = ?", (ip,))
    }
    seen: set[tuple] = set()
    added = unchanged = 0
    for p in packages:
        key = (p["name"], p["arch"], p["version"])
        seen.add(key)
        row = existing.get(key)
        if row is None:
            conn.execute(
                "INSERT INTO host_package (ip, asset_serial, name, version, arch, vendor, "
                "installed_at, source, first_seen, last_seen) VALUES (?,?,?,?,?,?,?,?,?,?)",
                (ip, asset_serial, p["name"], p["version"], p["arch"], p.get("vendor"),
                 p.get("installed_at"), source, now, now))
            is_new = True
        else:
            conn.execute(
                "UPDATE host_package SET asset_serial = ?, vendor = ?, installed_at = ?, "
                "source = ?, last_seen = ?, gone_at = NULL WHERE id = ?",
                (asset_serial, p.get("vendor"), p.get("installed_at"), source, now, row["id"]))
            # 之前標過消失、這次又出現＝重新裝回來，也是一筆新增
            is_new = row["gone_at"] is not None
        if is_new:
            added += 1
            if not baseline:
                _log_change(conn, ip, asset_serial, p, "added", now, run_id)
        else:
            unchanged += 1

    removed = 0
    for key, row in (existing.items() if mark_gone else ()):
        if key in seen or row["gone_at"] is not None:
            continue
        conn.execute("UPDATE host_package SET gone_at = ? WHERE id = ?", (now, row["id"]))
        removed += 1
        name, arch, version = key
        _log_change(conn, ip, asset_serial,
                    {"name": name, "arch": arch, "version": version}, "removed", now, run_id)

    conn.commit()
    return {"added": 0 if baseline else added, "removed": removed,
            "unchanged": unchanged, "baseline": baseline}


def _log_change(conn, ip, asset_serial, p, change, when, run_id) -> None:
    conn.execute(
        "INSERT INTO package_change (ip, asset_serial, name, arch, version, change, "
        "detected_at, run_id) VALUES (?,?,?,?,?,?,?,?)",
        (ip, asset_serial, p["name"], p.get("arch") or "", p.get("version") or "",
         change, when, run_id))


def _collect_windows(conn, ip: str, asset_serial: str | None, failed: list) -> dict | None:
    """Windows：WinRM 讀登錄檔。憑證從庫裡取、用完即丟、留稽核（同服務盤點）。未在真機驗證。"""
    import credential_store
    import software_collector
    import win_onboard
    import winrm_collector

    # Windows 勾選才收（2026-10-22）：沒納管的不登入（第二道；第一道是只挑 collect_ok=1）
    blocked = win_onboard.collect_block(conn, ip, asset_serial)
    if blocked:
        failed.append({"asset_serial": asset_serial, "ip": ip, "error": blocked})
        return None
    cred_name = credential_store.pick_for_host(conn, ip, kind="winrm")
    if not cred_name:
        failed.append({"asset_serial": asset_serial, "ip": ip,
                       "error": "沒有可用的收集憑證——請先在系統設定新增 WinRM 服務帳號"})
        return None
    got = credential_store.get_for_use(conn, cred_name)
    if got is None:
        failed.append({"asset_serial": asset_serial, "ip": ip,
                       "error": f"憑證「{cred_name}」解不開（加密金鑰可能已更換），請重新設定"})
        return None
    username, password = got
    try:
        raw = winrm_collector.collect_software(ip, username, password)
    except Exception as exc:  # noqa: BLE001
        msg = str(exc)[:200]
        if "actively refused" in msg or "timed out" in msg or "Max retries" in msg:
            msg = f"{msg}｜{winrm_collector.enable_hint()}"
        credential_store.audit_use(conn, cred_name, ip, False, msg)
        failed.append({"asset_serial": asset_serial, "ip": ip, "error": msg})
        return None
    credential_store.audit_use(conn, cred_name, ip, True, "軟體盤點成功")
    source, packages = software_collector.parse_packages(raw)
    notes = winrm_collector.explain_errors(winrm_collector.parse_errors(raw))
    if not packages and notes:
        # 讀不到登錄檔 ≠ 沒裝軟體：講權限，不要退成「沒有收到任何套件」
        failed.append({"asset_serial": asset_serial, "ip": ip, "error": "；".join(notes)[:400]})
        return None
    return {"source": source, "packages": packages, "notes": notes}




def _acct(conn, asset_serial, platform: str) -> str:
    """這一台的收集帳號。**每台一個答案**（`hardware.collect_account`，NULL 就走全域）。

    2026-09-24 收集帳號統一成 webit3sc 的遷移需要它：全域一次翻＝ 09-23 那個
    「好好的機器變成 0/9」的機隊放大版。驗過的那一台才寫新帳號，其餘不受影響。
    """
    import collect_account_migration as cam

    return cam.account_for_host(conn, asset_serial, platform)


def _save_trace(conn, run, serial: str, ip: str) -> None:
    """把這一跳的 SSH 事實落庫（離開碼／stderr／指令原文）。

    ⚠️ **失敗的時候也要寫**——那才是最需要看診斷的時候。
    2026-09-22 真機第一次驗證：AIX 四類全空，但我們證明不了是「SSH 沒連上」
    還是「連上了但指令跑不起來」，因為證據在 stderr 裡而它被丟掉了。

    注入 runner 的測試沒有 save()，所以先問過再叫。
    """
    if not hasattr(run, "save"):
        return
    try:
        run.save(conn, serial, ip)
    except Exception:  # noqa: BLE001 - 診斷寫不進去不可以反過來害收集失敗
        pass


@__import__("quiet_window").guarded("scan_post_software")
def collect_software(conn, key_path: str | None = None, runner=None,
                     only_serial: str | None = None, trigger: str = "manual") -> dict:
    """對已納管主機逐台收軟體清單，寫進 host_package，並留一筆執行紀錄。"""
    import manage_state
    import service_inventory
    import software_collector

    cur = conn.execute(
        "INSERT INTO software_collect_runs (trigger, status, started_at) "
        "VALUES (?, 'running', ?)", (trigger, _now_local()))
    conn.commit()
    run_id = cur.lastrowid

    # ⚠️ 2026-09-23：收集帳號**要按平台決定，而且要在迴圈裡決定**。
    # AIX 的收集帳號是 8 字元的 webit3sc（max_logname 限制），不是 webit3scan。
    # 原本這裡在迴圈外呼叫 get_collect_account(conn)（沒帶平台），於是：
    #   · 一律用 webit3scan -> 那個帳號在 AIX 上不存在 -> SSH 認證失敗
    #   · 每一條指令都回空字串 -> 畫面顯示「收不到」，看起來像指令有問題
    # 真機實測（test1T，公司機）四樣全空就是這個原因。
    # 放在迴圈外還有第二個問題：一批機器混著 Linux 與 AIX 時只會有一個答案。
    targets = _resolve_targets(conn, only_serial)
    failed: list[dict] = []
    unsupported: list[dict] = []
    skipped: list[dict] = []
    # 指定單台卻一台都沒進迴圈 -> 講得出為什麼（2026-09-23）。
    # 不講的話前端只能填「可能不在可收集清單、或被排除」，那句話等於沒講。
    if only_serial and not targets:
        import manage_state as _ms
        _why = _ms.why_not_collectable(conn, only_serial)
        if _why:
            skipped.append({"asset_serial": only_serial, "reason": _why})

    per_host: list[dict] = []
    total = 0

    for t in targets:
        if not __import__("quiet_window").checkpoint(conn, "scan_post_software"):
            break      # AUD-02：進窗後不再對下一台連線
        ip, serial = t["ip"], t["asset_serial"]
        # 平台判定跟服務盤點共用同一支，兩邊不會一台判成 Windows、一台判成 Linux
        platform = service_inventory._platform_for(conn, ip, serial)
        if platform == "windows" and runner is None:
            result = _collect_windows(conn, ip, serial, failed)
            if result is None:
                continue
            source = "winrm_registry"
        else:
            run = runner or manage_state._runner_for(
                ip, key_path or manage_state.COLLECTOR_KEY_DEFAULT,
                account=_acct(conn, serial, platform))
            try:
                result = software_collector.collect(run, ip, platform)
            except Exception as exc:  # noqa: BLE001 - 單台失敗不中斷整批
                failed.append({"asset_serial": serial, "ip": ip, "error": str(exc)[:200]})
                _save_trace(conn, run, serial, ip)
                continue
            _save_trace(conn, run, serial, ip)
            if result.get("error"):
                unsupported.append({"asset_serial": serial, "ip": ip,
                                    "reason": result["error"]})
                continue
            # 來源要標對：AIX 收的是 fileset（lslpp），不是 rpm。
            # 兩者的涵蓋範圍不同，混成同一個字串會讓人以為 AIX 也查過 rpm。
            source = "ssh_lslpp" if platform == "aix" else "ssh_rpm"

        if result["source"] == "none":
            # 沒有 rpm（Debian/Ubuntu）：不支援，不是「沒裝軟體」
            unsupported.append({"asset_serial": serial, "ip": ip,
                                "reason": "這台沒有 rpm（Debian／Ubuntu 類），目前不支援"})
            continue
        if result["source"] is None or not result["packages"]:
            # 見檔頭：收到 0 個一律當失敗，不能讓這台的資料被標成全部移除
            why = ("AIX：`lslpp -Lc` 沒有回任何 fileset。AIX 不可能零 fileset，"
                   "所以這是收集失敗（指令沒跑起來或被擋），不是這台沒裝軟體。"
                   if platform == "aix"
                   else "沒有收到任何套件（指令沒跑起來或輸出為空），這台資料維持上一輪")
            failed.append({"asset_serial": serial, "ip": ip, "error": why})
            continue

        # Windows 某個機碼讀不到（notes 有東西）：那一側的舊套件不標移除——讀不到不等於被移除
        stat = upsert_packages(conn, ip, serial, result["packages"], source, run_id,
                               mark_gone=not result.get("notes"))
        total += len(result["packages"])
        per_host.append({"asset_serial": serial, "ip": ip,
                         "found": len(result["packages"]), "notes": result.get("notes") or [],
                         **stat})

    status = "failed" if failed and not per_host else "ok"
    conn.execute(
        "UPDATE software_collect_runs SET status = ?, host_count = ?, ok_count = ?, "
        "package_count = ?, failed_count = ?, unsupported_count = ?, error = ?, "
        "finished_at = ? WHERE id = ?",
        (status, len(targets), len(per_host), total, len(failed), len(unsupported),
         "; ".join(f["error"] for f in failed)[:500] or None, _now_local(), run_id))
    conn.commit()
    return {"run_id": run_id, "status": status, "candidates": len(targets),
            "packages": total, "hosts": per_host, "failed": failed,
            "unsupported": unsupported, "skipped": skipped}


# ===== 查詢 =====

def software_summary(conn, live: list[dict] | None = None) -> dict:
    """頁首數字：全是「這份資料有多真」的線索。"""
    import service_inventory as _si

    days = _si.stale_days(conn)
    st = _si.stale_cond(days, "hp.")
    row = conn.execute(
        "SELECT COUNT(DISTINCT ip) AS hosts, COUNT(*) AS live, COUNT(DISTINCT name) AS names, "
        f"SUM(CASE WHEN {st} THEN 0 ELSE 1 END) AS current, "
        f"SUM(CASE WHEN {st} THEN 1 ELSE 0 END) AS stale, "
        f"COUNT(DISTINCT CASE WHEN {st} THEN NULL ELSE ip END) AS hosts_current, "
        f"COUNT(DISTINCT CASE WHEN {st} THEN ip END) AS hosts_stale "
        "FROM host_package hp WHERE gone_at IS NULL").fetchone()
    changes = conn.execute(
        "SELECT COUNT(*) FROM package_change "
        "WHERE detected_at >= datetime('now','localtime','-30 days')").fetchone()[0]
    last = conn.execute(
        "SELECT * FROM software_collect_runs ORDER BY id DESC LIMIT 1").fetchone()
    # 2.043.8（D3，CLAUDE.md 天條「同一台只有 machine_key 一把尺」）：台數一律跟 V2「依主機」同一份計算
    # （_current_by_machine：machine_key 分組、排除退役）。hosts_ip＝舊算法（不重複 IP），只給舊版 /software 頁
    # 的「依主機」卡片用（那頁的依主機分頁還是一個 IP 一列；舊網址已一律轉 V2，只有 ?legacy=1 進得去）。
    live = live if live is not None else _live_rows(conn)
    groups = _current_by_machine(conn, live)
    return {
        "hosts": len(groups), "hosts_ip": row["hosts"] or 0, "live": row["live"] or 0,
        # 2.043.9：軟體種數＝軟體清單列數（同樣排除退役）；names_all＝舊算法（含退役）
        "names": len({r["name"] for r in live}), "names_all": row["names"] or 0,
        # W221-012：live ＝ current ＋ stale（過期＝last_seen 超過 stale_days 天，或該主機最近一次收集失敗）
        # live／current／stale 是套件「筆數」（不是台數），照舊算 host_package 現行列
        "current": row["current"] or 0, "stale": row["stale"] or 0,
        "hosts_current": sum(1 for g in groups.values() if g["has_current"]),
        "hosts_stale": sum(1 for g in groups.values() if g["has_stale"]),
        "stale_days": days,
        "changes_30d": changes or 0,
        "last_run": dict(last) if last else None,
    }


def _live_rows(conn, name: str | None = None, like: str | None = None, rows: list[dict] | None = None) -> list[dict]:
    """現行套件列（gone_at IS NULL），排除退役（lifecycle.RETIRED_STATUS，正典），每列帶 mkey＝system_stats.machine_key
    （全站「同一台」唯一一把尺，不自寫去重）與 is_stale。2.043.9（D3）：軟體清單、各版本、搜尋下鑽、依主機、頁首台數都從這份算。
    效能（GPT 審查 6）：rows＝同一個 request 已經讀好的全部列（只在 Python 篩 name／like，不再讀一次表）；
    machine_key 依 (主機名, IP, 序號) 記住結果——同一台幾百個套件只呼叫一次（呼叫的仍是 machine_key 本身）。"""
    if rows is not None:
        lk = (like or "").lower()
        return [r for r in rows if (name is None or r["name"] == name) and (not lk or lk in (r["name"] or "").lower())]
    import service_inventory as _si
    import system_stats
    from lifecycle import RETIRED_STATUS

    st = _si.stale_cond(_si.stale_days(conn), "hp.")
    sql = ("SELECT hp.id, hp.ip, hp.asset_serial, h.hostname, h.asset_status, hp.name, hp.version, hp.arch, hp.vendor, "
           "hp.installed_at, hp.first_seen, hp.last_seen, hp.source, "
           f"CASE WHEN {st} THEN 1 ELSE 0 END AS is_stale "
           "FROM host_package hp LEFT JOIN hardware h ON h.asset_serial = hp.asset_serial WHERE hp.gone_at IS NULL")
    params: list = []
    if name is not None:
        sql += " AND hp.name = ?"
        params.append(name)
    if like:
        sql += " AND LOWER(hp.name) LIKE ?"
        params.append(f"%{like.lower()}%")
    out = []
    keys: dict[tuple, str] = {}
    for r in conn.execute(sql, params):
        if (r["asset_status"] or "").strip() in RETIRED_STATUS:
            continue
        d = dict(r)
        t = (r["hostname"], r["ip"], r["asset_serial"])
        if t not in keys:
            keys[t] = system_stats.machine_key(*t)
        d["mkey"] = keys[t]
        out.append(d)
    return out


def list_software(conn, q: str | None = None, live: list[dict] | None = None) -> list[dict]:
    """依軟體名稱彙總：幾個版本、幾台。版本字串一併帶回，畫面直接列出來。
    2.043.9（D3）：台數＝不同 machine_key 的台數（排除退役），不是不重複 IP；
    current_host_count＝這個軟體有現行（未過期）列的台、stale_host_count＝有過期列的台（同一台兩邊都有時兩邊都算）。"""
    agg: dict[str, dict] = {}
    for r in _live_rows(conn, like=q, rows=live):
        a = agg.setdefault(r["name"], {"name": r["name"], "versions": set(), "sources": set(), "last_seen": None,
                                       "m": set(), "cur": set(), "stl": set()})
        a["versions"].add(r["version"] or "")
        if r["source"]:
            a["sources"].add(r["source"])
        if r["last_seen"] and (a["last_seen"] is None or r["last_seen"] > a["last_seen"]):
            a["last_seen"] = r["last_seen"]
        a["m"].add(r["mkey"])
        (a["stl"] if r["is_stale"] else a["cur"]).add(r["mkey"])
    out = []
    for a in agg.values():
        out.append({"name": a["name"], "version_count": len(a["versions"]), "host_count": len(a["m"]),
                    "versions": sorted(a["versions"]), "sources": sorted(a["sources"]), "last_seen": a["last_seen"],
                    "current_host_count": len(a["cur"]), "stale_host_count": len(a["stl"])})
    out.sort(key=lambda x: x["name"])          # 跟舊 SQL GROUP BY name 一樣依名稱排（項次固定）
    return out


def software_versions(conn, name: str) -> list[dict]:
    """某個軟體的各版本各幾台（下鑽第一層）。2.043.9：台＝machine_key、排除退役；同一台裝兩個版本時兩個版本各算一台。"""
    agg: dict[str, dict] = {}
    for r in _live_rows(conn, name=name):
        a = agg.setdefault(r["version"] or "", {"version": r["version"] or "", "m": set(), "archs": set()})
        a["m"].add(r["mkey"])
        if r["arch"]:
            a["archs"].add(r["arch"])
    return [{"version": a["version"], "host_count": len(a["m"]), "archs": ",".join(sorted(a["archs"])) or None}
            for a in sorted(agg.values(), key=lambda x: x["version"])]


def software_hosts(conn, name: str, version: str | None = None) -> list[dict]:
    """裝了某軟體（某版本）的主機（下鑽第二層）。2.043.9（D3）：一台一列（machine_key、排除退役）——列數＝清單上的台數。
    同一台多個 IP／多個版本合在一列：ip＝最近一次收到的那個 IP、ips 全列；version／arch／source 合併；
    is_stale＝這一台的這個軟體沒有任何現行列（全部過期）才算過期。"""
    groups: dict[str, dict] = {}
    for r in _live_rows(conn, name=name):
        if version is not None and (r["version"] or "") != version:
            continue
        g = groups.setdefault(r["mkey"], {"key": r["mkey"], "rows": []})
        g["rows"].append(r)
    out = []
    for k, g in groups.items():
        rs = sorted(g["rows"], key=lambda x: x["last_seen"] or "", reverse=True)
        top = rs[0]
        vers = sorted({x["version"] or "" for x in rs})
        out.append({"key": k, "ip": top["ip"], "ips": sorted({x["ip"] for x in rs}),
                    "asset_serial": next((x["asset_serial"] for x in rs if x["asset_serial"]), None),
                    "hostname": next((x["hostname"] for x in rs if x["hostname"]), None),
                    "version": "、".join(vers), "versions": vers,
                    "arch": "、".join(sorted({x["arch"] for x in rs if x["arch"]})) or None,
                    "installed_at": min((x["installed_at"] for x in rs if x["installed_at"]), default=None),
                    "first_seen": min((x["first_seen"] for x in rs if x["first_seen"]), default=None),
                    "last_seen": top["last_seen"],
                    "source": ",".join(sorted({x["source"] for x in rs if x["source"]})),
                    "is_stale": 0 if any(not x["is_stale"] for x in rs) else 1})
    out.sort(key=lambda x: ((x["hostname"] or x["ip"] or "").lower()))
    return out


def hosts_overview(conn) -> list[dict]:
    """依主機：每台幾個套件、最後一次收到是什麼時候（看得出哪台資料舊了）。"""
    return [dict(r) for r in conn.execute(
        "SELECT hp.ip, hp.asset_serial, h.hostname, "
        "SUM(CASE WHEN hp.gone_at IS NULL THEN 1 ELSE 0 END) AS package_count, "
        "MAX(hp.last_seen) AS last_seen, MIN(hp.first_seen) AS first_seen, "
        "GROUP_CONCAT(DISTINCT hp.source) AS sources "
        "FROM host_package hp LEFT JOIN hardware h ON h.asset_serial = hp.asset_serial "
        "GROUP BY hp.ip")]


def _current_by_machine(conn, live: list[dict] | None = None) -> dict[str, dict]:
    """現行套件依「同一台」分組：同一台＝system_stats.machine_key（全站唯一一把尺，CLAUDE.md 天條；不自寫 IP 去重）。
    一台換過 IP、或同一 IP 先後給不同資產，都照 machine_key 算。退役（RETIRED_STATUS）不列、沒登記的 IP 照列（見 _live_rows）。
    回 {machine_key: {"ips": {ip: 最後收到}, "serials", "hostnames", "sources", "pkgs": {(name, version, arch): row},
    "first_seen", "last_seen", "has_current", "has_stale"}}。live＝同一個 request 已讀好的 _live_rows（不再讀一次表）。"""
    out: dict[str, dict] = {}
    for r in (live if live is not None else _live_rows(conn)):
        k = r["mkey"]
        g = out.setdefault(k, {"ips": {}, "serials": set(), "hostnames": set(), "sources": set(), "pkgs": {},
                               "first_seen": None, "last_seen": None, "has_current": False, "has_stale": False})
        g["has_stale" if r["is_stale"] else "has_current"] = True
        g["ips"][r["ip"]] = max(g["ips"].get(r["ip"]) or "", r["last_seen"] or "")
        if r["asset_serial"]:
            g["serials"].add(r["asset_serial"])
        if r["hostname"]:
            g["hostnames"].add(r["hostname"])
        g["sources"].add(r["source"])
        g["pkgs"].setdefault((r["name"], r["version"], r["arch"]), r)
        if r["last_seen"] and (g["last_seen"] is None or r["last_seen"] > g["last_seen"]):
            g["last_seen"] = r["last_seen"]
        if r["first_seen"] and (g["first_seen"] is None or r["first_seen"] < g["first_seen"]):
            g["first_seen"] = r["first_seen"]
    return out


def machines_overview(conn) -> list[dict]:
    """V2 7.3「依主機」（2.043.7）：一台一列（machine_key），只列還有現行套件的機器——標題台數＝列數。
    同一台多個 IP 的套件合在一起、同名同版同架構只算一次；代表 IP＝最近一次收到的那個。"""
    rows = []
    for k, g in _current_by_machine(conn).items():
        ips = sorted(g["ips"], key=lambda ip: g["ips"][ip], reverse=True)
        rows.append({"key": k, "ip": ips[0] if ips else None, "ips": ips,
                     "asset_serial": sorted(g["serials"])[0] if g["serials"] else None,
                     "hostname": sorted(g["hostnames"])[0] if g["hostnames"] else None,
                     "package_count": len(g["pkgs"]), "last_seen": g["last_seen"], "first_seen": g["first_seen"],
                     "sources": ",".join(sorted(s for s in g["sources"] if s))})
    rows.sort(key=lambda r: (r["hostname"] or r["ip"] or "").lower())
    return rows


def machine_packages(conn, key: str) -> list[dict]:
    """V2「依主機」點套件數：這一台（machine_key）目前的套件，跟 machines_overview 的 package_count 同一份。"""
    g = _current_by_machine(conn).get(key)
    return sorted(g["pkgs"].values(), key=lambda p: (p["name"].lower(), p["version"])) if g else []


def host_packages(conn, ip: str, include_gone: bool = False) -> list[dict]:
    sql = "SELECT * FROM host_package WHERE ip = ?"
    if not include_gone:
        sql += " AND gone_at IS NULL"
    return [dict(r) for r in conn.execute(sql, (ip,))]


def list_changes(conn, days: int = 30, ip: str | None = None) -> list[dict]:
    """異動紀錄（新裝／移除）。第一次盤點不記，所以這裡只會有真的異動。"""
    days = max(1, min(int(days), 3650))
    sql = ("SELECT pc.*, h.hostname FROM package_change pc "
           "LEFT JOIN hardware h ON h.asset_serial = pc.asset_serial "
           "WHERE pc.detected_at >= datetime('now','localtime', ?)")
    params: list = [f"-{days} days"]
    if ip:
        sql += " AND pc.ip = ?"
        params.append(ip)
    return [dict(r) for r in conn.execute(sql + " ORDER BY pc.detected_at DESC, pc.id DESC",
                                          params)]


# ---- 診斷外掛（跟其他模組同一套）----
try:
    import diagnostics

    @diagnostics.register("software")
    def _diag(conn) -> dict:
        try:
            return software_summary(conn)
        except Exception as exc:  # noqa: BLE001
            return {"error": str(exc)[:200]}
except ImportError:
    pass


def coverage(conn) -> dict:
    """7.3 收集涵蓋（2.007.13，使用者：「我納管有 200 多台，這裡才 1xx 台」「怎麼沒有 AIX」）：
    已納管的主機（2.1「已納管」同一份 v2_hosts.machines）依作業系統大類，各有幾台收到軟體清單、幾台沒有。
    「有」＝這台的 IP 或資產編號在 host_package 有現役套件。數字＝清單長度（加總＝下鑽）。"""
    import v2_hosts

    pk: dict[str, str] = {}
    for r in conn.execute("SELECT ip, asset_serial, MAX(last_seen) t FROM host_package WHERE gone_at IS NULL GROUP BY ip, asset_serial"):
        for k in (r["ip"], r["asset_serial"]):
            if k and (k not in pk or (r["t"] or "") > pk[k]):
                pk[k] = r["t"] or ""      # 有現役套件但沒記時間：照樣算「有」（時間顯示空白）
    fam: dict[str, dict] = {}
    for m in v2_hosts.machines(conn):
        if not m["onboarded"]:
            continue
        f = (m["badge"] or {}).get("os_class") or "未知"
        b = fam.setdefault(f, {"family": f, "with": [], "without": []})
        keys = [k for k in (m["ip"], m["serial"]) if k and k in pk]
        t = max((pk[k] for k in keys), default="")
        row = {"key": m["key"], "name": m["name"], "ip": m["ip"], "serial": m["serial"], "collected_at": t or None}
        b["with" if keys else "without"].append(row)
    rows = sorted(fam.values(), key=lambda b: (-len(b["with"]) - len(b["without"]), b["family"]))
    times = [x["collected_at"] for b in rows for x in b["with"] if x["collected_at"]]     # 時間未知的主機仍算「有清單」，只是不參與最早／最晚（Codex 343：混 None 會 500）
    last = conn.execute("SELECT * FROM software_collect_runs ORDER BY id DESC LIMIT 1").fetchone()
    return {"rows": [{**b, "n_onboarded": len(b["with"]) + len(b["without"]), "n_with": len(b["with"]), "n_without": len(b["without"])} for b in rows],
            "oldest": min(times) if times else None, "newest": max(times) if times else None,
            "last_run": dict(last) if last else None}
