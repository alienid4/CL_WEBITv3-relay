<script setup lang="ts">
const { isViewer } = useAuth()     // Q91：只能看的帳號不顯示寫入按鈕（後端另外擋）
// 資料品質量測：盤點清單到底準不準，用查得到來源的數字講。
//
// 這頁的設計立場（跟一般「品質分數儀表板」不一樣的地方）：
// 只有拿得出機器證據的維度才給正確率並計入總分；保管者/用途/CIA 這種純人為判斷的欄位，
// 機器永遠驗不了，硬給正確率是在編數字——那些改列填寫率，並在畫面上講明白它衡量的
// 不是對錯，是「有沒有人在維護」。
interface Dim {
  key: string
  label: string
  kind: 'verifiable' | 'filled' | 'freshness' | 'coverage'
  checked: number
  ok: number
  bad: number
  rate: number | null
  note: string
}
interface Summary {
  asset_total: number
  score: number | null
  score_sample: number
  score_basis: string
  coverage_rate: number | null
  fresh_days: number
  stale_days: number
  dimensions: Dim[]
}
interface Offender {
  asset_serial: string
  hostname: string | null
  ip: string | null
  asset_status: string | null
  os: string | null
  inventory_department: string | null
  custodian: string | null
  updated_at: string | null
  reason: string
}

const { apiFetch } = useApi()
const summary = ref<Summary | null>(null)
const loading = ref(true)

const openKey = ref('')
const offenders = ref<Offender[]>([])
const offLoading = ref(false)

const dims = computed(() => summary.value?.dimensions ?? [])
const { sortKey, sortDir, toggle, sorted } = useSort(dims, '')
const { sortKey: oKey, sortDir: oDir, toggle: oToggle, sorted: oSorted } = useSort(offenders, '')

onMounted(async () => {
  try {
    summary.value = await apiFetch<Summary>('/api/data-quality')
  } finally {
    loading.value = false
  }
})

// 系統校正（v1.473.0）：實測／RVTools 跟 CIA 不符的筆數，點進去是 /corrections 同一份清單
const mm = ref<{ corrected: any[]; suspect: any[]; hosts: number } | null>(null)
const mmErr = ref('')
onMounted(async () => {
  try { mm.value = await apiFetch('/api/measured-mismatch') } catch (e: any) {
    mmErr.value = `系統校正清單載入失敗：${e?.data?.detail ?? e?.message ?? e}`
  }
})

// 只出現一次的人名＝打錯字高風險候選（人名改可搜尋新增後要能定期檢查，2026-09-17）
const singleNames = ref<string[]>([])
const singleOpen = ref(false)
onMounted(async () => {
  try { singleNames.value = (await apiFetch<{ names: string[] }>('/api/data-quality/single-person-names')).names } catch { /* 不擋整頁 */ }
})

// 人名合併（預覽版，2026-09-19）：把打錯的名字併到正確名字。先預覽會改幾筆，確認才寫。
const { showToast } = useToast()
interface MergePreview {
  from_name: string; to_name: string; total: number; preview_token?: string
  fields: { label: string; count: number }[]
  sample: { asset_serial: string; hostname: string | null; field: string }[]
}
const mergeFrom = ref('')
const mergeTo = ref('')
const mergePreview = ref<MergePreview | null>(null)
const mergeBusy = ref(false)
function pickMergeFrom(n: string) { mergeFrom.value = n; mergePreview.value = null }
async function doMergePreview() {
  if (!mergeFrom.value.trim() || !mergeTo.value.trim()) { showToast('原名與正確名都要填', 'warn'); return }
  mergeBusy.value = true
  try {
    mergePreview.value = await apiFetch<MergePreview>('/api/data-quality/person-merge/preview',
      { method: 'POST', body: { from_name: mergeFrom.value, to_name: mergeTo.value } })
    if (mergePreview.value.total === 0) showToast('這個原名在資料裡找不到（要完全一致）', 'warn')
  } catch (e: any) {
    showToast(e?.data?.detail ?? '預覽失敗，請稍後再試', 'error')
  } finally {
    mergeBusy.value = false
  }
}
async function doMergeApply() {
  if (!mergePreview.value || !mergePreview.value.total) return
  if (!confirm(`確定把「${mergePreview.value.from_name}」全部改成「${mergePreview.value.to_name}」？共 ${mergePreview.value.total} 筆，這個動作會直接改資料。`)) return
  mergeBusy.value = true
  try {
    const r = await apiFetch<{ total: number }>('/api/data-quality/person-merge',
      { method: 'POST', body: { from_name: mergePreview.value.from_name, to_name: mergePreview.value.to_name, preview_token: mergePreview.value.preview_token } })
    showToast(`已合併 ${r.total} 筆`, 'success')
    mergePreview.value = null; mergeFrom.value = ''; mergeTo.value = ''
    // 重載「只出現一次人名」——併完錯名應該消失
    try { singleNames.value = (await apiFetch<{ names: string[] }>('/api/data-quality/single-person-names')).names } catch { /* 不擋 */ }
  } catch (e: any) {
    showToast(e?.data?.detail ?? '合併失敗，請稍後再試', 'error')
  } finally {
    mergeBusy.value = false
  }
}

// 填充率最低的欄位＝「待補資料」清單（欄位先立、機器後補；機房搬遷的北極星，2026-09-19）
interface FieldFill { column: string; meaning: string; filled: number; fill_rate: number | null }
const fieldFill = ref<FieldFill[]>([])
const fillTotal = ref(0)
onMounted(async () => {
  try {
    const r = await apiFetch<{ fields: FieldFill[]; total_rows: number }>('/api/data-quality/field-fill')
    fieldFill.value = r.fields
    fillTotal.value = r.total_rows
  } catch { /* 輔助看板，載不到不擋整頁 */ }
})
const lowestFill = computed(() => fieldFill.value.slice(0, 12))

// 下鑽清單可匯出（2026-09-18 十項盤點第 8 條）：像「主機名與 IP 都有」這種要交給 CIA 清冊
// 維護單位回頭補的清單，只能在畫面上看等於沒用。BOM 讓 Excel 開中文不亂碼。
function exportOffenders(d: Dim) {
  const cols: [keyof Offender, string][] = [
    ['asset_serial', '資產序號'], ['hostname', '主機名稱'], ['ip', 'IP'], ['asset_status', '資產狀態'],
    ['os', 'OS'], ['inventory_department', '盤點部門'], ['custodian', '保管者'], ['updated_at', '最後更新'],
    ['reason', '原因'],
  ]
  const esc = (v: unknown) => { const s = String(v ?? ''); return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s }
  const lines = [cols.map((c) => c[1]).join(',')]
  for (const r of oSorted.value) lines.push(cols.map(([k]) => esc((r as any)[k])).join(','))
  const blob = new Blob(['\uFEFF' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' })
  const a = document.createElement('a')
  a.href = URL.createObjectURL(blob)
  a.download = `資料品質_${d.label}_${new Date().toISOString().slice(0, 10)}.csv`
  a.click()
  URL.revokeObjectURL(a.href)
}

// 天條：數字要能下鑽。點一列就展開「是哪幾台」，不用另開頁面
async function drill(d: Dim) {
  if (openKey.value === d.key) { openKey.value = ''; return }
  openKey.value = d.key
  offLoading.value = true
  offenders.value = []
  try {
    const r = await apiFetch<{ items: Offender[] }>(`/api/data-quality/${d.key}`)
    offenders.value = r.items
  } finally {
    offLoading.value = false
  }
}

const KIND_TEXT: Record<string, string> = {
  verifiable: '機器可驗',
  filled: '填寫率',
  freshness: '新鮮度',
  coverage: '涵蓋率',
}

// ===== 資料可信度分布（2026-09-11）=====
// 每台一個分數：幾個來源互相印證（dynassets／RVTools／CIA）＋有沒有機器證據（網路通／已納管）。
// 使用者：「知道 100 分的有幾個、90 分的有幾個…那 100 分的我可以點進去看，50 分的我也可以點進去看」。
interface TrustDist {
  total: number; machines?: number; rule: string
  by_score: { score: number; count: number; reasons: { text: string; count: number }[] }[]
  by_combo: { combo: string; count: number }[]
}
interface TrustHost {
  asset_serial: string; hostname: string | null; ip: string | null; score: number
  kind: string; evidence: string | null; sources: Record<string, boolean | null>
  alive_basis?: string | null; dynassets_imported_at?: string | null
  src_dyn?: string; src_rv?: string; src_cia?: string; evid_text?: string
}
const trust = ref<TrustDist | null>(null)
// reason_text：把「怎麼來的」攤平成字串，這一欄才排得了序（鐵規則：每欄可排）
const scoreRows = computed(() => (trust.value?.by_score ?? []).map((b) => ({
  ...b, reason_text: b.reasons.map((x) => x.text).join('／'),
})))
const comboRows = computed(() => (trust.value?.by_combo ?? []).map((c) => ({ ...c, label: comboLabel(c.combo) })))
const { sortKey: sKey, sortDir: sDir, toggle: sToggle, sorted: sSorted } = useSort(scoreRows, '')
const { sortKey: cbKey, sortDir: cbDir, toggle: cbToggle, sorted: cbSorted } = useSort(comboRows, '')
const trustOpen = ref('')
const trustTitle = ref('')
const trustHosts = ref<TrustHost[]>([])
const trustLoading = ref(false)
const { sortKey: thKey, sortDir: thDir, toggle: thToggle, sorted: thSorted } = useSort(trustHosts, 'hostname')

const SRC_NAME: Record<string, string> = { dynassets: 'dynassets', rvtools: 'RVTools', cia: 'CIA' }
function comboLabel(c: string) {
  return c.startsWith('（') ? c : c.split('+').map((s) => SRC_NAME[s] ?? s).join('＋')
}
function srcText(v: boolean | null | undefined) { return v === null ? '不適用' : v ? '有' : '沒有' }
const KIND_NAME: Record<string, string> = { vm: 'VM', physical: '實體機', esxi: 'ESXi 主機', unknown: '不明（照 VM 算）' }
const EVID_NAME: Record<string, string> = { managed: '已納管 +30', collected: '已收集（設備）+30', alive: '網路通 +20' }

onMounted(async () => {
  // 可信度分佈是這頁的輔助小圖，載不到就不顯示那一塊、不擋主資料（trust.value=null → v-if 收起）
  try { trust.value = await apiFetch<TrustDist>('/api/trust/distribution') } catch { trust.value = null }
})

async function openTrust(kind: 's' | 'c', value: number | string, title: string) {
  const key = `${kind}:${value}`
  if (trustOpen.value === key) { trustOpen.value = ''; return }
  trustOpen.value = key
  trustTitle.value = title
  trustLoading.value = true
  trustHosts.value = []
  try {
    const r = await apiFetch<{ items: TrustHost[] }>('/api/trust/hosts', {
      query: kind === 's' ? { score: value } : { combo: value },
    })
    // 攤平成字串欄位，每一欄才排得了序（鐵規則：表格每欄都能排）
    trustHosts.value = r.items.map((h) => ({
      ...h, src_dyn: srcText(h.sources.dynassets), src_rv: srcText(h.sources.rvtools), src_cia: srcText(h.sources.cia),
      // 網路通要講依據：我們自己掃到的，還是 dynassets 存活清單說的（哪一天的清單）
      evid_text: h.evidence === 'managed' ? '已納管 +30'
        : h.evidence === 'collected' ? '已收集（設備）+30'
        : h.evidence === 'alive'
          ? (h.alive_basis === 'dynassets'
            ? `網路通 +20（dynassets ${(h.dynassets_imported_at || '').slice(0, 10)}）`
            : '網路通 +20（掃描）')
          : '—',
    }))
  } finally {
    trustLoading.value = false
  }
}

function rateClass(d: Dim) {
  if (d.rate === null) return ''
  if (d.kind !== 'verifiable') return d.rate >= 80 ? 'good' : 'warn'
  return d.rate >= 95 ? 'good' : d.rate >= 80 ? 'warn' : 'bad'
}
</script>

<template>
  <div>
    <div class="section-divider">資料治理</div>
    <div class="breadcrumb-bar"><span class="pin">📌</span> <b>資料品質</b></div>

    <p v-if="loading" class="muted">計算中…</p>

    <template v-else-if="summary">
      <div class="card hero">
        <div class="score-box">
          <div class="score" :class="{ none: summary.score === null }">
            {{ summary.score === null ? '—' : summary.score }}<small v-if="summary.score !== null">%</small>
          </div>
          <div class="score-label">可驗證資料正確率
            <InfoNote>量測母體：<b>{{ summary.asset_total }}</b> 筆非退役資產。{{ summary.score_basis }}。<br><br>「近 {{ summary.fresh_days }} 天被機器看到」＝掃描或服務採集有紀錄；超過 {{ summary.stale_days }} 天沒更新的資料另計新鮮度。<b>沒收到機器資料的主機一律不列入分母</b>——不知道不等於錯，也不等於對，把它算成任何一邊都是在編數字。<br><br><b>這個分數不能告訴你什麼：</b>填寫率高不代表填得對——「保管者」欄位每一筆都有值，但那個人可能三年前就離職了。機器驗不了的欄位，只有<b>定期複核＋指定負責人</b>能拉高正確率。這頁的用途是量出<b>導入前後的差距</b>與<b>該先修哪一類</b>，不是宣稱清單已經正確。</InfoNote>
          </div>
          <div class="score-sample">依據 {{ summary.score_sample }} 筆機器證據</div>
        </div>
        <div class="hero-text">
          <p
            v-if="summary.coverage_rate !== null && summary.coverage_rate < 90"
            class="cover-warn"
          >
            ⚠ 掃描只涵蓋 <b>{{ summary.coverage_rate }}%</b> 的使用中資產——分數只代表已涵蓋的那部分，不是整份清單的正確率。
          </p>
        </div>
      </div>

      <!-- 系統校正：數字可下鑽（/corrections 同一支後端） -->
      <div class="card">
        <div class="card-title">實測與 CIA 不符
          <InfoNote>已納管主機登入收集到的（或 RVTools 回報的）跟 CIA 登記不一樣：畫面與分類已用實測值「⟲ 系統校正」，CIA 登記值沒有被改，清單交給 CIA 窗口更正。只有存活掃描講不一樣的列「疑似不符」，不自動校正。</InfoNote>
        </div>
        <p v-if="mmErr" class="err">{{ mmErr }}</p>
        <div v-else-if="mm" class="mm-head">
          <NuxtLink to="/corrections">系統校正 <b class="mono">{{ mm.corrected.length }}</b> 筆（CIA 待更正）</NuxtLink>
          <NuxtLink :to="{ path: '/corrections', query: { tab: 'suspect' } }">疑似不符 <b class="mono">{{ mm.suspect.length }}</b> 筆</NuxtLink>
        </div>
      </div>

      <!-- 資料可信度分布：每個數字都能點進去看是哪幾台 -->
      <div v-if="trust" class="card">
        <div class="card-title">資料可信度分布（{{ trust.total }} 筆登記<span v-if="trust.machines">／{{ trust.machines }} 台</span>，非退役）
          <InfoNote><b>一筆登記一個分數，越高越可信。</b>分數問的是「這一筆登記有幾個來源佐證」，所以母體是<b>登記筆數</b>；同一台若在 CIA 與 DY 各有一筆，會各自計分。括號裡另外附去重後的台數（2026-09-20 修：原本只寫「台」，其實是筆）。<br><br><br>{{ trust.rule }}。<br><br>實體機不會出現在 RVTools，所以實體機只算 dynassets＋CIA（照比例換算成 70 分滿分）；型態不明的照 VM 算。<br><br>第一版的「有」＝這個來源裡有這台；欄位對不上（IP、主機名不同）先不扣分。<br><br>點筆數看是哪幾筆。</InfoNote>
        </div>
        <div class="trust-grid">
          <div class="tbl-wrap">
            <table>
              <thead><tr>
                <SortTh k="score" :active="sKey" :dir="sDir" @sort="sToggle">分數</SortTh>
                <SortTh k="count" :active="sKey" :dir="sDir" @sort="sToggle">筆數</SortTh>
                <SortTh k="reason_text" :active="sKey" :dir="sDir" @sort="sToggle">
                  分數怎麼來的 <InfoNote>型態・有哪幾個來源（來源分）＋機器證據（加分）。同一個分數可能由不同組合湊出來，分別列出各幾筆，加總就是左邊的筆數。</InfoNote>
                </SortTh>
              </tr></thead>
              <tbody>
                <tr v-for="b in sSorted" :key="b.score" class="clickable"
                    :class="{ on: trustOpen === `s:${b.score}` }" @click="openTrust('s', b.score, `${b.score} 分`)">
                  <td class="mono"><span class="tscore" :class="b.score >= 90 ? 'good' : b.score >= 50 ? 'warn' : 'bad'">{{ b.score }}</span></td>
                  <td class="mono lnk-in">{{ b.count }}</td>
                  <td class="why">
                    <div v-for="x in b.reasons" :key="x.text">{{ x.text }} <span class="muted">×{{ x.count }}</span></div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <div class="tbl-wrap">
            <table>
              <thead><tr>
                <SortTh k="label" :active="cbKey" :dir="cbDir" @sort="cbToggle">出現在哪幾個來源</SortTh>
                <SortTh k="count" :active="cbKey" :dir="cbDir" @sort="cbToggle">筆數</SortTh>
              </tr></thead>
              <tbody>
                <tr v-for="c in cbSorted" :key="c.combo" class="clickable"
                    :class="{ on: trustOpen === `c:${c.combo}` }" @click="openTrust('c', c.combo, c.label)">
                  <td>{{ c.label }}</td>
                  <td class="mono lnk-in">{{ c.count }}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div v-if="trustOpen" class="trust-drill">
          <div class="card-title">{{ trustTitle }}：{{ trustHosts.length }} 台</div>
          <p v-if="trustLoading" class="muted">載入中…</p>
          <div v-else class="tbl-wrap inner">
            <table>
              <thead><tr>
                <SortTh k="asset_serial" :active="thKey" :dir="thDir" @sort="thToggle">資產序號</SortTh>
                <SortTh k="hostname" :active="thKey" :dir="thDir" @sort="thToggle">主機名稱</SortTh>
                <SortTh k="ip" :active="thKey" :dir="thDir" @sort="thToggle">IP</SortTh>
                <SortTh k="score" :active="thKey" :dir="thDir" @sort="thToggle">分數</SortTh>
                <SortTh k="kind" :active="thKey" :dir="thDir" @sort="thToggle">型態</SortTh>
                <SortTh k="src_dyn" :active="thKey" :dir="thDir" @sort="thToggle">dynassets</SortTh>
                <SortTh k="src_rv" :active="thKey" :dir="thDir" @sort="thToggle">RVTools</SortTh>
                <SortTh k="src_cia" :active="thKey" :dir="thDir" @sort="thToggle">CIA</SortTh>
                <SortTh k="evid_text" :active="thKey" :dir="thDir" @sort="thToggle">機器證據</SortTh>
              </tr></thead>
              <tbody>
                <tr v-for="h in thSorted" :key="h.asset_serial">
                  <td class="mono"><NuxtLink :to="`/assets/${h.asset_serial}`" class="lnk-in">{{ h.asset_serial }}</NuxtLink></td>
                  <td>{{ h.hostname ?? '—' }}</td>
                  <td class="mono">{{ h.ip ?? '—' }}</td>
                  <td class="mono">{{ h.score }}</td>
                  <td>{{ KIND_NAME[h.kind] ?? h.kind }}</td>
                  <td :class="{ muted: h.src_dyn !== '有' }">{{ h.src_dyn }}</td>
                  <td :class="{ muted: h.src_rv !== '有' }">{{ h.src_rv }}</td>
                  <td :class="{ muted: h.src_cia !== '有' }">{{ h.src_cia }}</td>
                  <td>{{ h.evid_text }}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- 填充率最低的欄位＝待補資料（欄位先立、機器後補，2026-09-19） -->
      <div v-if="lowestFill.length" class="card">
        <div class="card-title">填充率最低的欄位（待補資料）
          <InfoNote>人可以維護的欄位裡，目前收得最少的前 12 個。欄位先立、機器後補——這裡就是「還缺什麼」。分母＝{{ fillTotal }} 筆 hardware。待處理旗標、收集錯誤、時間戳、*_override／*_source 這類系統狀態欄位可以合法為空，不列在這裡。</InfoNote>
        </div>
        <div class="fill-list">
          <div v-for="f in lowestFill" :key="f.column" class="fill-row">
            <div class="fill-meta"><b>{{ f.meaning }}</b><span class="fmono">{{ f.column }}</span></div>
            <div class="fill-bar"><span :style="{ width: Math.round((f.fill_rate ?? 0) * 100) + '%' }" /></div>
            <div class="fill-pct mono">{{ Math.round((f.fill_rate ?? 0) * 100) }}%<span class="fdim">（{{ f.filled }}）</span></div>
          </div>
        </div>
      </div>

      <!-- SSH 測連線（2026-09-15 使用者：「把測試小工具也一次放進去，可以放在品質分析裡面」） -->
      <SshProbe />

      <div class="card">
        <div class="card-title">各維度 <InfoNote>點一列看是哪幾台。</InfoNote></div>
        <div class="tbl-wrap">
          <table>
            <thead>
              <tr>
                <SortTh k="label" :active="sortKey" :dir="sortDir" @sort="toggle">維度</SortTh>
                <SortTh k="kind" :active="sortKey" :dir="sortDir" @sort="toggle">性質</SortTh>
                <SortTh k="checked" :active="sortKey" :dir="sortDir" @sort="toggle">母體</SortTh>
                <SortTh k="ok" :active="sortKey" :dir="sortDir" @sort="toggle">符合</SortTh>
                <SortTh k="bad" :active="sortKey" :dir="sortDir" @sort="toggle">不符合</SortTh>
                <SortTh k="rate" :active="sortKey" :dir="sortDir" @sort="toggle">比率</SortTh>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <template v-for="d in sorted" :key="d.key">
                <tr class="clickable" :class="{ on: openKey === d.key }" @click="drill(d)">
                  <td>
                    {{ d.label }}
                    <div class="note">{{ d.note }}</div>
                  </td>
                  <td><span class="tag" :class="d.kind">{{ KIND_TEXT[d.kind] }}</span></td>
                  <td class="mono">{{ d.checked }}</td>
                  <td class="mono">{{ d.ok }}</td>
                  <td class="mono" :class="{ hasbad: d.bad > 0 }">{{ d.bad }}</td>
                  <td class="mono rate" :class="rateClass(d)">
                    {{ d.rate === null ? '—' : d.rate + '%' }}
                  </td>
                  <td class="caret">{{ openKey === d.key ? '▾' : '▸' }}</td>
                </tr>
                <tr v-if="openKey === d.key" class="drill">
                  <td colspan="7">
                    <p v-if="offLoading" class="muted">載入中…</p>
                    <p v-else-if="offenders.length === 0" class="muted">這個維度沒有不符合的資產。</p>
                    <div v-else class="tbl-wrap inner">
                      <div class="off-bar">
                        共 {{ offenders.length }} 筆
                        <button class="btn small" type="button" @click.stop="exportOffenders(d)">匯出 CSV</button>
                      </div>
                      <table>
                        <thead>
                          <tr>
                            <SortTh k="asset_serial" :active="oKey" :dir="oDir" @sort="oToggle">資產序號</SortTh>
                            <SortTh k="hostname" :active="oKey" :dir="oDir" @sort="oToggle">主機名稱</SortTh>
                            <SortTh k="ip" :active="oKey" :dir="oDir" @sort="oToggle">IP</SortTh>
                            <SortTh k="asset_status" :active="oKey" :dir="oDir" @sort="oToggle">狀態</SortTh>
                            <SortTh k="inventory_department" :active="oKey" :dir="oDir" @sort="oToggle">部門</SortTh>
                            <SortTh k="custodian" :active="oKey" :dir="oDir" @sort="oToggle">保管者</SortTh>
                            <SortTh k="reason" :active="oKey" :dir="oDir" @sort="oToggle">原因</SortTh>
                          </tr>
                        </thead>
                        <tbody>
                          <tr v-for="o in oSorted" :key="o.asset_serial">
                            <td class="mono">
                              <NuxtLink :to="`/assets/${o.asset_serial}`" class="lnk-in">{{ o.asset_serial }}</NuxtLink>
                            </td>
                            <td>{{ o.hostname ?? '—' }}</td>
                            <td class="mono">{{ o.ip ?? '—' }}</td>
                            <td>{{ o.asset_status ?? '—' }}</td>
                            <td>{{ o.inventory_department ?? '—' }}</td>
                            <td>{{ o.custodian ?? '—' }}</td>
                            <td class="reason">{{ o.reason }}</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>
      </div>

      <!-- 只出現一次的人名：打錯字高風險候選（2026-09-17 使用者） -->
      <div class="card">
        <button type="button" class="dq-toggle" @click="singleOpen = !singleOpen">
          {{ singleOpen ? '▾' : '▸' }} 只出現一次的人名（可能打錯字）<b>{{ singleNames.length }}</b> 個
          <InfoNote>跨「使用者／保管者／人員名冊」統計，只用在一筆的名字。可能是真的只管一台，也可能是把「李太明」打成「李太名」。人名改成可搜尋＋可新增後，這裡定期看一眼、抓出近似的錯字。</InfoNote>
        </button>
        <div v-if="singleOpen" class="names">
          <span v-for="n in singleNames" :key="n" class="nchip" :class="{ on: mergeFrom === n }"
                title="點一下帶入下方合併的「原名」" @click="pickMergeFrom(n)">{{ n }}</span>
          <p v-if="!singleNames.length" class="muted">沒有只出現一次的人名。</p>
        </div>
        <!-- 一鍵合併（預覽版）：先看會改幾筆，確認才寫。改的是真資料，所以強制預覽這道關。 -->
        <div v-if="singleOpen" class="merge">
          <div class="merge-hd">合併到正確人名 <InfoNote>把打錯字的名字（原名）併到正確名字。會改 <b>使用者／保管者／人員名冊</b> 三處完全一致的值。<b>先按「預覽」看會動幾筆</b>，確認無誤再按「確認合併」——這個動作直接改資料。</InfoNote></div>
          <div class="merge-row">
            <input v-model="mergeFrom" class="minp" type="text" placeholder="原名（打錯的，可點上面名字帶入）" />
            <span class="marrow">→</span>
            <input v-model="mergeTo" class="minp" type="text" placeholder="正確名" />
            <button class="btn small" type="button" :disabled="mergeBusy" @click="doMergePreview">預覽</button>
          </div>
          <div v-if="mergePreview" class="merge-prev">
            <template v-if="mergePreview.total">
              <p class="mp-sum">會把「<b>{{ mergePreview.from_name }}</b>」改成「<b>{{ mergePreview.to_name }}</b>」，共 <b>{{ mergePreview.total }}</b> 筆：
                <span v-for="f in mergePreview.fields" :key="f.label" class="mp-f">{{ f.label }} {{ f.count }}</span>
              </p>
              <div v-if="mergePreview.sample.length" class="mp-sample">
                影響的機器（前 {{ mergePreview.sample.length }}）：
                <span v-for="s in mergePreview.sample" :key="s.asset_serial + s.field" class="mp-chip">
                  {{ s.hostname || s.asset_serial }}<i>{{ s.field }}</i>
                </span>
              </div>
              <button v-if="!isViewer" class="btn small danger" type="button" :disabled="mergeBusy" @click="doMergeApply">確認合併（{{ mergePreview.total }} 筆）</button>
            </template>
            <p v-else class="muted">找不到完全一致的「{{ mergePreview.from_name }}」，沒有可合併的資料。</p>
          </div>
        </div>
      </div>

    </template>
  </div>
</template>

<style scoped>
.mm-head { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; }
.fill-list { display: flex; flex-direction: column; gap: 6px; }
.fill-row { display: grid; grid-template-columns: minmax(180px, 1.4fr) 2fr auto; align-items: center; gap: 10px; font-size: 12.5px; }
.fill-meta { display: flex; flex-direction: column; }
.fill-meta b { color: var(--ink); font-weight: 600; }
.fmono { font-family: ui-monospace, monospace; font-size: 11px; color: var(--muted); }
.fill-bar { height: 8px; background: var(--border); border-radius: 4px; overflow: hidden; }
.fill-bar span { display: block; height: 100%; background: var(--brand); }
.fill-pct { color: var(--ink-soft); white-space: nowrap; }
.fdim { color: var(--muted); font-size: 11px; }
.section-divider { margin: 0 0 16px; font-size: 11px; color: var(--brand-dark);
  font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; }
.breadcrumb-bar { background: var(--mint); border: 1px solid var(--border-strong);
  padding: 8px 14px; font-size: 12.5px; color: var(--ink-soft); display: flex;
  align-items: center; gap: 8px; margin-bottom: 14px; }
.breadcrumb-bar b { color: var(--brand-dark); }
.card { border: 1px solid var(--border); background: var(--card); padding: 16px; margin-bottom: 16px; }
.card-title { font-size: 13px; font-weight: 700; color: var(--ink-soft); margin-bottom: 10px; }
.hero { display: flex; gap: 24px; align-items: center; flex-wrap: wrap; }
.score-box { text-align: center; min-width: 150px; }
.score { font-size: 46px; font-weight: 700; color: var(--brand-dark); line-height: 1;
  font-family: 'Space Grotesk', ui-monospace, monospace; }
.score small { font-size: 20px; margin-left: 2px; }
.score.none { color: var(--muted); }
.score-label { font-size: 11.5px; color: var(--muted); margin-top: 6px; }
.score-sample { font-size: 10.5px; color: var(--muted); margin-top: 2px; opacity: .8; }
.cover-warn { font-size: 12px; line-height: 1.8; color: var(--ink-soft); margin: 0 0 10px;
  border-left: 2px solid var(--warn, #d8a13a); padding: 6px 0 6px 12px; }
.cover-warn b { color: var(--warn-text); }
.tag.coverage { border-color: var(--warn, #d8a13a); color: var(--warn-text); }
.hero-text { flex: 1; min-width: 280px; }
.rv-hint { font-size: 12px; color: var(--muted); line-height: 1.8; }
.rv-hint b { color: var(--ink-soft); }
.muted { color: var(--muted); font-size: 12.5px; }
.lnk-in { color: var(--brand-dark); text-decoration: none; }
.lnk-in:hover { text-decoration: underline; }
.tbl-wrap { overflow-x: auto; border: 1px solid var(--border); }
.tbl-wrap.inner { margin: 6px 0; }
table { border-collapse: collapse; width: 100%; font-size: 12.5px; min-width: 620px; }
th, td { text-align: left; padding: 8px 12px; border-bottom: 1px solid var(--border); vertical-align: top; }
th { color: var(--ink-soft); font-weight: 700; font-size: 12px; background: var(--mint); }
tr:last-child td { border-bottom: none; }
.clickable { cursor: pointer; }
.clickable:hover td { background: rgba(15,23,42,.03); }
.clickable.on td { background: rgba(0,145,66,.06); }
.drill td { background: rgba(0,0,0,.15); }
/* 資料可信度分布（2026-09-11）：左邊分數、右邊來源組合，下面展開是哪幾台 */
/* 分數表多了「怎麼來的」一欄會變寬，所以兩張表上下疊，不再左右擠 */
.trust-grid { display: grid; grid-template-columns: minmax(0, 1fr); gap: 16px; align-items: start; }
.why { font-size: 12px; line-height: 1.7; color: var(--ink-soft); }
.trust-drill { margin-top: 14px; }
.tscore { display: inline-block; min-width: 36px; text-align: center; font-weight: 700;
  padding: 2px 8px; border-radius: 999px; font-variant-numeric: tabular-nums; }
.tscore.good { background: var(--good-soft); color: var(--brand-dark); }
.tscore.warn { background: var(--warn-soft); color: var(--warn-text); }
.tscore.bad { background: var(--bad-soft); color: var(--bad); }
.mono { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }
.note { font-size: 10.5px; color: var(--muted); margin-top: 3px; line-height: 1.5; }
.tag { font-size: 10.5px; padding: 2px 7px; border: 1px solid var(--border-strong); color: var(--muted); white-space: nowrap; }
.tag.verifiable { border-color: var(--brand); color: var(--brand-dark); }
.rate { font-weight: 700; }
.rate.good { color: var(--brand-dark); }
.rate.warn { color: var(--warn-text); }
.rate.bad { color: var(--bad); }
.hasbad { color: var(--bad); }
.caret { color: var(--muted); width: 24px; }
.reason { font-size: 11.5px; }
.dq-toggle { width: 100%; text-align: left; background: none; border: none; cursor: pointer;
  font-family: inherit; font-size: 14px; font-weight: 600; color: var(--ink); padding: 4px 0; }
.dq-toggle b { color: var(--brand-dark); font-family: var(--disp); margin: 0 2px; }
.names { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 10px; }
.nchip { font-size: 12.5px; padding: 3px 10px; border-radius: 999px; background: var(--sub);
  color: var(--ink); border: 1px solid var(--border); cursor: pointer; }
.nchip:hover { border-color: var(--brand); }
.nchip.on { background: var(--mint); border-color: var(--brand); color: var(--brand-dark); font-weight: 600; }
.merge { margin-top: 14px; padding-top: 12px; border-top: 1px dashed var(--border); }
.merge-hd { font-size: 12.5px; font-weight: 600; color: var(--ink-soft); margin-bottom: 8px; }
.merge-row { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
.minp { font-family: inherit; font-size: 12.5px; padding: 6px 10px; min-width: 200px;
  border: 1px solid var(--border-strong); background: var(--card); color: var(--ink); border-radius: 6px; }
.marrow { color: var(--muted); }
.merge-prev { margin-top: 10px; font-size: 12.5px; }
.mp-sum { color: var(--ink-soft); margin: 0 0 6px; }
.mp-f { display: inline-block; margin-left: 8px; padding: 1px 8px; border-radius: 999px;
  background: var(--sub); font-size: 11.5px; }
.mp-sample { color: var(--muted); font-size: 11.5px; margin-bottom: 8px; line-height: 1.9; }
.mp-chip { display: inline-block; margin: 0 4px; padding: 1px 8px; border: 1px solid var(--border);
  border-radius: 6px; }
.mp-chip i { color: var(--muted); font-style: normal; margin-left: 4px; font-size: 10.5px; }
.btn.small.danger { border-color: var(--bad); color: var(--bad); }
.btn.small.danger:hover:not(:disabled) { background: var(--bad); color: #fff; }
.off-bar { display: flex; gap: 10px; align-items: center; font-size: 12px; margin: 4px 0 6px; }
</style>
