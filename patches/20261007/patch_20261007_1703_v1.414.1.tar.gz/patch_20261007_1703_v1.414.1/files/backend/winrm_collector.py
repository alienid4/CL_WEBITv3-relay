"""Windows 原生收集：WinRM／CIM。

## 為什麼不用 SSH（2026-07-19 使用者定案：「Windows 應該靠 Windows 方式，不該走 SSH」）

先前硬把 Unix 那套（OpenSSH ＋ 本機唯讀帳號 ＋ 公鑰）套到 Windows，撞了一連串牆，
而**每一面牆都是典範錯置**，不是 Windows 的問題：

  新帳號沒 profile → 找不到 .ssh/     ← Unix 家目錄慣例
  authorized_keys 有 BOM 就壞          ← Unix 純文字檔慣例
  sshd_config 同指令只認第一條          ← OpenSSH 設定語意
  New-LocalUser 不給群組                ← 拿 useradd 的心智模型硬套

更關鍵的是**規模**：公司幾千台 Windows 不可能一台台裝 OpenSSH、建本機帳號、佈金鑰；
在 AD 環境那根本不是標準做法。

## Windows 的正解

**收集資料完全不需要建帳號。** WinRM（WS-Man，Windows 內建的遠端管理）＋ CIM 查詢
就能拿到主機名／OS／序號／機型——那正是我們要的全部。網域環境用一組服務帳號即可
涵蓋所有機器，不必碰每一台。

  Linux    → SSH ＋ 金鑰 ＋ 唯讀帳號
  Windows  → WinRM/CIM ＋ 服務帳號（不建帳號、不佈金鑰、不碰 sshd）

## 目標機需要什麼

WinRM 沒開的機器要跑一次 `Enable-PSRemoting -Force`（Windows 原生指令，
網域環境通常已由 GPO 開好）。這比「裝 OpenSSH ＋ 建帳號 ＋ 佈金鑰 ＋ 改 sshd_config」
單純得多，而且是 Windows 管理員本來就熟悉的做法。

## 憑證

WinRM 需要帳密，SSH 用金鑰——但**兩者同一類**：221 上本來就存著收集用的私鑰，
存一組 Windows 服務帳號憑證是等價的事（業界 CMDB 工具都有憑證庫）。
差別是 Windows 這條需要加密的憑證庫，由 credential_store 負責。
"""
from __future__ import annotations

# CIM 查詢：一次拿齊我們要的欄位。用 PowerShell 輸出 key=value，好解析且不依賴 JSON。
# 刻意不使用 ConvertTo-Json——舊版 PowerShell 的 JSON 輸出格式不穩，key=value 最保險。
FACTS_PS = r"""
$ErrorActionPreference='SilentlyContinue'
$os  = Get-CimInstance Win32_OperatingSystem
$cs  = Get-CimInstance Win32_ComputerSystem
$bios= Get-CimInstance Win32_BIOS
$net = Get-CimInstance Win32_NetworkAdapterConfiguration | Where-Object { $_.IPEnabled -eq $true } | Select-Object -First 1
"hostname=" + $env:COMPUTERNAME
"os=" + $os.Caption
"os_version=" + $os.Version
"device_model=" + $cs.Model
"vendor=" + $cs.Manufacturer
"hw_serial=" + $bios.SerialNumber
"mac=" + $net.MACAddress
"is_vm=" + $(if ($cs.Model -match 'Virtual|VMware|KVM|Xen') { '1' } else { '0' })
"""


# M2 服務發現的 Windows 版。對應 Linux 的 `ss -tlnp`：
# Get-NetTCPConnection -State Listen 就是 Windows 原生的「誰在聽埠」。
#
# ⚠️ 不要改成 netstat -ano：那要再自己對 PID 查行程名，而且輸出格式在不同語系
# 的 Windows 上會變（中文版欄位標題是中文），解析很脆。CIM/Cmdlet 輸出跟語系無關。
#
# 輸出格式刻意跟 Linux 那條對齊成「bind:port process」，讓解析器共用同一支。
SERVICES_PS = r"""
$ErrorActionPreference='SilentlyContinue'
Get-NetTCPConnection -State Listen | ForEach-Object {
  $p = (Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue).ProcessName
  "LISTEN 0 0 $($_.LocalAddress):$($_.LocalPort) *:* " + $(if ($p) { "users:((`"$p`"))" } else { "" })
}
"""


def collect_services(host: str, username: str, password: str, runner=None,
                     transport: str = "ntlm", timeout: int = 30) -> str:
    """對一台 Windows 收監聽清單，回傳「跟 ss 對齊」的原始文字。

    刻意回原始文字而不是解析後的結構：解析交給 service_collector.parse_listen，
    兩個平台共用同一支解析器，才不會 Linux 修了 bug、Windows 那條還留著。

    ⚠️ password 用完即丟，不進回傳值、不進 log（同 collect）。
    """
    if runner is not None:
        return runner(host, SERVICES_PS)

    import winrm  # 延後匯入：沒裝 pywinrm 時不影響其他功能

    session = winrm.Session(
        f"http://{host}:5985/wsman",
        auth=(username, password),
        transport=transport,
        read_timeout_sec=timeout + 10,
        operation_timeout_sec=timeout,
    )
    r = session.run_ps(SERVICES_PS)
    if r.status_code != 0:
        raise ConnectionError(
            (r.std_err or b"").decode("utf-8", "replace")[:300] or "WinRM 執行失敗"
        )
    return (r.std_out or b"").decode("utf-8", "replace")


def collect_software(host: str, username: str, password: str, runner=None,
                     transport: str = "ntlm", timeout: int = 60) -> str:
    """對一台 Windows 收「程式和功能」清單，回傳原始文字（解析交給 software_collector）。

    ⚠️ 未在真機驗證。password 用完即丟，不進回傳值、不進 log（同 collect）。
    timeout 比服務盤點長：登錄檔兩個 Uninstall 機碼加起來可能上千筆。
    """
    import software_collector

    if runner is not None:
        return runner(host, software_collector.WINDOWS_PS)

    import winrm  # 延後匯入：沒裝 pywinrm 時不影響其他功能

    session = winrm.Session(
        f"http://{host}:5985/wsman",
        auth=(username, password),
        transport=transport,
        read_timeout_sec=timeout + 10,
        operation_timeout_sec=timeout,
    )
    r = session.run_ps(software_collector.WINDOWS_PS)
    if r.status_code != 0:
        raise ConnectionError(
            (r.std_err or b"").decode("utf-8", "replace")[:300] or "WinRM 執行失敗"
        )
    return (r.std_out or b"").decode("utf-8", "replace")



# 值班健檢（8-3）的 Windows 版。對應 Linux 那支 _METRICS_CMD：
# **一次往返收齊**，用 @@MARKER 切段，解析交給 health_probe，兩個平台共用切段器。
#
# 三個刻意的取捨，每一個都是「寧可少一格，不要填一個假的」：
#
# 1. **全部走 CIM，不用效能計數器**（Get-Counter '\Memory\...'）。
#    計數器的路徑名稱**會隨系統語言變**——中文版 Windows 是「\記憶體\...」，
#    在英文版寫死的路徑會查不到，而錯誤長得像「這台沒有這個指標」。
#    CIM 的屬性名跟語言無關。
#
# 2. **時間同步用 `w32tm /query /source`**，不用 `/status`。
#    /status 的欄位標題是翻譯過的（中文版是「來源:」），比對字面一定會漏掉一種；
#    /source 直接吐來源字串本身（例如 time.windows.com 或 Local CMOS Clock），
#    那個值跟語言無關。
#
# 3. **沒有 iowait、沒有 load average、沒有「唯讀重掛」**。
#    Windows 沒有這三個概念的等價物。這裡就不收，由 health_probe 標成
#    「這個平台沒有這個指標」——**不可以填 0**，0 會被讀成「量到了，而且很好」。
HEALTH_PS = r"""
$ErrorActionPreference='SilentlyContinue'
$os = Get-CimInstance Win32_OperatingSystem
$cs = Get-CimInstance Win32_ComputerSystem

"@@OS"
"caption=" + $os.Caption
"version=" + $os.Version

"@@UP"
if ($os.LastBootUpTime) {
  "boot=" + $os.LastBootUpTime.ToString("yyyy-MM-dd HH:mm:ss")
  "now="  + (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
}

"@@CPU"
"ncpu=" + $cs.NumberOfLogicalProcessors
$cpu = (Get-CimInstance Win32_Processor | Measure-Object -Property LoadPercentage -Average).Average
if ($cpu -ne $null) { "usage=" + $cpu }

"@@MEM"
"total_kb=" + $os.TotalVisibleMemorySize
"free_kb="  + $os.FreePhysicalMemory
"commit_total_kb=" + $os.TotalVirtualMemorySize
"commit_free_kb="  + $os.FreeVirtualMemory

"@@DISK"
Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" | ForEach-Object {
  "$($_.DeviceID)|$($_.Size)|$($_.FreeSpace)"
}

"@@SVC"
Get-CimInstance Win32_Service -Filter "StartMode='Auto' AND State<>'Running'" | ForEach-Object {
  "$($_.Name)|$($_.DisplayName)|$($_.State)"
}

"@@LISTEN"
Get-NetTCPConnection -State Listen | ForEach-Object {
  $p = (Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue).ProcessName
  "LISTEN 0 0 $($_.LocalAddress):$($_.LocalPort) *:* " + $(if ($p) { "users:((`"$p`"))" } else { "" })
}

"@@TIME"
$src = (w32tm /query /source 2>$null)
"rc=$LASTEXITCODE"
if ($src) { "src=" + ($src -join " ").Trim() }

"@@END"
"""


def collect_health(host: str, username: str, password: str, runner=None,
                   transport: str = "ntlm", timeout: int = 30) -> str:
    """值班健檢：對一台 Windows 收齊指標，回**原始文字**（解析交給 health_probe）。

    回原始文字而不是結構，理由同 collect_services：解析只有一份，
    兩邊修同一支，不會這裡修好了那裡還留著。

    ⚠️ password 用完即丟，不進回傳值、不進 log（同 collect）。
    """
    if runner is not None:
        return runner(host, HEALTH_PS)

    import winrm  # 延後匯入：沒裝 pywinrm 時不影響其他功能

    session = winrm.Session(
        f"http://{host}:5985/wsman",
        auth=(username, password),
        transport=transport,
        read_timeout_sec=timeout + 10,
        operation_timeout_sec=timeout,
    )
    r = session.run_ps(HEALTH_PS)
    if r.status_code != 0:
        raise ConnectionError(
            (r.std_err or b"").decode("utf-8", "replace")[:300] or "WinRM 執行失敗"
        )
    return (r.std_out or b"").decode("utf-8", "replace")


def parse_facts(output: str) -> dict:
    """把 key=value 輸出解析成 dict。空值一律 None，不留空字串。

    為什麼分開成純函式：這是唯一有邏輯的部分，要能不碰網路直接測。
    """
    out: dict = {}
    for line in (output or "").splitlines():
        line = line.strip()
        if not line or "=" not in line:
            continue
        k, _, v = line.partition("=")
        v = v.strip()
        out[k.strip()] = v or None
    if out.get("is_vm") is not None:
        out["is_vm"] = 1 if out["is_vm"] == "1" else 0
    # 只回我們認得的欄位，避免把目標機的雜訊帶進資產表
    allowed = ("hostname", "os", "os_version", "device_model", "vendor",
               "hw_serial", "mac", "is_vm")
    return {k: out.get(k) for k in allowed if k in out}


def collect(host: str, username: str, password: str, runner=None,
            transport: str = "ntlm", timeout: int = 30) -> dict:
    """對一台 Windows 收 facts。

    ⚠️ password 只在本函式與 runner 之間傳遞、用完即丟——不寫回傳值、不寫 log。
    runner 可注入，測試不碰真網路、不碰真密碼。

    transport 預設 ntlm：獨立機（非網域）也能用，且 NTLM 會加密內容，
    不像 basic 需要 AllowUnencrypted（那等於明文，內網也不該用）。
    """
    if runner is not None:
        return parse_facts(runner(host, FACTS_PS))

    import winrm  # 延後匯入：沒裝 pywinrm 時不影響其他功能

    session = winrm.Session(
        f"http://{host}:5985/wsman",
        auth=(username, password),
        transport=transport,
        read_timeout_sec=timeout + 10,
        operation_timeout_sec=timeout,
    )
    r = session.run_ps(FACTS_PS)
    if r.status_code != 0:
        raise ConnectionError(
            (r.std_err or b"").decode("utf-8", "replace")[:300] or "WinRM 執行失敗"
        )
    return parse_facts((r.std_out or b"").decode("utf-8", "replace"))


def enable_hint(collector_ip: str | None = None) -> str:
    """WinRM 連不上時給的解法。

    collector_ip 不給就現場解析（畫面設定 → 環境變數 → 自動偵測），**沒有寫死的預設**。
    原本簽章預設是開發機位址，於是每台公司主機的錯誤訊息都叫人去放行一個不存在的位址——
    照著做會「規則加好了、WinRM 還是連不進來」，比不給提示更難查（2026-10-06 查出）。

    ⚠️ 這裡**刻意不 raise**。這支只在「已經出錯、正在組錯誤訊息」時被呼叫；
    在錯誤路徑上再丟例外會把原始故障蓋掉，變成查不到真因。
    解不出來就在訊息裡明寫「這一格沒填、要去哪裡填」——人看得懂，也不會照著貼錯值。

    ⚠️ 實測（示範網段內一台）發現：光跑 Enable-PSRemoting 不夠。服務會起來、5985 也會監聽，
    但如果那張網卡被 Windows 判定成「公用網路」，防火牆的公用設定檔規則是**關閉**的，
    外面照樣連不進來——而症狀只是「連線逾時」，完全看不出是防火牆設定檔的問題。

    這裡刻意建議「只放行收集來源 IP」而不是「把網路改成私人」：
    改成私人會一次放寬那張網卡的所有防火牆行為，暴露面大得多；
    只開一個埠給一台機器，其餘完全不動。
    """
    if not collector_ip:
        import onboard_engine

        collector_ip = (onboard_engine.resolve_collector_ip() or "").strip()
    if not collector_ip:
        collector_ip = "<這台收集器的位址：請在「設定 → 自動納管」填收集器位址後重試>"
    return (
        "這台的 WinRM 連不上。在該機器以系統管理員 PowerShell 執行：\n"
        "  1) Enable-PSRemoting -Force\n"
        f"  2) New-NetFirewallRule -DisplayName \"WinRM from webit3 collector\" "
        f"-Direction Inbound -Protocol TCP -LocalPort 5985 "
        f"-RemoteAddress {collector_ip} -Action Allow -Profile Any\n"
        "（第 2 步常被忽略：網卡若被判為「公用網路」，Enable-PSRemoting 開的規則不含公用設定檔，"
        "外面仍連不進來。只放行收集來源 IP 比把網路改成私人安全得多。"
        "網域環境通常已由 GPO 處理，不需逐台執行）"
    )


# ENABLE_HINT 這個「模組載入時就算好」的常數已經移除（2026-10-06），呼叫點改成直接
# 呼叫 enable_hint()。兩個理由，第二個是真的 bug：
#   1. enable_hint() 現在會解析收集器位址（可能開 UDP socket 探預設路由）。
#      放在模組層等於**import 就有副作用**，backend 任何一支 import 到它都會跑，
#      解不出來時還會讓整個服務起不來。
#   2. 收集器位址是**畫面上可以改的設定**。在 import 時算好一次，之後使用者改了設定，
#      錯誤訊息永遠停在舊值——而且沒有任何跡象，只會讓人照著舊位址開防火牆開不通。
# 要字串就呼叫 enable_hint()，一次呼叫一次解析，永遠反映當下設定。
