<script setup lang="ts">
// 網段配置表：公司「總分公司網段配置表」Excel 的系統版本。
//
// 這頁不只是把 Excel 貼上來——它是三件事的來源：
//   1. 新增資產時「機房 → 環境 → 網段」選 IP（填表的人記不住 10.99.163 是哪裡）
//   2. 掃描範圍：弱掃說明裡註記「建議排除掃描」的段不該被主動掃
//   3. 資料品質涵蓋率的分母：哪些網段該掃卻還沒掃
interface Segment {
  id: number
  cidr: string | null
  raw_cidr: string
  usage_status: string | null
  location: string | null
  purpose_desc: string | null
  category: string | null
  usage: string | null
  environment: string | null
  environment_raw: string | null
  vlan: string | null
  remark: string | null
  expanded_from: string | null
  net_start: number | null
  row_no: number | null
  scan_excluded: number
  scan_note: string | null
  asset_count: number
  capacity: number | null
  imported_at: string | null
}
interface UsedIp {
  asset_serial: string
  hostname: string | null
  ip: string
  asset_status: string | null
}

const { apiFetch } = useApi()
const { showToast } = useToast()

const rows = ref<Segment[]>([])
const loading = ref(true)

const q = ref('')
const scanFilter = ref<'' | 'include' | 'exclude'>('')
// 2026-08-26 使用者：「我要怎麼知道無法解析的 9 個是哪 9 個？」
// 原本那 9 筆只在匯入當下的警告區出現，重新整理就消失了——等於「知道有問題，
// 但永遠找不到是哪幾筆」。改成清單上永遠篩得出來。
const rowFilter = ref<'' | 'unparsed' | 'expanded' | 'range'>('')

// 快速多選（2026-09-12 使用者）：機房×環境×用途各自可複選，同維度 OR、跨維度 AND，
// 讓「板橋+敦南的測試」「內湖的 DMZ」這種組合一鍵篩出來。空＝該維度不限。
const roomSel = ref<Set<string>>(new Set())
const envSel = ref<Set<string>>(new Set())
const useSel = ref<Set<string>>(new Set())
// ⚠️ 不能把 ref 當參數傳（template 會自動 unwrap 成 Set 本身，sel.value 就是 undefined、
// 點了沒反應）。改用維度名稱在函式內部取對應 ref。
function togSel(dim: 'room' | 'env' | 'use', v: string) {
  const sel = dim === 'room' ? roomSel : dim === 'env' ? envSel : useSel
  const s = new Set(sel.value)
  s.has(v) ? s.delete(v) : s.add(v)
  sel.value = s
}

const filtered = computed(() => {
  const needle = q.value.trim().toLowerCase()
  return rows.value.filter((r) => {
    if (roomSel.value.size && !roomSel.value.has(r.location ?? '')) return false
    if (envSel.value.size && !envSel.value.has(r.environment ?? '')) return false
    if (useSel.value.size && !useSel.value.has(r.usage ?? '')) return false
    if (scanFilter.value === 'include' && r.scan_excluded) return false
    if (scanFilter.value === 'exclude' && !r.scan_excluded) return false
    if (rowFilter.value === 'unparsed' && r.net_start !== null) return false
    if (rowFilter.value === 'expanded' && !r.expanded_from) return false
    if (rowFilter.value === 'range' && (r.cidr || r.net_start === null)) return false
    if (!needle) return true
    return [r.cidr, r.raw_cidr, r.purpose_desc, r.usage, r.category, r.scan_note,
      r.vlan, r.remark]
      .some((v) => String(v ?? '').toLowerCase().includes(needle))
  })
})
const { sortKey, sortDir, toggle, sorted } = useSort(filtered, 'cidr')

const locations = computed(() =>
  [...new Set(rows.value.map((r) => r.location).filter(Boolean))].sort() as string[],
)
const envOptions = computed(() =>
  [...new Set(rows.value.map((r) => r.environment).filter(Boolean))].sort() as string[])
const usageOptions = computed(() =>
  [...new Set(rows.value.map((r) => r.usage).filter(Boolean))].sort() as string[])
const stats = computed(() => ({
  total: rows.value.length,
  excluded: rows.value.filter((r) => r.scan_excluded).length,
  // 「無法解析」＝連起訖位址都算不出來（真的看不懂）。
  // 位址範圍寫法有 net_start，查得到「IP 屬於哪段」，不算無法解析——
  // 兩者混在一起會讓人以為問題比實際大。
  unparsed: rows.value.filter((r) => r.net_start === null).length,
  expanded: rows.value.filter((r) => r.expanded_from).length,
  rangeOnly: rows.value.filter((r) => !r.cidr && r.net_start !== null).length,
  assets: rows.value.reduce((n, r) => n + r.asset_count, 0),
}))

async function load() {
  loading.value = true
  try {
    rows.value = (await apiFetch<{ segments: Segment[] }>('/api/segments')).segments
  } finally {
    loading.value = false
  }
}
onMounted(load)

// 天條：數字要能下鑽。點「已登記幾台」就看得到是哪幾台、下一個可用 IP 是什麼
const openCidr = ref('')
const ipDetail = ref<{ used: UsedIp[]; suggestion: string | null; capacity: number } | null>(null)
const ipLoading = ref(false)
async function drill(r: Segment) {
  if (!r.cidr) return
  if (openCidr.value === r.cidr) { openCidr.value = ''; return }
  openCidr.value = r.cidr
  ipLoading.value = true
  ipDetail.value = null
  try {
    ipDetail.value = await apiFetch(`/api/segments/ips`, { query: { cidr: r.cidr } })
  } finally {
    ipLoading.value = false
  }
}

</script>

<template>
  <div>
    <div class="section-divider">資料治理</div>
    <div class="breadcrumb-bar"><span class="pin">📌</span> <b>網段配置表</b>
      <InfoNote>來源是公司的「總分公司網段配置表」Excel。<b>匯入是整批取代</b>——Excel 是這份清單的唯一真相，段被刪掉就該從系統消失；累加式匯入會讓作廢網段永遠留著，越用越髒。解析不掉的寫法（一格兩段、IP 範圍）<b>會保留並列出警告</b>，不會被靜默丟掉。</InfoNote>
    </div>

    <div class="card">
      <div class="bar-row">
        <!-- 匯入／匯出入口已移除（2026-09-12 使用者：匯入匯出已在資料匯入功能，這頁只做檢視／篩選／下鑽）。 -->
        <div class="stats">
          <span><b>{{ stats.total }}</b> 段</span>
          <span title="弱掃說明欄裡寫了「建議排除掃描」的網段數。這是資安人員的判斷（員工電腦、UAT、重複 IP 網段），不是系統猜的。">
            建議排除掃描 <b class="warn">{{ stats.excluded }}</b> 段
          </span>
          <span v-if="stats.expanded" title="原檔用「A/24----B/24」這種範圍寫法的格子，系統展開成一段一段。原檔並沒有這麼多列。">
            展開自原檔 <b>{{ stats.expanded }}</b> 段
          </span>
          <span v-if="stats.rangeOnly" title="位址範圍寫法（如 10.99.156.0/24~10.99.157.230）。查得到「IP 屬於哪段」，但不是單一 CIDR，不會出現在新增資產的網段選單。">
            範圍寫法 <b>{{ stats.rangeOnly }}</b> 段
          </span>
          <span v-if="stats.unparsed" title="連起訖位址都算不出來的格子（手寫中文、亂碼）。點下面的「無法解析」頁籤可以列出是哪幾筆。">
            無法解析 <b class="warn">{{ stats.unparsed }}</b> 段
          </span>
          <span>已登記資產 <b>{{ stats.assets }}</b></span>
        </div>
      </div>

    </div>

    <div class="card">
      <div class="filters">
        <input v-model="q" class="search" type="search" placeholder="搜尋網段、用途、說明…" />
        <!-- 快速多選：機房×環境×用途（同維度可複選=OR、跨維度=AND） -->
        <div class="qsel">
          <div class="qrow">
            <span class="qlbl">機房</span>
            <button v-for="l in locations" :key="l" class="chip" :class="{ on: roomSel.has(l) }" @click="togSel('room', l)">{{ l }}</button>
            <button v-if="roomSel.size" class="chip clr" @click="roomSel = new Set()">清除</button>
          </div>
          <div class="qrow">
            <span class="qlbl">環境</span>
            <button v-for="e in envOptions" :key="e" class="chip" :class="{ on: envSel.has(e) }" @click="togSel('env', e)">{{ e }}</button>
            <button v-if="envSel.size" class="chip clr" @click="envSel = new Set()">清除</button>
          </div>
          <div class="qrow" v-if="usageOptions.length">
            <span class="qlbl">用途</span>
            <button v-for="u in usageOptions" :key="u" class="chip" :class="{ on: useSel.has(u) }" @click="togSel('use', u)">{{ u }}</button>
            <button v-if="useSel.size" class="chip clr" @click="useSel = new Set()">清除</button>
          </div>
        </div>
        <div class="tabs">
          <button :class="{ on: scanFilter === '' }" @click="scanFilter = ''">全部</button>
          <button :class="{ on: scanFilter === 'include' }" @click="scanFilter = 'include'">可掃描</button>
          <button :class="{ on: scanFilter === 'exclude' }" @click="scanFilter = 'exclude'">建議排除</button>
        </div>
        <div class="tabs">
          <button :class="{ on: rowFilter === '' }" @click="rowFilter = ''">不限寫法</button>
          <button
            v-if="stats.unparsed" :class="{ on: rowFilter === 'unparsed' }"
            @click="rowFilter = 'unparsed'"
          >無法解析 {{ stats.unparsed }}</button>
          <button
            v-if="stats.rangeOnly" :class="{ on: rowFilter === 'range' }"
            @click="rowFilter = 'range'"
          >範圍寫法 {{ stats.rangeOnly }}</button>
          <button
            v-if="stats.expanded" :class="{ on: rowFilter === 'expanded' }"
            @click="rowFilter = 'expanded'"
          >展開自原檔 {{ stats.expanded }}</button>
        </div>
      </div>

      <p v-if="loading" class="muted">載入中…</p>
      <p v-else-if="rows.length === 0" class="muted">
        還沒有網段資料。到 <NuxtLink to="/import">6A-1 資料匯入</NuxtLink> 的「網段配置表」那一列上傳 Excel。
      </p>
      <div v-else class="tbl-wrap">
        <table>
          <thead>
            <tr>
              <SortTh k="cidr" :active="sortKey" :dir="sortDir" @sort="toggle">網段</SortTh>
              <SortTh k="location" :active="sortKey" :dir="sortDir" @sort="toggle">機房</SortTh>
              <SortTh k="environment" :active="sortKey" :dir="sortDir" @sort="toggle">環境</SortTh>
              <SortTh k="vlan" :active="sortKey" :dir="sortDir" @sort="toggle">VLAN</SortTh>
              <SortTh k="category" :active="sortKey" :dir="sortDir" @sort="toggle">類別</SortTh>
              <SortTh k="usage" :active="sortKey" :dir="sortDir" @sort="toggle">用途</SortTh>
              <SortTh k="purpose_desc" :active="sortKey" :dir="sortDir" @sort="toggle">說明</SortTh>
              <SortTh k="asset_count" :active="sortKey" :dir="sortDir" @sort="toggle">已登記</SortTh>
              <SortTh k="scan_excluded" :active="sortKey" :dir="sortDir" @sort="toggle">掃描</SortTh>
            </tr>
          </thead>
          <tbody>
            <template v-for="r in sorted" :key="r.id">
              <tr :class="{ clickable: !!r.cidr, on: openCidr === r.cidr }" @click="drill(r)">
                <td class="mono">
                  {{ r.cidr ?? r.raw_cidr }}
                  <div v-if="r.expanded_from" class="note">
                    展開自原檔第 {{ r.row_no }} 列的 <code>{{ r.expanded_from }}</code>
                  </div>
                  <div v-else-if="!r.cidr && r.net_start !== null" class="note">
                    位址範圍寫法：查得到「IP 屬於哪段」，但不是單一 CIDR，不會出現在網段選單
                  </div>
                  <div v-else-if="!r.cidr" class="note warn">
                    寫法無法解析，不能用於 IP 配置與掃描——請到原檔改成單一 CIDR
                  </div>
                </td>
                <td>{{ r.location ?? '—' }}</td>
                <td>
                  <span
                    v-if="r.environment" class="tag"
                    :class="r.environment === '測試' ? 'test' : 'prod'"
                  >{{ r.environment }}</span>
                  <!-- 認不出來的值不猜成正式（見 segments.derive_environment）。
                       畫面要顯示得出「他填了什麼」，不然人不知道要去改哪一格。 -->
                  <span
                    v-else class="tag unknown"
                    :title="r.environment_raw
                      ? `檔案填的是「${r.environment_raw}」，系統只認得 UAT／PROD`
                      : '這一段沒有環境資訊'"
                  >{{ r.environment_raw ? `？${r.environment_raw}` : '—' }}</span>
                </td>
                <td class="mono">{{ r.vlan ?? '—' }}</td>
                <td>{{ r.category ?? '—' }}</td>
                <td>{{ r.usage ?? '—' }}</td>
                <td>
                  {{ r.purpose_desc ?? '—' }}
                  <div v-if="r.remark" class="note remark">註解：{{ r.remark }}</div>
                  <div v-if="r.scan_note" class="note">{{ r.scan_note }}</div>
                </td>
                <td class="mono">
                  {{ r.asset_count }}<span v-if="r.capacity" class="cap">／{{ r.capacity }}</span>
                  <!-- 使用率條：已登記 ÷ 容量，一眼看出哪段快滿（>85% 轉紅） -->
                  <div v-if="r.capacity" class="usebar" :title="`使用率 ${Math.round(r.asset_count / r.capacity * 100)}%`">
                    <span :style="{ width: Math.min(100, Math.round(r.asset_count / r.capacity * 100)) + '%' }"
                          :class="{ hot: r.asset_count / r.capacity >= 0.85 }" />
                  </div>
                </td>
                <td>
                  <span v-if="r.scan_excluded" class="st ex">建議排除</span>
                  <span v-else class="st inc">可掃描</span>
                </td>
              </tr>
              <tr v-if="openCidr === r.cidr" class="drill">
                <td colspan="8">
                  <p v-if="ipLoading" class="muted">載入中…</p>
                  <template v-else-if="ipDetail">
                    <p class="rv-hint" style="margin:0 0 8px">
                      這段共 {{ ipDetail.capacity }} 個可用位址，清單裡已登記
                      <b>{{ ipDetail.used.length }}</b> 個。
                      建議下一個：<b class="mono">{{ ipDetail.suggestion ?? '沒有空位' }}</b>
                      <span class="caveat">（只代表這份清單沒登記，不代表實際上沒人在用）</span>
                    </p>
                    <div v-if="ipDetail.used.length" class="ip-chips">
                      <NuxtLink
                        v-for="u in ipDetail.used" :key="u.ip"
                        :to="`/assets/${u.asset_serial}`" class="ip-chip"
                      >
                        <b class="mono">{{ u.ip }}</b>
                        <span>{{ u.hostname ?? u.asset_serial }}</span>
                      </NuxtLink>
                    </div>
                    <p v-else class="muted">這段還沒有任何已登記的資產。</p>
                  </template>
                </td>
              </tr>
            </template>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<style scoped>
.import-result .diff { margin-top: 6px; padding: 6px 8px; border-radius: 6px;
  background: var(--good-soft); font-size: 12px; line-height: 1.7; }
.import-result .diff.danger { background: var(--bad-soft); }
.import-result .hint { color: var(--ink-aux); }
.import-result .good { color: var(--good); }
.import-result .bad { color: var(--bad); }
.removed-note { margin-top: 4px; }
.removed-list { margin-top: 3px; word-break: break-all; }
.removed-list code { margin-right: 6px; }
.tag.unknown { background: var(--warn-soft); color: var(--warn); }
.note.remark { color: var(--ink-aux); }
.section-divider { margin: 0 0 16px; font-size: 11px; color: var(--brand-dark);
  font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; }
.breadcrumb-bar { background: var(--mint); border: 1px solid var(--border-strong);
  padding: 8px 14px; font-size: 12.5px; color: var(--ink-soft); display: flex;
  align-items: center; gap: 8px; margin-bottom: 14px; }
.breadcrumb-bar b { color: var(--brand-dark); }
.card { border: 1px solid var(--border); background: var(--card); padding: 16px; margin-bottom: 16px; }
.rv-hint { font-size: 12px; color: var(--muted); line-height: 1.8; margin: 0 0 12px; }
.rv-hint b { color: var(--ink-soft); }
.bar-row { display: flex; align-items: center; gap: 16px; flex-wrap: wrap; }
.upload input { display: none; }
.btn { display: inline-block; font-size: 12.5px; font-weight: 700; padding: 8px 18px;
  background: var(--brand); color: #fff; cursor: pointer; border: none; border-radius: 10px;
  font-family: inherit; }
.btn:hover { background: var(--brand-dark); }
.btn:disabled { opacity: .6; cursor: not-allowed; }
/* 次要按鈕（範本下載這種不是主流程的動作）：跟主按鈕擺一起要看得出主副之分 */
.btn.ghost { background: var(--card); border: 1px solid var(--border-strong); color: var(--ink-soft); }
.btn.ghost:hover { background: var(--card); border-color: var(--brand); color: var(--brand-dark); }
.stats { display: flex; gap: 16px; font-size: 12px; color: var(--muted); flex-wrap: wrap; }
.stats b { color: var(--ink); }
.stats b.warn, .warn { color: var(--warn-text); }
.import-result { margin-top: 12px; border: 1px solid var(--border-strong);
  padding: 10px 14px; font-size: 12px; color: var(--ink-soft); line-height: 1.8; }
.warns { margin-top: 8px; }
.warns-hd { color: var(--warn-text); font-weight: 700; margin-bottom: 4px; }
.warn-row { font-size: 11.5px; color: var(--muted); line-height: 1.7; }
.warn-row code { color: var(--ink-soft); }
.filters { display: flex; gap: 10px; margin-bottom: 14px; flex-wrap: wrap; align-items: center; }
.search, .filters select { font-family: inherit; font-size: 12.5px; padding: 6px 10px;
  border: 1px solid var(--border-strong); background: var(--card); color: var(--ink); }
.search { min-width: 220px; }
.qsel { flex-basis: 100%; display: flex; flex-direction: column; gap: 6px; }
.qrow { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
.qlbl { font-size: 12px; color: var(--muted); min-width: 34px; }
.chip { font-family: inherit; font-size: 12px; padding: 4px 11px; cursor: pointer;
  border: 1px solid var(--border-strong); background: var(--card); color: var(--ink-aux); border-radius: 999px; }
.chip:hover { border-color: var(--brand); }
.chip.on { background: var(--mint); border-color: var(--brand); color: var(--brand-dark); font-weight: 600; }
.chip.clr { color: var(--muted); border-style: dashed; }
.tabs { display: flex; gap: 6px; }
.tabs button { font-family: inherit; font-size: 12px; padding: 6px 12px;
  border: 1px solid var(--border-strong); background: var(--card); color: var(--muted); cursor: pointer; }
.tabs button.on { border-color: var(--brand); color: var(--ink); }
.muted { color: var(--muted); font-size: 12.5px; }
.tbl-wrap { overflow-x: auto; border: 1px solid var(--border); }
table { border-collapse: collapse; width: 100%; font-size: 12.5px; min-width: 880px; }
th, td { text-align: left; padding: 8px 12px; border-bottom: 1px solid var(--border); vertical-align: top; }
th { color: var(--ink-soft); font-weight: 700; font-size: 12px; background: var(--mint); }
tr:last-child td { border-bottom: none; }
.clickable { cursor: pointer; }
.clickable:hover td { background: rgba(15,23,42,.03); }
.clickable.on td { background: rgba(0,145,66,.06); }
.drill td { background: rgba(0,0,0,.15); }
.mono { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }
.note { font-size: 10.5px; color: var(--muted); margin-top: 3px; line-height: 1.5; }
.cap { color: var(--muted); }
.usebar { margin-top: 3px; height: 4px; width: 60px; background: var(--border); border-radius: 3px; overflow: hidden; }
.usebar span { display: block; height: 100%; background: var(--brand); }
.usebar span.hot { background: var(--bad); }
.tag { font-size: 10.5px; padding: 2px 7px; border: 1px solid var(--border-strong); }
.tag.prod { border-color: var(--brand); color: var(--brand-dark); }
.tag.test { color: var(--muted); }
.st { font-size: 11.5px; white-space: nowrap; }
.st.ex { color: var(--warn-text); }
.st.inc { color: var(--brand-dark); }
.caveat { color: var(--muted); font-size: 11px; }
.ip-chips { display: flex; flex-wrap: wrap; gap: 6px; }
.ip-chip { display: flex; gap: 6px; align-items: baseline; text-decoration: none;
  border: 1px solid var(--border-strong); padding: 3px 8px; font-size: 11.5px; color: var(--muted); }
.ip-chip b { color: var(--ink); }
.ip-chip:hover { border-color: var(--brand); }
</style>
