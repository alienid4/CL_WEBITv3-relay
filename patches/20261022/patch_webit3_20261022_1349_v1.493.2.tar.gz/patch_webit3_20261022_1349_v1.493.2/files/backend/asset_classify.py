"""資產分類：平台（Windows/Linux/AIX…）與角色（DB／Web／主機…）。

兩個軸刻意分開，因為它們回答的是不同問題：
  平台 = 這台是什麼作業系統 → 決定「怎麼收它、誰維護它」
  角色 = 這台在做什麼         → 決定「它掛了誰受影響」

## 角色從「服務」推導，不是人填的欄位

一台機器是不是資料庫，看它有沒有在聽 3306/5432/1521——這是機器自己講的事實，
比人填的「資產用途」可靠得多（那欄常年沒人更新）。這也是 M2 服務盤點的複利：
先收到服務，資產分類就自動有了。

⚠️ 沒收過服務的機器角色是「未知」，不是「主機」——把「還沒查」講成「查過了是普通主機」
是在製造假確定性。畫面必須把這兩者分開顯示。
"""
from __future__ import annotations

import fleet_cache as _fleet_cache

# 角色判定用的監聽埠。一台機器可以同時是多個角色（跑 nginx 又跑 MySQL 很常見）。
ROLE_PORTS = {
    "db": {1433, 1521, 3306, 5432, 6379, 9200, 11211, 27017},
    "web": {80, 443, 3000, 8000, 8080, 8443, 9000},
    "middleware": {2181, 4369, 5672, 9092},          # 訊息佇列／協調服務
    "infra": {53, 123, 389, 636, 3268, 2049, 514},   # DNS/NTP/LDAP/NFS/Syslog
    "mgmt": {22, 3389, 5985, 5986, 623},             # 遠端管理通道
}

ROLE_LABELS = {
    "db": "資料庫",
    "web": "Web／應用",
    "middleware": "中介服務",
    "infra": "基礎服務",
    "mgmt": "僅管理通道",
    "unknown": "未知（未收過服務）",
}

# 只有管理通道（22/3389）的機器不該被叫成「Web／應用」也不該叫「普通主機」——
# 它就是「有開機、但沒看到在提供什麼服務」。這個區別在盤點時很有用：
# 那可能是閒置機器，也可能是收集權限不足，兩種都值得有人看一眼。
_SUBSTANTIVE = ("db", "web", "middleware", "infra")


def roles_by_ip(conn) -> dict[str, list[str]]:
    """每個 IP 目前在聽的服務 → 角色清單。只看還活著的服務（gone_at 為空）。"""
    out: dict[str, set] = {}
    try:
        rows = conn.execute(
            "SELECT ip, port FROM host_service WHERE gone_at IS NULL"
        ).fetchall()
    except Exception:  # noqa: BLE001 - 還沒建表（舊 DB）就是全部未知
        return {}
    for r in rows:
        ip, port = r["ip"], r["port"]
        bucket = out.setdefault(ip, set())
        for role, ports in ROLE_PORTS.items():
            if port in ports:
                bucket.add(role)
    result: dict[str, list[str]] = {}
    for ip, roles in out.items():
        substantive = [r for r in _SUBSTANTIVE if r in roles]
        # 有實質服務就不再標 mgmt——每台都有 SSH，標了等於沒標
        result[ip] = substantive or (["mgmt"] if "mgmt" in roles else [])
    return result


def role_of(conn_roles: dict[str, list[str]], ip: str | None) -> list[str]:
    """單台的角色。沒收過服務回 ['unknown']——不預設成「主機」，不製造假確定性。"""
    if not ip:
        return ["unknown"]
    return conn_roles.get(ip) or ["unknown"]


def platform_of_row(row, guesses: dict, conn=None) -> str:
    """單列資產的平台大類。沿用 manage_state 的判準，避免兩邊分岔成兩套規則。

    優先序：hardware.os（收到的真 OS，用 normalize_os() 那套判斷）> 掃描 os_guess
    （推測）> device_model 關鍵字（見 manage_state.platform_of_from_os()）。
    """
    import manage_state

    guess_os = guesses.get(row["ip"], (None, None))[0] if row["ip"] else None
    return manage_state.platform_of_from_os(row["os"], row["device_model"], conn, guess_os)


def scan_os_guesses(conn) -> dict:
    """最近一次掃描的 os_guess／mac_vendor，供平台判定退回使用。"""
    latest = conn.execute("SELECT MAX(scan_time) AS t FROM scan_history").fetchone()
    if not latest or not latest["t"]:
        return {}
    return {
        r["ip"]: (r["os_guess"], r["mac_vendor"])
        for r in conn.execute(
            "SELECT ip, os_guess, mac_vendor FROM scan_history "
            "WHERE scan_time = ? AND scan_ok = 1", (latest["t"],)
        )
    }


#: Linux 的細分（沿用原本平台判斷的發行版分類）
LINUX_DETAILS = ("RHEL", "CentOS", "Debian", "Oracle Linux", "Linux(其他)")


@_fleet_cache.cached   # 跨請求快取：資料庫沒變就不重算（fleet_cache）
def classify_all(conn) -> dict[str, dict]:
    """全部資產的 OS 類型（大類）＋ Linux 細分＋角色，key 是 asset_serial。

    2026-09-18 使用者：「我們平台不是還有，這部分是要對應嗎？」——資產查詢的「平台」
    跟漏斗的「OS 類型」是兩套規則（網路設備一邊 666 筆、一邊 581 台，還各有對方沒有的類）。
    改成兩層：
    - **os_type（大類）**＝漏斗那套 pipeline._os_type，並套用人工指定（os_override）——只有一套
    - **os_detail（細分）**＝只有 Linux 才有：原本平台判斷的發行版（RHEL／CentOS…）；
      原本判斷給不出發行版的歸「Linux(其他)」
    - platform 保留原值，給舊連結（?platform=）與相容用
    """
    import os_override
    import pipeline

    guesses = scan_os_guesses(conn)
    roles = roles_by_ip(conn)
    ov_map = os_override.active_map(conn)
    import collected_os
    measured = collected_os.measured_map(conn)
    out = {}
    for r in conn.execute(
        "SELECT asset_serial, ip, hostname, asset_name, os, device_model, group_name, asset_purpose FROM hardware"
    ).fetchall():
        m = measured.get(r["asset_serial"])
        out[r["asset_serial"]] = _classify_row(r, guesses, roles, ov_map, conn,
                                               m["platform"] if m else None, m)
    return out


def _classify_row(r, guesses, roles, ov_map, conn, collected: str | None = None,
                  measured: dict | None = None) -> dict:
    """單台的分類。classify_all 與 classify_one 共用——分類只有一套，
    不能因為「查一台」跟「查全部」走不同程式而給出不同答案。

    `collected`：已納管主機收集到的平台（collected_os.platform_map），
    優先序 人工指定 > 收集到的 OS > 資產登記 OS 欄（見 collected_os）。"""
    import collected_os
    import os_override
    import pipeline

    import os_class

    plat = platform_of_row(r, guesses, conn)
    guess_os = guesses.get(r["ip"], (None, None))[0] if r["ip"] else None
    auto = collected_os.apply_os_type(
        pipeline._os_type(r["os"], None, r["device_model"], (r["hostname"], r["asset_name"])),
        collected)
    os_type, ov = os_override.resolve(ov_map, r["hostname"], r["ip"], r["asset_serial"], auto)
    detail = None
    if os_type == pipeline.OS_LINUX:
        # Linux 細分（RHEL／CentOS…）：已納管主機用實測 OS 字樣判（CIA 寫 Windows、實測 RedHat
        # 的那台，細分要是 RHEL，不是「Linux(其他)」）。platform 欄不動（首頁平台長條／舊連結同一份）。
        d_plat = plat
        if measured and measured.get("platform") == "linux" and collected == "linux":
            import manage_state
            d_plat = manage_state.platform_of_from_os(measured.get("os"), r["device_model"], conn, None)
        detail = d_plat if d_plat in LINUX_DETAILS else "Linux(其他)"
    return {
        "platform": plat,
        # OS 大類（首頁平台長條同一支 classify、同樣吃掃描推測）——首頁點進來 ?os_class= 用這個
        "os_class": collected_os.apply_os_class(os_class.classify_row(r, guess_os), collected),
        # 這台的分類是不是靠收集到的 OS 判的（畫面可標「依收集」）
        "os_collected": collected,
        "os_type": os_type,
        "os_detail": detail,
        "roles": role_of(roles, r["ip"]),
        # 人工指定的話，os_type 已經是指定值；這兩欄讓畫面講得出
        # 「這是人搬的，機器本來判 X」——不分的話三個月後沒人知道為什麼是這類。
        "os_type_auto": auto,
        "os_type_override": ov,
    }


def classify_one(conn, asset_serial: str) -> dict | None:
    """單台的分類（資產明細頁用）。查不到回 None。"""
    import os_override

    r = conn.execute(
        "SELECT asset_serial, ip, hostname, asset_name, os, device_model, group_name, asset_purpose "
        "FROM hardware WHERE asset_serial = ?", (asset_serial,)).fetchone()
    if r is None:
        return None
    import collected_os
    m = collected_os.measured_map(conn).get(asset_serial)
    return _classify_row(r, scan_os_guesses(conn), roles_by_ip(conn),
                         os_override.active_map(conn), conn,
                         m["platform"] if m else None, m)
