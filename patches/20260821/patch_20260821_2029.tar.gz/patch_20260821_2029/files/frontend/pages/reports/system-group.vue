<script setup lang="ts">
// 系統組月報（2026-08-21）。使用者每月要把三張表貼進部門報告，原本是人工統計的。
// 他的原話：「以後我就 COPY 畫面，不用再自己統計」。
//
// 所以這一頁的成敗標準不是「數字算得出來」，是**他敢直接貼進報告**。那要求兩件事：
//   1. 版面要能直接複製（表格乾淨、不要有一堆只在畫面上有意義的裝飾）
//   2. 每個數字都要能追——他的第二個要求：「你每個數字我都要可以追」
//
// 第 2 點是這頁最重要的設計：**每一格數字都是連結**，點下去列出是哪幾台、
// 以及每一台為什麼被分到這一類（reason 欄）。後端加總與下鑽走同一份計算，
// 所以格子上的數字跟清單筆數必然一致——不一致的報表沒有人敢用。
definePageMeta({ ssr: false })

const { apiFetch } = useApi()
const { showToast } = useToast()

interface PlatformRow {
  platform: string; total: number
  已EOS: number; 一年內EOS: number; 需確認: number; 支援中: number
}
interface Report {
  meta: { generated_at: string; period: string | null
          rvtools_exported_at: string | null; rvtools_note: string }
  platform_lifecycle: {
    rows: PlatformRow[]; total: number
    excluded: { platform: string; count: number }[]
    excluded_total: number; retired_excluded: number
  }
  cluster_summary: {
    locations: { location: string; total: number
                 rows: { service: string; esxi_count: number }[] }[]
    basis: string; unmapped_vcenters: string[]
  }
  virtualization_env: {
    clusters: { location: string; vcenter: string; environment: string; cluster: string
                count: number; version: string | null; mixed_version: boolean
                eos_status: string | null; eos_date: string | null }[]
    physical_hosts: Record<string, any>[]
  }
  notes: Record<string, string>
}

const report = ref<Report | null>(null)
const loading = ref(true)
const STATUS_COLS = ['已EOS', '一年內EOS', '需確認', '支援中'] as const

async function load() {
  loading.value = true
  try {
    report.value = await apiFetch<Report>('/api/reports/system-group')
  } catch (err: any) {
    showToast(`報告載入失敗：${err?.data?.detail ?? err?.message ?? '請稍後再試'}`, 'error', 15000)
  } finally {
    loading.value = false
  }
}
onMounted(load)

// ---- 下鑽 ----
// 點任何一格數字都開這個面板。標題要講清楚「你點的是哪一格」，
// 否則列了 200 台出來，人會忘記自己在看什麼。
const drillOpen = ref(false)
const drillTitle = ref('')
const drillRows = ref<any[]>([])
const drillLoading = ref(false)
const drillKind = ref<'platform' | 'cluster'>('platform')

// Esc 關閉。點了十幾格之後，手不用離開鍵盤就能關掉。
function onEsc(e: KeyboardEvent) {
  if (e.key === 'Escape' && drillOpen.value) drillOpen.value = false
}
onMounted(() => document.addEventListener('keydown', onEsc))
onUnmounted(() => document.removeEventListener('keydown', onEsc))

// R2：版本欄要標EOS，跟表1同一套四態配色語彙，看的人不用再學一套新顏色。
function eosClass(status: string) {
  if (status === '已EOS') return 'eos-expired'
  if (status === '一年內EOS') return 'eos-upcoming'
  if (status === '支援中') return 'eos-ok'
  return 'eos-unknown'
}

async function drill(kind: 'platform' | 'cluster', title: string, query: Record<string, any>) {
  drillOpen.value = true
  drillKind.value = kind
  drillTitle.value = title
  drillLoading.value = true
  drillRows.value = []
  try {
    drillRows.value = await apiFetch<any[]>('/api/reports/system-group/drill', {
      query: { table: kind, ...query },
    })
  } catch (err: any) {
    showToast(`清單載入失敗：${err?.data?.detail ?? err?.message}`, 'error', 15000)
    drillOpen.value = false
  } finally {
    drillLoading.value = false
  }
}

// ---- 備註（可編輯，跨月保留）----
const editingKey = ref<string | null>(null)
const editingText = ref('')
function startEdit(key: string) {
  editingKey.value = key
  editingText.value = report.value?.notes?.[key] ?? ''
}
async function saveNote() {
  if (!editingKey.value) return
  const key = editingKey.value
  try {
    await apiFetch('/api/reports/system-group/note', {
      method: 'PUT', body: { row_key: key, note: editingText.value },
    })
    if (report.value) report.value.notes = { ...report.value.notes, [key]: editingText.value }
    editingKey.value = null
    showToast('備註已存，下個月開這頁還會在', 'success')
  } catch (err: any) {
    showToast(`備註存檔失敗：${err?.data?.detail ?? err?.message}`, 'error', 15000)
  }
}

// ---- 月份定稿 ----
const period = ref(new Date().toISOString().slice(0, 7))
const saving = ref(false)
async function saveSnapshot() {
  saving.value = true
  try {
    await apiFetch('/api/reports/system-group/snapshots', {
      method: 'POST', body: { period: period.value },
    })
    showToast(`${period.value} 已存檔。之後數字再變，這份不會跟著變`, 'success', 8000)
  } catch (err: any) {
    showToast(`存檔失敗：${err?.data?.detail ?? err?.message}`, 'error', 15000)
  } finally {
    saving.value = false
  }
}
</script>

<template>
  <div class="page">
    <div class="hd">
      <h1>系統組報告</h1>
      <div class="hdact">
        <input v-model="period" type="month" class="mon">
        <button class="btn" :disabled="saving" @click="saveSnapshot">
          {{ saving ? '存檔中…' : '存為本月定稿' }}
        </button>
        <button class="btn" @click="load">重新整理</button>
      </div>
    </div>

    <p v-if="loading" class="dim">載入中…</p>

    <template v-else-if="report">
      <!-- 資料新鮮度固定顯示、不給關。這一頁最大的風險不是算錯，是算得很精確
           但底層是三週前的快照，而看報告的人不知道。 -->
      <div class="fresh" :class="{ warn: !report.meta.rvtools_exported_at }">
        {{ report.meta.rvtools_note }}　·　產生於 {{ report.meta.generated_at }}
      </div>
      <p class="tip">每一個數字都可以點，會列出是哪幾台、以及為什麼被分到那一類。</p>

      <!-- ===== 表1 ===== -->
      <h2>平台數量與生命週期</h2>
      <table class="rt">
        <thead><tr>
          <th>平台類別</th><th>總量</th>
          <th v-for="s in STATUS_COLS" :key="s">{{ s }}</th>
          <th class="wide">備註說明</th>
        </tr></thead>
        <tbody>
          <tr v-for="r in report.platform_lifecycle.rows" :key="r.platform">
            <td class="rh">{{ r.platform }}</td>
            <td>
              <a v-if="r.total" class="n" @click="drill('platform', `${r.platform}（全部）`, { platform: r.platform })">{{ r.total }}</a>
              <span v-else class="z">·</span>
            </td>
            <td v-for="s in STATUS_COLS" :key="s">
              <a v-if="r[s]" class="n" @click="drill('platform', `${r.platform} ／ ${s}`, { platform: r.platform, status: s })">{{ r[s] }}</a>
              <span v-else class="z">·</span>
            </td>
            <td class="wide">
              <template v-if="editingKey === `platform:${r.platform}`">
                <input v-model="editingText" class="ni" @keyup.enter="saveNote">
                <button class="mini" @click="saveNote">存</button>
                <button class="mini" @click="editingKey = null">取消</button>
              </template>
              <span v-else class="note" @click="startEdit(`platform:${r.platform}`)">
                {{ report.notes[`platform:${r.platform}`] || '＋ 加備註' }}
              </span>
            </td>
          </tr>
          <tr class="sum">
            <td class="rh">合計</td><td>{{ report.platform_lifecycle.total }}</td>
            <td :colspan="STATUS_COLS.length + 1" class="dim">
              本表不含：
              <a v-for="e in report.platform_lifecycle.excluded" :key="e.platform" class="n ex"
                 @click="drill('platform', `不列入本報告：${e.platform}`, { bucket: e.platform })">
                {{ e.platform }} {{ e.count }}
              </a>
              <span>　共 {{ report.platform_lifecycle.excluded_total }} 台（網路設備歸網路組統計）；</span>
              <a class="n ex" @click="drill('platform', '已退役（不列入）', { retired: true })">
                另有退役 {{ report.platform_lifecycle.retired_excluded }} 台
              </a>
            </td>
          </tr>
        </tbody>
      </table>

      <!-- ===== 表2 ===== -->
      <h2>叢集分類與 ESXi 數量</h2>
      <p class="basis">※ {{ report.cluster_summary.basis }}</p>
      <p v-if="report.cluster_summary.unmapped_vcenters.length" class="warnline">
        ⚠ 有 vCenter 對不到機房：{{ report.cluster_summary.unmapped_vcenters.join('、') }}
        —— 請在 report_groups.json 補上，否則這批 ESXi 會歸在「未對應」
      </p>
      <div class="locwrap">
        <div v-for="loc in report.cluster_summary.locations" :key="loc.location" class="locbox">
          <div class="locname">{{ loc.location }}</div>
          <table class="rt small">
            <thead><tr><th>叢集分類</th><th>ESXi 數量</th></tr></thead>
            <tbody>
              <tr v-for="r in loc.rows" :key="r.service">
                <td class="rh">{{ r.service }}</td>
                <td>
                  <a class="n" @click="drill('cluster', `${loc.location} ／ ${r.service}`, { location: loc.location, service: r.service })">{{ r.esxi_count }}</a>
                </td>
              </tr>
              <tr class="sum"><td class="rh">合計</td><td>{{ loc.total }}</td></tr>
            </tbody>
          </table>
        </div>
      </div>

      <!-- ===== 表3 ===== -->
      <h2>虛擬化與 AIX、IBM i 環境資訊</h2>
      <table class="rt">
        <thead><tr>
          <th>Location</th><th>vCenter IP</th><th>環境</th><th>Cluster</th><th>臺數</th><th>版本</th>
        </tr></thead>
        <tbody>
          <tr v-for="c in report.virtualization_env.clusters" :key="c.vcenter + c.cluster + c.version">
            <td class="rh">{{ c.location }}</td>
            <td class="mono">{{ c.vcenter }}</td>
            <td>{{ c.environment }}</td>
            <td>{{ c.cluster || '（未歸叢集）' }}</td>
            <td>
              <!-- R2：混版拆成一叢集多列，每列各自算自己的臺數，下鑽要帶 version
                   才會對到剛好這幾台（2026-08-21 backlog，跟表1「可追」同一原則）。 -->
              <a class="n" @click="drill('cluster', `${c.cluster} 的 ESXi（${c.version || '版本未知'}）`, { vcenter: c.vcenter, cluster: c.cluster, version: c.version })">{{ c.count }}</a>
            </td>
            <td :class="{ mixed: c.mixed_version }">
              {{ c.version || '—' }}<span v-if="c.mixed_version" class="mixtag">混版</span>
              <span v-if="c.eos_status" class="eosb" :class="eosClass(c.eos_status)">
                {{ c.eos_status }}<span v-if="c.eos_date"> {{ c.eos_date }}</span>
              </span>
            </td>
          </tr>
        </tbody>
      </table>

      <h3>實體主機（AIX／IBM i）</h3>
      <table class="rt">
        <thead><tr>
          <th>Location</th><th>IP</th><th>環境</th><th>服務</th><th>作業系統</th>
        </tr></thead>
        <tbody>
          <tr v-for="h in report.virtualization_env.physical_hosts" :key="h.ip + h.hostname">
            <td class="rh">{{ h.physical_location || '未填' }}</td>
            <td class="mono">{{ h.ip }}</td>
            <td>{{ h.environment || '未填' }}</td>
            <td>{{ h.asset_name || h.hostname }}</td>
            <td>{{ h.os }}</td>
          </tr>
          <tr v-if="!report.virtualization_env.physical_hosts.length">
            <td colspan="5" class="dim">無</td>
          </tr>
        </tbody>
      </table>
    </template>

    <!-- ===== 下鑽面板 ===== -->
    <!-- 遮罩：讓面板真的浮在最上層，也讓人點旁邊就能關掉 -->
    <div v-if="drillOpen" class="drillmask" @click="drillOpen = false" />
    <div v-if="drillOpen" class="drill">
      <div class="dhd">
        <b>{{ drillTitle }}</b>
        <span class="dim">　{{ drillRows.length }} 筆</span>
        <button class="mini" @click="drillOpen = false">關閉</button>
      </div>
      <p v-if="drillLoading" class="dim">載入中…</p>
      <div v-else class="dwrap">
        <table class="rt small">
          <thead v-if="drillKind === 'platform'"><tr>
            <th>主機名</th><th>IP</th><th>OS 原始值</th><th>正規化</th><th>EOS</th><th>判定依據</th>
          </tr></thead>
          <thead v-else><tr>
            <th>ESXi</th><th>Cluster</th><th>vCenter</th><th>版本</th><th>判定依據</th>
          </tr></thead>
          <tbody v-if="drillKind === 'platform'">
            <tr v-for="r in drillRows" :key="r.asset_serial">
              <td class="rh">{{ r.hostname || r.asset_serial }}</td>
              <td class="mono">{{ r.ip }}</td>
              <td>{{ r.os_raw || '（空）' }}</td>
              <td>{{ r.os_canonical || '認不出' }}</td>
              <td>{{ r.eos_date || r.eos_status }}</td>
              <td class="dim">{{ r.reason }}</td>
            </tr>
          </tbody>
          <tbody v-else>
            <tr v-for="r in drillRows" :key="r.host + r.cluster">
              <td class="rh mono">{{ r.host }}</td>
              <td>{{ r.cluster }}</td>
              <td class="mono">{{ r.vcenter }}</td>
              <td>{{ r.version }}</td>
              <td class="dim">{{ r.reason }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<style scoped>
.page { padding: 18px 22px 60px; }
.hd { display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px; }
h1 { font-size: 19px; margin: 0; }
h2 { font-size: 15px; margin: 26px 0 8px; }
h3 { font-size: 13px; margin: 18px 0 6px; color: var(--ink-soft); }
.hdact { display: flex; gap: 8px; align-items: center; }
.mon { padding: 6px 10px; border-radius: 5px; border: 1px solid var(--border-strong);
       background: var(--card); color: var(--ink); }
.btn { padding: 6px 12px; border-radius: 5px; border: 1px solid var(--border-strong);
       background: var(--card); color: var(--ink); cursor: pointer; }
.btn:hover { border-color: var(--brand); }

/* 資料新鮮度：固定顯示、不可關 */
.fresh { margin: 12px 0 4px; padding: 7px 11px; border-radius: 5px; font-size: 12px;
         background: rgba(47,214,172,.08); color: #7fa89b;
         border: 1px solid rgba(47,214,172,.2); }
.fresh.warn { background: rgba(224,176,96,.1); color: #e0b060;
              border-color: rgba(224,176,96,.35); }
.tip { font-size: 11px; color: var(--ink-soft); margin: 4px 0 0; }
.basis { font-size: 11px; color: var(--ink-soft); margin: 0 0 6px; }
.warnline { font-size: 12px; color: #e0b060; margin: 0 0 8px; }

/* 表格刻意樸素：這些是要被整塊複製貼進 Word/PPT 的，
   花俏的底色與陰影貼過去只會變成一堆雜訊。 */
.rt { border-collapse: collapse; font-size: 12.5px; }
.rt th, .rt td { border: 1px solid var(--border); padding: 5px 11px; text-align: right; }
.rt th { background: rgba(255,255,255,.04); color: var(--ink-soft); font-weight: 600; font-size: 11.5px; }
.rt .rh, .rt th:first-child { text-align: left; }
.rt .wide { text-align: left; min-width: 240px; }
.rt.small { font-size: 11.5px; }
.rt .sum td { background: rgba(255,255,255,.03); font-weight: 600; }
.mono { font-family: ui-monospace, monospace; }
.z { color: #4a5a55; }
.dim { color: var(--ink-soft); }

/* 每個數字都是連結——這是「可追」的入口 */
.n { color: #4fe3c0; cursor: pointer; text-decoration: none; }
.n:hover { text-decoration: underline; }
.n.ex { margin-right: 10px; }

.note { cursor: pointer; color: var(--ink-soft); font-size: 11.5px; }
.note:hover { color: var(--ink); }
.ni { padding: 3px 7px; border-radius: 4px; border: 1px solid var(--border-strong);
      background: var(--card); color: var(--ink); min-width: 200px; font-size: 11.5px; }
.mini { margin-left: 5px; padding: 2px 8px; font-size: 11px; border-radius: 4px;
        border: 1px solid var(--border-strong); background: var(--card);
        color: var(--ink); cursor: pointer; }

.locwrap { display: flex; gap: 18px; flex-wrap: wrap; }
.locname { font-size: 12px; color: var(--ink-soft); margin-bottom: 4px; }
.mixed { color: #e0b060; }
.mixtag { font-size: 10px; margin-left: 5px; padding: 1px 5px; border-radius: 3px;
          background: rgba(224,176,96,.16); }

.eosb { display: inline-block; font-size: 10px; margin-left: 6px; padding: 1px 6px;
        border-radius: 3px; white-space: nowrap; }
.eos-expired { color: #ff6b6b; background: rgba(255,107,107,.14); }
.eos-upcoming { color: #e0b060; background: rgba(224,176,96,.16); }
.eos-ok { color: #4fe3c0; background: rgba(47,214,172,.14); }
.eos-unknown { color: var(--ink-soft); background: rgba(255,255,255,.06); }

/* 下鑽面板：固定在底部浮在最上層。
   ⚠️ 底色一定要用 --card-solid（實心 #101c19），不可以用 --card——後者是
   rgba(255,255,255,.04) 的「玻璃卡」，設計上是要疊在頁面底色之上的，
   拿來當浮動面板等於 96% 透明，底下整頁的文字會透出來疊在一起完全看不懂
   （2026-08-21 使用者截圖回報「點選 AIX/IBM i 畫面很亂」，就是這個）。 */
.drillmask { position: fixed; inset: 0; background: rgba(0,0,0,.45); z-index: 39; }
.drill { position: fixed; left: 0; right: 0; bottom: 0; max-height: 60vh;
         background: var(--card-solid); border-top: 2px solid var(--brand);
         box-shadow: 0 -6px 22px rgba(0,0,0,.6); display: flex; flex-direction: column; z-index: 40; }
.dhd { padding: 9px 14px; border-bottom: 1px solid var(--border-strong); font-size: 13px;
       display: flex; align-items: center; background: var(--card-solid);
       position: sticky; top: 0; }
.dhd .mini { margin-left: auto; }
.dwrap { overflow: auto; padding: 8px 14px 14px; background: var(--card-solid); }
/* 清單也用實心底，並讓表頭在捲動時黏住——200 台捲到一半就忘記哪欄是哪欄 */
.dwrap .rt { background: var(--card-solid); width: 100%; }
.dwrap .rt thead th { position: sticky; top: 0; background: #16241f; z-index: 1; }
/* 判定依據那欄字多，給它換行不要撐爆表格 */
.dwrap .rt td:last-child { white-space: normal; min-width: 260px; max-width: 480px; }
</style>
