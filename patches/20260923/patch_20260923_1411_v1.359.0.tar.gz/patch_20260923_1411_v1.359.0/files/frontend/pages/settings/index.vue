<script setup lang="ts">
// S10：系統設定頁-連線設定分頁。D14/D15：帳密與連線目標合併同一表格，行內編輯。
// 密碼write-only：後端從不回傳密碼內容，這裡的密碼輸入框永遠是空的，填了才代表要覆蓋。
// S11：架構圖分頁，資料來源是同一份connections清單（不是另外造假資料），依last_status
// 畫綠/紅/灰邊線，跟連線設定分頁「同一份真相」，改一邊另一邊自動同步。
interface ConnectionRow {
  id: number
  name: string
  connection_type: string | null
  target: string
  port: number | null
  username: string | null
  has_password: boolean
  last_status: string
  last_tested_at: string | null
  enabled?: number
  scan_time?: string | null   // 這個網段自己的每日排程時間；空＝跟全域排程一起掃
}

const { apiFetch } = useApi()
const runtimeConfig = useRuntimeConfig()
const route = useRoute()
const { flags, isEnabled, ensureLoaded: ensureFlagsLoaded, setEnabled } = useFeatureFlags()

const { showToast } = useToast()
// 可以用 ?tab=backup 直接開到某一分頁——側邊選單的「備份與還原」靠這個進來
// （2026-09-09 使用者：「備份應該拉出到『資料匯入』項目當中」）。
// 不做成獨立頁面的理由：備份的內容與這頁其他分頁共用同一批狀態與樣式，
// 拆頁會多一份重複的程式；但**選單上要看得到**，因為它是常用動作，
// 藏在「系統設定」裡等於沒有。
const _TABS = ['connections', 'diagram', 'modules', 'schedule',
               'backup', 'credentials', 'autoonboard', 'mail'] as const
const _q = String(route.query.tab || '')
const initialTab = (_TABS as readonly string[]).includes(_q)
  ? (_q as typeof _TABS[number])
  : (route.query.disabled ? 'modules' : 'connections')
const activeTab = ref<'connections' | 'diagram' | 'modules' | 'schedule' | 'backup' | 'credentials' | 'autoonboard' | 'mail'>(initialTab)
// 2026-09-09 使用者定案：從側邊選單「備份與還原」(?tab=backup) 進來時，
// 這頁只是備份頁——不要露出連線設定/架構圖/功能模組/憑證/自動納管/掃描排程那排頁籤
// （那些留在「系統設定」）。備份不另開一支檔（會複製一份備份邏輯與狀態），
// 改用這個旗標把同一頁「窄化」成純備份頁。
const backupOnly = computed(() => activeTab.value === 'backup')
const connections = ref<ConnectionRow[]>([])
// 天條：表格每欄可排。useSort 回傳的是同一批物件的新陣列，
// 所以連線那張表的 v-model 編輯照樣綁得到原物件，排序不會弄丟使用者正在改的內容。
const { sortKey: cnKey, sortDir: cnDir, toggle: cnToggle, sorted: connectionsSorted } =
  useSort(connections, 'name')
const { sortKey: fgKey, sortDir: fgDir, toggle: fgToggle, sorted: flagsSorted } =
  useSort(flags, 'label')
const drafts = reactive<Record<number, { password: string }>>({})

// ===== 收集用憑證（Windows WinRM 服務帳號等）=====
// ⚠️ 密碼只在送出那一次存在於前端，送完立刻清空；後端加密後才進 DB，
// 回應永不含密碼（連密文都不給）。
interface CredRow {
  id: number; name: string; kind: string; username: string
  scope: string | null; note: string | null; updated_at: string; has_secret: boolean
}
const creds = ref<CredRow[]>([])
const newCred = reactive({ name: '', kind: 'winrm', username: '', password: '', scope: '', note: '' })
const savingCred = ref(false)

async function loadCreds() {
  try { creds.value = await apiFetch<CredRow[]>('/api/credentials') }
  catch (e: any) { creds.value = []; showToast(`憑證庫載入失敗：${e?.data?.detail ?? e?.message ?? '未知錯誤'}`, 'error') }
}
async function saveCred() {
  if (!newCred.name || !newCred.username || !newCred.password) {
    showToast('名稱、帳號、密碼都要填', 'warn'); return
  }
  savingCred.value = true
  try {
    await apiFetch('/api/credentials', { method: 'POST', body: { ...newCred } })
    newCred.password = ''          // 用完立刻從前端清掉
    showToast(`已儲存憑證「${newCred.name}」`, 'success')
    newCred.name = ''; newCred.username = ''; newCred.scope = ''; newCred.note = ''
    await loadCreds()
  } catch (err: any) {
    showToast(`儲存失敗：${err?.data?.detail ?? '請稍後重試'}`, 'error')
  } finally {
    newCred.password = ''
    savingCred.value = false
  }
}
async function delCred(name: string) {
  try {
    await apiFetch(`/api/credentials/${encodeURIComponent(name)}`, { method: 'DELETE' })
    showToast(`已刪除「${name}」`, 'success')
    await loadCreds()
  } catch { showToast('刪除失敗', 'error') }
}
watch(activeTab, (t) => { if (t === 'credentials' && !creds.value.length) loadCreds() })

// ===== 收集金鑰（Linux 用的 SSH 私鑰）=====
// Linux 走金鑰、Windows 走帳密，兩個都是「收集用的身分」，放同一頁。
//
// 這頁最重要的數字是 onboarded_hosts——換金鑰會讓那些主機的收集**當場失效**
// （它們 authorized_keys 裡是舊公鑰）。沒有那個數字，換金鑰看起來只是改設定。
interface CollectorKeyStatus {
  has_key: boolean
  path: string
  fingerprint: string | null
  public_key: string | null
  modified_at: string | null
  onboarded_hosts: number
  last_import: string | null
}
const ckStatus = ref<CollectorKeyStatus | null>(null)
const ckMode = ref<'paste' | 'path'>('path')   // 預設走「不過網路」那條
const ckPrivate = ref('')
const ckPath = ref('')
const ckConfirm = ref('')
const ckBusy = ref(false)
const ckResult = ref<any>(null)

async function loadCollectorKey() {
  try {
    ckStatus.value = await apiFetch<CollectorKeyStatus>('/api/collector-key')
  } catch { /* 讀不到就不顯示，不擋整頁 */ }
}
watch(activeTab, (t) => { if (t === 'credentials' && !ckStatus.value) loadCollectorKey() })

// ===== 停用登入（測試用）=====
// 使用者 2026-09-10：「我現在測試階段，用不到登入。」
// ⚠️ 這是關掉存取控制，所以：打開要打字確認、關掉不用——**讓安全的方向比較好走**。
// 只有已登入的人打得開（後端掛了 require_auth）；不然就變成「未登入的人自己
// 把登入關掉」，那是後門不是開關。
const authOff = ref<{ disabled: boolean; by_env: boolean; env_name: string } | null>(null)
const authOffConfirm = ref('')
const authOffBusy = ref(false)

async function loadAuthOff() {
  try {
    authOff.value = await apiFetch<any>('/api/admin/auth-disabled')
  } catch { /* 讀不到就不顯示，不擋整頁 */ }
}
watch(activeTab, (t) => { if (t === 'modules' && !authOff.value) loadAuthOff() })

async function setAuthOff(enabled: boolean) {
  authOffBusy.value = true
  try {
    await apiFetch<any>('/api/admin/auth-disabled', {
      method: 'PUT',
      body: { enabled, confirm: enabled ? authOffConfirm.value : undefined },
    })
    authOffConfirm.value = ''
    await loadAuthOff()
    showToast(enabled ? '登入已停用——請記得測試完關回來' : '登入已恢復',
              enabled ? 'warn' : 'success', 10000)
    // 重新整理才會套用（守衛與橫幅都在載入時判斷）
    setTimeout(() => window.location.reload(), 800)
  } catch (e: any) {
    showToast(e?.data?.detail || '設定失敗', 'error', 8000)
  } finally {
    authOffBusy.value = false
  }
}

const ckReady = computed(() =>
  !ckBusy.value && ckConfirm.value === 'REPLACE'
  && (ckMode.value === 'paste' ? !!ckPrivate.value.trim() : !!ckPath.value.trim()))

async function importCollectorKey() {
  if (!ckReady.value) return
  ckBusy.value = true
  ckResult.value = null
  try {
    const body: any = { confirm: ckConfirm.value }
    if (ckMode.value === 'paste') body.private_key = ckPrivate.value
    else body.from_path = ckPath.value.trim()
    ckResult.value = await apiFetch<any>('/api/collector-key/import',
                                         { method: 'POST', body })
    // 私鑰用完就從畫面清掉，不要留在輸入框裡等人截圖
    ckPrivate.value = ''
    ckConfirm.value = ''
    await loadCollectorKey()
    showToast(ckResult.value.changed ? '金鑰已更換' : '指紋相同——就是同一把金鑰',
              ckResult.value.changed ? 'warn' : 'success', 10000)
  } catch (e: any) {
    showToast(e?.data?.detail || '匯入失敗', 'error', 10000)
  } finally {
    ckBusy.value = false
  }
}

// ===== B：排程自動納管 =====
// 安全閘門是「授權網段」——排程只碰列在這裡且啟用的網段前綴。總開關預設關閉，
// 開了也只碰授權網段內、已登記卻未納管的主機（Linux 用庫裡 ssh 憑證跑 bootstrap，
// Windows 走 WinRM 收集不跑 bootstrap）。
interface SegRow {
  id: number; prefix: string; enabled: number; note: string | null
  created_at: string; updated_at: string
}
interface AutoAuditRow {
  target_ip: string; platform: string | null; login_user: string | null
  ok: number; stage: string | null; message: string | null; created_at: string
}
const aoEnabled = ref(false)
const aoSegments = ref<SegRow[]>([])
const aoRecent = ref<AutoAuditRow[]>([])
const newSeg = reactive({ prefix: '', note: '' })
const aoLoading = ref(false)
const aoSavingSeg = ref(false)
const aoTogglingEnabled = ref(false)
const aoTogglingSeg = ref<number | null>(null)
const aoRunning = ref(false)
const aoRunResult = ref<any>(null)
// 天條：兩張表都要可排
const { sortKey: segKey, sortDir: segDir, toggle: segToggle, sorted: segSorted } =
  useSort(aoSegments, 'prefix')
const { sortKey: aaKey, sortDir: aaDir, toggle: aaToggle, sorted: aoRecentSorted } =
  useSort(aoRecent, 'created_at')

async function loadAutoOnboard() {
  aoLoading.value = true
  try {
    const r = await apiFetch<{ enabled: boolean; segments: SegRow[]; recent: AutoAuditRow[] }>('/api/auto-onboard')
    aoEnabled.value = r.enabled
    aoSegments.value = r.segments
    aoRecent.value = r.recent
  } catch {
    showToast('自動納管設定載入失敗', 'error')
  } finally {
    aoLoading.value = false
  }
}
async function toggleAutoOnboardEnabled() {
  aoTogglingEnabled.value = true
  const next = !aoEnabled.value
  try {
    const r = await apiFetch<{ enabled: boolean }>('/api/auto-onboard/enabled', {
      method: 'PATCH', body: { enabled: next },
    })
    aoEnabled.value = r.enabled
    showToast(next ? '已啟用排程自動納管' : '已關閉排程自動納管', 'success')
  } catch (err: any) {
    showToast(`切換失敗：${err?.data?.detail ?? '請稍後重試'}`, 'error')
  } finally {
    aoTogglingEnabled.value = false
  }
}
async function saveSeg() {
  if (!newSeg.prefix.trim()) { showToast('網段前綴要填，如 192.168.1.', 'warn'); return }
  aoSavingSeg.value = true
  try {
    const r = await apiFetch<{ segments: SegRow[] }>('/api/auto-onboard/segments', {
      method: 'POST', body: { prefix: newSeg.prefix.trim(), enabled: true, note: newSeg.note || null },
    })
    aoSegments.value = r.segments
    showToast(`已授權網段「${newSeg.prefix.trim()}」`, 'success')
    newSeg.prefix = ''; newSeg.note = ''
  } catch (err: any) {
    showToast(`儲存失敗：${err?.data?.detail ?? '請稍後重試'}`, 'error')
  } finally {
    aoSavingSeg.value = false
  }
}
async function toggleSeg(row: SegRow) {
  aoTogglingSeg.value = row.id
  const next = row.enabled === 0
  try {
    const r = await apiFetch<{ segments: SegRow[] }>(`/api/auto-onboard/segments/${row.id}/enabled`, {
      method: 'PATCH', body: { enabled: next },
    })
    aoSegments.value = r.segments
  } catch (err: any) {
    showToast(`切換失敗：${err?.data?.detail ?? '請稍後重試'}`, 'error')
  } finally {
    aoTogglingSeg.value = null
  }
}
async function delSeg(row: SegRow) {
  try {
    const r = await apiFetch<{ segments: SegRow[] }>(`/api/auto-onboard/segments/${row.id}`, { method: 'DELETE' })
    aoSegments.value = r.segments
    showToast(`已移除授權網段「${row.prefix}」`, 'success')
  } catch { showToast('移除失敗', 'error') }
}
async function runAutoOnboardNow() {
  aoRunning.value = true
  aoRunResult.value = null
  try {
    const r = await apiFetch<any>('/api/auto-onboard/run', { method: 'POST' })
    aoRunResult.value = r
    const msg = `候選 ${r.candidates}｜納管 ${r.onboarded}｜失敗 ${r.failed}｜跳過 ${r.skipped}`
    showToast(`執行完成 · ${msg}`, r.failed ? 'warn' : 'success')
    await loadAutoOnboard()   // 稽核與狀態刷新
  } catch (err: any) {
    showToast(`執行失敗：${err?.data?.detail ?? '請稍後重試'}`, 'error')
  } finally {
    aoRunning.value = false
  }
}
watch(activeTab, (t) => { if (t === 'autoonboard' && !aoSegments.value.length && !aoLoading.value) loadAutoOnboard() })

// VC 自動匯入（方案 B：檔案中繼）整塊已搬到 components/VcenterAutoImport.vue，
// 掛在「資料匯入」頁的 RVTools 手動上傳旁邊——那兩個本來就是同一條管線的兩種觸發方式。

const newRow = reactive({ name: '', connection_type: '', target: '', port: '', username: '', password: '' })
const errorMessage = ref('')
const savingId = ref<number | 'new' | null>(null)
const testingId = ref<number | null>(null)
const deletingId = ref<number | null>(null)
const togglingKey = ref<string | null>(null)
const togglingConn = ref<number | null>(null)

/** 來源啟用／停用。停用＝排程掃描跳過，不會被算成「掃描失敗」。
 *  有些來源現階段本來就連不到（CMDB Gateway 在家碰不到公司內網），沒有開關的話
 *  它每次都失敗、每次點亮「掃描不完整」——常態假警報會讓真正的問題沒人看見。 */
async function toggleConnection(row: ConnectionRow) {
  togglingConn.value = row.id
  const next = row.enabled === 0
  try {
    await apiFetch(`/api/connections/${row.id}/enabled`, { method: 'PATCH', body: { enabled: next } })
    row.enabled = next ? 1 : 0
    showToast(`「${row.name}」已${next ? '啟用' : '停用'}`, 'success')
  } catch (err: any) {
    showToast(`切換失敗：${err?.data?.detail ?? '請稍後重試'}`, 'error')
  } finally {
    togglingConn.value = null
  }
}

interface Schedule {
  enabled: boolean
  mode: string
  time: string
  interval_hours: number
  weekday?: number          // weekly 用：0=週一 … 6=週日
  weekday_label?: string
}
const WEEKDAYS = ['週一', '週二', '週三', '週四', '週五', '週六', '週日']
const schedule = reactive<Schedule>({ enabled: true, mode: 'daily', time: '01:00',
                                     interval_hours: 6, weekday: 6 })
const savingSchedule = ref(false)

// ===== S14 備份與健康 =====
// 目的：工程師/助理不用進命令列就能看狀態、手動備份。
// 燈號不是「有沒有跑過備份」，後端會實際開檔跑 integrity_check——
// 「檔案在但內容是壞的」才是最危險的情況，只看檔案存在的儀表板會顯示綠燈。
interface BackupHealth {
  status: 'green' | 'yellow' | 'red'
  reasons: string[]
  checked_at: string
  db: {
    path: string; exists: boolean; integrity_ok: boolean
    integrity_detail: string; journal_mode: string | null; size_bytes: number
  }
  last_backup: {
    name: string; size_bytes: number; modified_at: string
    age_hours: number | null; integrity_ok: boolean | null; integrity_detail: string
  } | null
  local: { dir: string; count: number; free_mb: number | null; retention_days: number }
  offsite: { configured: boolean; dir: string | null; count: number }
}

const backupHealth = ref<BackupHealth | null>(null)
const backupLoading = ref(false)
const backupRunning = ref(false)
const backupError = ref('')

const LAMP_LABEL: Record<string, string> = {
  green: '正常', yellow: '需要注意', red: '有問題',
}

function fmtBytes(n: number | null | undefined) {
  if (!n && n !== 0) return '—'
  if (n < 1024) return `${n} B`
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`
  return `${(n / 1024 / 1024).toFixed(1)} MB`
}

async function loadBackupHealth() {
  backupLoading.value = true
  backupError.value = ''
  try {
    backupHealth.value = await apiFetch<BackupHealth>('/api/backup/status')
  } catch (err: any) {
    backupError.value = err?.data?.detail ?? '備份狀態載入失敗，請稍後再試'
  } finally {
    backupLoading.value = false
  }
}

// ===== 加密匯出的金鑰（決策 SEC5）=====
// 匯出檔會離開這台機器（下載→email），裡面有全公司主機清單、IP、帳號名。
// 所以一律加密，只有持私鑰的收件端（221）解得開。
// 公鑰不需要保密——它只能加密不能解密，所以整個流程不用傳任何秘密。
interface ExportKeyStatus {
  is_recipient: boolean
  private_key_path: string
  my_public_key: string | null
  my_fingerprint: string | null
  recipient_fingerprint: string | null
  encryption_enabled?: boolean
  can_export: boolean
}
const keyStatus = ref<ExportKeyStatus | null>(null)
const recipientInput = ref('')
const keyBusy = ref(false)

async function toggleEncryption(on: boolean) {
  keyBusy.value = true
  try {
    await apiFetch('/api/export-key/encryption', { method: 'PUT', body: { enabled: on } })
    showToast(on ? '匯出時加密：已開啟（需設定收件人公鑰）' : '匯出時加密：已關閉', 'success')
    await loadKeyStatus()
  } catch (err: any) {
    showToast(`切換失敗：${err?.data?.detail ?? err?.message ?? err}`, 'error')
  } finally {
    keyBusy.value = false
  }
}

async function loadKeyStatus() {
  try {
    keyStatus.value = await apiFetch<ExportKeyStatus>('/api/export-key')
  } catch { /* 讀不到就不顯示，不擋整頁 */ }
}
await loadKeyStatus()

async function genKeypair() {
  if (keyBusy.value) return
  keyBusy.value = true
  try {
    const r = await apiFetch<any>('/api/export-key/generate', { method: 'POST' })
    await loadKeyStatus()
    showToast(`金鑰已產生，指紋 ${r.fingerprint}。私鑰留在這台，公鑰複製到來源端。`,
              'success', 10000)
  } catch (e: any) {
    // 已經有私鑰時後端會拒絕（覆蓋會讓過去的加密匯出永遠打不開）
    showToast(e?.data?.detail || '產生失敗', 'error', 10000)
  } finally {
    keyBusy.value = false
  }
}

async function saveRecipient() {
  if (keyBusy.value) return
  keyBusy.value = true
  try {
    const r = await apiFetch<any>('/api/export-key/recipient',
                                  { method: 'PUT', body: { public_key: recipientInput.value } })
    recipientInput.value = ''
    await loadKeyStatus()
    showToast(`收件人公鑰已設定，指紋 ${r.fingerprint}`, 'success')
  } catch (e: any) {
    showToast(e?.data?.detail || '設定失敗', 'error', 10000)
  } finally {
    keyBusy.value = false
  }
}

// ===== 匯出全部資料（Dump，下載到自己的電腦）=====
// 跟上面的「立即備份」不同：立即備份存在伺服器本機/異地，這裡是直接下載到使用者
// 瀏覽器。二進位／文字兩種格式讓使用者自己選——文字檔內容一模一樣看得到，但也更容易
// 被不小心複製貼到不該去的地方（2026-08-18 真的發生過），二進位檔案要多一道「傳檔案」
// 的手續，比較不會手滑外洩。只匯出，不做匯入/還原（還原風險層級不同，故意不做在這裡）。
const dumpFormat = ref<'binary' | 'sql'>('binary')
const dumpSplit = ref(false)   // 切成 10MB 一片（給 email 附件），伺服器打包成 zip
const dumpRunning = ref(false)
async function downloadDump() {
  dumpRunning.value = true
  try {
    const splitQ = dumpSplit.value ? '&split_mb=10' : ''
    const res = await fetch(
      `${runtimeConfig.public.apiBase}/api/backup/dump?fmt=${dumpFormat.value}${splitQ}`,
      { credentials: 'include' },
    )
    if (!res.ok) throw new Error(await httpReason(res))
    const blob = await res.blob()
    const cd = res.headers.get('Content-Disposition') || ''
    const m = cd.match(/filename="?([^"]+)"?/)
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = m ? m[1] : (dumpSplit.value ? 'asset_dump_split10MB.zip' : `asset_dump.${dumpFormat.value === 'sql' ? 'sql' : 'db'}`)
    a.click()
    URL.revokeObjectURL(url)
    showToast(
      `已匯出並加密（指紋 ${keyStatus.value?.recipient_fingerprint ?? '—'}）`
      + (dumpSplit.value ? '，已切成 10MB 一片打包成 zip' : ''),
      'success', 8000,
    )
  } catch (err: any) {
    showToast(`匯出失敗：${err?.message ?? '請稍後重試'}`, 'error')
  } finally {
    dumpRunning.value = false
  }
}

// ===== 資料庫還原（2026-08-19 拍板方案B：簡單覆蓋＋單一確認框）=====
// 開關預設關閉，不在 ROUTE_MODULE_MAP（不是獨立頁面），isEnabled('restore') 直接
// 決定要不要顯示這塊——這是唯一可能直接砸掉正式資料的功能，平時就該關著。
const restoreFile = ref<File | null>(null)
const restoreConfirmText = ref('')
const restoreRunning = ref(false)
const RESTORE_CONFIRM_WORD = '覆蓋還原'
function onRestoreFileChange(e: Event) {
  const input = e.target as HTMLInputElement
  restoreFile.value = input.files?.[0] ?? null
}
async function runRestore() {
  if (!restoreFile.value) { showToast('請先選一個 .db 檔案', 'warn'); return }
  if (restoreConfirmText.value !== RESTORE_CONFIRM_WORD) {
    showToast(`請在確認欄位輸入「${RESTORE_CONFIRM_WORD}」才能執行`, 'warn')
    return
  }
  restoreRunning.value = true
  try {
    const form = new FormData()
    form.append('file', restoreFile.value)
    const res = await fetch(`${runtimeConfig.public.apiBase}/api/backup/restore`, {
      method: 'POST', credentials: 'include', body: form,
    })
    if (!res.ok) {
      // 後端正常回 JSON 時用 detail；但 413（檔案太大）、502（後端沒起來）這些是
      // 反向代理擋掉的，回的是 HTML，res.json() 會炸掉、detail 變 null，原因就整個
      // 不見了——2026-08-19 使用者回報「失敗沒寫原因」的其中一條路徑。
      // 退而求其次讀 text()，至少把狀態碼與伺服器講的話帶出來。
      // 401 幾乎一定代表「上一次還原已經成功、把登入資料一起換掉了」，不是這次的
      // 檔案有問題。報成「還原失敗」會讓人以為功能壞掉而一直重試（實際踩過），
      // 所以這條單獨處理，直接送去重新登入。
      if (res.status === 401) {
        showToast(
          '登入階段已失效。這通常代表上一次還原「已經成功」，'
          + '而登入資料存在同一個資料庫裡、被一併覆蓋了。'
          + '請用上傳檔裡的帳號密碼重新登入，再確認資料是否已是你要的那份。',
          'warn', 15000,
        )
        setTimeout(() => { navigateTo('/login?reason=restored') }, 3000)
        return
      }
      const raw = await res.text().catch(() => '')
      let detail = ''
      try { detail = JSON.parse(raw)?.detail ?? '' } catch { detail = raw.slice(0, 300) }
      throw new Error(detail ? `${detail}（HTTP ${res.status}）` : `HTTP ${res.status} ${res.statusText}`)
    }
    const body = await res.json()
    restoreFile.value = null
    restoreConfirmText.value = ''
    // 還原成功 = 自己一定被登出。sessions/users 表就在同一個資料庫裡，整庫覆蓋會
    // 把目前這張登入憑證換成上傳檔裡的內容，之後每個請求都是 401。
    // 2026-08-19 使用者實際踩到：還原其實成功了，但接著點什麼都回 401，畫面寫
    // 「還原失敗」——看起來像功能壞掉，其實是成功之後把人踢掉還謊報失敗。
    // 所以這裡不能只是 showToast 就算了，要主動把人送去重新登入。
    showToast(
      `✅ 還原成功。覆蓋前的舊資料已存證：${body.pre_restore_backup ?? '（無，這是首次建庫）'}。`
      + '　登入資料被一併覆蓋，3 秒後跳轉登入頁，需要重新登入。',
      'success', 8000,
    )
    // 帶 reason 過去，讓登入頁自己把說明顯示出來——toast 會跟著這一頁一起消失。
    setTimeout(() => { navigateTo('/login?reason=restored') }, 3000)
  } catch (err: any) {
    // 30 秒而不是預設的 3.4 秒：這則訊息要告訴使用者「哪一步失敗、正式資料有沒有
    // 被動到」，是不可逆操作出錯時唯一的線索，來不及看完就消失等於沒講。
    const msg = err?.message
      || '連線中斷或伺服器沒有回應（請確認後端服務還在，以及檔案是否超過上傳大小限制）'
    showToast(`還原失敗：${msg}`, 'error', 30000)
  } finally {
    restoreRunning.value = false
  }
}

async function runBackupNow() {
  backupRunning.value = true
  backupError.value = ''
  try {
    const r = await apiFetch<any>('/api/backup/run', { method: 'POST' })
    if (r.ok) {
      const extra = r.offsite_path
        ? '（含異地副本）'
        : r.offsite_error ? `（異地副本失敗：${r.offsite_error}）` : ''
      showToast(`備份完成 · ${fmtBytes(r.size_bytes)} · 完整性 PASS ${extra}`,
                r.offsite_error ? 'warn' : 'success')
    } else {
      // 後端刻意用 200 回失敗細節，這裡把原因原樣顯示，不要吞成一句「失敗」
      backupError.value = r.message ?? r.error ?? '備份失敗'
      showToast(backupError.value, 'error')
    }
    await loadBackupHealth()
  } catch (err: any) {
    backupError.value = err?.data?.detail ?? '備份執行失敗，請稍後再試'
    showToast(backupError.value, 'error')
  } finally {
    backupRunning.value = false
  }
}

// immediate：從 /settings?tab=backup 直接進來時，activeTab 在 setup 當下就已經是
// 'backup'，沒有 immediate 這個 watch 永遠不觸發 → 狀態不載入、下面整塊空白又沒有
// 任何錯誤訊息（2026-09-17 NB session 定位、2026-09-18 使用者在公司機回報「備份失敗」）。
watch(activeTab, (t) => {
  if (t === 'backup' && !backupHealth.value) loadBackupHealth()
}, { immediate: true })

// 異地備份路徑：畫面可設（存 app_settings），不用改 systemd 環境變數再重啟。
// 路徑要指到「真正獨立的儲存」才算異地——例如掛載另一台機器（222）的 /ai_backup。
const offsiteDraft = ref('')
const savingOffsite = ref(false)
watch(backupHealth, (h) => { if (h) offsiteDraft.value = h.offsite.dir ?? '' })
async function saveOffsite() {
  savingOffsite.value = true
  try {
    backupHealth.value = await apiFetch<BackupHealth>('/api/backup/offsite', {
      method: 'PUT', body: { dir: offsiteDraft.value.trim() },
    })
    showToast(offsiteDraft.value.trim() ? '已設定異地備份路徑' : '已清除異地備份路徑', 'success')
  } catch (err: any) {
    showToast(`儲存失敗：${err?.data?.detail ?? '請稍後重試'}`, 'error')
  } finally {
    savingOffsite.value = false
  }
}

// ── B-19 弱點到期寄信設定（2026-09-22 使用者：「MAIL 設定應該放在這邊」）──
// 每週一／每月 1 號到點自己寄；收件人＝弱點報告上的負責人，信箱查 AD 名單。
// **SMTP 每一個值都存 DB、都能在這裡改**——程式碼裡沒有任何預設主機。
type MailCfg = {
  enabled: boolean
  smtp_host?: string
  smtp_port?: number
  mail_from?: string
  send_time?: string
  fallback_to?: string
  manager_cc?: boolean
  buckets?: number[]
  subject_prefix?: string
  always_cc?: string
  only_depts?: string[]
  only_people?: string[]
}
type MailRun = {
  run_date: string; schedule: string; started_at: string
  config_ok: number; sent: number; failed: number; reason: string | null
}
const mail = reactive<MailCfg>({ enabled: false, manager_cc: true })
const mailMissing = ref<string[]>([])
const mailAdReady = ref(true)
const mailCorrupt = ref<string | null>(null)
const mailBuckets = ref('14,30,60')
const mailRuns = ref<MailRun[]>([])
const mailLoading = ref(false)
const mailLoaded = ref(false)
const savingMail = ref(false)
const mailPreview = ref<any>(null)
const mailDepts = ref<{ dept: string; n: number }[]>([])
const mailPeople = ref<{ employee_id: string; display_name: string; dept_name: string }[]>([])

async function loadMail() {
  mailLoading.value = true
  try {
    const r = await apiFetch<any>('/api/vuln-notify/settings')
    Object.assign(mail, { enabled: false, manager_cc: true }, r.settings ?? {})
    mailMissing.value = r.missing ?? []
    mailAdReady.value = !!r.ad_ready
    mailCorrupt.value = r.corrupt ?? null
    mail.send_time = r.send_time
    mailBuckets.value = (r.buckets ?? []).join(',')
    mailRuns.value = r.last_runs ?? []
    mailLoaded.value = true
    await loadMailRecipients()
  } catch (err: any) {
    showToast(`寄信設定載入失敗：${err?.data?.detail ?? '請稍後重試'}`, 'error')
  } finally {
    mailLoading.value = false
  }
}
// immediate：從 /settings?tab=mail 直接進來時，activeTab 在 setup 當下就已經是
// 'mail'，沒有 immediate 就永遠不會觸發——畫面會顯示「還沒有任何一期跑過」，
// 跟「根本沒載到」長得一模一樣。這頁 ?tab=backup 早就踩過同一個坑。
watch(activeTab, (t) => { if (t === 'mail' && !mailLoaded.value && !mailLoading.value) loadMail() },
      { immediate: true })

async function loadMailRecipients() {
  try {
    const q = (mail.only_depts ?? []).join(',')
    const r = await apiFetch<any>('/api/vuln-notify/recipients', q ? { query: { depts: q } } : {})
    mailDepts.value = r.departments ?? []
    mailPeople.value = r.people ?? []
  } catch {
    // 挑不到人不該讓整頁壞掉：設定本身還是要能改。
    mailDepts.value = []
    mailPeople.value = []
  }
}

// 換了單位就重抓人，並把已挑的人裡「不在新單位」的清掉——
// 留著會變成畫面顯示「只通知架構部」，實際卻還寄給別單位的人。
async function onDeptChange() {
  await loadMailRecipients()
  const ids = new Set(mailPeople.value.map((x) => x.employee_id))
  mail.only_people = (mail.only_people ?? []).filter((x) => ids.has(x))
}

function mailBody() {
  const buckets = mailBuckets.value.split(',')
    .map((x) => Number(x.trim())).filter((n) => Number.isFinite(n) && n > 0)
  return {
    enabled: mail.enabled,
    smtp_host: (mail.smtp_host ?? '').trim() || null,
    smtp_port: mail.smtp_port ? Number(mail.smtp_port) : null,
    mail_from: (mail.mail_from ?? '').trim() || null,
    send_time: mail.send_time || null,
    fallback_to: (mail.fallback_to ?? '').trim() || null,
    manager_cc: mail.manager_cc !== false,
    subject_prefix: (mail.subject_prefix ?? '').trim() || null,
    always_cc: (mail.always_cc ?? '').trim() || null,
    // 空陣列要送出去（代表「全部」），不可以送 null——後端會當成沒給而保留舊設定
    only_depts: mail.only_depts ?? [],
    only_people: mail.only_people ?? [],
    buckets: buckets.length ? buckets : null,
  }
}

async function saveMail() {
  savingMail.value = true
  try {
    const r = await apiFetch<any>('/api/vuln-notify/settings', { method: 'PUT', body: mailBody() })
    mailMissing.value = r.missing ?? []
    showToast(mail.enabled ? '已儲存，到點會自動寄送' : '已儲存（目前未啟用，不會寄）', 'success')
    await loadMail()
  } catch (err: any) {
    showToast(`儲存失敗：${err?.data?.detail ?? '請稍後重試'}`, 'error')
  } finally {
    savingMail.value = false
  }
}

// 預覽：**只組信不寄**，也不動任何一筆的通知狀態。
// 沒有這顆，第一次設定的人只能「按下去看會不會出事」。
async function previewMail() {
  mailPreview.value = null
  try {
    mailPreview.value = await apiFetch<any>('/api/vuln-notify/preview', { method: 'POST' })
  } catch (err: any) {
    showToast(`預覽失敗：${err?.data?.detail ?? '請稍後重試'}`, 'error')
  }
}

// 立刻寄一期。**會真的寄出信**，所以要二次確認——這頁其他動作都只影響本系統，
// 這一顆會送東西到別人的信箱，誤按收不回來。
async function runMailNow() {
  if (!confirm('會立刻寄出這一期的到期通知給各負責人（主管收副本）。確定要寄？')) return
  try {
    const r = await apiFetch<any>('/api/vuln-notify/run', { method: 'POST' })
    showToast(r.ok ? `已寄出 ${r.sent} 封，失敗 ${r.failed} 封` : `沒有寄出：${r.reason}`,
              r.ok && !r.failed ? 'success' : 'error')
    await loadMail()
  } catch (err: any) {
    showToast(`寄送失敗：${err?.data?.detail ?? '請稍後重試'}`, 'error')
  }
}

async function loadSchedule() {
  Object.assign(schedule, await apiFetch<Schedule>('/api/scan/schedule'))
}

async function saveSchedule() {
  savingSchedule.value = true
  errorMessage.value = ''
  try {
    await apiFetch('/api/scan/schedule', {
      method: 'PUT',
      body: {
        enabled: schedule.enabled,
        mode: schedule.mode,
        time: schedule.time,
        interval_hours: Number(schedule.interval_hours),
        weekday: Number(schedule.weekday ?? 6),
      },
    })
    showToast('掃描排程已儲存，下次依新設定執行', 'success')
  } catch (err: any) {
    showToast(`排程儲存失敗：${err?.data?.detail ?? '請稍後重試'}`, 'error')
  } finally {
    savingSchedule.value = false
  }
}

// 各網段自己的排程時間（2026-09-12）：設了就在那個時間單獨掃這一段（公司多個測試網段可錯開）；
// 留空＝跟上面的全域排程一起掃。存完立即生效，不用重啟。
async function saveScanTime(row: ConnectionRow) {
  const t = (row.scan_time || '').trim()
  if (t && !/^([01]?\d|2[0-3]):[0-5]\d$/.test(t)) {
    showToast('時間格式要是 HH:MM（24 小時制），例如 03:30', 'error'); return
  }
  try {
    const r = await apiFetch<ConnectionRow>(`/api/connections/${row.id}/scan-time`, {
      method: 'PATCH', body: { scan_time: t || null },
    })
    row.scan_time = r.scan_time
    showToast(t ? `已設 ${row.name} 於每日 ${t} 單獨掃` : `已清除，${row.name} 回到跟全域排程一起掃`, 'success')
  } catch (err: any) {
    showToast(`設定失敗：${err?.data?.detail ?? '請稍後重試'}`, 'error')
  }
}
// 只有「會被掃的網段」才需要自訂時間（vCenter/SNMP 這類不是逐台掃，不列）
const segConns = computed(() => connections.value.filter(
  (c) => c.connection_type === '網路掃描' || (c.target || '').includes('/')))

// ===== 從資產 IP 反推掃描網段 =====
interface SegRow {
  cidr: string; hosts: number; main_location: string
  locations: Record<string, number>; mixed: boolean; already: boolean; suggest_name: string
}
const segData = ref<{ segments: SegRow[]; bad_ip_count: number; existing_count: number } | null>(null)
const segLoading = ref(false)
const segCreating = ref(false)
const segChecked = ref<string[]>([])
const segMsg = ref('')   // 這一區自己的結果訊息，不跟全頁的錯誤訊息共用
const segTxtLoading = ref(false)

// 外部掃描機連不到這裡的資料庫（那正是要外部掃描的原因），網段清單只能由人搬過去。
// 用 fetch 而非 apiFetch：回的是純文字檔不是 JSON，要拿 blob 觸發下載。
async function downloadSegmentsTxt() {
  segTxtLoading.value = true
  try {
    const res = await fetch(
      `${runtimeConfig.public.apiBase}/api/connections/suggest-segments?fmt=txt`,
      { credentials: 'include' },
    )
    if (!res.ok) throw new Error(await httpReason(res))
    const blob = await res.blob()
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'segments.txt'   // mmap.sh 只認這個檔名
    a.click()
    URL.revokeObjectURL(url)
    showToast('已下載 segments.txt，放到掃描機跟 mmap.sh 同一個目錄', 'success')
  } catch (err: any) {
    showToast(`下載失敗：${err?.message ?? '請稍後重試'}`, 'error')
  } finally {
    segTxtLoading.value = false
  }
}

// 只列還沒設定的：已經建過的再列出來只是雜訊，使用者要找的是「還缺哪些」
const pendingSegments = computed(() => (segData.value?.segments ?? []).filter(s => !s.already))
const segMixedCount = computed(() => pendingSegments.value.filter(s => s.mixed).length)
const allSegChecked = computed(() =>
  pendingSegments.value.length > 0 && segChecked.value.length === pendingSegments.value.length)

function toggleAllSegs() {
  segChecked.value = allSegChecked.value ? [] : pendingSegments.value.map(s => s.cidr)
}

async function loadSegments() {
  segLoading.value = true
  errorMessage.value = ''
  try {
    segData.value = await apiFetch('/api/connections/suggest-segments')
    // 預設全選未建立的：使用者按這個鈕就是想把缺的補齊，不該再逐一勾
    segChecked.value = pendingSegments.value.map(s => s.cidr)
  } catch {
    errorMessage.value = '網段分析失敗，請稍後再試'
  } finally {
    segLoading.value = false
  }
}

async function createSegments() {
  if (!segChecked.value.length) return
  segCreating.value = true
  errorMessage.value = ''
  try {
    const r = await apiFetch<{ created: any[]; skipped: string[] }>('/api/connections/batch-segments', {
      method: 'POST',
      body: { cidrs: segChecked.value },
    })
    await loadConnections()
    await loadSegments()   // 重新分析，剛建立的會自動移出待建清單
    segMsg.value = `已建立 ${r.created.length} 個掃描網段`
      + (r.skipped.length ? `（略過 ${r.skipped.length} 個已存在）` : '')
  } catch {
    errorMessage.value = '批次建立失敗，請稍後再試'
  } finally {
    segCreating.value = false
  }
}

async function loadConnections() {
  connections.value = await apiFetch<ConnectionRow[]>('/api/connections')
  for (const c of connections.value) {
    if (!(c.id in drafts)) drafts[c.id] = { password: '' }
  }
}
await Promise.all([loadConnections(), ensureFlagsLoaded(), loadSchedule()])

const disabledModuleLabel = computed(() => {
  const key = route.query.disabled as string | undefined
  if (!key) return null
  return flags.value.find((f) => f.module_key === key)?.label ?? key
})

async function toggleModule(moduleKey: string, enabled: boolean) {
  togglingKey.value = moduleKey
  errorMessage.value = ''
  try {
    await setEnabled(moduleKey, enabled)
  } catch (err: any) {
    errorMessage.value = err?.data?.detail ?? '切換失敗'
  } finally {
    togglingKey.value = null
  }
}

function statusDotClass(status: string) {
  if (status === '綠') return 'green'
  if (status === '紅') return 'red'
  return 'gray'
}
function statusLabel(status: string) {
  if (status === '綠') return '已連線'
  if (status === '紅') return '未連線'
  return '未知'
}

async function saveExisting(row: ConnectionRow) {
  savingId.value = row.id
  errorMessage.value = ''
  try {
    const body: Record<string, any> = {
      name: row.name,
      connection_type: row.connection_type,
      target: row.target,
      port: row.port ? Number(row.port) : null,
      username: row.username,
    }
    const pw = drafts[row.id]?.password
    if (pw) body.password = pw
    await apiFetch(`/api/connections/${row.id}`, { method: 'PUT', body })
    drafts[row.id].password = ''
    await loadConnections()
  } catch (err: any) {
    errorMessage.value = err?.data?.detail ?? '儲存失敗'
  } finally {
    savingId.value = null
  }
}

async function saveNew() {
  if (!newRow.name || !newRow.target) {
    errorMessage.value = '連線名稱與目標位址為必填'
    return
  }
  savingId.value = 'new'
  errorMessage.value = ''
  try {
    await apiFetch('/api/connections', {
      method: 'POST',
      body: {
        name: newRow.name,
        connection_type: newRow.connection_type || null,
        target: newRow.target,
        port: newRow.port ? Number(newRow.port) : null,
        username: newRow.username || null,
        password: newRow.password || null,
      },
    })
    newRow.name = ''
    newRow.connection_type = ''
    newRow.target = ''
    newRow.port = ''
    newRow.username = ''
    newRow.password = ''
    await loadConnections()
  } catch (err: any) {
    errorMessage.value = err?.data?.detail ?? '新增失敗'
  } finally {
    savingId.value = null
  }
}

async function testConnection(row: ConnectionRow) {
  testingId.value = row.id
  errorMessage.value = ''
  try {
    await apiFetch(`/api/connections/${row.id}/test`, { method: 'POST' })
    await loadConnections()
  } catch (err: any) {
    errorMessage.value = err?.data?.detail ?? '測試失敗'
  } finally {
    testingId.value = null
  }
}

async function deleteConnection(row: ConnectionRow) {
  if (!confirm(`確定要刪除連線設定「${row.name}」？此操作無法復原。`)) return
  deletingId.value = row.id
  errorMessage.value = ''
  try {
    await apiFetch(`/api/connections/${row.id}`, { method: 'DELETE' })
    await loadConnections()
  } catch (err: any) {
    errorMessage.value = err?.data?.detail ?? '刪除失敗'
  } finally {
    deletingId.value = null
  }
}

const ROW_HEIGHT = 64
const NODE_W = 150
const NODE_H = 48
const HUB_X = 20
const NODE_X = 420

const diagramHeight = computed(() => Math.max(connections.value.length * ROW_HEIGHT + 20, 120))

const diagramNodes = computed(() =>
  connections.value.map((c, i) => ({
    ...c,
    y: 20 + i * ROW_HEIGHT,
    edgeClass: c.last_status === '綠' ? 'edge-green' : c.last_status === '紅' ? 'edge-red' : 'edge-gray',
    label: c.port ? `${c.name} :${c.port}` : c.name,
  }))
)

const hubY = computed(() => diagramHeight.value / 2)
</script>

<template>
  <div>
    <div class="section-divider">{{ backupOnly ? '備份與還原' : '系統設定' }}</div>
    <div v-if="!backupOnly" class="tabs">
      <div class="tab" :class="{ active: activeTab === 'connections' }" @click="activeTab = 'connections'">
        連線設定
      </div>
      <div class="tab" :class="{ active: activeTab === 'diagram' }" @click="activeTab = 'diagram'">
        架構圖
      </div>
      <div class="tab" :class="{ active: activeTab === 'modules' }" @click="activeTab = 'modules'">
        功能模組管理
      </div>
      <div class="tab" :class="{ active: activeTab === 'credentials' }" @click="activeTab = 'credentials'">
        收集憑證
      </div>
      <div class="tab" :class="{ active: activeTab === 'autoonboard' }" @click="activeTab = 'autoonboard'">
        自動納管
        <span v-if="aoEnabled" class="tab-lamp green" />
      </div>
      <div class="tab" :class="{ active: activeTab === 'schedule' }" @click="activeTab = 'schedule'">
        掃描排程
      </div>
      <div class="tab" :class="{ active: activeTab === 'mail' }" @click="activeTab = 'mail'">
        寄信設定
        <span v-if="mail.enabled" class="tab-lamp green" />
      </div>
    </div>

    <div v-if="disabledModuleLabel" class="notice-banner">
      「{{ disabledModuleLabel }}」目前已停用，可在下方「功能模組管理」重新啟用。
    </div>

    <p v-if="errorMessage" class="error-text">{{ errorMessage }}</p>

    <template v-if="activeTab === 'connections'">
      <!-- 從資產 IP 反推該掃哪些網段。手動一條一條建太容易漏，
           而漏建的那個網段整批機器都會變成「失聯」，看起來像機器出事。 -->
      <div class="segbox">
        <div class="segbar">
          <button class="btn" type="button" :disabled="segLoading" @click="loadSegments">
            {{ segLoading ? '分析中…' : '從資產推導掃描網段' }}
          </button>
          <InfoNote>依現有資產的 IP 算出應該掃哪些網段，並對到機房。不會動到既有設定。</InfoNote>
        </div>

        <!-- 外部掃描走的是另一條路：戰情室本身連不到那些網段，所以清單下載成檔案、
             由人帶到走得通的那台機器上掃，結果再打包回來匯入。 -->
        <div class="segbar">
          <button class="btn" type="button" :disabled="segTxtLoading" @click="downloadSegmentsTxt">
            {{ segTxtLoading ? '產生中…' : '⬇ 下載 segments.txt（外部掃描用）' }}
          </button>
          <InfoNote>給外部掃描機的網段清單。放到掃描機上跟 <code>mmap.sh</code>、<code>scan_segments.py</code> 同一個目錄，再跑 <code>sudo bash mmap.sh</code>。</InfoNote>
        </div>

        <template v-if="segData">
          <div class="segsum">
            共 <b>{{ segData.segments.length }}</b> 個網段；
            已設定 <b>{{ segData.segments.filter(s => s.already).length }}</b> 個，
            尚未設定 <b class="warn">{{ pendingSegments.length }}</b> 個
            <span v-if="segData.bad_ip_count"> ｜ IP 格式異常 {{ segData.bad_ip_count }} 筆</span>
          </div>

          <div v-if="pendingSegments.length" class="tbl-wrap segtbl">
            <table>
              <thead>
                <tr>
                  <th style="width:38px">
                    <input type="checkbox" :checked="allSegChecked" @change="toggleAllSegs" />
                  </th>
                  <th>網段</th>
                  <th>台數</th>
                  <th>機房</th>
                  <th>建立後的名稱</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="s in pendingSegments" :key="s.cidr">
                  <td><input type="checkbox" :value="s.cidr" v-model="segChecked" /></td>
                  <td><code>{{ s.cidr }}</code></td>
                  <td>{{ s.hosts.toLocaleString() }}</td>
                  <td>
                    {{ s.main_location }}
                    <span v-if="s.mixed" class="mixed" :title="Object.entries(s.locations).map(([k,v]) => k + '：' + v + ' 台').join('、')">
                      跨 {{ Object.keys(s.locations).length }} 種
                    </span>
                  </td>
                  <td class="muted">{{ s.suggest_name }}</td>
                </tr>
              </tbody>
            </table>
          </div>
          <p v-else class="segdone">所有推導出來的網段都已經設定過了，不用再補。</p>

          <p v-if="segMsg" class="segok">{{ segMsg }}</p>
          <div v-if="pendingSegments.length" class="segbar">
            <button class="btn" type="button"
                    :disabled="!segChecked.length || segCreating" @click="createSegments">
              {{ segCreating ? '建立中…' : `建立選取的 ${segChecked.length} 個網段` }}
            </button>
            <InfoNote>建立後預設啟用，下次排程掃描就會涵蓋。掃描範圍變大，時間會拉長。</InfoNote>
          </div>
          <p v-if="segMixedCount" class="segwarn">
            有 {{ segMixedCount }} 個網段的資產分散在多個機房 —— 可能是真的跨機房共用，
            也可能是資產的機房欄位填錯，值得順手查一下。
          </p>
        </template>
      </div>

      <div class="tbl-wrap">
        <table>
          <thead>
            <tr>
              <SortTh k="enabled" :active="cnKey" :dir="cnDir" @sort="cnToggle">啟用</SortTh><SortTh k="name" :active="cnKey" :dir="cnDir" @sort="cnToggle">連線</SortTh><SortTh k="target" :active="cnKey" :dir="cnDir" @sort="cnToggle">目標位址／網段</SortTh><SortTh k="port" :active="cnKey" :dir="cnDir" @sort="cnToggle">Port</SortTh><SortTh k="username" :active="cnKey" :dir="cnDir" @sort="cnToggle">帳號</SortTh><th>密碼</th><SortTh k="last_status" :active="cnKey" :dir="cnDir" @sort="cnToggle">狀態</SortTh><th>操作</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="row in connectionsSorted" :key="row.id" :class="{ off: row.enabled === 0 }">
              <td>
                <button class="tgl" :class="{ on: row.enabled !== 0 }" type="button"
                        :disabled="togglingConn === row.id"
                        :title="row.enabled === 0 ? '目前停用：排程掃描會跳過，不算掃描失敗' : '目前啟用：會被排程掃描'"
                        @click="toggleConnection(row)">
                  {{ row.enabled === 0 ? '停用' : '啟用' }}
                </button>
              </td>
              <td><input v-model="row.name" type="text" class="cell-input" /></td>
              <td><input v-model="row.target" type="text" class="cell-input" /></td>
              <td><input v-model="row.port" type="text" class="cell-input narrow" /></td>
              <td><input v-model="row.username" type="text" class="cell-input" /></td>
              <td>
                <input
                  v-model="drafts[row.id].password"
                  type="password"
                  class="cell-input"
                  :placeholder="row.has_password ? '留空＝不變更' : '尚未設定'"
                />
              </td>
              <td>
                <span class="status-dot" :class="statusDotClass(row.last_status)">
                  <span class="d"></span>{{ statusLabel(row.last_status) }}
                </span>
              </td>
              <td class="actions-cell">
                <button class="btn small" :disabled="savingId === row.id" @click="saveExisting(row)">
                  {{ savingId === row.id ? '儲存中…' : '儲存' }}
                </button>
                <button class="btn ghost small" :disabled="testingId === row.id" @click="testConnection(row)">
                  {{ testingId === row.id ? '測試中…' : '測試連線' }}
                </button>
                <button class="btn ghost small" :disabled="deletingId === row.id" @click="deleteConnection(row)">
                  刪除
                </button>
              </td>
            </tr>
            <tr>
              <td><input v-model="newRow.name" type="text" class="cell-input" placeholder="連線名稱" /></td>
              <td><input v-model="newRow.target" type="text" class="cell-input" placeholder="目標位址／網段" /></td>
              <td><input v-model="newRow.port" type="text" class="cell-input narrow" placeholder="Port" /></td>
              <td><input v-model="newRow.username" type="text" class="cell-input" placeholder="帳號" /></td>
              <td><input v-model="newRow.password" type="password" class="cell-input" placeholder="密碼" /></td>
              <td class="muted-cell">—</td>
              <td>
                <button class="btn small" :disabled="savingId === 'new'" @click="saveNew">
                  {{ savingId === 'new' ? '新增中…' : '新增連線' }}
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </template>

    <template v-else-if="activeTab === 'diagram'">
      <div v-if="connections.length === 0" class="diagram-placeholder">
        還沒有任何連線設定，請先到「連線設定」分頁新增，架構圖會自動反映同一份資料。
      </div>
      <div v-else class="diagram-wrap">
        <svg :viewBox="`0 0 620 ${diagramHeight}`" width="100%" style="max-width: 620px; display: block; margin: 0 auto">
          <rect :x="HUB_X" :y="hubY - 30" width="130" height="60" rx="3" class="node" />
          <text :x="HUB_X + 65" :y="hubY - 8" text-anchor="middle" class="node-label">資產盤點服務</text>
          <text :x="HUB_X + 65" :y="hubY + 8" text-anchor="middle" class="node-sub">本機</text>

          <template v-for="n in diagramNodes" :key="n.id">
            <line
              :x1="HUB_X + 130"
              :y1="hubY"
              :x2="NODE_X"
              :y2="n.y + NODE_H / 2"
              :class="n.edgeClass"
            />
            <text
              :x="(HUB_X + 130 + NODE_X) / 2"
              :y="(hubY + n.y + NODE_H / 2) / 2 - 6"
              text-anchor="middle"
              class="edge-label"
            >
              {{ n.label }}
            </text>
            <rect :x="NODE_X" :y="n.y" :width="NODE_W" :height="NODE_H" rx="3" class="node" />
            <text :x="NODE_X + NODE_W / 2" :y="n.y + 20" text-anchor="middle" class="node-label">{{ n.name }}</text>
            <text :x="NODE_X + NODE_W / 2" :y="n.y + 36" text-anchor="middle" class="node-sub">
              {{ n.target }}{{ n.port ? ':' + n.port : '' }}
            </text>
          </template>
        </svg>

        <div class="legend-list">
          <div class="row-l"><span class="mk" style="background: var(--good)">綠</span>已連線（最近一次測試成功）</div>
          <div class="row-l"><span class="mk" style="background: var(--bad)">紅</span>未連線（最近一次測試失敗）</div>
          <div class="row-l"><span class="mk" style="background: var(--muted)">灰</span>未知（未測過，或太久沒更新，D15）</div>
        </div>
      </div>
    </template>

    <template v-else-if="activeTab === 'modules'">
      <div v-if="authOff" class="card" style="margin-bottom:16px">
        <div class="card-title">
          停用登入（測試用）
          <InfoNote>打開之後<b>不需要登入就能使用整套系統</b>——包含所有資產、人員姓名與分機。任何連得到這個網址的人都看得到。<br><br>設計上刻意讓<b>安全的方向比較好走</b>：打開要打字確認，關掉直接按。<br><br>而且只有<b>已經登入的人</b>打得開；否則就變成「未登入的人自己把登入關掉」，那是後門不是開關。<br><br>開著的時候畫面最上面會有一條紅色警告條，關不掉——那是為了不要忘記它開著。</InfoNote>
        </div>
        <div v-if="authOff.by_env" class="credhint">
          目前由伺服器的環境變數 <code>{{ authOff.env_name }}</code> 停用中——
          <b>這個畫面關不掉它</b>，要到伺服器移除該變數並重啟服務。
        </div>
        <div v-else class="actions" style="gap:10px;align-items:center;flex-wrap:wrap">
          <template v-if="authOff.disabled">
            <span class="credhint" style="color:var(--bad)">登入目前是<b>停用</b>狀態</span>
            <button class="btn" type="button" :disabled="authOffBusy" @click="setAuthOff(false)">
              恢復登入
            </button>
          </template>
          <template v-else>
            <span class="credhint">登入正常運作</span>
            <input v-model="authOffConfirm" class="ein" style="max-width:220px"
                   placeholder="輸入 DISABLE-LOGIN" :disabled="authOffBusy" />
            <button class="btn" type="button"
                    :disabled="authOffBusy || authOffConfirm !== 'DISABLE-LOGIN'"
                    @click="setAuthOff(true)">停用登入</button>
          </template>
        </div>
      </div>

      <div class="tbl-wrap">
        <table>
          <thead>
            <tr><SortTh k="label" :active="fgKey" :dir="fgDir" @sort="fgToggle">模組</SortTh><SortTh k="enabled" :active="fgKey" :dir="fgDir" @sort="fgToggle">狀態</SortTh><th>操作</th></tr>
          </thead>
          <tbody>
            <tr v-for="f in flagsSorted" :key="f.module_key">
              <td>{{ f.label }}</td>
              <td>
                <span class="status-dot" :class="f.enabled ? 'green' : 'gray'">
                  <span class="d"></span>{{ f.enabled ? '已啟用' : '已停用' }}
                </span>
              </td>
              <td>
                <button
                  class="btn small"
                  :class="{ ghost: f.enabled }"
                  :disabled="togglingKey === f.module_key"
                  @click="toggleModule(f.module_key, !f.enabled)"
                >
                  {{ togglingKey === f.module_key ? '處理中…' : f.enabled ? '停用' : '啟用' }}
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </template>

    <!-- 收集用憑證：Windows WinRM 服務帳號等，排程收集反覆使用 -->
    <template v-else-if="activeTab === 'credentials'">
      <!-- Linux 的收集身分是一把 SSH 金鑰。跟下面 Windows 的帳密同一類東西，放一起。 -->
      <div class="card" style="margin-bottom:16px">
        <div class="card-title">
          收集金鑰（Linux）
          <InfoNote>Linux 主機走 SSH 金鑰收集（Windows 走下面的服務帳號）。私鑰存在伺服器 <code>{{ ckStatus?.path }}</code>（0600），畫面與 API <b>永遠不會回傳私鑰</b>。<br><br>平常不用動這裡——<code>deploy.sh</code> 第一次就會產一把。會用到匯入，是因為公司可能<b>已經有一把佈遍全機隊的金鑰</b>（例如巡檢用的），匯入它就省掉重新納管每一台。</InfoNote>
        </div>

        <div v-if="ckStatus" class="actions" style="gap:14px;align-items:center;flex-wrap:wrap">
          <span class="credhint">指紋 <code>{{ ckStatus.fingerprint ?? '（還沒有金鑰）' }}</code></span>
          <span class="credhint">已納管 <b>{{ ckStatus.onboarded_hosts }}</b> 台
            <InfoNote>換金鑰會讓這 {{ ckStatus.onboarded_hosts }} 台的收集<b>當場失效</b>——它們的 <code>authorized_keys</code> 裡是<b>舊公鑰</b>，新鑰匙不開那些鎖。<br><br>除非你匯入的正是它們認得的那一把，否則全部要重新納管。這就是這裡要打字確認的原因。</InfoNote>
          </span>
          <span v-if="ckStatus.modified_at" class="credhint">更新於 {{ ckStatus.modified_at }}</span>
        </div>

        <details style="margin-top:12px">
          <summary style="cursor:pointer;font-size:13px;color:var(--ink-2)">匯入既有金鑰</summary>
          <div style="margin-top:12px">
            <div class="actions" style="gap:10px;align-items:center;flex-wrap:wrap">
              <select v-model="ckMode" style="padding:8px 12px;border-radius:6px;border:1px solid var(--border-strong);background:var(--card);color:var(--ink)">
                <option value="path">指定主機上的檔案路徑</option>
                <option value="paste">直接貼上私鑰</option>
              </select>
              <InfoNote>兩種方式的差別是<b>私鑰會不會經過網路</b>。<br><br><b>指定路徑</b>：你自己用 scp／WinSCP 把私鑰放到這台主機上，網頁只負責驗證配對、設好權限、搬到正確位置、重啟服務。私鑰<b>完全不過網路</b>。<br><br><b>直接貼上</b>：方便，但這套系統走的是內網 <code>http</code>（沒有 TLS），私鑰會以<b>明文</b>經過網路。自己權衡。</InfoNote>
            </div>

            <div v-if="ckMode === 'path'" class="actions" style="gap:10px;align-items:center;margin-top:10px">
              <span class="credhint" style="min-width:72px">私鑰路徑</span>
              <input v-model="ckPath" class="ein" style="flex:1;min-width:260px"
                     placeholder="/tmp/id_ed25519" :disabled="ckBusy" />
            </div>
            <div v-else style="margin-top:10px">
              <textarea v-model="ckPrivate" class="ein" rows="6" :disabled="ckBusy"
                        style="width:100%;font-family:var(--mono,monospace);font-size:12px"
                        placeholder="貼上私鑰全文（含開頭與結尾那兩行 BEGIN／END）"></textarea>
            </div>

            <div class="actions" style="gap:10px;align-items:center;margin-top:10px;flex-wrap:wrap">
              <span class="credhint" style="min-width:72px">確認</span>
              <input v-model="ckConfirm" class="ein" style="max-width:200px"
                     placeholder="輸入 REPLACE" :disabled="ckBusy" />
              <button class="btn" type="button" :disabled="!ckReady" @click="importCollectorKey">
                {{ ckBusy ? '匯入中…' : '匯入金鑰' }}
              </button>
              <InfoNote>這個動作會讓<b>已經在運作的東西停止運作</b>（{{ ckStatus?.onboarded_hosts ?? 0 }} 台的收集），按鈕太容易誤觸，所以要打字。</InfoNote>
            </div>

            <p v-if="ckResult" class="credhint" style="margin-top:12px"
               :style="{ color: ckResult.changed ? 'var(--warn)' : 'var(--good)' }">
              {{ ckResult.next_step }}
            </p>
          </div>
        </details>
      </div>

      <div class="card">
        <div class="card-title">收集用憑證（Windows） <InfoNote>Windows 走 <b>WinRM／CIM</b> 收集，需要一組服務帳號（Linux 走 SSH 金鑰，不需要這個）。密碼以 <b>Fernet 加密</b>後才存進資料庫，加密金鑰另存於伺服器 <code>/opt/webit3/.credential_key</code>（0600、不在資料庫裡——資料庫被複製走也解不開）。畫面與 API <b>永遠不會回傳密碼</b>，連密文都不給；每次使用都留稽核（不含密碼）。</InfoNote></div>

        <details class="compensating">
          <summary>⚠️ Windows 服務帳號的補償措施（帳密外洩時能擋住什麼）</summary>
          <p class="credhint">
            這組帳號<b>不需要本機系統管理員權限</b>——只需要能建立 WinRM 連線＋讀取唯讀的
            OS／硬體／網路資訊（跟 Ansible 對 SSH 帳號的最小權限原則同一個精神）。建議照下面
            幾層一起做，帳密就算外洩，能造成的傷害也被鎖得很死：
          </p>
          <ol class="credhint">
            <li><b>限制來源 IP</b>：Windows 防火牆把 WinRM（5985）規則鎖到只准收集器
              （<code>YOUR_SERVER_IP</code>）連進來，其他來源一律拒絕——等同 SSH 的
              <code>authorized_keys</code> <code>from=</code> 限制。</li>
            <li><b>JEA（Just Enough Administration）</b>：不要整個丟進
              <code>Remote Management Users</code> 群組換全 WinRM 權限，改建一個限定端點，
              把帳號鎖死只能跑收集腳本實際會用到的那幾個唯讀指令
              （<code>Get-CimInstance</code> 限四個類別、<code>Get-NetTCPConnection</code>、
              <code>Get-Process</code>），其餘一律連列出來都不行。這是微軟自己對「WinRM 最小
              權限」的標準做法，比群組成員資格精確得多。</li>
            <li><b>擋掉互動登入</b>：本機安全性原則把這個帳號設成「拒絕本機登入」「拒絕透過
              遠端桌面服務登入」，只保留「從網路存取這台電腦」——帳密外洩也沒辦法拿去登入
              桌面、只能觸發那個被鎖死的收集端點。</li>
            <li><b>帳戶鎖定原則</b>：連續打錯密碼 N 次自動鎖住，擋暴力破解，等同 SSH 那端的
              速率限制。</li>
            <li><b>關閉 Basic 驗證</b>，只走 Kerberos／NTLM——密碼不會以明碼形式在協定層
              傳輸。</li>
          </ol>
        </details>

        <div class="tbl-wrap">
          <table>
            <thead><tr>
              <th>名稱</th><th>類型</th><th>帳號</th><th>適用範圍</th><th>密碼</th><th>更新時間</th><th>操作</th>
            </tr></thead>
            <tbody>
              <tr v-for="c in creds" :key="c.id">
                <td>{{ c.name }}</td>
                <td>{{ c.kind }}</td>
                <td class="mono">{{ c.username }}</td>
                <td class="mono">{{ c.scope || '（通用）' }}</td>
                <td><span class="lockchip">🔒 已加密儲存</span></td>
                <td class="mono dim">{{ c.updated_at }}</td>
                <td><button class="btn danger small" @click="delCred(c.name)">刪除</button></td>
              </tr>
              <tr v-if="!creds.length"><td colspan="7" class="dim">尚未設定任何收集憑證</td></tr>
            </tbody>
          </table>
        </div>

        <div class="card-title" style="margin-top:18px">新增／更新憑證</div>
        <div class="credform">
          <label>名稱<input v-model="newCred.name" placeholder="例：公司網域收集帳號" /></label>
          <label>類型
            <select v-model="newCred.kind">
              <option value="winrm">winrm（Windows 收集）</option>
              <option value="ssh">ssh（Linux 自動納管 bootstrap）</option>
            </select>
          </label>
          <label>帳號<input v-model="newCred.username" autocomplete="off" placeholder="例：DOMAIN\svc_collect 或本機管理員" /></label>
          <label>密碼<input v-model="newCred.password" type="password" autocomplete="new-password" /></label>
          <label>適用範圍<input v-model="newCred.scope" placeholder="網段前綴，如 192.168.1.（留空=通用）" /></label>
          <label>備註<input v-model="newCred.note" placeholder="選填" /></label>
        </div>
        <div class="actions">
          <button class="btn" :disabled="savingCred" @click="saveCred">
            {{ savingCred ? '儲存中…' : '儲存憑證' }}
          </button>
        </div>
      </div>
    </template>

    <!-- B：排程自動納管。授權網段是安全閘門，總開關預設關閉。 -->
    <template v-else-if="activeTab === 'autoonboard'">
      <div class="card">
        <div class="ao-head">
          <div>
            <div class="card-title">排程自動納管 <InfoNote>排程掃描後，自動把<b>授權網段內「已登記卻連不進去」</b>的主機帶到已納管：Linux 用憑證庫裡的 <code>ssh</code> 憑證跑 bootstrap，Windows 走 WinRM 收集（不動目標機）。只碰下方<b>授權且啟用</b>的網段；未登記的主機不會被自動建成資產（那是人的決定）。每次動作都留稽核，<b>永不含密碼</b>。</InfoNote></div>
          </div>
          <label class="ao-switch" :class="{ on: aoEnabled }">
            <input type="checkbox" :checked="aoEnabled" :disabled="aoTogglingEnabled"
                   @change="toggleAutoOnboardEnabled" />
            <span class="ao-switch-track"><span class="ao-switch-knob" /></span>
            <span class="ao-switch-label">{{ aoEnabled ? '排程已啟用' : '排程已關閉' }}</span>
          </label>
        </div>

        <div class="card-title" style="margin-top:18px">授權網段 <InfoNote>只有列在這裡且啟用的網段，排程才會自動納管。前綴用開頭比對，如 <code>192.168.1.</code> 會涵蓋 <code>192.168.1.*</code>。</InfoNote></div>
        <div class="tbl-wrap">
          <table>
            <thead><tr>
              <SortTh k="enabled" :active="segKey" :dir="segDir" @sort="segToggle">啟用</SortTh>
              <SortTh k="prefix" :active="segKey" :dir="segDir" @sort="segToggle">網段前綴</SortTh>
              <SortTh k="note" :active="segKey" :dir="segDir" @sort="segToggle">備註</SortTh>
              <SortTh k="updated_at" :active="segKey" :dir="segDir" @sort="segToggle">更新時間</SortTh>
              <th>操作</th>
            </tr></thead>
            <tbody>
              <tr v-for="s in segSorted" :key="s.id">
                <td>
                  <button class="btn ghost small" :disabled="aoTogglingSeg === s.id"
                          @click="toggleSeg(s)">
                    {{ s.enabled ? '✔ 啟用中' : '停用' }}
                  </button>
                </td>
                <td class="mono">{{ s.prefix }}</td>
                <td>{{ s.note || '—' }}</td>
                <td class="mono dim">{{ s.updated_at }}</td>
                <td><button class="btn danger small" @click="delSeg(s)">移除</button></td>
              </tr>
              <tr v-if="!segSorted.length"><td colspan="5" class="dim">
                還沒有授權任何網段——排程不會自動納管任何主機。
              </td></tr>
            </tbody>
          </table>
        </div>
        <div class="credform" style="margin-top:12px">
          <label>網段前綴<input v-model="newSeg.prefix" placeholder="例：192.168.1." /></label>
          <label>備註<input v-model="newSeg.note" placeholder="選填，如：機房 A 內網" /></label>
        </div>
        <div class="actions">
          <button class="btn" :disabled="aoSavingSeg" @click="saveSeg">
            {{ aoSavingSeg ? '儲存中…' : '授權此網段' }}
          </button>
        </div>

        <div class="ao-run">
          <div>
            <div class="card-title">立即執行一輪 <InfoNote>手動觸發：試連 → 納管授權網段內未納管的 Linux → 收 facts。操作者在場，不受總開關約束，但仍只碰授權網段。會花數秒到數十秒。</InfoNote></div>
          </div>
          <button class="btn" :disabled="aoRunning" @click="runAutoOnboardNow">
            {{ aoRunning ? '執行中…' : '立即執行' }}
          </button>
        </div>
        <div v-if="aoRunResult" class="ao-result">
          候選 <b>{{ aoRunResult.candidates }}</b>｜納管成功 <b>{{ aoRunResult.onboarded }}</b>｜
          失敗 <b>{{ aoRunResult.failed }}</b>｜跳過 <b>{{ aoRunResult.skipped }}</b>
          <ul v-if="aoRunResult.details && aoRunResult.details.length" class="ao-detail">
            <li v-for="(d, i) in aoRunResult.details" :key="i">
              <span class="mono">{{ d.ip }}</span>（{{ d.platform }}）·
              <span :class="d.action === 'onboarded' ? 'ok' : d.action === 'failed' ? 'bad' : 'dim'">
                {{ d.action === 'onboarded' ? '已納管' : d.action === 'failed' ? '失敗' : '跳過' }}
              </span> — {{ d.message }}
            </li>
          </ul>
        </div>

        <div class="card-title" style="margin-top:18px">自動納管稽核</div>
        <div class="tbl-wrap">
          <table>
            <thead><tr>
              <SortTh k="created_at" :active="aaKey" :dir="aaDir" @sort="aaToggle">時間</SortTh>
              <SortTh k="target_ip" :active="aaKey" :dir="aaDir" @sort="aaToggle">目標</SortTh>
              <SortTh k="platform" :active="aaKey" :dir="aaDir" @sort="aaToggle">平台</SortTh>
              <SortTh k="login_user" :active="aaKey" :dir="aaDir" @sort="aaToggle">登入帳號</SortTh>
              <SortTh k="ok" :active="aaKey" :dir="aaDir" @sort="aaToggle">結果</SortTh>
              <th>訊息</th>
            </tr></thead>
            <tbody>
              <tr v-for="(a, i) in aoRecentSorted" :key="i">
                <td class="mono dim">{{ a.created_at }}</td>
                <td class="mono">{{ a.target_ip }}</td>
                <td>{{ a.platform || '—' }}</td>
                <td class="mono">{{ a.login_user || '—' }}</td>
                <td><span :class="a.ok ? 'ok' : 'bad'">{{ a.ok ? '成功' : '失敗' }}</span></td>
                <td>{{ a.message || '—' }}</td>
              </tr>
              <tr v-if="!aoRecentSorted.length"><td colspan="6" class="dim">
                還沒有任何自動納管紀錄。
              </td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </template>

    <!-- VC 自動匯入（方案 B）：Windows 排程匯出 RVTools → 我抓最新檔 -->

    <template v-else-if="activeTab === 'backup'">
      <p v-if="backupError" class="error-text">{{ backupError }}</p>
      <p v-if="backupLoading && !backupHealth" class="muted">檢查中…</p>
      <!-- 沒載入、沒在載、也沒錯誤 → 以前是整塊空白。空白會被讀成「壞了」或「沒東西」，
           兩個都不對，所以明講狀態並給一個按鈕。 -->
      <p v-if="!backupHealth && !backupLoading && !backupError" class="muted">
        尚未檢查備份狀態 · <button class="btn small" @click="loadBackupHealth">立即檢查</button>
      </p>

      <template v-if="backupHealth">
        <div class="bk-hero" :class="backupHealth.status">
          <div class="bk-lamp" :class="backupHealth.status" />
          <div class="bk-hero-text">
            <div class="bk-verdict">備份狀態 · {{ LAMP_LABEL[backupHealth.status] }} <InfoNote>備份用 SQLite 的 VACUUM INTO 產生一致快照（不是直接複製檔案，避免複製到寫入中的頁面），完成後會實際開檔跑 integrity_check——沒驗過的備份不算備份。</InfoNote></div>
            <div v-if="backupHealth.reasons.length === 0" class="bk-sub">
              上次備份成功且在時限內、完整性檢查通過、空間充足。
            </div>
            <ul v-else class="bk-reasons">
              <li v-for="(r, i) in backupHealth.reasons" :key="i">{{ r }}</li>
            </ul>
          </div>
          <div class="bk-actions">
            <button class="btn" type="button" :disabled="backupRunning" @click="runBackupNow">
              {{ backupRunning ? '備份中…' : '立即備份' }}
            </button>
            <button class="btn ghost" type="button" :disabled="backupLoading" @click="loadBackupHealth">
              {{ backupLoading ? '檢查中…' : '重新檢查' }}
            </button>
          </div>
        </div>

        <!-- 加密匯出的金鑰。畫面只留按鈕與欄位，說明進「註」。 -->
        <div class="bk-card" style="margin-bottom:16px">
          <div class="bk-card-title">
            匯出加密金鑰
            <InfoNote>匯出檔會離開這台機器（下載→email），裡面有全公司主機清單、IP、主機名、帳號名與業務系統歸屬。寄錯人或信箱被入侵就是整份資產清冊外流，所以匯出一律加密，<b>只有持私鑰的那台解得開</b>。<br><br>公鑰<b>不需要保密</b>——它只能加密、不能解密，可以直接貼在信裡。所以整個流程<b>不用傳任何密碼</b>。<br><br>收件端按「產生金鑰對」，把公鑰複製到來源端貼上，就完成了。</InfoNote>
          </div>

          <!-- 2026-09-18 使用者：「我自己都會忘，所以我要拿掉，以後功能關閉即可」。
               改成開關、預設關；關著時金鑰欄整個收起來，不用記任何步驟。 -->
          <label v-if="keyStatus" class="enc-toggle">
            <input type="checkbox" :checked="!!keyStatus.encryption_enabled" :disabled="keyBusy"
                   @change="toggleEncryption(($event.target as HTMLInputElement).checked)" />
            匯出時加密：<b>{{ keyStatus.encryption_enabled ? '開' : '關' }}</b>
            <span class="muted small">{{ keyStatus.encryption_enabled ? '（需設定收件人公鑰；只有持私鑰的那台解得開）' : '（直接下載原始檔；每次匯出都會記一筆操作紀錄）' }}</span>
          </label>

          <div v-if="keyStatus && keyStatus.encryption_enabled" class="actions" style="gap:10px;align-items:center;flex-wrap:wrap">
            <template v-if="keyStatus.is_recipient">
              <span class="credhint">本機公鑰指紋 <code>{{ keyStatus.my_fingerprint }}</code>
                <InfoNote>指紋是<b>拿來核對的</b>，不是拿來貼的。貼到來源端的是右邊那串長的（64 個字元）；貼完兩邊指紋一樣，才代表貼對了。</InfoNote>
              </span>
              <!-- 公鑰直接顯示成可選取的欄位。使用者 2026-09-08：「公鑰本來就不需要
                   保密，那就不需要有複製功能」——而且複製按鈕在 http 環境本來就
                   不可靠，一顆可能失敗的按鈕比不上一個一定能選取的欄位。
                   點一下就全選，直接 Ctrl+C。 -->
              <input class="ein" style="flex:1;min-width:320px;font-family:var(--mono,monospace);font-size:12px"
                     :value="keyStatus.my_public_key" readonly
                     title="點一下全選，然後複製"
                     @focus="($event.target as HTMLInputElement).select()"
                     @click="($event.target as HTMLInputElement).select()" />
              <InfoNote>把這串貼到<b>來源端</b>（要匯出資料的那台）的「收件人公鑰」欄位。私鑰留在這台，不要外流也不要複製走。<br><br>⚠️ 私鑰弄丟＝過去所有加密匯出永遠打不開。備援做法見 <code>AI/SOP_匯出加密金鑰保管.md</code>。</InfoNote>
            </template>
            <template v-else>
              <button class="btn" type="button" :disabled="keyBusy" @click="genKeypair">
                {{ keyBusy ? '產生中…' : '產生金鑰對' }}
              </button>
              <InfoNote>只在<b>收件端</b>（要解開匯出檔的那台）按。私鑰會落在 <code>{{ keyStatus.private_key_path }}</code>（0600）。<br><br>⚠️ 已經有私鑰時會拒絕、不覆蓋——覆蓋之後過去所有加密匯出就永遠打不開了，而且是無聲的（畫面顯示成功，要還原時才發現）。</InfoNote>
            </template>
          </div>

          <div v-if="keyStatus && keyStatus.encryption_enabled" class="actions" style="gap:10px;align-items:center;margin-top:10px;flex-wrap:wrap">
            <span class="credhint" style="min-width:96px">收件人公鑰</span>
            <input v-model="recipientInput" class="ein" style="flex:1;min-width:280px"
                   :placeholder="keyStatus.recipient_fingerprint ? `已設定（指紋 ${keyStatus.recipient_fingerprint}）` : '貼上收件端的公鑰'"
                   :disabled="keyBusy" @keyup.enter="saveRecipient" />
            <button class="btn" type="button" :disabled="keyBusy || !recipientInput" @click="saveRecipient">儲存</button>
            <InfoNote>來源端（要匯出的那台）貼收件端的公鑰。沒設定就<b>不能匯出</b>——寧可擋下來，也不要給一份沒有保護的檔案。</InfoNote>
          </div>
        </div>

        <div class="bk-card" style="margin-bottom:16px">
          <div class="bk-card-title">匯出全部資料（下載到你的電腦） <InfoNote>跟上面的備份不同——這是直接下載一份完整資料的複本到你的電腦，用於搬機／備份轉移。<br><br>存在伺服器上的備份<b>不加密</b>（自己救得回來）。這份會離開機器：上方「匯出時加密」開著就加密（順便壓縮，45MB 壓完約 4MB）；關著就是原始檔，每次匯出記一筆操作紀錄。</InfoNote></div>
          <div class="actions" style="gap:10px;align-items:center">
            <select v-model="dumpFormat" style="padding:8px 12px;border-radius:6px;border:1px solid var(--border-strong);background:var(--card);color:var(--ink)">
              <option value="binary">二進位資料庫（.db）</option>
              <option value="sql">文字 SQL（.sql）</option>
            </select>
            <button class="btn" type="button" :disabled="dumpRunning" @click="downloadDump">
              {{ dumpRunning ? '匯出中…' : '⬇ 下載' }}
            </button>
            <label style="display:flex;align-items:center;gap:6px;font-size:12.5px">
              <input v-model="dumpSplit" type="checkbox" />
              切成 10MB 一片（給 email）
              <InfoNote>檔太大要當 email 附件寄時勾這個。會打包成一個 zip，解壓後是 <code>.001/.002…</code> 每片 ≤10MB，逐片寄信；內附併回說明（Windows <code>copy /b</code>／Linux <code>cat</code>）。下載本身走區網、不受 10MB 限制。</InfoNote>
            </label>
          </div>
        </div>

        <div v-if="isEnabled('restore')" class="bk-card" style="margin-bottom:16px;border-color:rgba(224,108,108,.45)">
          <div class="bk-card-title" style="color:var(--bad)">⚠ 資料庫還原（整庫覆蓋）</div>
          <p class="credhint" style="margin:6px 0 12px">
            上傳一份先前用「匯出全部資料」下載的檔案（加密的 <code>.enc</code> 或伺服器備份的 <code>.db</code>），會<b>整個覆蓋掉現在的正式資料庫</b>。
            這個動作不可逆，覆蓋前系統會自動先把現有資料存證一份到伺服器本機備份目錄，但那是最後防線，
            不是「反悔按鈕」。確定要做才繼續。<br>
            <b style="color:var(--warn-text)">還原成功後你會被自動登出</b>——帳號與登入階段也存在同一個資料庫裡，
            整庫覆蓋會一併換成上傳檔裡的那份。請改用<b>上傳檔中的帳號密碼</b>重新登入。
          </p>
          <div class="actions" style="gap:10px;align-items:center;flex-wrap:wrap">
            <input type="file" accept=".db" @change="onRestoreFileChange">
            <input
              v-model="restoreConfirmText" type="text"
              :placeholder="`輸入「${RESTORE_CONFIRM_WORD}」以啟用下方按鈕`"
              style="padding:8px 12px;border-radius:6px;border:1px solid var(--border-strong);background:var(--card);color:var(--ink);min-width:220px"
            >
            <button
              class="btn danger" type="button"
              :disabled="restoreRunning || !restoreFile || restoreConfirmText !== RESTORE_CONFIRM_WORD"
              @click="runRestore"
            >
              {{ restoreRunning ? '還原中…' : '⚠ 覆蓋還原' }}
            </button>
          </div>
        </div>

        <div class="bk-grid">
          <div class="bk-card">
            <div class="bk-card-title">上次備份</div>
            <template v-if="backupHealth.last_backup">
              <div class="bk-big">{{ backupHealth.last_backup.modified_at }}</div>
              <div class="bk-line">
                {{ backupHealth.last_backup.age_hours }} 小時前 ·
                {{ fmtBytes(backupHealth.last_backup.size_bytes) }}
              </div>
              <div class="bk-line">
                完整性檢查
                <span :class="backupHealth.last_backup.integrity_ok ? 'ok' : 'bad'">
                  {{ backupHealth.last_backup.integrity_ok ? 'PASS' : 'FAIL' }}
                </span>
                <span v-if="!backupHealth.last_backup.integrity_ok" class="bk-detail">
                  {{ backupHealth.last_backup.integrity_detail }}
                </span>
              </div>
            </template>
            <div v-else class="bk-line bad">還沒有任何備份</div>
          </div>

          <div class="bk-card">
            <div class="bk-card-title">本地備份</div>
            <div class="bk-big">{{ backupHealth.local.count }} 份</div>
            <div class="bk-line">保留 {{ backupHealth.local.retention_days }} 天，超過自動刪除</div>
            <div class="bk-line">
              磁碟剩餘
              {{ backupHealth.local.free_mb === null ? '—' : backupHealth.local.free_mb + ' MB' }}
            </div>
            <div class="bk-path">{{ backupHealth.local.dir }}</div>
          </div>

          <div class="bk-card">
            <div class="bk-card-title">異地備份 <InfoNote>只有本地一份，磁碟壞掉就跟正本一起沒了。設定一個指到<b>另一台機器</b>的路徑（例如掛載 222 的 <code>/ai_backup</code>）才算真異地。設好後按上方「立即備份」測一次；複製成功、有備份份數，燈就會轉綠。掛載步驟見 <code>AI/SOP_異地備份_掛載222.md</code>。</InfoNote></div>
            <template v-if="backupHealth.offsite.configured">
              <div class="bk-big">{{ backupHealth.offsite.count }} 份</div>
              <div class="bk-path">{{ backupHealth.offsite.dir }}</div>
            </template>
            <template v-else>
              <div class="bk-big warn">未設定</div>
            </template>
            <div class="bk-offsite-edit">
              <input v-model="offsiteDraft" class="bk-offsite-input"
                     placeholder="例：/mnt/ai_backup（掛載 222:/ai_backup），留空=清除" />
              <button class="btn small" :disabled="savingOffsite" @click="saveOffsite">
                {{ savingOffsite ? '儲存中…' : '儲存' }}
              </button>
            </div>
          </div>

          <div class="bk-card">
            <div class="bk-card-title">資料庫本身</div>
            <div class="bk-line">
              完整性
              <span :class="backupHealth.db.integrity_ok ? 'ok' : 'bad'">
                {{ backupHealth.db.integrity_ok ? 'PASS' : 'FAIL' }}
              </span>
            </div>
            <div class="bk-line">
              日誌模式
              <span :class="backupHealth.db.journal_mode === 'wal' ? 'ok' : 'warn'">
                {{ backupHealth.db.journal_mode ?? '—' }}
              </span>
            </div>
            <div class="bk-line">大小 {{ fmtBytes(backupHealth.db.size_bytes) }}</div>
            <div class="bk-path">{{ backupHealth.db.path }}</div>
          </div>
        </div>

        <p class="bk-foot">檢查時間 {{ backupHealth.checked_at }}</p>
      </template>
    </template>

    <template v-else-if="activeTab === 'schedule'">
      <div class="sched-card">
        <div class="sched-row">
          <span class="sched-label">自動掃描 <InfoNote>改了<b>馬上生效</b>，不用重新部署、也不用進主機改設定檔。維護當天可先「停用」暫停自動掃描，事後再啟用；想立刻掃一次，用儀表板右上的「重新掃描」。</InfoNote></span>
          <label class="switch">
            <input v-model="schedule.enabled" type="checkbox" />
            <span>{{ schedule.enabled ? '啟用' : '已停用（維護時可暫停）' }}</span>
          </label>
        </div>
        <div class="sched-row">
          <span class="sched-label">頻率</span>
          <select v-model="schedule.mode" class="cell-input">
            <option value="daily">每日固定時間</option>
            <option value="weekly">每週固定時間</option>
            <option value="interval">每隔 N 小時</option>
          </select>
        </div>
        <!-- 每週（2026-09-16 使用者：「每週一次，時間我再指定」）：
             全網段存活掃描一輪要幾分鐘，不必每天跑；但每天跑的人也不受影響，daily 沒動。 -->
        <div v-if="schedule.mode === 'weekly'" class="sched-row">
          <span class="sched-label">每週</span>
          <select v-model.number="schedule.weekday" class="cell-input narrow">
            <option v-for="(w, i) in WEEKDAYS" :key="i" :value="i">{{ w }}</option>
          </select>
          <input v-model="schedule.time" type="time" class="cell-input" />
        </div>
        <div v-else-if="schedule.mode === 'daily'" class="sched-row">
          <span class="sched-label">執行時間</span>
          <input v-model="schedule.time" type="time" class="cell-input" />
        </div>
        <div v-else class="sched-row">
          <span class="sched-label">間隔</span>
          <input v-model="schedule.interval_hours" type="number" min="1" max="168" class="cell-input narrow" />
          <span class="sched-unit">小時掃一次</span>
        </div>
        <div class="sched-actions">
          <button class="btn small" :disabled="savingSchedule" @click="saveSchedule">
            {{ savingSchedule ? '儲存中…' : '儲存排程' }}
          </button>
        </div>
      </div>

      <!-- 掃描範圍（2026-09-16）：排程要掃哪些網段，以網段配置表為準。
           以前這件事沒有入口，connections 是空的 → 只掃本機一段 → 其餘全被判失聯。 -->
      <ScanScope />

      <!-- 各網段自訂時間已併進上面的「掃描範圍」表（2026-09-17 使用者：
           「看這兩個表要不要整合在一起？我會認為上面的打勾了就是已經啟動了，
           我根本不會再去看它自己掃描的時間是什麼」）。
           同一批網段列兩張表，會讓人以為下面那張是必填——其實勾了就會掃，
           自訂時間只是讓某些網段錯開。 -->

    </template>

    <template v-else-if="activeTab === 'mail'">
      <!-- 為什麼現在不會寄，要在最上面講清楚。只放一個開關的話，
           人會把它打開、以為好了，然後一整週沒有半封信，也不知道為什麼。 -->
      <p v-if="mailCorrupt" class="error-text">
        寄信設定讀不出來（內容壞掉，不是沒設定）：{{ mailCorrupt }}
      </p>
      <p v-if="mailMissing.length" class="error-text">
        還缺：{{ mailMissing.join('、') }}——填齊才能啟用。
      </p>
      <p v-if="!mailAdReady" class="error-text">
        AD 名單還沒匯入，查不到任何人的信箱。請先到「6 資料匯入」(/import) 匯入。
      </p>

      <div class="sched-card">
        <div class="sched-row">
          <span class="sched-label">自動寄送
            <InfoNote>每週一與每月 1 號到點各寄一期（撞在一起時只寄月報那一封）。寄不成功會在一小時後自己補寄，不是整週不寄。<b>預設是關的</b>——設定沒填完的系統不會自己開始對外寄信。</InfoNote>
          </span>
          <label class="switch">
            <input v-model="mail.enabled" type="checkbox" />
            <span>{{ mail.enabled ? '啟用' : '已停用（不會寄任何信）' }}</span>
          </label>
        </div>
        <div class="sched-row">
          <span class="sched-label">SMTP 主機</span>
          <input v-model="mail.smtp_host" class="cell-input" placeholder="例：10.0.0.25" />
          <span class="sched-unit">埠</span>
          <input v-model.number="mail.smtp_port" type="number" min="1" max="65535"
                 class="cell-input narrow" placeholder="25" />
        </div>
        <div class="sched-row">
          <span class="sched-label">寄件者
            <InfoNote>收信的人會回信到這個地址，填一個真的收得到的信箱。</InfoNote>
          </span>
          <input v-model="mail.mail_from" class="cell-input" placeholder="webit3@公司網域" />
        </div>
        <div class="sched-row">
          <span class="sched-label">寄送時間</span>
          <input v-model="mail.send_time" type="time" class="cell-input" />
        </div>
        <div class="sched-row">
          <span class="sched-label">到期門檻
            <InfoNote>剩幾天要提醒。同一筆只在<b>跨進更急的一級</b>時才再寄一次，不會 60/30/14 各寄一次洗版。</InfoNote>
          </span>
          <input v-model="mailBuckets" class="cell-input" placeholder="14,30,60" />
          <span class="sched-unit">天（逗號分隔）</span>
        </div>
        <div class="sched-row">
          <span class="sched-label">找不到負責人時寄給
            <InfoNote>沒填負責人、AD 查無此人、同名疑慮、帳號已停用——這四種都不會靜靜跳過，會集中寄到這個信箱。沒填的話這批弱點就沒有人收得到。</InfoNote>
          </span>
          <input v-model="mail.fallback_to" class="cell-input" placeholder="例：資安信箱" />
        </div>
        <div class="sched-row">
          <span class="sched-label">主旨前綴
            <InfoNote>會加在每封信主旨最前面，收信端可以用它做規則分類。空白就不加。</InfoNote>
          </span>
          <input v-model="mail.subject_prefix" class="cell-input" placeholder="例：[資安]" />
        </div>
        <div class="sched-row">
          <span class="sched-label">一律副本給
            <InfoNote>固定窗口，每一封都副本（含「沒人收」與「本期 0 筆」那兩種）。跟下面的主管副本是兩件事：這個是全域固定的，主管是依人不同（走 AD 資料）。</InfoNote>
          </span>
          <input v-model="mail.always_cc" class="cell-input" placeholder="逗號分隔" />
        </div>
        <div class="sched-row">
          <span class="sched-label">只通知這些單位
            <InfoNote><b>都不選＝全部通知</b>。選了單位就只通知那幾個單位的人；不在範圍內的弱點<b>不會消失</b>，會併進「沒人收」寄給代收信箱。</InfoNote>
          </span>
          <select v-model="mail.only_depts" multiple class="cell-input multi" @change="onDeptChange">
            <option v-for="d in mailDepts" :key="d.dept" :value="d.dept">
              {{ d.dept }}（{{ d.n }} 人）
            </option>
          </select>
        </div>
        <div class="sched-row">
          <span class="sched-label">只通知這些人
            <InfoNote>挑了人就<b>以人為準</b>，上面的單位設定不會再把別人放進來。都不選＝該單位全部。</InfoNote>
          </span>
          <select v-model="mail.only_people" multiple class="cell-input multi">
            <option v-for="x in mailPeople" :key="x.employee_id" :value="x.employee_id">
              {{ x.display_name }}（{{ x.dept_name || '未填單位' }}）
            </option>
          </select>
        </div>
        <div class="sched-row">
          <span class="sched-label">月報給主管副本</span>
          <label class="switch">
            <input v-model="mail.manager_cc" type="checkbox" />
            <span>{{ mail.manager_cc !== false ? '副本給主管' : '不給副本' }}</span>
          </label>
        </div>
        <div class="sched-actions">
          <button class="btn small" :disabled="savingMail" @click="saveMail">
            {{ savingMail ? '儲存中…' : '儲存設定' }}
          </button>
          <button class="btn small ghost" @click="previewMail">預覽這期（不寄）</button>
          <button class="btn small ghost" @click="runMailNow">立刻寄一期</button>
        </div>
      </div>

      <template v-if="mailPreview">
        <div class="section-divider">預覽：月報範圍（沒有寄出，也沒有動任何一筆的通知狀態）</div>
        <p v-if="!mailPreview.ok" class="error-text">{{ mailPreview.reason }}</p>
        <p v-else-if="mailPreview.ok && !mailPreview.details.length" class="muted">
          這期沒有任何到期弱點要通知。
        </p>
        <!-- 「沒人收」那一籃要在預覽就看得到：那正是設定完最該先確認的一件事。
             沒填代收信箱的話，這批弱點不會有任何人收到。 -->
        <p v-if="mailPreview.orphan_items" class="error-text">
          有 {{ mailPreview.orphan_items }} 筆找不到收件人（沒填負責人／AD 查無此人／同名疑慮／帳號已停用）；
          {{ mail.fallback_to ? `會集中寄到 ${mail.fallback_to}` : '而且還沒設代收信箱——這批不會有任何人收到' }}。
        </p>
        <div v-if="mailPreview.details.length" class="tbl-wrap">
        <table>
          <thead>
            <tr><th>收件人</th><th>副本</th><th>筆數</th><th>主旨</th></tr>
          </thead>
          <tbody>
            <tr v-for="(d, i) in mailPreview.details" :key="i">
              <td>{{ d.to }}</td>
              <td>{{ (d.cc || []).join('、') || '—' }}</td>
              <td>{{ d.count }}</td>
              <td>{{ d.subject }}</td>
            </tr>
          </tbody>
        </table>
        </div>
      </template>

      <!-- 「寄了 0 封」與「根本沒跑」要分得出來：只給數字不給依據，等於要人用猜的。 -->
      <div class="section-divider">最近幾期</div>
      <p v-if="!mailRuns.length" class="muted">還沒有任何一期跑過。</p>
      <div v-else class="tbl-wrap">
      <table>
        <thead>
          <tr><th>日期</th><th>班表</th><th>開始</th><th>寄出</th><th>失敗</th><th>狀態</th></tr>
        </thead>
        <tbody>
          <tr v-for="(r, i) in mailRuns" :key="i">
            <td>{{ r.run_date }}</td>
            <td>{{ r.schedule === 'weekly' ? '週報' : r.schedule === 'monthly' ? '月報' : '手動' }}</td>
            <td>{{ r.started_at }}</td>
            <td>{{ r.sent }}</td>
            <td>{{ r.failed }}</td>
            <td>{{ r.config_ok && !r.failed ? '完成' : (r.reason || '有信沒寄成') }}</td>
          </tr>
        </tbody>
      </table>
      </div>
    </template>
  </div>
</template>

<style scoped>
.section-divider {
  margin: 0 0 16px;
  font-size: 11px;
  color: var(--brand-dark);
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.04em;
}
.cell-input.multi {
  min-height: 92px;
  min-width: 220px;
}

.tabs {
  display: flex;
  gap: 2px;
  margin-bottom: 14px;
  border-bottom: 1px solid var(--border);
}
.tab {
  padding: 8px 16px;
  font-size: 12.5px;
  color: var(--ink-soft);
  cursor: pointer;
  border-bottom: 2px solid transparent;
  margin-bottom: -1px;
}
.tab.active {
  color: var(--brand-dark);
  font-weight: 700;
  border-bottom-color: var(--brand);
}
.error-text {
  color: var(--bad);
  font-size: 13px;
  margin-bottom: 14px;
}

/* ===== S14 備份與健康 =====
   燈號用顏色 + 文字雙軌（「正常/需要注意/有問題」），不只靠顏色分辨——
   色盲使用者看不出紅綠差別時，文字仍然講得清楚。 */
.tab-lamp {
  display: inline-block;
  width: 7px; height: 7px;
  border-radius: 50%;
  margin-left: 6px;
  vertical-align: middle;
}
.tab-lamp.green { background: var(--brand); }
.tab-lamp.yellow { background: #d99a2b; }
.tab-lamp.red { background: var(--bad); }

.bk-hero {
  display: flex;
  align-items: flex-start;
  gap: 16px;
  padding: 18px 20px;
  border-radius: 12px;
  border: 1px solid var(--border-strong);
  border-left-width: 4px;
  margin-bottom: 18px;
  flex-wrap: wrap;
}
.bk-hero.green { border-left-color: #009142; }
.bk-hero.yellow { border-left-color: #d99a2b; }
.bk-hero.red { border-left-color: #d9534f; }
.bk-lamp {
  width: 15px; height: 15px;
  border-radius: 50%;
  margin-top: 4px;
  flex-shrink: 0;
}
.bk-lamp.green { background: var(--brand); }
.bk-lamp.yellow { background: #d99a2b; }
.bk-lamp.red { background: var(--bad); }
.bk-hero-text { flex: 1; min-width: 240px; }
.bk-verdict { font-size: 15px; font-weight: 700; margin-bottom: 5px; }
.bk-sub { font-size: 13px; opacity: 0.8; }
.bk-reasons { margin: 4px 0 0; padding-left: 18px; font-size: 13px; line-height: 1.7; }
.bk-actions { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }

.bk-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
  gap: 12px;
}
.bk-card {
  border: 1px solid var(--border-strong);
  border-radius: 10px;
  padding: 14px 16px;
}
.bk-card-title { font-size: 12px; opacity: 0.65; margin-bottom: 8px; }
.bk-big { font-size: 19px; font-weight: 700; margin-bottom: 6px; }
.bk-big.warn { color: var(--warn-text); }
.bk-line { font-size: 12.5px; line-height: 1.7; }
.bk-line .ok { color: var(--brand-dark); font-weight: 700; }
.bk-line .bad { color: var(--bad); font-weight: 700; }
.bk-line .warn { color: var(--warn-text); font-weight: 700; }
.bk-line.bad { color: var(--bad); }
.bk-detail { display: block; opacity: 0.7; font-size: 11.5px; }
.bk-path {
  margin-top: 8px;
  font-size: 11.5px;
  opacity: 0.55;
  word-break: break-all;
}
.bk-foot { font-size: 12px; opacity: 0.65; line-height: 1.7; margin-top: 16px; }
.bk-foot code { font-size: 11.5px; }
.muted { opacity: 0.7; font-size: 14px; }

/* ===== 從資產推導掃描網段 ===== */
.segbox { border: 1px solid rgba(15,23,42,.08); border-radius: 10px;
  padding: 14px 16px; margin-bottom: 16px; background: rgba(15,23,42,.02); }
.segbar { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; }
.segbar + .segbar { margin-top: 12px; }
.seghint { font-size: 12px; opacity: .6; line-height: 1.5; }
.segsum { margin: 12px 0 8px; font-size: 13px; opacity: .85; }
.segsum b { font-weight: 600; }
.segsum .warn { color: var(--warn-text); }
.segtbl { max-height: 320px; overflow-y: auto; }
.segtbl code { font-size: 12px; }
/* 同一網段跨多個機房：不是錯誤，但值得看一眼，所以標示而不擋 */
.mixed { margin-left: 6px; font-size: 11px; color: var(--warn-text); opacity: .9; cursor: help; }
.segdone { margin: 12px 0 0; font-size: 13px; opacity: .7; }
.segok { margin: 12px 0 0; font-size: 13px; color: var(--brand-dark); }
.segwarn { margin: 10px 0 0; font-size: 12px; color: var(--warn-text); opacity: .85; line-height: 1.6; }
.notice-banner {
  background: var(--warn-soft);
  color: var(--warn-text);
  border: 1px solid var(--border-strong);
  padding: 8px 14px;
  font-size: 12.5px;
  margin-bottom: 14px;
}
.modules-hint {
  font-size: 12px;
  color: var(--muted);
}
.tbl-wrap {
  overflow-x: auto;
  border: 1px solid var(--border);
  margin-bottom: 14px;
}
table {
  border-collapse: collapse;
  width: 100%;
  font-size: 12.5px;
  min-width: 720px;
}
th, td {
  text-align: left;
  padding: 8px 12px;
  border-bottom: 1px solid var(--border);
}
th {
  color: var(--ink-soft);
  font-weight: 700;
  font-size: 12px;
  background: var(--mint);
}
tr:last-child td {
  border-bottom: none;
}
.tgl { font-family: inherit; font-size: 11.5px; font-weight: 700; padding: 3px 10px;
  border-radius: 999px; cursor: pointer; border: 1px solid var(--border-strong);
  background: transparent; color: var(--muted); }
.tgl.on { border-color: var(--good); color: var(--brand-dark); background: var(--good-soft); }
.tgl:disabled { opacity: .5; cursor: default; }
tr.off { opacity: .55; }
.credhint { font-size: 11.5px; color: var(--muted); line-height: 1.7; margin: 0 0 14px; }
.credhint code { color: var(--brand-dark); }
.credhint b { color: var(--ink-soft); }
.compensating {
  margin: 0 0 14px;
  padding: 10px 14px;
  border: 1px solid var(--border-strong);
  border-radius: 6px;
  background: var(--mint);
}
.compensating summary {
  cursor: pointer;
  font-size: 12.5px;
  font-weight: 700;
  color: var(--ink-soft);
}
.compensating .credhint { margin: 10px 0; }
.compensating ol.credhint { padding-left: 18px; }
.compensating ol.credhint li { margin-bottom: 8px; }
.lockchip { font-size: 11px; color: var(--brand-dark); background: var(--good-soft); padding: 2px 8px; border-radius: 4px; }
.credform { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 10px 14px; }
.credform label { display: flex; flex-direction: column; gap: 4px; font-size: 11.5px; color: var(--muted); }
.credform input, .credform select { font-family: inherit; font-size: 13px; padding: 7px 10px;
  border: 1px solid var(--border-strong); background: var(--card); color: var(--ink); }
.btn.danger { background: var(--bad); }
.cell-input {
  width: 130px;
  padding: 5px 8px;
  border: 1px solid var(--border-strong);
  font-family: inherit;
  font-size: 12.5px;
  background: var(--card);
  color: var(--ink);
}
.cell-input.narrow {
  width: 55px;
}
.muted-cell {
  color: var(--muted);
}
.actions-cell {
  white-space: nowrap;
  display: flex;
  gap: 6px;
}
.btn {
  font-family: inherit;
  font-weight: 700;
  border: none;
  background: var(--brand);
  color: #fff;
  cursor: pointer;
}
.btn:hover:not(:disabled) {
  background: var(--brand-dark);
}
.btn:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}
.btn.ghost {
  background: var(--card);
  border: 1px solid var(--border-strong);
  color: var(--ink-soft);
}
.btn.small {
  padding: 5px 10px;
  font-size: 11.5px;
}
.status-dot {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  font-size: 12px;
  font-weight: 700;
}
.status-dot .d {
  width: 9px;
  height: 9px;
  border-radius: 50%;
}
.status-dot.green {
  color: var(--brand-dark);
}
.status-dot.green .d {
  background: var(--good);
}
.status-dot.red {
  color: var(--bad);
}
.status-dot.red .d {
  background: var(--bad);
}
.status-dot.gray {
  color: var(--muted);
}
.status-dot.gray .d {
  background: var(--muted);
}
.diagram-placeholder {
  border: 1px solid var(--border);
  background: var(--card);
  padding: 40px;
  text-align: center;
  color: var(--muted);
  font-size: 13px;
}
.diagram-wrap {
  border: 1px solid var(--border);
  background: var(--card);
  padding: 18px;
}
.node {
  fill: var(--mint);
  stroke: var(--border-strong);
  stroke-width: 1.4;
}
.node-label {
  font-size: 11px;
  fill: var(--ink);
  font-weight: 700;
}
.node-sub {
  font-size: 9px;
  fill: var(--muted);
}
.edge-green {
  stroke: var(--good);
  stroke-width: 2.4;
}
.edge-red {
  stroke: var(--bad);
  stroke-width: 2.4;
  stroke-dasharray: 5 3;
}
.edge-gray {
  stroke: var(--muted);
  stroke-width: 2;
  stroke-dasharray: 2 3;
}
.edge-label {
  font-size: 9.5px;
  fill: var(--ink-soft);
}
.legend-list {
  margin-top: 14px;
  padding-top: 12px;
  border-top: 1px dashed var(--border);
  font-size: 12px;
  color: var(--ink-soft);
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.legend-list .mk {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 16px;
  height: 16px;
  border-radius: 50%;
  color: var(--ink);
  font-size: 9.5px;
  font-weight: 700;
  flex-shrink: 0;
  margin-right: 7px;
}
.legend-list .row-l {
  display: flex;
  align-items: center;
}
.sched-card {
  border: 1px solid var(--border);
  background: var(--card);
  padding: 20px 22px;
  max-width: 460px;
}
.sched-title { font-size: 14px; font-weight: 600; color: var(--ink); margin-bottom: 12px; }
.segtime { width: 100%; border-collapse: collapse; font-size: 13px; }
.segtime th, .segtime td { border-bottom: 1px solid var(--border); padding: 7px 8px; text-align: left; }
.segtime th { color: var(--ink-soft); font-weight: 600; font-size: 12px; }
.segtime .btn.small { margin-right: 6px; }
.dim { color: var(--ink-soft); }
.dim.sm, .sm { font-size: 11px; }
.sched-row {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 16px;
}
.sched-label {
  width: 84px;
  font-size: 12.5px;
  font-weight: 700;
  color: var(--ink-soft);
  flex-shrink: 0;
}
.sched-unit {
  font-size: 12.5px;
  color: var(--ink-soft);
}
.switch {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  font-size: 12.5px;
  color: var(--ink);
  cursor: pointer;
}
.sched-actions {
  margin: 4px 0 14px;
}

/* B：排程自動納管 */
.ao-head { display: flex; justify-content: space-between; align-items: flex-start; gap: 20px; flex-wrap: wrap; }
.ao-switch { display: inline-flex; align-items: center; gap: 9px; cursor: pointer; flex-shrink: 0; }
.ao-switch input { position: absolute; opacity: 0; width: 0; height: 0; }
.ao-switch-track {
  width: 44px; height: 24px; border-radius: 999px; background: var(--line, #33414f);
  position: relative; transition: background 0.18s; flex-shrink: 0;
}
.ao-switch-knob {
  position: absolute; top: 3px; left: 3px; width: 18px; height: 18px; border-radius: 50%;
  background: #fff; transition: transform 0.18s;
}
.ao-switch.on .ao-switch-track { background: var(--brand); }
.ao-switch.on .ao-switch-knob { transform: translateX(20px); }
.ao-switch-label { font-size: 12.5px; color: var(--ink-soft, #cbd5e1); font-weight: 600; }
.ao-run {
  display: flex; justify-content: space-between; align-items: center; gap: 20px; flex-wrap: wrap;
  margin-top: 20px; padding-top: 16px; border-top: 1px solid var(--line, #2a3642);
}
.ao-result { margin-top: 12px; font-size: 13px; color: var(--ink-soft, #cbd5e1); }
.ao-result b { color: var(--brand-dark); }
.ao-detail { margin: 8px 0 0; padding-left: 18px; font-size: 12px; line-height: 1.75; }
.ao-detail .ok { color: var(--brand-dark); font-weight: 700; }
.ao-detail .bad { color: var(--bad); font-weight: 700; }
.ao-detail .dim { color: var(--muted); }
td .ok { color: var(--brand-dark); font-weight: 700; }
td .bad { color: var(--bad); font-weight: 700; }
.vc-cmd {
  display: flex; align-items: center; gap: 10px;
  background: var(--code-bg, #0d1b26); border: 1px solid var(--line, #2a3642);
  border-radius: 6px; padding: 10px 12px; overflow-x: auto;
}
.vc-cmd code {
  flex: 1; font-family: 'Space Grotesk', ui-monospace, monospace; font-size: 12px;
  color: var(--brand-dark); white-space: nowrap;
}
.vc-cmd .btn { flex-shrink: 0; }
.bk-offsite-edit { display: flex; gap: 8px; margin-top: 10px; }
.bk-offsite-input {
  flex: 1; min-width: 0; font-family: inherit; font-size: 12px; padding: 6px 9px;
  border: 1px solid var(--line, #33414f); border-radius: 5px;
  background: var(--card, #12212c); color: var(--ink, #e6edf3);
}
.enc-toggle { display: flex; gap: 8px; align-items: center; margin: 4px 0 10px; font-size: 13px; cursor: pointer; }
</style>
