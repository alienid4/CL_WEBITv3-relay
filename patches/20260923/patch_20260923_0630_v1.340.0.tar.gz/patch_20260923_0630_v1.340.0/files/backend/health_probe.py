"""主機自我檢查（值班即時健檢）。

值班情境（2026-09-21 使用者）：WhatsUp Gold 對某台發告警（當機／服務異常），
值班的人不知道是誤報還是真出事。輸入 IP → 這裡對那台**唯讀**跑一輪、一次掃過
一台 Linux 主機該看的面向，產出可回報的證據。

## 檢查面向（專業健檢，不是只看四樣）
- 可達性：連得上？剛重開機（uptime<10 分＝可能剛當過）？OS／kernel。
- CPU：load÷核數、使用率、**iowait（磁碟瓶頸的關鍵指標）**、吃最兇前 5。
- 記憶體：用量、**swap**、吃最兇前 5。
- 磁碟：每掛載空間%、**inode%（空間夠但 inode 滿照樣當）**、**唯讀重掛（磁碟故障徵兆）**。
- 網路：介面丟包／錯誤、TCP established 數。
- 服務：**systemctl --failed（掛掉的服務直接列）**、監聽 port＋服務、殭屍進程、進程數。
- 時間：NTP 同步（時間飄會連鎖出怪事）。

## 判定：多訊號、絕對閾值
單一動態值不亂判；絕對閾值不依賴 baseline（baseline 比較是批次 2）。
連不上、唯讀重掛、有 failed unit＝紅（這些幾乎一定是真問題）。

## 權限與界線（批次 1：免提權）
- 以上**全部免提權**（df／/proc／ss／systemctl --failed／ps／timedatectl 一般帳號就收得到）。
- 讀 log（dmesg 的 OOM／I/O error、journalctl -p err）要 root／sudo，是**批次 3**，本檔不碰。
- 走既有收集管道：webit3scan ＋ collector 金鑰、系統 ssh（同 service_collector），非 paramiko。
- 只打已知目標；並發上限見 api；只支援 Linux（非 Linux 回 skipped，不假裝檢查過）。
"""
from __future__ import annotations

import datetime as _dt
import subprocess

import manage_state as ms

# ===== 判定門檻（絕對閾值，不依賴 baseline）=====
DISK_RED, DISK_YELLOW = 90, 80          # 空間使用率 %
INODE_RED, INODE_YELLOW = 90, 80        # inode 使用率 %
MEM_RED, MEM_YELLOW = 90, 80            # 記憶體使用率 %
SWAP_RED, SWAP_YELLOW = 80, 50          # swap 使用率 %（一直吃 swap＝記憶體壓力）
LOAD_RED, LOAD_YELLOW = 1.0, 0.7        # load1 ÷ 核數
IOWAIT_RED, IOWAIT_YELLOW = 50, 25      # CPU 花在等 I/O 的 %（磁碟塞住）
CPU_RED, CPU_YELLOW = 95, 85            # CPU 總使用率 %
UPTIME_FRESH_MIN = 10                   # 開機不到這麼久＝剛重開（可能剛當過），標黃
ZOMBIE_YELLOW = 10                      # 殭屍進程數
NETDROP_YELLOW = 1000                   # 介面累計丟包／錯誤（大量才提示）

# 掛載點雜訊：暫存／虛擬檔案系統滿不滿沒有維運意義，排掉不然一堆假黃燈。
_DF_X = "-x tmpfs -x devtmpfs -x overlay -x squashfs -x aufs -x iso9660"

# 一次 SSH 收完所有指標（減少往返）。marker 切段，解析端各認自己那段。
# CPU 使用率／iowait 要兩次取樣算差，中間 sleep 1。
_METRICS_CMD = (
    "echo @@OS; uname -sr 2>/dev/null; grep PRETTY_NAME /etc/os-release 2>/dev/null; "
    "echo @@UP; cat /proc/uptime 2>/dev/null; "
    "echo @@LOAD; cat /proc/loadavg 2>/dev/null; "
    "echo @@CPU; nproc 2>/dev/null || getconf _NPROCESSORS_ONLN 2>/dev/null "
    "|| grep -c ^processor /proc/cpuinfo 2>/dev/null; "
    "echo @@STAT1; grep '^cpu ' /proc/stat 2>/dev/null; sleep 1; "
    "echo @@STAT2; grep '^cpu ' /proc/stat 2>/dev/null; "
    "echo @@MEM; cat /proc/meminfo 2>/dev/null; "
    "echo @@DF; df -P -k " + _DF_X + " 2>/dev/null; "
    "echo @@DFI; df -P -i " + _DF_X + " 2>/dev/null; "
    "echo @@MOUNTS; cat /proc/mounts 2>/dev/null; "
    "echo @@FAILED; systemctl --failed --no-legend --plain 2>/dev/null; "
    # 失敗的 unit 再補問三件事，因為「failed」對兩種 unit 的意思完全不同：
    #   Type=oneshot（多半由 timer 觸發的批次）→ 是「上一次那批沒跑成」
    #   Type=simple/notify（常駐服務）        → 是「服務現在是掛的」
    # 混在一起講，值班會把「昨晚批次失敗」當成「服務死了」而去重啟，
    # 或反過來把服務死掉當成批次沒跑而放著。
    "echo @@FAILEDINFO; for u in $(systemctl --failed --no-legend --plain 2>/dev/null | awk '{print $1}'); do echo \"##$u\"; systemctl show \"$u\" -p Type -p Result -p ExecMainStatus -p TriggeredBy -p ActiveEnterTimestamp --no-pager 2>/dev/null; done; "
    "echo @@ZOMB; ps -eo stat= 2>/dev/null | grep -c '^Z'; "
    "echo @@TCPSTATES; ss -tan 2>/dev/null | awk 'NR>1{print $1}' | sort | uniq -c; "
    "echo @@NETDEV; cat /proc/net/dev 2>/dev/null; "
    # 磁碟忙碌度：取兩次 /proc/diskstats，中間隔 1 秒，自己算增量。
    # **不用 iostat**——那要裝 sysstat（使用者 2026-09-22：「不要裝軟體，
    # 指令都用內建的」）。/proc/diskstats 是核心介面，任何 Linux 都有，
    # 不需要任何套件，也不需要提權。
    "echo @@DISKSTAT1; cat /proc/diskstats 2>/dev/null; sleep 1; "
    "echo @@DISKSTAT2; cat /proc/diskstats 2>/dev/null; "
    "echo @@DNS; (getent hosts github.com >/dev/null 2>&1 && echo ok || echo fail); "
    "echo @@NTP; timedatectl show -p NTPSynchronized --value 2>/dev/null; "
    "echo @@WHO; who 2>/dev/null | wc -l; "
    "echo @@LAST; last -n 6 -w 2>/dev/null | head -6; "
    "echo @@TOPCPU; ps -eo pid,comm,pcpu,pmem --sort=-pcpu 2>/dev/null | head -6; "
    "echo @@TOPMEM; ps -eo pid,comm,pcpu,pmem --sort=-pmem 2>/dev/null | head -6; "
    # 批次 3：需要 sudo 的兩項唯讀日誌。使用者 2026-09-22：「要 root，就 sudo 給權限」。
    #
    # `sudo -n` 不會卡在密碼提示；**沒授權時要看得出來是「沒授權」而不是「沒問題」**，
    # 所以把 stderr 一起收（sudo 會寫 "a password is required" 或 "not allowed"），
    # 由 parse_sudo_log 判成「尚未開通」。靜默跳過會變成假的安全感。
    # **stderr 丟掉、離開碼另外印**。
    # 2>&1 會把 sudo 的錯誤訊息混進資料裡：221 是中文 locale，
    # 「sudo: 需要密碼」曾被當成一筆核心錯誤算進統計（2026-09-22）。
    # 判「有沒有授權」只看 __RC__，不看訊息文字——訊息會隨語言與版本變，離開碼不會。
    "echo @@SECURELOG; sudo -n /usr/bin/tail -n 200 /var/log/secure 2>/dev/null; echo __RC__=$?; "
    "echo @@DMESGERR; sudo -n /usr/bin/dmesg --level=err,crit 2>/dev/null; echo __RC__=$?; "
    # 監聽 port 的行程名：ss -tlnp 的 -p 要 root。有 sudo 白名單就拿得到真實服務名，
    # 沒授權（__RC__!=0）就維持免提權那份（只有 port 號）。2026-09-22 使用者核准 sudo。
    "echo @@LISTENP; sudo -n ss -tlnp 2>/dev/null; echo __RC__=$?; "
    "echo @@END"
)

# TCP 狀態判定門檻（維度 3）
CLOSE_WAIT_YELLOW = 100                  # 連線沒關乾淨堆積（多半是應用忘了 close）
SYN_RECV_YELLOW = 50                    # 半開連線堆積（可能 SYN flood 或 backlog 滿）
#: 會參與「總燈號」計算的指標。每一個的 parser **都必須回 level**。
#: 抽成常數是為了讓測試能 import 它逐一檢查——2026-09-22 就是因為
#: 這串寫死在迴圈裡，測試沒辦法跟著同步，io 漏了 level 才沒被擋下來。
LEVELLED_KEYS = ("cpu", "load", "mem", "uptime", "net", "tcp", "io")

#: 需要 sudo 才查得到的指標。**拿不到時是 None，不納入總燈號**——
#: 把「沒查到」算成綠色就是假的安全感。它們沒授權時由 notes 講明。
SUDO_LEVELLED_KEYS = ("ssh_fails", "kernel_errors")

#: SSH 登入失敗次數門檻（取樣自 /var/log/secure 最後 200 行）
SSHFAIL_RED, SSHFAIL_YELLOW = 50, 10

IOUTIL_RED, IOUTIL_YELLOW = 90, 70      # 磁碟忙碌度 %util（由 /proc/diskstats 增量算）

_ORDER = {"green": 0, "yellow": 1, "red": 2}


def _worst(*levels: str) -> str:
    return max((l for l in levels if l), key=lambda x: _ORDER.get(x, 0), default="green")


def _lv(v: float, red: float, yellow: float) -> str:
    return "red" if v >= red else "yellow" if v >= yellow else "green"


def _run_ssh(ip: str, cmd: str, key_path: str, account: str, timeout: int = 14):
    """跑一條唯讀指令，回 (ok, stdout, err)。多回 returncode／stderr，才分得出
    「連不上」（紅色證據）與「連得上但有問題」。"""
    try:
        r = subprocess.run(
            ["ssh", "-i", key_path, "-o", "BatchMode=yes", *ms._ssh_hostkey_opts(),
             "-o", f"ConnectTimeout={timeout}", f"{account}@{ip}", cmd],
            capture_output=True, text=True, timeout=timeout + 12,
        )
        return r.returncode == 0, r.stdout, (r.stderr or "").strip()
    except subprocess.TimeoutExpired:
        return False, "", "連線逾時（機器沒回應／被防火牆擋／已當機）"
    except OSError as exc:
        return False, "", f"無法執行 ssh：{exc}"


def _split_markers(out: str) -> dict:
    seg: dict[str, list[str]] = {}
    cur = None
    for line in out.splitlines():
        if line.startswith("@@"):
            cur = line[2:].strip()
            seg[cur] = []
        elif cur is not None:
            seg[cur].append(line)
    return {k: "\n".join(v) for k, v in seg.items()}


# ---------- 各面向解析 ----------
def parse_os(text: str) -> dict:
    kern = ""
    pretty = ""
    for line in text.splitlines():
        if line.startswith("PRETTY_NAME"):
            pretty = line.split("=", 1)[1].strip().strip('"')
        elif line.strip():
            kern = line.strip()
    return {"kernel": kern, "os": pretty}


def parse_uptime(text: str) -> dict | None:
    parts = text.split()
    if not parts:
        return None
    try:
        secs = float(parts[0])
    except ValueError:
        return None
    fresh = secs < UPTIME_FRESH_MIN * 60
    return {"uptime_sec": int(secs), "days": round(secs / 86400, 1),
            "just_rebooted": fresh, "level": "yellow" if fresh else "green"}


def parse_cpu(stat1: str, stat2: str, ncpu_text: str) -> dict | None:
    def _row(t):
        p = t.split()
        return [int(x) for x in p[1:]] if len(p) > 4 and p[0] == "cpu" else None
    a, b = _row(stat1), _row(stat2)
    if not a or not b:
        return None
    da = [y - x for x, y in zip(a, b)]
    total = sum(da)
    if total <= 0:
        return None
    idle = da[3] + (da[4] if len(da) > 4 else 0)         # idle + iowait
    iowait = da[4] if len(da) > 4 else 0
    usage = round(100 * (total - idle) / total, 1)
    iowait_pct = round(100 * iowait / total, 1)
    ncpu = next((int(t) for t in ncpu_text.split() if t.isdigit()), 1) or 1
    return {"usage_pct": usage, "iowait_pct": iowait_pct, "ncpu": ncpu,
            "level": _worst(_lv(usage, CPU_RED, CPU_YELLOW),
                            _lv(iowait_pct, IOWAIT_RED, IOWAIT_YELLOW))}


def parse_load(loadavg: str, ncpu: int) -> dict | None:
    parts = loadavg.split()
    if len(parts) < 3:
        return None
    try:
        l1, l5, l15 = float(parts[0]), float(parts[1]), float(parts[2])
    except ValueError:
        return None
    proc_total = 0
    if len(parts) >= 4 and "/" in parts[3]:
        proc_total = int(parts[3].split("/")[1])
    ncpu = ncpu or 1
    per = round(l1 / ncpu, 2)
    return {"load1": l1, "load5": l5, "load15": l15, "ncpu": ncpu, "per_cpu": per,
            "proc_total": proc_total, "level": _lv(per, LOAD_RED, LOAD_YELLOW)}


def parse_mem(meminfo: str) -> dict | None:
    vals = {}
    for line in meminfo.splitlines():
        k, _, rest = line.partition(":")
        num = rest.strip().split()
        if num and num[0].isdigit():
            vals[k.strip()] = int(num[0])          # KB
    total = vals.get("MemTotal")
    if not total:
        return None
    avail = vals.get("MemAvailable")
    if avail is None:
        avail = vals.get("MemFree", 0) + vals.get("Buffers", 0) + vals.get("Cached", 0)
    used_pct = round((total - avail) / total * 100, 1)
    swap_total = vals.get("SwapTotal", 0)
    swap_free = vals.get("SwapFree", 0)
    swap_pct = round((swap_total - swap_free) / swap_total * 100, 1) if swap_total else 0.0
    return {"total_kb": total, "avail_kb": avail, "used_pct": used_pct,
            "swap_total_kb": swap_total, "swap_pct": swap_pct,
            "level": _worst(_lv(used_pct, MEM_RED, MEM_YELLOW),
                            _lv(swap_pct, SWAP_RED, SWAP_YELLOW) if swap_total else "green")}


def _parse_df(text: str, pct_idx_from_end: int = 1):
    """df -P 通用解析：回 {mount: (…, pct)}。空白掛載點併回。"""
    out = {}
    for line in text.splitlines():
        p = line.split()
        if len(p) < 6 or p[0].lower() == "filesystem":
            continue
        try:
            pct = int(p[-2].rstrip("%"))
        except ValueError:
            continue
        mount = " ".join(p[5:])
        out[mount] = (p, pct)
    return out


def parse_disks(df_text: str, dfi_text: str) -> list[dict]:
    space = _parse_df(df_text)
    inode = _parse_df(dfi_text)
    disks = []
    for mount, (p, pct) in space.items():
        try:
            size_kb, used_kb, avail_kb = int(p[1]), int(p[2]), int(p[3])
        except (ValueError, IndexError):
            size_kb = used_kb = avail_kb = 0
        ipct = inode.get(mount, (None, -1))[1]
        disks.append({
            "mount": mount, "fs": p[0], "size_kb": size_kb, "used_kb": used_kb,
            "avail_kb": avail_kb, "use_pct": pct, "inode_pct": ipct,
            "level": _worst(_lv(pct, DISK_RED, DISK_YELLOW),
                            _lv(ipct, INODE_RED, INODE_YELLOW) if ipct >= 0 else "green"),
        })
    disks.sort(key=lambda d: -max(d["use_pct"], d["inode_pct"]))
    return disks


# 這些檔案系統本來就是唯讀（光碟／squashfs／唯讀 bind），不算異常。
_RO_OK_FS = {"squashfs", "iso9660", "cramfs"}
_RO_OK_MOUNT_PREFIX = ("/snap", "/sys", "/proc", "/run")


def parse_readonly_mounts(mounts: str) -> list[dict]:
    """從 /proc/mounts 找**該可寫卻變唯讀**的真實檔案系統——磁碟出錯時 kernel 會把它
    重掛成 ro，這是很強的故障訊號。過濾掉本來就唯讀的（光碟／snap／虛擬檔案系統）。"""
    ro = []
    for line in mounts.splitlines():
        p = line.split()
        if len(p) < 4:
            continue
        dev, mount, fstype, opts = p[0], p[1], p[2], p[3]
        flags = opts.split(",")
        if "ro" not in flags:
            continue
        if fstype in _RO_OK_FS or not dev.startswith("/dev"):
            continue
        if any(mount.startswith(pre) for pre in _RO_OK_MOUNT_PREFIX):
            continue
        ro.append({"mount": mount, "fs": fstype, "dev": dev})
    return ro


def parse_failed_units(text: str) -> list[str]:
    units = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        units.append(line.split()[0])          # 第一欄＝unit 名
    return units


def parse_failed_detail(text: str, units: list[str]) -> list[dict]:
    """每個 failed unit 給：判讀 ＋ 該下哪些指令。

    **只給唯讀的查詢指令當第一組**，重啟類的另外標成「確認原因後再做」。
    這是金融業主機：系統不會替人按重啟，畫面只負責把「該看哪裡」講清楚。
    指令一律純文字可複製，不做成會執行的按鈕——按鈕會讓人跳過判斷。
    """
    info: dict[str, dict] = {}
    cur = None
    for line in (text or "").splitlines():
        line = line.strip()
        if line.startswith("##"):
            cur = line[2:].strip()
            info[cur] = {}
        elif cur and "=" in line:
            k, v = line.split("=", 1)
            info[cur][k.strip()] = v.strip()

    out = []
    for u in units:
        d = info.get(u, {})
        typ = d.get("Type", "")
        result = d.get("Result", "")
        code = d.get("ExecMainStatus", "")
        trig = d.get("TriggeredBy", "")
        oneshot = typ == "oneshot" or bool(trig)
        if oneshot:
            verdict = ("這是**批次型**工作（由 timer 觸發），failed 代表"
                       "**上一次執行沒成功**，不是服務現在掛著。"
                       "要看的是那次為什麼失敗，重啟它只會再跑一次。")
        elif typ:
            verdict = ("這是**常駐服務**，failed 代表它**現在沒在跑**。"
                       "先看日誌確認原因，再決定要不要拉起來。")
        else:
            verdict = "查不到這個 unit 的型態（可能已被移除），先看它的狀態與日誌。"
        why = {"exit-code": "程式自己回傳非 0",
               "timeout": "執行超時被砍",
               "signal": "被訊號終止（常見是 OOM）",
               "core-dump": "程式崩潰",
               "start-limit-hit": "短時間內重啟太多次，systemd 放棄了",
               "resources": "資源不足起不來"}.get(result, "")
        out.append({
            "unit": u,
            "type": typ or None,
            "result": result or None,
            "exit_status": code or None,
            "triggered_by": trig or None,
            "oneshot": oneshot,
            "verdict": verdict,
            "reason_hint": why or None,
            "last_active": d.get("ActiveEnterTimestamp") or None,
            # 先查（唯讀，隨時可跑）
            "inspect": [
                f"systemctl status {u} --no-pager -l",
                f"journalctl -u {u} -n 100 --no-pager",
                f"systemctl cat {u}",
            ] + ([f"systemctl list-timers --all | grep -i {u.split('.')[0]}"] if oneshot else []),
            # 再處理（**確認原因後**才做，畫面上要標清楚）
            "act": ([f"systemctl reset-failed {u}",
                     f"systemctl start {u}   # 手動補跑這一次"]
                    if oneshot else
                    [f"systemctl reset-failed {u}",
                     f"systemctl restart {u}"]),
        })
    return out


def parse_netdev(text: str) -> dict:
    """/proc/net/dev → 累計 rx/tx 錯誤＋丟包（排掉 lo）。回總數＋有問題的介面。"""
    total_err = total_drop = 0
    ifaces = []
    for line in text.splitlines():
        if ":" not in line:
            continue
        name, _, rest = line.partition(":")
        name = name.strip()
        if name == "lo":
            continue
        f = rest.split()
        if len(f) < 16:
            continue
        # rx: bytes packets errs drop ... (idx2=errs,3=drop) ; tx errs=idx10 drop=idx11
        try:
            rx_err, rx_drop, tx_err, tx_drop = int(f[2]), int(f[3]), int(f[10]), int(f[11])
        except (ValueError, IndexError):
            continue
        err = rx_err + tx_err
        drop = rx_drop + tx_drop
        if err or drop:
            ifaces.append({"iface": name, "errs": err, "drops": drop})
        total_err += err
        total_drop += drop
    return {"total_errs": total_err, "total_drops": total_drop, "ifaces": ifaces,
            "level": "yellow" if (total_err + total_drop) >= NETDROP_YELLOW else "green"}


def parse_top(text: str) -> list[dict]:
    rows = []
    for line in text.splitlines():
        p = line.split(None, 3)
        if len(p) < 4 or p[0].upper() == "PID" or not p[0].isdigit():
            continue
        try:
            rows.append({"pid": int(p[0]), "comm": p[1],
                         "cpu": float(p[2]), "mem": float(p[3])})
        except ValueError:
            continue
    return rows[:5]


def parse_tcp_states(text: str) -> dict:
    """ss -tan 的狀態計數（維度 3）：關注 CLOSE-WAIT／SYN-RECV／TIME-WAIT 堆積。"""
    counts: dict[str, int] = {}
    for line in text.splitlines():
        p = line.split()
        if len(p) == 2 and p[0].isdigit():
            counts[p[1].upper()] = int(p[0])
    cw = counts.get("CLOSE-WAIT", 0)
    sr = counts.get("SYN-RECV", 0)
    lvl = "yellow" if (cw >= CLOSE_WAIT_YELLOW or sr >= SYN_RECV_YELLOW) else "green"
    return {"counts": counts, "estab": counts.get("ESTAB", 0),
            "time_wait": counts.get("TIME-WAIT", 0), "close_wait": cw,
            "syn_recv": sr, "level": lvl}


def parse_diskstats(t1: str, t2: str, secs: float = 1.0) -> dict | None:
    """兩次 /proc/diskstats 的增量 → 最忙裝置的 %util 與平均等待毫秒。

    為什麼不用 iostat：那要裝 sysstat。使用者 2026-09-22：「不要裝軟體，
    指令都用內建的」。`/proc/diskstats` 是核心介面，任何 Linux 都有，
    免安裝、免提權，而且 iostat 本身也是讀它算出來的。

    欄位（Linux 核心 Documentation/admin-guide/iostats.rst）：
      1 major  2 minor  3 name  4 reads  ...  7 read_ms  8 writes  ...
      11 write_ms  12 in_flight  **13 io_ms（花在 I/O 上的毫秒）**  14 weighted_ms

    %util = io_ms 增量 ÷ 經過毫秒 × 100；平均等待 = (read_ms+write_ms) 增量 ÷ 次數增量。

    只看整顆實體碟，**跳過分割區與虛擬裝置**（loop/ram/dm/sr）——
    分割區的 io_ms 會跟母碟重複計算，不跳掉會挑出假的最忙裝置。
    """
    def rows(text):
        out = {}
        for line in (text or "").splitlines():
            f = line.split()
            if len(f) < 14:
                continue
            name = f[2]
            if name.startswith(("loop", "ram", "dm-", "sr", "zram", "md")):
                continue
            if name[-1].isdigit() and not name.startswith("nvme"):
                continue          # sda1 這種分割區；nvme0n1 結尾是數字但那是整顆
            if name.startswith("nvme") and "p" in name.split("n")[-1]:
                continue          # nvme0n1p1 才是分割區
            try:
                out[name] = {"reads": int(f[3]), "rms": int(f[6]), "writes": int(f[7]),
                             "wms": int(f[10]), "io_ms": int(f[12])}
            except (ValueError, IndexError):
                continue
        return out

    a, b = rows(t1), rows(t2)
    if not a or not b:
        return None
    elapsed_ms = max(secs, 0.1) * 1000.0
    worst = None
    for name, cur in b.items():
        prev = a.get(name)
        if not prev:
            continue
        d_io = cur["io_ms"] - prev["io_ms"]
        if d_io < 0:
            continue                              # 計數器重置（重開機）→ 這輪不算
        util = min(100.0, d_io / elapsed_ms * 100.0)
        d_cnt = (cur["reads"] - prev["reads"]) + (cur["writes"] - prev["writes"])
        d_wait = (cur["rms"] - prev["rms"]) + (cur["wms"] - prev["wms"])
        await_ms = round(d_wait / d_cnt, 1) if d_cnt > 0 else None
        if worst is None or util > worst["util"]:
            worst = {"device": name, "util": round(util, 1), "await_ms": await_ms}
    if worst is not None:
        # level 一定要有：check_one 的總燈號會對每個有值的指標取 level。
        # 2026-09-22 把 iostat 換成 diskstats 時漏了這個欄位，
        # 結果 221 上 check_one 直接 KeyError 炸掉——單元測試全綠但一跑就死。
        worst["level"] = ("red" if worst["util"] >= IOUTIL_RED
                          else "yellow" if worst["util"] >= IOUTIL_YELLOW
                          else "green")
    return worst

def parse_last(text: str) -> list[str]:
    """last -n 的近期登入（維度 4）。過濾表尾 wtmp begins 那行。"""
    out = []
    for line in text.splitlines():
        s = line.strip()
        if not s or s.startswith("wtmp begins") or s.startswith("btmp begins"):
            continue
        out.append(s)
    return out[:5]


def split_rc(text: str) -> tuple[str, int | None]:
    """把 `__RC__=<n>` 從段落尾巴拆出來。回（內容, 離開碼）。

    離開碼是**跟語言無關**的判準。訊息文字會隨 locale 與 sudo 版本變
    （221 是中文，回的是「sudo: 需要密碼」），比對字面永遠會漏下一種。

    拿不到 __RC__ 就回 None——那代表指令根本沒跑到（連線斷、shell 不支援），
    一樣要當成「沒查到」，不可以當成 0。
    """
    rc = None
    kept = []
    for line in (text or "").splitlines():
        t = line.strip()
        if t.startswith("__RC__="):
            try:
                rc = int(t.split("=", 1)[1])
            except ValueError:
                rc = None
            continue
        kept.append(line)
    return "\n".join(kept), rc


def looks_like_sudo_error(line: str) -> bool:
    """這一行像不像 sudo 吐的錯誤，而不是資料。

    **不管判斷對不對，這種行都不可以被收進資料。**
    2026-09-22：「sudo: 需要密碼」被算成一筆核心錯誤、讓那區變黃——
    判斷錯只是少一個警示，資料污染是直接產生假數字。
    `sudo:` 這個前綴是 sudo 自己印的，各語言都一樣。
    """
    return line.strip().startswith(("sudo:", "sudo :"))


def sudo_denied(text: str) -> bool:
    """這段輸出是不是「sudo 沒授權」而不是真的沒東西。

    sudo -n 沒授權時會吐這幾種訊息（各版本措辭不同，所以比對多個關鍵字）。
    判錯的代價不對稱：把「沒授權」當成「沒問題」會給假的安全感，
    反過來只是多顯示一行提醒，所以**寧可寬鬆地判成沒授權**。
    """
    t = (text or "").lower()
    return any(k in t for k in (
        "password is required", "a terminal is required", "not allowed to execute",
        "sudo: no tty", "may not run", "command not allowed", "not in the sudoers",
        # 中文 locale（221 就是）。**這只是第三道防線**——主要判準是離開碼，
        # 因為下一台可能是日文或別的措辭，比對字面永遠追不完。
        "需要密碼", "不在 sudoers", "不允許執行", "沒有權限",
    ))


def parse_ssh_fails(text: str) -> dict | None:
    """/var/log/secure 最後 200 行裡的 SSH 登入失敗。

    回 None ＝**沒授權或讀不到**，畫面要顯示「尚未開通」；
    回 dict 才是真的查過。兩者絕不可以混——
    「沒查到」跟「查過沒問題」在資安上是完全相反的結論。
    """
    body, rc = split_rc(text)
    # rc 不是 0（含拿不到 rc）＝沒跑成。**這是主要判準**，跟語言無關。
    # **離開碼是主要判準**：rc=0 就是指令真的跑成了，這時不可以再被字面比對推翻
    # （輸出裡剛好有「需要密碼」這類字樣是有可能的，那不代表沒授權）。
    # sudo_denied 只在**拿不到 rc** 時當第二道用。
    if rc is None:
        return None
    if rc != 0 or (rc is None and sudo_denied(body)):
        return None
    # rc=0 但沒輸出＝**查過了、真的沒有失敗登入**，要回 0 不是 None。
    # 回 None 會顯示成「沒有查到」，把乾淨的機器誤報成沒查——
    # 那跟把沒查當成沒問題一樣糟，只是方向相反。
    if not body.strip():
        return {"fails": 0, "distinct_ips": 0, "top_sources": [], "level": "green",
                "note": "取樣自 /var/log/secure 最後 200 行，期間沒有失敗登入"}
    # 就算判成有授權，像 sudo 錯誤的行也一律不收——不可以變成統計數字
    body = "\n".join(l for l in body.splitlines() if not looks_like_sudo_error(l))
    if not body.strip():
        return None
    text = body
    import re as _re
    fails = 0
    by_ip: dict[str, int] = {}
    for line in text.splitlines():
        if "Failed password" not in line and "Invalid user" not in line:
            continue
        fails += 1
        m = _re.search(r"from (\d{1,3}(?:\.\d{1,3}){3})", line)
        if m:
            by_ip[m.group(1)] = by_ip.get(m.group(1), 0) + 1
    top = sorted(by_ip.items(), key=lambda kv: -kv[1])[:5]
    lvl = ("red" if fails >= SSHFAIL_RED
           else "yellow" if fails >= SSHFAIL_YELLOW else "green")
    return {"fails": fails, "distinct_ips": len(by_ip),
            "top_sources": [{"ip": i, "count": n} for i, n in top],
            "level": lvl,
            "note": "取樣自 /var/log/secure 最後 200 行，不是全部歷史"}


def parse_kernel_errors(text: str) -> dict | None:
    """dmesg 的 err/crit。OOM 與 I/O error 是最該先看到的兩種。

    回 None ＝沒授權或讀不到（同上，要顯示「尚未開通」）。
    """
    body, rc = split_rc(text)
    # **離開碼是主要判準**：rc=0 就是指令真的跑成了，這時不可以再被字面比對推翻
    # （輸出裡剛好有「需要密碼」這類字樣是有可能的，那不代表沒授權）。
    # sudo_denied 只在**拿不到 rc** 時當第二道用。
    if rc is None:
        return None
    if rc != 0 or (rc is None and sudo_denied(body)):
        return None
    lines = [l.strip() for l in body.splitlines()
             if l.strip() and not looks_like_sudo_error(l)]
    if not lines:
        # 有授權但 dmesg 真的沒有 err/crit＝好事，回 0 而不是 None
        return {"total": 0, "oom": 0, "io_error": 0, "samples": [], "level": "green"}
    oom = [l for l in lines if "out of memory" in l.lower() or "oom-kill" in l.lower()]
    io_err = [l for l in lines if "i/o error" in l.lower() or "ata error" in l.lower()
              or "medium error" in l.lower()]
    lvl = "red" if (oom or io_err) else ("yellow" if lines else "green")
    # 去重：一行可能同時落在 oom 與 lines，直接串接會重複顯示同一條。
    # 保留順序（嚴重的先）：dict.fromkeys 比 set 好，set 會把順序打亂。
    samples = list(dict.fromkeys(oom + io_err + lines))[:5]
    return {"total": len(lines), "oom": len(oom), "io_error": len(io_err),
            "samples": samples, "level": lvl}


def check_one(ip: str, platform: str = "linux",
              key_path: str | None = None, account: str | None = None,
              _ssh=_run_ssh, _svc=None) -> dict:
    """對單台跑完整健檢。回結構化結果（含 overall 燈號）。"""
    key_path = key_path or ms.COLLECTOR_KEY_DEFAULT
    account = account or ms.DEFAULT_COLLECT_ACCOUNT
    # 掃描時間（使用者 2026-09-22：「掃描時間要顯示出來」）。
    # 沒有時間的數字沒人敢用——三分鐘前跟三天前的「綠燈」意義完全不同。
    # 記開始時間而不是結束時間：那才是這些數字的量測時點。
    _t0 = _dt.datetime.now()
    base = {
        "ip": ip, "platform": platform, "reachable": False, "error": None, "unresolved": False,
        "checked_at": _t0.strftime("%Y-%m-%d %H:%M:%S"), "took_ms": None,
        "os": None, "kernel": None, "uptime": None,
        "cpu": None, "load": None, "mem": None,
        "disks": [], "readonly_mounts": [], "failed_units": [],
        "net": None, "tcp": None, "io": None, "zombies": 0,
        "ntp_synced": None, "dns_ok": None, "logins": None, "recent_logins": [],
        # 批次 3：None ＝**沒授權或讀不到**，畫面要顯示「尚未開通」而不是「正常」
        "ssh_fails": None, "kernel_errors": None,
        "sudo_log_authorized": None,
        "top_cpu": [], "top_mem": [], "ports": [], "process_visible": False,
        "overall": "red", "notes": [],
    }
    if platform != "linux":
        base["overall"] = "skipped"
        base["error"] = "批次 1 僅支援 Linux，這台先跳過"
        base["took_ms"] = int((_dt.datetime.now() - _t0).total_seconds() * 1000)
        return base

    ok, out, err = _ssh(ip, _METRICS_CMD, key_path, account)
    if not ok and not out.strip():
        base["error"] = err or "連線失敗"
        # 區分「解析不出主機名」（輸入格式或 DNS 問題）與「連不上」（機器可能當機）。
        # 前者不是機器死了——把它說成當機會讓值班以為好好的主機掛了（2026-09-22 使用者
        # 貼 http://…／打錯時踩到）。判斷只看錯誤關鍵字，不猜。
        _e = (err or "").lower()
        if "resolve" in _e or "name or service not known" in _e or "nodename nor servname" in _e:
            base["unresolved"] = True
            base["notes"].append(
                "主機名無法解析——多半是輸入帶了 http://／打錯／DNS 查不到，"
                "**不是機器當機**。確認輸入的是純 IP 或正確主機名。")
        else:
            base["notes"].append("連不上這台——可能真的當機／關機，或網路/防火牆問題")
        base["took_ms"] = int((_dt.datetime.now() - _t0).total_seconds() * 1000)
        return base

    base["reachable"] = True
    seg = _split_markers(out)
    osd = parse_os(seg.get("OS", ""))
    base["os"], base["kernel"] = osd["os"], osd["kernel"]
    base["uptime"] = parse_uptime(seg.get("UP", ""))
    ncpu_text = seg.get("CPU", "")
    base["cpu"] = parse_cpu(seg.get("STAT1", ""), seg.get("STAT2", ""), ncpu_text)
    ncpu = base["cpu"]["ncpu"] if base["cpu"] else \
        next((int(t) for t in ncpu_text.split() if t.isdigit()), 1)
    base["load"] = parse_load(seg.get("LOAD", ""), ncpu)
    base["mem"] = parse_mem(seg.get("MEM", ""))
    base["disks"] = parse_disks(seg.get("DF", ""), seg.get("DFI", ""))
    base["readonly_mounts"] = parse_readonly_mounts(seg.get("MOUNTS", ""))
    base["failed_units"] = parse_failed_units(seg.get("FAILED", ""))
    base["ssh_fails"] = parse_ssh_fails(seg.get("SECURELOG", ""))
    base["kernel_errors"] = parse_kernel_errors(seg.get("DMESGERR", ""))
    # 兩項都拿不到就是 sudo 白名單還沒佈；要讓畫面講清楚，不可以看起來像「都正常」
    base["sudo_log_authorized"] = not (
        base["ssh_fails"] is None and base["kernel_errors"] is None)
    if not base["sudo_log_authorized"]:
        base["notes"].append(
            "SSH 爆破偵測與核心錯誤這兩項**沒有查到**（收集帳號還沒拿到 sudo 授權），"
            "不是「沒有異常」")
    base["failed_detail"] = parse_failed_detail(
        seg.get("FAILEDINFO", ""), base["failed_units"])
    base["net"] = parse_netdev(seg.get("NETDEV", ""))
    base["tcp"] = parse_tcp_states(seg.get("TCPSTATES", ""))
    # 兩次取樣算增量；取不到（例如非 Linux）回 None，畫面顯示「未量到」而不是 0
    base["io"] = parse_diskstats(seg.get("DISKSTAT1", ""), seg.get("DISKSTAT2", ""))
    try:
        base["zombies"] = int((seg.get("ZOMB", "0").strip() or "0").splitlines()[0])
    except (ValueError, IndexError):
        base["zombies"] = 0
    dns = seg.get("DNS", "").strip().lower()
    base["dns_ok"] = True if "ok" in dns else False if "fail" in dns else None
    ntp = seg.get("NTP", "").strip().lower()
    base["ntp_synced"] = True if ntp == "yes" else False if ntp == "no" else None
    try:
        base["logins"] = int((seg.get("WHO", "").strip() or "0").splitlines()[0])
    except (ValueError, IndexError):
        base["logins"] = None
    base["recent_logins"] = parse_last(seg.get("LAST", ""))
    base["top_cpu"] = parse_top(seg.get("TOPCPU", ""))
    base["top_mem"] = parse_top(seg.get("TOPMEM", ""))

    # port／服務：復用 service_collector（同一個 runner 抽象）。收不到不讓整份掛掉。
    svc = _svc
    if svc is None:
        import service_collector

        def _runner(host, cmd):
            _ok, _out, _e = _ssh(host, cmd, key_path, account)
            return _out
        try:
            svc = service_collector.collect(_runner, ip, "linux")
        except Exception as exc:  # noqa: BLE001 - 服務收不到只是少一塊證據，不是整台失敗
            svc = None
            base["notes"].append(f"服務／port 這次沒收到（{str(exc)[:80]}）")
    if svc:
        base["ports"] = svc.get("services", [])
        base["process_visible"] = svc.get("process_visible", False)

    # 有 sudo 授權時，用 `sudo ss -tlnp` 拿到的行程名覆蓋上去（免提權那份只有 port 號）。
    # 只補 process／refresh service_guess，不動 is_infra／exposure——最小改動，沒授權就跳過。
    lp = seg.get("LISTENP", "")
    if "__RC__=0" in lp and base["ports"]:
        try:
            import service_collector as _sc
            proc_by_port = {s["port"]: s["process"]
                            for s in _sc.parse_listen(lp) if s.get("process")}
            if proc_by_port:
                for p in base["ports"]:
                    if not p.get("process") and p.get("port") in proc_by_port:
                        p["process"] = proc_by_port[p["port"]]
                        p["service_guess"] = _sc.guess_service(p["port"], p["process"], [])
                base["process_visible"] = True
        except Exception:  # noqa: BLE001 - 補行程名失敗不影響其餘健檢
            pass

    # ---- 總燈號：多訊號取最嚴重 ----
    levels = [d["level"] for d in base["disks"]]
    for k in LEVELLED_KEYS + SUDO_LEVELLED_KEYS:
        v = base[k]
        if not v:
            continue
        lv = v.get("level")
        if lv is None:
            # 少了 level 是**程式的錯**，不是那台主機的問題。
            # 這裡不炸掉整台健檢（一個欄位缺失不該讓值班看不到其他證據），
            # 但要在畫面上明講，不可以靜默當成沒事——
            # 靜默的話會變成「少算一個指標卻還是綠燈」。
            base["notes"].append(f"內部錯誤：{k} 少了 level 欄位，這個指標沒算進總燈號")
            continue
        levels.append(lv)
    if base["readonly_mounts"]:
        levels.append("red")                       # 該可寫卻唯讀＝磁碟故障徵兆
        base["notes"].append("有檔案系統被重掛成唯讀（磁碟可能出錯）")
    if base["failed_units"]:
        levels.append("red")                       # systemd 有服務掛了
        base["notes"].append(f"systemd 有 {len(base['failed_units'])} 個 failed 服務")
    if base["zombies"] >= ZOMBIE_YELLOW:
        levels.append("yellow")
    if base["ntp_synced"] is False:
        levels.append("yellow")
        base["notes"].append("NTP 未同步（時間可能飄）")
    base["overall"] = _worst(*levels)
    base["took_ms"] = int((_dt.datetime.now() - _t0).total_seconds() * 1000)
    return base


def check_batch(ips: list[str], platform_of=None, concurrency: int = 8,
                key_path: str | None = None, account: str | None = None,
                _one=check_one) -> list[dict]:
    """並發對多台健檢。concurrency 由呼叫端夾在上限內（見 api）。只打傳進來的已知 IP。"""
    from concurrent.futures import ThreadPoolExecutor

    seen, targets = set(), []
    for ip in ips:
        ip = (ip or "").strip()
        if ip and ip not in seen:
            seen.add(ip)
            targets.append(ip)
    if not targets:
        return []

    def _task(ip: str) -> dict:
        plat = (platform_of(ip) if platform_of else "linux") or "linux"
        return _one(ip, platform=plat, key_path=key_path, account=account)

    workers = max(1, min(concurrency, len(targets)))
    with ThreadPoolExecutor(max_workers=workers) as ex:
        results = list(ex.map(_task, targets))
    results.sort(key=lambda r: -_ORDER.get(r["overall"], 0))
    return results
