#!/usr/bin/ksh
#=============================================================================
# install_fcb_aix_cron.ksh —— 把「每月第四個禮拜日 09:00 跑 FCB AIX 檢核」裝進 root 的 crontab
#
# 用法（要用 root：FCB 檢核有很多項只有 root 讀得到）：
#     ksh ./install_fcb_aix_cron.ksh        安裝（已裝過就印「已安裝，略過」）
#     ksh ./install_fcb_aix_cron.ksh -r     移除（只刪本工具那一行）
#
# 裝進去的那一行：
#     0 9 22-28 * * /usr/bin/ksh <同目錄>/run_fcb_aix_monthly.ksh >/dev/null 2>&1 # webit3-fcb-aix-monthly
#   cron 只限定 22~28 號；「是不是禮拜日」由 run_fcb_aix_monthly.ksh 判斷。
#   不能寫成 `0 9 22-28 * 0`：日期與星期兩欄同時有值時 cron 取 OR，會變成每天跑。
#
# 為什麼另寫一支、不寫進稽核腳本：稽核腳本必須維持唯讀、不改系統設定。
#
# 安全做法：
#   * 冪等：先看 crontab 有沒有行尾標記 `# webit3-fcb-aix-monthly`，有就不再加。
#   * 不覆蓋別人的排程：crontab -l 取出 -> 附加一行 -> crontab <檔案>，
#     裝完再讀回來核對「多了剛好一行、其他行不變」。
#   * crontab -l 失敗時分兩種：原本就沒有 crontab（正常，視為空白），
#     或讀不到但 spool 檔其實存在（停下來，絕不拿空白蓋掉既有排程）。
#
# ksh88 相容：變數一律 ${VAR}、輸出一律 printf、不用 bash 語法、不用 echo。
#
# 測試用環境變數（平常不要設）：
#   FCBAIX_CRONTAB_CMD   取代 crontab 指令（測試時換成用檔案模擬的假 crontab）
#   FCBAIX_TEST_NOROOT=1 略過 root 檢查（只給模擬測試用）
#   FCBAIX_CRON_SPOOL    取代 /var/spool/cron（測試用，以 root 跑測試時不可碰真機 spool）
#
# 其他環境變數：
#   FCBAIX_ALLOW_TMP=1   腳本放在 /tmp、/var/tmp 底下仍要安裝（預設拒絕，見下方說明）
#=============================================================================

PATH=/usr/bin:/bin:/usr/sbin:/sbin:/usr/local/bin
export PATH
umask 077

MARK_ID="webit3-fcb-aix-monthly"
MARK="# ${MARK_ID}"
CRON_SPEC="0 9 22-28 * *"
KSH_PATH="/usr/bin/ksh"
CRONTAB_CMD="${FCBAIX_CRONTAB_CMD:-crontab}"
CRON_SPOOL="${FCBAIX_CRON_SPOOL:-/var/spool/cron}"
SAFE_DIR="/opt/webit3/fcbaix"

die() {
    printf '%s\n' "錯誤：$*" >&2
    exit 1
}

ACTION=install
case "$1" in
    "")  ACTION=install ;;
    -r)  ACTION=remove ;;
    *)   die "不認得的參數 $1。用法：ksh install_fcb_aix_cron.ksh [-r]" ;;
esac

# --- root 檢查 ---
if [ -z "${FCBAIX_TEST_NOROOT}" ]; then
    _uid=`id -u`
    [ "${_uid}" = "0" ] || die "請用 root 執行（FCB 檢核有很多項只有 root 讀得到，排程要裝在 root 的 crontab）。"
fi
ME=`id -un 2>/dev/null`

# --- 包裝程式的絕對路徑 ---
SDIR=`dirname "$0"`
SDIR=`cd "${SDIR}" 2>/dev/null && pwd`
WRAPPER="${SDIR}/run_fcb_aix_monthly.ksh"
case "${WRAPPER}" in
    *" "*) die "路徑 ${WRAPPER} 含空白，crontab 那一行會被拆開。請把腳本放到沒有空白的目錄。" ;;
esac
if [ "${ACTION}" = install ]; then
    [ -f "${WRAPPER}" ] || die "找不到 ${WRAPPER}（要跟本檔放在同一個目錄）。"
    _n=`ls "${SDIR}"/fcb_aixV[0-9][0-9][0-9].ksh 2>/dev/null | wc -l | tr -d ' '`
    [ "${_n}" -gt 0 ] || die "${SDIR} 底下沒有 fcb_aixV###.ksh，裝了排程也沒東西可跑。"
    # /tmp、/var/tmp 會被重開機或定期清理：腳本被清掉後 cron 照樣每月叫，
    # 但叫不到東西、沒有 log、也沒人知道——排程等於靜默失效。所以預設拒裝。
    # （移除 -r 不擋：舊的裝在 /tmp 的排程要能從原地移除。）
    case "${SDIR}" in
        /tmp|/tmp/*|/var/tmp|/var/tmp/*)
            if [ "${FCBAIX_ALLOW_TMP}" = "1" ]; then
                printf '%s\n' "警告：腳本目錄 ${SDIR} 在暫存區底下，被清掉後排程會靜默失效（FCBAIX_ALLOW_TMP=1，仍照裝）。" >&2
            else
                die "腳本目錄 ${SDIR} 在 /tmp 或 /var/tmp 底下，重開機或清理後排程會靜默失效。請先把整個目錄搬到固定位置（建議 ${SAFE_DIR}）再裝：mkdir -p ${SAFE_DIR} && cp ${SDIR}/*.ksh ${SAFE_DIR}/ && cd ${SAFE_DIR} && ksh ./install_fcb_aix_cron.ksh。確定要留在這裡就設 FCBAIX_ALLOW_TMP=1。"
            fi
            ;;
    esac
fi
CRON_LINE="${CRON_SPEC} ${KSH_PATH} ${WRAPPER} >/dev/null 2>&1 ${MARK}"

# --- 私人暫存目錄（不用 -p：已存在就是異常）---
TMPD="/tmp/.fcbaix_cron_$$"
mkdir "${TMPD}" || die "建不出暫存目錄 ${TMPD}"
chmod 700 "${TMPD}"
trap 'rm -rf "${TMPD}"' 0
trap 'exit 1' 1 2 15

# --- 取出目前的 crontab ---
"${CRONTAB_CMD}" -l > "${TMPD}/cur" 2> "${TMPD}/err"
_rc=$?
if [ "${_rc}" -ne 0 ]; then
    # 讀不到：是「原本沒有 crontab」還是「有但讀不到」？後者絕不能拿空白去蓋。
    for _sp in "${CRON_SPOOL}/crontabs/${ME}" "${CRON_SPOOL}/${ME}"; do
        if [ -n "${ME}" ] && [ -s "${_sp}" ]; then
            die "crontab -l 失敗，但 ${_sp} 存在且有內容。為了不蓋掉既有排程，停止。（crontab -l 訊息：`cat "${TMPD}/err"`）"
        fi
    done
    _msg=`cat "${TMPD}/err"`
    printf '%s\n' "提醒：目前沒有 crontab（${_msg}），視為空白。"
    : > "${TMPD}/cur"
fi


# 統一補上結尾換行（最後一行沒有換行的話，附加的那行會黏在它後面）。
awk '{ print }' "${TMPD}/cur" > "${TMPD}/base"
NOLD=`wc -l < "${TMPD}/base" | tr -d ' '`

if [ "${ACTION}" = install ]; then
    if grep "${MARK_ID}" "${TMPD}/base" > /dev/null 2>&1; then
        printf '%s\n' "已安裝，略過。目前那一行："
        grep "${MARK_ID}" "${TMPD}/base"
        exit 0
    fi
    cat "${TMPD}/base" > "${TMPD}/new"
    printf '%s\n' "${CRON_LINE}" >> "${TMPD}/new"
    "${CRONTAB_CMD}" "${TMPD}/new" || die "crontab 寫入失敗，原本的排程沒有被更動。"
    "${CRONTAB_CMD}" -l > "${TMPD}/after" 2> /dev/null || die "裝完讀不回 crontab，請手動 crontab -l 檢查。"
    _nmark=`grep -c "${MARK_ID}" "${TMPD}/after"`
    _nnew=`grep -v "${MARK_ID}" "${TMPD}/after" | wc -l | tr -d ' '`
    _nbase=`wc -l < "${TMPD}/base" | tr -d ' '`
    if [ "${_nmark}" != "1" ] || [ "${_nnew}" != "${_nbase}" ]; then
        die "裝完核對不符（標記 ${_nmark} 行、其他 ${_nnew} 行，原本 ${_nbase} 行）。請手動 crontab -l 檢查。"
    fi
    printf '%s\n' "已安裝（原有 ${NOLD} 行保留不動，新增 1 行）："
    printf '%s\n' "${CRON_LINE}"
    printf '%s\n' "確認：crontab -l | grep ${MARK_ID}"
    exit 0
fi

# --- 移除 ---
# 不寫 `if ! grep`：ksh88 不支援 `!` 反轉。
if grep "${MARK_ID}" "${TMPD}/base" > /dev/null 2>&1; then
    :
else
    printf '%s\n' "沒有安裝，略過。"
    exit 0
fi
grep -v "${MARK_ID}" "${TMPD}/base" > "${TMPD}/new"
"${CRONTAB_CMD}" "${TMPD}/new" || die "crontab 寫入失敗，原本的排程沒有被更動。"
"${CRONTAB_CMD}" -l > "${TMPD}/after" 2> /dev/null
if grep "${MARK_ID}" "${TMPD}/after" > /dev/null 2>&1; then
    die "移除後仍看得到 ${MARK_ID}，請手動 crontab -l 檢查。"
fi
printf '%s\n' "已移除本工具的排程（其他行保留不動）。"
exit 0
