# AIX 組態檢核 `fcb_aixV###.ksh` 使用說明

> **檔名帶版號**：腳本叫 `fcb_aixV001.ksh`，**內容一改就遞增**（V002、V003…）。
> 看檔名就知道手上是哪一版。
>
> 這份說明文件**刻意不帶版號**：說明常看常改，若跟著叫「使用說明V001」，
> 下次遞增就會同時存在兩三份說明，看的人不知道該信哪一份。
> 說明永遠只有這一份，講的是最新那支腳本。
>
> 下面的指令範例寫 `V001`，實際跑的時候請換成你手上那支的檔名。

對象：公司 8 台 AIX 7.2。Claude 連不到公司設備，**由管理者自己執行**，
把產出檔回傳給 Claude 判讀。

---

## 一、傳檔上去

用 WinSCP／scp 把 `fcb_aixV001.ksh` 放到 AIX 主機，例如 `/home/<你的帳號>/fcb_aixV001.ksh`。

**從 Windows 傳過去一定會帶 CRLF 換行**，ksh 會噴 `^M: not found`。上去後先轉一次：

```
tr -d '\r' < fcb_aixV001.ksh > fcb_aixV001.ksh.tmp && mv fcb_aixV001.ksh.tmp fcb_aixV001.ksh
```

確認沒有 `^M`（應該沒有輸出）：

```
grep -c $'\r' fcb_aixV001.ksh
```

---

## 二、執行

需要 root（非 root 會有 30 條以上 Error，那份結果不能用）。

```
ksh ./fcb_aixV001.ksh
```

不要用 `sh ./fcb_aixV001.ksh`——AIX 的 `/usr/bin/sh` 是 bsh，語法不同。

輸出目錄預設 **當下目錄**（2026-09-30 改；跑完就在手邊，不用再去 /var/tmp 撈）。
`cd` 到你要放結果的地方再跑就對了。

安全提醒：如果當下目錄是**其他本機帳號也寫得進去**的（例如 `/tmp`、`/var/tmp`），
腳本會在畫面與 HTML 上出聲警告。那種目錄有被人預先佈置 symlink／hard link
騙 root 覆寫系統檔的風險；腳本會逐一檢查並拒寫，但建議直接換到自己的目錄。

要換地方（排程一定要用這個，cron 的「當下目錄」是 `$HOME`，不是腳本所在處）：

```
FCBAIX_OUTDIR=/var/tmp/fcbaudit ksh ./fcb_aixV001.ksh
```

整支約數秒跑完，唯讀、不改任何系統設定。

### 檔名會帶執行時間（2026-09-30 起）

`FCB_<主機名>_<IP>_<YYYYMMDD_HHMM>.txt`（`.html`／`.debug.log` 同樣）。

為什麼：同一台跑第二次**不會蓋掉第一次**（改完設定要能跟改之前對照），
事後拿到一疊報告也能從檔名直接看出先後。

真的需要固定檔名（例如某個流程寫死了）就設 `FCBAIX_NOSTAMP=1`，會退回舊的無時間戳檔名：

```
FCBAIX_NOSTAMP=1 ksh ./fcb_aixV001.ksh
```

> 查證過：巡檢系統**不靠檔名認檔**——平台是讀檔案表頭的「平台:」，
> 匯入端點只把檔名當標籤存起來。所以加時間戳不會影響匯入。

### 報告最上面有一塊抬頭，先看那裡

`.txt` 與 `.html` 的最上方都有一塊「這份報告是什麼」：

```
================================================================================
 FCB AIX 組態檢核報告
--------------------------------------------------------------------------------
 腳本版本戳: SV.AIX.202609302300
 受檢主機  : <主機名>  (<IP>)
 執行時間  : 2026-09-30 22:14:05  ~  2026-09-30 22:14:31
 判定總數  : 已判定 98 項 / 應有 98 項    未完成 52 項（Non-Compliant 10、Error 42）
 執行身分  : root
================================================================================
```

**要回報「我跑的是哪一版」就看「腳本版本戳」那一行。**
（版本戳以前就有印，但它夾在一整塊等寬灰字表頭的中間，等於沒印——所以拉出來。）

已判定項數不等於 98、或機器不是 AIX，抬頭區塊會直接用 `!!` 標出來。

---

## 三、要回傳給 Claude 的東西

當下目錄（或 `FCBAIX_OUTDIR` 指定的目錄）底下三個檔，**全部都要**：

| 檔案 | 用途 |
|---|---|
| `FCB_<主機名>_<IP>_<YYYYMMDD_HHMM>.txt` | 檢核結果本體（就是要匯進系統的那份） |
| `FCB_<主機名>_<IP>_<YYYYMMDD_HHMM>.debug.log` | 每一條實際判定與原始輸出，出問題靠這個查 |
| `FCB_<主機名>_<IP>_<YYYYMMDD_HHMM>.html` | 給人看的版本：狀態／CIS 控制項／生效方式／關鍵字四種篩選可疊加，每欄可排序，指令欄有「複製」鈕。左上角紅色「未完成」卡片點下去只剩 Non-Compliant 與 Error |

若腳本整支跑不起來（例如一開頭就 syntax error），
**把畫面從第一行截圖**回傳——開頭的環境自檢區會列出
`uname -s`／`oslevel -s`／執行身分／13 個指令在不在／8 個關鍵檔可不可讀，
那段就足以判斷原因。

---

## 四、怎麼看結果對不對

最後一行一定是：

```
Check summary: 合計 98 項；Compliant xx；Non-Compliant xx；Not-Applicable xx；Error xx
```

**沒有這一行 = 腳本中途死掉，那份檔案不算數**，不要拿去匯入。

四種結果的意思：

| 結果 | 意思 |
|---|---|
| `Compliant` | 合規 |
| `Non-Compliant` | 不合規，要處理 |
| `Not-Applicable` | 這台沒用到（例如沒有 NFS），不列入分母 |
| `Error` | **沒查到**——指令不存在、檔案讀不到、權限不足。不是合規也不是不合規 |

`Error` 多就代表這份報告不可信。特別是非 root 執行會一次冒出 30 條以上。

合規率的分母是 **總數 − Not-Applicable − Error**，不是 98。

---

## 五、第一輪預期會踩到的雷（Claude 沒有 AIX 可先驗，這是憑經驗列的）

以下都是**推論不是證據**，請實際跑完回報：

1. `lssec` 的節名：`/etc/security/user` 的 `default` 節。若貴司用其他節（例如 `sysadmin`），
   86/91~96 會判錯，要調整
2. SNMP 設定檔路徑：腳本先找 `/etc/snmpdv3.conf`，找不到再找 `/etc/snmpd.conf`。
   若實際用其他檔名，64~66 會變 Not-Applicable
3. `/etc/exports` 的寫法各家不同，19~22 可能誤判
4. `/var/tmp/dpid2.log` 等三個 SNMP log（80~82）若未啟用 SNMP 會是 Not-Applicable
5. 檔案權限項（71~82）的期望值是照檢核表原文寫死的，
   若貴司標準與檢核表不同會誤報

回報時把 `debug.log` 一起給，Claude 才改得準。

---

## 六、這 98 條的基準是 CIS，不是 TWGCB（稽核一定會問）

**AIX 對應的是 CIS，不是 TWGCB。** 證據在檢核表自己身上：

| 檢核表裡的東西 | 對應什麼 |
|---|---|
| 類別欄 `Secure Configuration of Enterprise Assets and Software`（86 條）、`Account Management`（12 條） | **CIS Controls v8** 的控制項 4 與 5 |
| 原則設定名稱字尾 `(Automated)` 96 條／`(Manual)` 2 條 | **CIS Benchmark** 的標準標記法 |
| 上游文件 | `CIS IBM AIX 7.2 Benchmark`（現行 v1.1.0） |

輸出檔表頭已寫明「檢核基準: CIS IBM AIX 7.2 Benchmark」，
每一條的「標準設定值」欄末也標了 `[CIS Controls v8 #4 …]` 或 `[#5 帳號管理]`。

### 2026-09-30 起：原本擠在「標準設定值」裡的東西拆成六個獨立欄

> **先講欄位順序的規矩**（動欄位之前一定要看）：
>
> | 產出 | 讀者 | 欄位順序 |
> |---|---|---|
> | `.txt` | **系統**（DYN、巡檢系統的 `config_audit.py`） | **是對外契約**：只能往後加，不能插中間、不能改順序、不能改名 |
> | `.html` | **人** | 沒有這個限制，怎麼好用怎麼排 |
>
> 所以 `.txt` 的**原本六欄位置一個都沒動**
> （`TWGCB-ID` / `檢查結果` / `類別` / `原則設定名稱` / `標準設定值` / `目前值`），
> 六個新欄**全部接在第 7~12**。`.html` 則照人看的順序排，兩邊不一致是刻意的。

**三個參考來源**（`.txt` 第 7~9 欄）。前兩個都是 CIS 出的，但**是兩份不同的出版品**，
所以分開兩欄：

| 欄 | 是什麼 | 拿來做什麼 |
|---|---|---|
| `CIS基準條號` | CIS AIX 7 Benchmark v1.2.0 的 §x.y.z。「這個參數該設什麼」 | **查對**用的鍵。98 條幾乎條條不同，不適合當篩選器 |
| `CIS控制項` | CIS Critical Security Controls v8 的控制族群（#4 安全組態／#5 帳號管理）。「這件事屬於哪一類控制」 | 值少、很多條共用 → 這才是好用的**篩選維度** |
| `本行對應條號` | 本行自己的 FCB-01-002-xxxx／TWGCB-01-012-xxxx | 對內報告的第三條軸 |

`本行對應條號` 的值前面會帶「對應」或「近似」：**對應**＝語意確實相同，可以直接引用；
**近似**＝只是接近（例如 AIX 的 `minother` 把數字與符號合計，RHEL 是分開兩條）。
那個修飾詞是「這個對照能不能拿去交差」的強度資訊，刻意留在值裡沒有拿掉。
對不到的一律寫「（本行查無對應條號）」，**不硬湊**。

**三個給操作者的欄**（`.txt` 第 10~12 欄）。目的是看到一條 Non-Compliant 可以不查手冊就動手：

| 欄 | 內容 |
|---|---|
| `查核指令` | 單獨確認這一條目前狀態的指令，複製貼上就能跑。例如 `maxrepeats` 是 `lssec -f /etc/security/user -s default -a maxrepeats` |
| `修正指令` | 改成合規的指令。例如 `chsec -f /etc/security/user -s default -a maxrepeats=4` |
| `生效方式` | **受控詞彙**，只會是這幾個：`立即生效`／`下次登入生效`／**`需重設密碼時生效`**／`需重啟服務：<服務名>`／`需重開機`／`需 bosboot + 重開機`／`未確認` |

`需重設密碼時生效` 是 2026-09-30 新增的，不是換句話說：
`minlen`／`minother`／`maxrepeats`／`minage` 這些是密碼**組成與變更**規則，
**既有密碼不會回頭被檢查**——使用者下次登入不會變合規，要等他真的去改密碼。
原本標「下次登入生效」會讓排時程的人以為登入就生效，稽核時才發現沒有。

`maxage`／`maxexpired` 這兩條標 `未確認`：它們是密碼到期判斷，
我們**分不清**確切的生效時機，所以不硬塞進最接近的格子。

> ⚠️ **「修正指令」只是報告裡的文字，腳本全程唯讀、不會替你執行。**
> 貼上去跑之前請自己看過一遍，尤其是要改系統檔那幾條（rc.tcpip、inetd.conf）
> ——那些給的是步驟說明不是一行指令，因為盲改系統檔不留備份在金融環境不可接受。

> ⚠️ **「未確認」是誠實，不是缺陷。** 推不出來的一律填「未確認」，
> 不會生一個看起來很像的指令出來——填錯的指令比空白危險得多。
> 那些條目要自己查 CIS 原文件或 AIX 手冊。

生效方式用受控詞彙是**刻意的**：「改完要重開機的有哪幾條」是排維護窗口要的數字，
自由文字問不出這個數字。HTML 那份可以直接用這一欄篩，跟狀態、CIS 控制項疊加
（「未完成」＋「需重開機」＝這次停機要一起做完的清單）。

### 條號怎麼來的（2026-09-22 改版）

基準是 **CIS IBM AIX 7 Benchmark v1.2.0**（CIS 官方 PDF，567 頁，使用者自行下載）。

> **原本用的是 v1.0.0，2026-09-22 全部改成 v1.2.0。**
> 使用者拍板「以 1.2 為主」「可以改，我們只要註明參考來源」。

| | 條數 |
|---|---|
| 對到 v1.2.0 真條號 | **97** |
| v1.2.0 查無對應（本行自訂 `A-01`） | **1**（`cas_agent`） |

**為什麼非改不可**：v1.2.0 章節整個重編，98 條裡 **87 條換號、0 條沒變**。
只補缺的、其餘沿用舊號的話，報表上 87 條都是錯的引用——
**混用兩個版本比缺號更糟，稽核一比就發現對不上**。

對照方法：用**指令名／參數名／檔案路徑**當錨點（`writesrv`／`minlen`／`/etc/passwd`，
跨版本不會變），不用標題字串比——v1.2.0 標題改成 `Ensure ...` 句型
（v1.0.0 是 `Disable writesrv`、`pop3`），直接比會大量落空。

逐條變更紀錄（含舊號、新號、v1.2.0 標題）在 `AI/CIS條號對照_v1.0.0_to_v1.2.0.md`。
**舊號只留在那份紀錄裡，不上畫面**——兩個版本的號同時出現，看的人不知道該引用哪個。

## 六之二、跟 TWGCB 的關係

**TWGCB 沒有發布 AIX 版。** 已發布的是 Windows 10/11、Windows Server、
RHEL 8/9、Ubuntu、macOS 等；AIX 不在清單內。所以：

- 本檔 ID 一律是本行自訂的 `FCB-AIX-0001~0098`，
  **不會也不可以自己編一個 TWGCB 號碼**——那是造假，稽核一問就破
- 能做的是**語意對應**：AIX 這一條等同 RHEL TWGCB 的哪一條。
  對得上的在「標準設定值」欄末加註，共 **22 條**：
  - `(對應 TWGCB-xxx)` = 語意確實相同（例如 PermitEmptyPasswords、MaxAuthTries、
    IgnoreRhosts、唯一的GID、密碼最小長度、密碼最短/最長使用期限、登入失敗鎖定次數）
  - `(近似 TWGCB-xxx)` = 只是接近，不可直接畫等號（例如 AIX `minother` 把
    數字與特殊字元合併成一個值，RHEL 是 0210／0213 兩條分開算）
- 其餘約 76 條（AIX 專屬的 `inittab`／`rc.tcpip`／`inetd.conf`／`no` 網路參數等）
  **TWGCB 沒有對應項**，就不加註，不硬湊

跨平台要合併統計時，**用「類別」對齊，不要用 ID 對齊**——
AIX 這 98 條已經收進跟 RHEL 完全相同的 5 個類別：
系統服務／系統設定與維護／SSH設定／日誌與稽核／帳號與存取控制。

## 七、報告欄位裡的技術名詞（2026-10-01 從報告搬過來）

使用者原話：**「老毛病，你的備註太多了。汽車儀錶板是不需要太多備註的。」**

報告的每一格改成「一眼可讀」優先——一句話講這條在管什麼，加一組具體期望值，
其他全部砍掉。被砍掉的白話解釋不會消失，放在這一節。

| 名詞 | 是什麼 | 哪幾條會用到 |
|---|---|---|
| `/etc/inittab` | AIX 的開機啟動項清單。列在裡面而且啟動欄位不是 `off` 的，開機就會自己起來 | 0001–0004、0053 |
| `/etc/rc.tcpip` | AIX 網路服務的開機啟動腳本。**「設定關了」跟「現在沒在跑」是兩件事**，兩個都要查 | 0005–0017 |
| `/etc/inetd.conf` | 定義哪些網路服務由 `inetd` 按需啟動。這類舊式服務的帳號密碼多半明文傳送 | 0023–0043 |
| `no` | AIX 用來查與改網路核心參數的指令。`no -p` 會同時改執行中的值與開機設定 | 0044–0050 |
| restricted tunable | 少數核心參數受保護，`no -p` 會被拒。要改用 `no -r -o`，再 `bosboot -a` 並重開機 | 0044–0050 |
| `lssec` / `chsec` | 讀／寫 `/etc/security/*` 屬性的一組指令，參數完全一樣 | 0069、0086、0091–0096、0098 |
| 社群字串（community string） | SNMP 的密碼。`public`／`private`／`system` 是出廠預設值，人人都知道 | 0064–0066 |
| `no_root_squash` | NFS 輸出選項，開著代表「對方的 root 就是這台的 root」 | 0021 |
| `nosuid` / `nodev` | NFS 掛載選項。沒有 `nosuid` 就能從 NFS 上跑 setuid 程式提權 | 0018 |
| `NOCHECK` 旗標 | 出現在 `/etc/security/passwd`，帶了這個旗標，`minlen`／`minother`／`maxrepeats` 等密碼原則**全部不生效** | 0089、0090 |
| rhosts 型信任 | `hosts.equiv`／`.shosts` 這類檔案，列在裡面的主機可以免密碼登入 | 0052、0055、0056 |

### 四種判定的差別（稽核靠這個分辨我們知道什麼）

| 判定 | 意思 |
|---|---|
| `Compliant` | 查過了，符合 |
| `Non-Compliant` | 查過了，不符合 |
| `Not-Applicable` | **查過了**，確定這台不適用（例如沒開 NFS 服務），報告會寫出不適用的理由 |
| `Error` | **沒查到／查不了**。不是沒問題，是不知道 |
| 「生效方式」寫 `未確認` | 查核與修正指令都有，只有「什麼時候生效」推不出來。**不是沒事要做** |

## 八、0095 / 0096 的「生效方式」怎麼驗（要在真機上做，目前仍標未確認）

`maxage`（密碼最長使用期限）與 `maxexpired`（過期寬限期）改了之後，
**對既有帳號是什麼時候開始算的**，從文件推不出來，所以報告上一直標 `未確認`。
使用者手上有 AIX 7.2，可以實測。

### 安全性先講清楚

**這組步驟全程不動任何正式帳號的密碼。**

- 新建一個**測試帳號**來做，做完刪掉。不要拿現有帳號試。
- 不要改 `default` 節（那會套用到全機所有帳號）。
  **只改測試帳號自己那一節**：`chsec -f /etc/security/user -s <測試帳號> -a maxage=...`
- 全程只用 `lsuser` / `lssec` 這類**唯讀**指令觀察，不執行 `passwd`、不執行 `pwdadm`。
- 在正式金融主機上做，即使只動測試帳號，仍建議**先報備變更**並在離峰時段做。
  如果環境不允許新建帳號，那就**不要做**——維持 `未確認` 是正確答案，
  硬推一個沒驗過的值進報告才是錯的。

### 步驟（每一步的輸出請一起回傳）

```
# 0) 先記下目前的 default 值，做完要能對照
lssec -f /etc/security/user -s default -a maxage -a maxexpired

# 1) 建一個測試帳號（用完會刪）
mkuser fcbtest

# 2) 記錄它現在的狀態：lastupdate 是「上次改密碼的時間」（Unix 秒數）
lsuser -a maxage maxexpired lastupdate account_locked fcbtest
lssec -f /etc/security/passwd -s fcbtest -a lastupdate -a flags

# 3) 只改這個測試帳號的 maxage，改成一個「以它的 lastupdate 來算已經過期」的值
#    （例如 maxage=1 代表 1 週；若 lastupdate 是今天，就改成 maxage=1 之後
#      再把 lastupdate 往前調也行，但那等同改密碼紀錄——**不要調**，
#      改成等一週太久的話，改用步驟 4 的觀察法）
chsec -f /etc/security/user -s fcbtest -a maxage=1

# 4) 不改任何密碼，直接觀察系統現在怎麼看這個帳號
lsuser -a maxage maxexpired lastupdate fcbtest
#    重點：lastupdate 有沒有變？（預期沒有——改 maxage 不會動 lastupdate）

# 5) 關鍵問題：這個帳號現在算不算過期？用唯讀方式問系統
#    （不要真的登入，也不要 su 進去改密碼）
lssec -f /etc/security/user -s fcbtest -a maxage
lsuser -a account_locked fcbtest

# 6) 清掉
rmuser -p fcbtest
```

### 要回答的是這兩件事

1. **改 `maxage` 之後，既有帳號的「已使用幾週」是從哪一刻起算的？**
   是從 `lastupdate`（上次改密碼那天）往回算，還是從「改 maxage 的那一刻」開始算？
2. **系統是在什麼時候判定「這個密碼過期了」？**
   是下次登入時才判，還是有背景程序會提前把帳號標起來？

拿到這兩題的答案，`生效方式` 才填得下去。
**在那之前維持 `未確認`——不要用一個最接近的詞把不知道蓋過去。**

---

## 九、每月自動執行（第四個禮拜日 09:00）——2026-10-13 起

兩支新檔，跟 `fcb_aixV###.ksh` **放在同一個目錄**（例如 `/opt/webit3/fcbaix/`）：

| 檔案 | 作用 |
|---|---|
| `install_fcb_aix_cron.ksh` | 把排程裝進 root 的 crontab（或用 `-r` 移除）。只做這件事，稽核腳本本身仍然唯讀、不改系統設定 |
| `run_fcb_aix_monthly.ksh` | cron 每月 22~28 號 09:00 叫它；它自己判斷「今天是禮拜日」才跑，不是就安靜離開 |

傳檔上去後一樣先轉 LF（見第一節）。

### 先放固定目錄再裝（不要放 /tmp）

crontab 記的是**腳本所在的絕對路徑**。放在 `/tmp`、`/var/tmp` 底下的話，重開機或定期清理把檔案清掉後，
cron 每月照樣叫，但叫不到東西、不會留 log——**排程靜默失效，沒人知道這個月沒跑**。

所以安裝程式發現自己在 `/tmp`、`/var/tmp` 底下會**拒絕安裝**，並提示搬到 `/opt/webit3/fcbaix`。
（真的要留在暫存區，設 `FCBAIX_ALLOW_TMP=1` 才會照裝，並印出警告。移除 `-r` 不受限制。）

**已經裝在 /tmp 底下的，照這三步搬：**

```
cd /tmp/lab                                   # 原本放的地方
ksh ./install_fcb_aix_cron.ksh -r             # 1. 先移除舊排程
mkdir -p /opt/webit3/fcbaix && chmod 700 /opt/webit3/fcbaix
cp ./*.ksh /opt/webit3/fcbaix/                # 2. 整個目錄搬到固定位置（安裝程式要用新版）
cd /opt/webit3/fcbaix && ksh ./install_fcb_aix_cron.ksh   # 3. 從新位置重裝
crontab -l | grep webit3-fcb-aix-monthly      # 確認路徑已是 /opt/webit3/fcbaix
```

### 安裝（要用 root）

FCB 檢核有很多項只有 root 讀得到（非 root 會有多條 Error），所以排程要裝在 root 的 crontab：

```
cd /opt/webit3/fcbaix
ksh ./install_fcb_aix_cron.ksh
```

裝進去的是這一行（路徑依實際位置）：

```
0 9 22-28 * * /usr/bin/ksh /opt/webit3/fcbaix/run_fcb_aix_monthly.ksh >/dev/null 2>&1 # webit3-fcb-aix-monthly
```

* **為什麼不寫 `0 9 22-28 * 0`**：cron 的「日期」與「星期」兩欄同時有值時是 **OR**，那樣寫會變成
  22~28 號每天跑、外加每個禮拜日跑。所以 cron 只寫 22-28 號，「是不是禮拜日」由包裝程式判斷。
  22~28 號之間的禮拜日，剛好就是當月第四個禮拜日。
* **重複跑安裝不會重複加**：已經有 `# webit3-fcb-aix-monthly` 那行就印「已安裝，略過」。
* **不會動到既有排程**：做法是 `crontab -l` 取出 → 附加一行 → `crontab 檔案` 寫回，
  寫完再讀回來核對「其他行數不變、標記剛好一行」。若 `crontab -l` 讀不到、但 spool 檔其實存在，
  會直接停下來，不會拿空白去蓋掉既有排程。

### 確認已裝

```
crontab -l | grep webit3-fcb-aix-monthly
```

有一行就是裝好了。想馬上試跑一次（不等禮拜日）：

```
FCBAIX_FORCE_RUN=1 ksh /opt/webit3/fcbaix/run_fcb_aix_monthly.ksh; echo "exit=$?"
tail -20 /var/tmp/fcbaudit/fcbaudit_monthly.log
```

### 移除

```
ksh ./install_fcb_aix_cron.ksh -r
```

只刪本工具那一行，其他排程不動。

### 跑哪一支稽核腳本

自動挑**同目錄流水號最大**的 `fcb_aixV###.ksh`。換新版只要把新檔放進來，排程不用重裝。
每次挑到哪一支、同目錄共有幾支，都會寫進 log——舊版請自己刪掉，不要留一堆在同目錄。

### 產出放在哪

| 位置 | 內容 | 檔名 | 權限 |
|---|---|---|---|
| `/tmp/`（取件點） | 給其他系統來抓分析，**不壓縮** | 跟手動執行一樣：`FCB_<主機>_<IP>_<YYYYMMDD_HHMM>.txt`、`.html`、`_audit.html`、`.debug.log` | 644；設了 `FCBAIX_PICKUP_GROUP=<群組>` 則 chgrp 該群組＋640 |
| `/var/tmp/fcbaudit/`（歷史） | 這次的所有產出＋本次執行 log，打包成一個檔 | `fcbaudit_<主機>_<YYYYMMDD_HHMM>.tar.Z`（找不到 compress 才用 gzip 產 `.tar.gz`） | 目錄 700、檔案 600，只有 root |
| `/var/tmp/fcbaudit/fcbaudit_monthly.log` | 每次執行的紀錄（累積） | 固定檔名 | 600 |

* **`/tmp` 可能被主機的定期清理刪掉。** 要長期留存請看 `/var/tmp/fcbaudit/` 的歷史備份，或自行搬走。
* `/tmp` 那份是 644，**本機其他帳號也讀得到**（內容是這台的不合規清單）。目前不知道來抓的系統用哪個帳號，
  只給 root 會讓它讀不到；知道之後請改成群組可讀：在 crontab 那行的指令前面加
  `FCBAIX_PICKUP_GROUP=<群組>`。
* `/tmp` 是所有人可寫的目錄：目標檔名已經存在（包括有人先放了 symlink）就不寫、記 log，不會跟著連結去覆寫系統檔。
* 稽核腳本沒有跑完（txt 裡沒有 `Check summary:`）時，**不放到 `/tmp`**，免得別的系統拿半份去分析；歷史備份照樣打包，方便查原因。

### 解開歷史備份

```
cd /某個暫存目錄
zcat /var/tmp/fcbaudit/fcbaudit_<主機>_<YYYYMMDD_HHMM>.tar.Z | tar -xf -
# .tar.gz 的話：
gzip -dc /var/tmp/fcbaudit/fcbaudit_<主機>_<YYYYMMDD_HHMM>.tar.gz | tar -xf -
```

### 保留三年，自動刪

每次執行最後，會刪掉 `/var/tmp/fcbaudit/` **本層**、檔名符合 `fcbaudit_*.tar.Z`／`fcbaudit_*.tar.gz`、
而且超過 1095 天的備份；刪了哪些寫進 `fcbaudit_monthly.log`。其他檔、子目錄一律不碰。
每月一包、量很小，三年內的不會自動清，要提早清請自己刪。

### 不會做的事

不寄信、不往外送任何東西。crontab 那行把輸出丟到 `/dev/null`，cron 也不會寄信；要看結果就看上面那個 log。
