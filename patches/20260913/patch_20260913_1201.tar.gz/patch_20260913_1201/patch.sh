#!/usr/bin/env bash
# 一鍵套用 patch —— 在解開的這個資料夾裡執行：  sudo bash patch.sh
#
# 跑完就結束，不需要再手動做別的事。它會：
#   換檔 → 讀出這台的安裝設定 → 確認連接埠沒被佔 → 重新部署 → 驗證
#
# 為什麼要重新部署而不是只 restart：port、服務帳號、API 位址這些設定是寫在
# systemd unit 裡的，光換檔案不會生效。deploy.sh 是冪等的，重跑會把 unit
# 依現有設定重寫一次，該裝的早就裝好也不會重做。
# （2026-07-29 公司 198-014：只換檔就重啟，8000 埠衝突依舊，白跑一趟。）
#
# 出事怎麼辦：畫面會印出備份目錄與一行還原指令。
# 可以重跑：同一包重複套用不會壞，只是再備份一次。
set -uo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
APP="${WEBIT_APP:-/opt/webit3/app}"
DATA="${WEBIT_DATA:-/opt/webit3/data}"
RUNTIME="${WEBIT_RUNTIME:-/opt/webit3/runtime}"
TS="$(date +%Y%m%d_%H%M%S)"
BACKUP="$DATA/patch_backup_$TS"
API_UNIT=/etc/systemd/system/webit3-api.service
WEB_UNIT=/etc/systemd/system/webit3-web.service

# 版號從 version.json 撈。看得到「從哪版到哪版」才知道 patch 到底有沒有生效，
# 否則畫面跑完一長串訊息，還是不確定自己套成功了沒。
ver_of() { grep -oE '[0-9]+\.[0-9]+\.[0-9]+' "$1" 2>/dev/null | head -1; }
OLD_VER="$(ver_of "$APP/backend/version.json")"
NEW_VER="$(ver_of "$HERE/files/backend/version.json")"

echo "════════════════════════════════════════════════"
echo " 套用 patch： $(basename "$HERE")"
echo " 目標位置　： $APP"
echo " 時間　　　： $(date '+%F %T')"
echo " 版本　　　： ${OLD_VER:-未知} → ${NEW_VER:-未變更}"
echo "════════════════════════════════════════════════"

if [ -f "$HERE/MANIFEST.txt" ]; then
  echo
  echo "這包改了什麼："
  sed -n '/== 這包改了什麼 ==/,/^$/p' "$HERE/MANIFEST.txt" | sed '1d;/^$/d' | sed 's/^/  · /'
fi

if [ -n "$OLD_VER" ] && [ "$OLD_VER" = "$NEW_VER" ]; then
  echo
  echo "  註：版號相同，這包可能已經套過了。重跑無害，會照樣覆蓋檔案並重啟。"
fi

[ "$(id -u)" = "0" ] || { echo "!! 請用 sudo 執行： sudo bash patch.sh"; exit 1; }

# 中途被 Ctrl+C 時要講清楚後果與怎麼收尾（2026-08-16 公司主機踩到）：
# 檔案在 [2/5] 就換好了，但 schema 遷移在 [4.5/5]——中斷在中間會留下
# 「程式是新的、資料庫是舊的」，打開新頁面就 no such table，而且沒有任何提示。
# patch.sh 本身冪等，所以正確的收尾就是「再跑一次」。
trap 'echo; echo "!! 中斷了。檔案可能已經換成新版、但資料庫遷移與重啟還沒做。"; \
      echo "   請直接再跑一次（這支腳本冪等，重跑無害）： sudo bash $0"; exit 130' INT TERM
[ -d "$APP" ] || { echo "!! 找不到 $APP —— 這台還沒安裝過，請先跑 setup.sh 做完整安裝"; exit 1; }
[ -d "$HERE/files" ] || { echo "!! 這包裡沒有 files/，patch 不完整"; exit 1; }

# ===== 1. 備份 =====
echo
echo "[1/5] 備份即將被覆蓋的檔案 → $BACKUP"
mkdir -p "$BACKUP"
COUNT=0
while IFS= read -r rel; do
  src="$APP/$rel"
  if [ -f "$src" ]; then
    mkdir -p "$BACKUP/$(dirname "$rel")"
    cp -p "$src" "$BACKUP/$rel"
    COUNT=$((COUNT+1))
  fi
done < <(cd "$HERE/files" && find . -type f | sed 's|^\./||')
echo "  已備份 $COUNT 個既有檔案"

# ===== 2. 覆蓋 =====
echo
echo "[2/5] 套用新檔案"
(cd "$HERE/files" && find . -type f | sed 's|^\./||') | while IFS= read -r rel; do
  mkdir -p "$APP/$(dirname "$rel")"
  cp -p "$HERE/files/$rel" "$APP/$rel"
  echo "  ✓ $rel"
done

# ===== 2.5 前端產物 =====
# 前端有改時 patch 會帶 frontend-output.tar.gz（目標主機不能自己 build）。
# 用「先解到旁邊、成功了才換上去」的方式：解壓解到一半失敗也不會留下半殘的 .output
# 讓前端服務起不來。
if [ -f "$HERE/frontend-output.tar.gz" ]; then
  echo
  echo "[2.5/5] 更新前端（已 build 的產物）"
  STAGE="$APP/frontend/.output.new.$$"
  rm -rf "$STAGE"; mkdir -p "$STAGE"
  if tar xzf "$HERE/frontend-output.tar.gz" -C "$STAGE" && [ -f "$STAGE/.output/server/index.mjs" ]; then
    rm -rf "$APP/frontend/.output.old"
    [ -d "$APP/frontend/.output" ] && mv "$APP/frontend/.output" "$APP/frontend/.output.old"
    mv "$STAGE/.output" "$APP/frontend/.output"
    rm -rf "$STAGE"
    echo "  ✓ 前端已更新（舊版留在 .output.old，確認沒問題可自行刪除）"
  else
    rm -rf "$STAGE"
    echo "  !! 前端產物解壓失敗，維持原本的版本不動"
    exit 1
  fi
fi

# ===== 3. 修換行 + 權限 =====
# 檔案經 Windows 中轉會變成 CRLF，bash 會直接噴 $'\r': command not found。
echo
echo "[3/5] 修正換行符與權限"
find "$APP" -maxdepth 2 -name '*.sh' -exec sed -i 's/\r$//' {} + 2>/dev/null
find "$APP" -maxdepth 2 -name '*.sh' -exec chmod +x {} + 2>/dev/null
OWNER="$(stat -c %U "$APP" 2>/dev/null || echo root)"
chown -R "$OWNER:$OWNER" "$APP" 2>/dev/null
echo "  ✓ 換行符已正規化，owner 維持 $OWNER"

# ===== 4. 讀出這台的安裝設定，並確認連接埠 =====
echo
echo "[4/5] 讀取安裝設定"
CONF="$DATA/install.conf"
if [ -f "$CONF" ]; then
  # shellcheck disable=SC1090
  . "$CONF"
  echo "  來源： $CONF"
else
  # 舊版安裝沒有留設定檔，就從現成的 systemd unit 反推——這些值本來就寫在裡面。
  echo "  來源： 既有 systemd unit（這台是舊版安裝的，沒有 install.conf）"
  API_PORT="$(grep -oE '\-\-port +[0-9]+' "$API_UNIT" 2>/dev/null | grep -oE '[0-9]+' | head -1)"
  WEB_PORT="$(grep -oE '^Environment=PORT=[0-9]+' "$WEB_UNIT" 2>/dev/null | grep -oE '[0-9]+' | head -1)"
  API_HOST="$(grep -oE 'NUXT_PUBLIC_API_BASE=https?://[^:]+' "$WEB_UNIT" 2>/dev/null | sed 's|.*//||' | head -1)"
  SVC_USER="$(grep -oE '^User=.+' "$API_UNIT" 2>/dev/null | cut -d= -f2 | head -1)"
  NODE_BIN="$(grep -oE '^ExecStart=[^ ]+' "$WEB_UNIT" 2>/dev/null | cut -d= -f2 | head -1)"
fi
API_PORT="${API_PORT:-8000}"; WEB_PORT="${WEB_PORT:-3000}"
SVC_USER="${SVC_USER:-$OWNER}"; API_HOST="${API_HOST:-127.0.0.1}"
ORIG_PORT="$API_PORT"   # 記著原值：只有埠真的被改掉時才需要重寫 systemd unit
[ -n "${NODE_BIN:-}" ] || { [ -x "$RUNTIME/node/bin/node" ] && NODE_BIN="$RUNTIME/node/bin/node" || NODE_BIN=/usr/bin/node; }
[ -n "${PYTHON311:-}" ] || { [ -x "$RUNTIME/python311/bin/python3" ] && PYTHON311="$RUNTIME/python311/bin/python3" || PYTHON311=python3.11; }
echo "  位址 $API_HOST ｜ 後端埠 $API_PORT ｜ 前端埠 $WEB_PORT ｜ 帳號 $SVC_USER"

# 先把自己的服務停掉，再看埠有沒有被佔 —— 這樣才分得出
# 「本來就是自己佔著」（正常）跟「被別的程式佔走」（會讓後端永遠起不來）。
#
# ⚠️ 這一步要有輸出、要有上限（2026-08-16 公司主機實際卡住）：
# `systemctl stop` 會一直等到服務真的停下來，行程若不理 SIGTERM，systemd 會等到
# TimeoutStopSec（預設 90 秒）才強制砍——兩個 unit 就是最多 3 分鐘**完全沒有任何
# 輸出**，看起來跟當掉一模一樣，人只會以為 patch 壞了然後 Ctrl+C（那才真的會留下
# 半套狀態：檔案換了、schema 沒遷移）。
# 所以：先講要做什麼、加 timeout 上限、逾時就強制砍並說明，絕不無限等。
echo "  停止服務以檢查埠是否被佔用（最多等 30 秒）…"
if command -v timeout >/dev/null 2>&1; then
  if ! timeout 30 systemctl stop webit3-api webit3-web 2>/dev/null; then
    echo "  ⚠ 服務 30 秒內沒停下來，改強制停止（不影響資料，服務稍後會重啟）"
    systemctl kill -s KILL webit3-api webit3-web 2>/dev/null || true
    sleep 2
  fi
else
  systemctl stop webit3-api webit3-web 2>/dev/null || true
fi
echo "  ✓ 服務已停止"
sleep 1
if ss -tln 2>/dev/null | grep -qE "[:.]${API_PORT}[[:space:]]"; then
  echo
  echo "  ⚠ 後端埠 $API_PORT 被別的程式佔用（已先停掉本系統服務，仍被佔）："
  ss -tlnp 2>/dev/null | grep -E "[:.]${API_PORT}[[:space:]]" | sed 's/^/      /'
  echo "    不換埠的話，後端會一直起不來（Errno 98 address already in use）。"
  if [ -t 0 ]; then
    read -rp "  輸入新的後端埠，直接 Enter 沿用 $API_PORT： " NEWPORT
    [ -n "$NEWPORT" ] && API_PORT="$NEWPORT" && echo "  → 改用 $API_PORT"
  else
    echo "    （非互動模式，維持 $API_PORT；要換請用： sudo API_PORT=8010 bash patch.sh）"
  fi
else
  echo "  ✓ 後端埠 $API_PORT 可用"
fi

# ===== 4.5 資料庫 schema 遷移 =====
# **這一段是必要的，不是保險**：patch 只換檔案，新版程式常常需要新的資料表／欄位
# （2026-08-15 一天就新增了 5 張表）。沒跑這步，程式碼是新的、資料庫是舊的，
# 打開那些新頁面就 "no such table"——而且 patch 會顯示成功，最難查的那種。
#
# db.py 的 init_db() 是冪等的：CREATE TABLE IF NOT EXISTS ＋ 只加欄位不刪欄位，
# 時區那次性遷移也用 app_settings 擋住重跑。所以**每次 patch 都跑**，
# 不去判斷「這次有沒有動 schema」——判斷錯的代價（安靜壞掉）遠大於多跑一秒。
echo
echo "[4.5/5] 資料庫 schema 遷移"
DB_FILE="$DATA/asset.db"
VENV_PY="${WEBIT_VENV:-/opt/webit3/venv}/bin/python"
[ -x "$VENV_PY" ] || VENV_PY="$PYTHON311"
if [ -f "$DB_FILE" ]; then
  # 動 schema 前先備份 DB。檔案覆蓋還原得回來，資料庫改壞了還不回來。
  cp -a "$DB_FILE" "$BACKUP/asset.db.pre_patch" 2>/dev/null     && echo "  ✓ 已備份資料庫 → $BACKUP/asset.db.pre_patch"
fi
if ASSET_DB_PATH="$DB_FILE" "$VENV_PY" "$APP/backend/db.py" >/tmp/webit3_migrate.log 2>&1; then
  echo "  ✓ schema 已是最新（$(tail -1 /tmp/webit3_migrate.log)）"
else
  echo "  !! schema 遷移失敗——新頁面可能會出現 no such table："
  tail -8 /tmp/webit3_migrate.log | sed 's/^/     /'
  echo "     還原： sudo cp -a $BACKUP/asset.db.pre_patch $DB_FILE"
fi

# ===== 4.6 Python 相依套件（離線）=====
# 2026-09-11 v1.94.0 把納管從 sshpass 換成 paramiko。221 能上網、deploy.sh 會自己裝；
# 公司主機離線，patch 又不跑 pip——沒有這步，程式照常啟動（paramiko 是納管當下才載入），
# 但**所有納管都會失敗**，而 patch 顯示成功，最難查的那種。
# 只從 patch 自帶的 wheels 裝（--no-index，絕不連網）；已經裝好的就跳過，重跑不會重裝。
echo
echo "[4.6/5] Python 相依套件（離線安裝）"
if "$VENV_PY" -c "import paramiko" 2>/dev/null; then
  echo "  ✓ paramiko 已安裝（$("$VENV_PY" -c 'import paramiko; print(paramiko.__version__)')），不用裝"
elif ls "$HERE/wheels/"*.whl >/dev/null 2>&1; then
  if "$VENV_PY" -m pip install --no-index --find-links "$HERE/wheels" paramiko >/tmp/webit3_pip.log 2>&1; then
    echo "  ✓ 已從 patch 內附的套件離線安裝 paramiko（$("$VENV_PY" -c 'import paramiko; print(paramiko.__version__)')）"
  else
    echo "  !! paramiko 安裝失敗——系統照常運作，但『納管』功能會失敗："
    tail -6 /tmp/webit3_pip.log | sed 's/^/     /'
    echo "     常見原因：venv 缺 cryptography／cffi（paramiko 需要它們），把上面訊息貼給開發者"
  fi
else
  echo "  !! 這包沒有附 wheels，paramiko 也還沒裝——『納管』功能會失敗"
fi

# ===== 5. 讓新程式碼生效 =====
# 重啟是必要的：後端是常駐的 uvicorn、前端是常駐的 node，不重啟就還在跑舊的記憶體內容，
# 檔案換了也沒用。但「重跑整支 deploy.sh」是另一回事——那會重建 venv、檢查 pip 依賴、
# 重寫 systemd、開防火牆，那些是安裝在做的事，換幾個檔案根本不需要，只是拖慢每次 patch。
# 所以只有真的動到設定時才走完整部署。
NEED_DEPLOY=0
REASON=""
if [ ! -f "$API_UNIT" ] || [ ! -f "$WEB_UNIT" ]; then
  NEED_DEPLOY=1; REASON="systemd unit 還不存在"
elif [ "$API_PORT" != "$ORIG_PORT" ]; then
  NEED_DEPLOY=1; REASON="後端埠改為 $API_PORT，unit 要重寫"
fi

echo
if [ "$NEED_DEPLOY" = "1" ]; then
  echo "[5/5] 重新部署（$REASON）"
  if [ -f "$APP/deploy.sh" ]; then
    export API_HOST API_PORT WEB_PORT SVC_USER PYTHON311 NODE_BIN
    bash "$APP/deploy.sh" 2>&1 | sed 's/^/  /'
    DEPLOY_RC=${PIPESTATUS[0]}
  else
    echo "  !! 找不到 $APP/deploy.sh"
    DEPLOY_RC=1
  fi
else
  echo "[5/5] 重啟服務（設定沒變動，不需要重跑安裝程序）"
  systemctl daemon-reload 2>/dev/null
  systemctl restart webit3-api webit3-web 2>/dev/null
  DEPLOY_RC=0
fi

sleep 2
OK=1
for svc in webit3-api webit3-web; do
  if systemctl is-active --quiet "$svc"; then
    echo "  ✓ $svc active"
  else
    echo "  ✗ $svc 沒起來"
    journalctl -u "$svc" -n 25 --no-pager 2>/dev/null | tail -15
    OK=0
  fi
done

# 設定留檔，下次 patch 直接沿用，不必再從 unit 反推。
mkdir -p "$DATA"
cat > "$CONF" <<CONFEOF
API_HOST=$API_HOST
API_PORT=$API_PORT
WEB_PORT=$WEB_PORT
SVC_USER=$SVC_USER
PYTHON311=$PYTHON311
NODE_BIN=$NODE_BIN
CONFEOF
chown "$SVC_USER:$SVC_USER" "$CONF" 2>/dev/null

echo
echo "════════════════════════════════════════════════"
if [ "$OK" = "1" ] && [ "${DEPLOY_RC:-0}" = "0" ]; then
  NOW_VER="$(ver_of "$APP/backend/version.json")"
  if [ -n "$OLD_VER" ] && [ "$OLD_VER" != "$NOW_VER" ]; then
    echo "✅ patch 完成：版本 $OLD_VER → $NOW_VER，服務已在跑"
  else
    echo "✅ patch 完成（版本 ${NOW_VER:-未知}），服務已在跑"
  fi
  echo "   前端： http://$API_HOST:$WEB_PORT   ← 開這個，右上角版號應該是 $NOW_VER"
  echo "   後端： http://$API_HOST:$API_PORT"
  echo "   備份： $BACKUP"
else
  echo "!! 沒有完成 —— 上面的錯誤訊息就是原因"
  echo
  echo "   要還原成套用前的狀態："
  echo "     sudo cp -rp $BACKUP/* $APP/ && sudo systemctl restart webit3-api webit3-web"
  echo
  echo "   查不出來就把整個畫面貼回給 AI。"
fi
echo "════════════════════════════════════════════════"
[ "$OK" = "1" ] && [ "${DEPLOY_RC:-0}" = "0" ]
