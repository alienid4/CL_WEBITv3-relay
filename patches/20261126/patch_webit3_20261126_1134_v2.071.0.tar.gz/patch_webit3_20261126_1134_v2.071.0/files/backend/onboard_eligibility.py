"""這台機器「可不可以被納管」——以資產庫登記的作業系統為準的白名單。

## 為什麼要有這一支（2026-09-08 使用者拍板）

批次納管原本只看「有沒有開 22」。問題是**一大堆不是伺服器的東西也開 22**：
交換器、儲存設備、F5、FortiGate、KVM 切換器、還有伺服器的管理卡（iDRAC）。
它們都吃 SSH、banner 也常自報 Linux/Unix，`useradd` 下去有的還會成功。

查 221 實際資料（4784 筆）之後才知道規模——`os` 欄不是伺服器作業系統的有 1051 筆：

    128 網路設備   83 儲存設備   52 Idrac(BMC)   30 APIC   cisco/juniper/HP 交換器
    21 V7R3 / 18 V7R5(IBM i)   6 BIG-IP   6 fortigate   8 ATEN(KVM)   Avamar

**為什麼是白名單不是黑名單**：上面那些值我一個也猜不到，黑名單漏掉一個廠牌
就是在網通設備上建帳號。白名單的失敗方向是「不認得就跳過」，那是對的方向。

## CoreOS／RHCOS 要單獨排除

221 上有約 167 台 CoreOS／RHCOS，那是 **OpenShift 節點**。它們**確實是 Linux、
SSH 進得去、useradd 也會成功**，所以任何「像 Linux 就納管」的判法都會掃到它們。
但 CoreOS 是不可變作業系統，本機帳號會在節點重佈時消失（收集之後會無聲失效），
而且那批機器歸 OpenShift 管。使用者 2026-09-08 原話：「CoreOS／RHCOS不能動他們」。

所以順序很重要：**先比對不可變清單，再比對 Linux 清單**。

## 這裡只回答「可不可以」，不回答「要不要」

環境別（正式／備援不碰）是另一層判斷，留在 batch_onboard_service。
一個函式只回答一件事，兩件混在一起以後沒人敢改。
"""
from __future__ import annotations

import re

#: 不可變作業系統：是 Linux，但**不可以**在上面建本機帳號（見模組說明）。
#: 一定要排在 LINUX_OK 前面比對——"Container Linux" 也會命中 LINUX_OK。
IMMUTABLE_OS = re.compile(
    r"coreos|rhcos|flatcar|container\s*linux|talos|bottlerocket", re.I)

#: 可以納管的伺服器 Linux。白名單：**不在這裡面的一律不跑**。
#: 結尾那個泛用的 `linux` 是給「Linux」「SUSE Linux Enterprise」這類寫法的，
#: 放最後，而且前面已經先擋掉不可變 OS 與設備。
LINUX_OK = re.compile(
    r"red\s*hat|rhel|centos|rocky|almalinux|oracle\s*linux|"
    r"debian|ubuntu|suse|sles|linux", re.I)

WINDOWS_OS = re.compile(r"windows", re.I)

#: 儲存設備：從 appliance 裡獨立出來（2026-10-13 使用者：「是 storage
#: 你怎麼抓不出來，可把 storage 獨立分類出來」）。原本網通／儲存／管理卡全擠在
#: appliance 一類，看不出哪些是儲存——221 實際資料裡儲存設備就有 83 筆。
#:
#: 規則用 `system_stats.STORAGE_RE`——**全站只有一條**。分佈統計的 Storage 分群、
#: pipeline 的 Storage/SAN 類別讀的是同一條；在這裡另寫一套會變成同一件事兩個
#: 答案，改了一邊另一邊靜靜地不一致。
#:
#: 比對順序必須在 WINDOWS_OS 之後：STORAGE_RE 含裸的 `storage`，順序寫錯會把
#: 「Windows Storage Server」這台 Windows 伺服器吃掉，漏掉一台該納管的機器。
def _storage_re():
    import system_stats
    return system_stats.STORAGE_RE

#: 是 Linux（或自稱 Linux），但**不走這支建帳號**的平台（2026-10-22 使用者：「做」）：
#:   - Oracle Linux（含 ODA／Exadata）：平台白名單 10-19 就擋了（onboard_engine），分類這層要一致，
#:     不然 2-1 擺在 SSH 頁簽、首頁算「可納管」，一按納管才被白名單拒
#:   - OS 欄寫「客製」：廠商客製系統（FireEye客製化系統(Linux)、Apex客製化系統(Linux)）
#:     ⚠️ 不可以抓「Apex」這個字——資產用途裡的 Apex 是防毒（Trend Apex One），會誤擋 Windows
#:   - ApplianceOS：設備自帶的作業系統
#: 一定要排在 LINUX_OK 前面比對——它們的字樣多半帶 Linux。結論是 appliance（擋），不是新類別：
#: classify_os 的讀者很多，多一個值它們會收到認不得的類別（見 KIND_NETWORK 那段）。
VENDOR_PLATFORM_OS = re.compile(r"oracle\s*(enterprise\s*)?linux|客製|appliance\s*os", re.I)

AIX_OS = re.compile(r"\baix\b", re.I)
ESXI_OS = re.compile(r"esxi|vmware", re.I)

#: 空值的各種寫法。人工填表填出來的，不是程式產的，所以要寬一點。
_BLANK = {"", "-", "--", "n/a", "na", "n.a.", "無", "不明", "未知"}


def classify_os(os_text: str | None) -> tuple[str, str]:
    """回 (類別, 給人看的理由)。

    類別：
      linux      —— 可以走這支批次納管
      immutable  —— 是 Linux 但不可以動（OpenShift 節點）
      windows    —— 走 WinRM，不是這支
      aix        —— 走 ksh 腳本，不是這支
      esxi       —— 虛擬化平台本身，不納管
      appliance  —— 認不出來的：網通／儲存／管理卡等設備
      unknown    —— 資產庫沒填作業系統，無從判斷
    """
    raw = (os_text or "").strip()
    if raw.lower() in _BLANK:
        return "unknown", "資產庫沒填作業系統——判不出這是伺服器還是設備，不自動納管"
    if IMMUTABLE_OS.search(raw):
        return "immutable", (
            f"{raw}——OpenShift 節點（不可變作業系統）。"
            "本機帳號會在節點重佈時消失，且該批機器歸 OpenShift 管，不納管")
    if ESXI_OS.search(raw):
        return "esxi", f"{raw}——虛擬化平台本身，不建本機帳號"
    if WINDOWS_OS.search(raw):
        return "windows", f"{raw}——要走 WinRM 流程，這支不做"
    if AIX_OS.search(raw):
        return "aix", f"{raw}——AIX 要走 ksh 腳本，批次這支只做 Linux"
    if _storage_re().search(raw):
        return "storage", f"{raw}——儲存設備，不建本機帳號"
    if LINUX_OK.search(raw):
        return "linux", raw
    return "appliance", (
        f"{raw}——不在可納管的作業系統清單裡（網通／儲存／管理卡之類的設備）。"
        "認不出來就不碰，不是漏掉")


def eligibility_os(os_text: str | None) -> tuple[str, str]:
    """「能不能納管」用的分類：classify_os 再加一層廠商平台（VENDOR_PLATFORM_OS）→ appliance。

    為什麼不直接改 classify_os：它也是**作業系統分類**的唯一來源（pipeline 的 OS 類型、
    帳號盤點的 OS 桶）。Oracle Linux 是 Linux 沒錯，只是不走這套納管——改 classify_os 會把它
    在作業系統統計裡變成「設備」，那是錯的。擋不擋只在這一層決定。
    """
    kind, why = classify_os(os_text)
    raw = (os_text or "").strip()
    if kind == "linux" and VENDOR_PLATFORM_OS.search(raw):
        return "appliance", (
            f"{raw}——廠商平台（Oracle Linux／客製系統／設備自帶 OS），另有納管方式，不建本機帳號")
    return kind, why


def is_onboardable(os_text: str | None) -> bool:
    """只有明確認得出是伺服器 Linux 才回 True。**認不出來一律 False。**"""
    return eligibility_os(os_text)[0] == "linux"


# ===== 收集分派用：這台「不可以納管」嗎？（2026-09-14）=====
# 使用者：「很明顯看得出是 VMware，可能是 ESXi……雖然它有 SSH，但應該要有一個標記，
# 這樣我就會不去納管它」「我的定義雖然是 Linux，但這種設備我不能納管」。
#
# 收集分派（/adopt 的收集結果表）原本只看 22 有沒有開，開了就去試連、就列進「要憑證」。
# 批次納管那支已經照作業系統白名單擋了，但分派表沒有，畫面上看不出哪台是 ESXi。
#
# 證據兩種，任一成立就不納管，理由寫清楚是哪一種：
#   1. 資產庫登記的作業系統（classify_os）是 ESXi／OpenShift 節點／設備
#   2. vCenter（RVTools）匯入把這台列為 ESXi 主機——作業系統欄沒填或填錯也抓得到

import json as _json
import re as _re

#: 不納管的類別 → 給人看的標籤。**公開名稱**：收集分派要用它把不納管的那幾台
#: 拆成「儲存幾台、ESXi 幾台」（2026-10-13 使用者：統計方塊是合計的，看不出其中
#: 幾台是儲存設備）。呼叫端一律用這個名字，不要去存取底線開頭的私有名。
#:
#: ⚠️ 這張表的鍵**就是** `classify_os` 會回的類別，而 `not_onboardable()` 靠
#: `kind in NOT_ONBOARDABLE_LABEL` 決定要不要擋——所以不要把 classify_os
#: 不會回的值塞進來（banner 自報的那一類見下面的 KIND_BANNER）。
NOT_ONBOARDABLE_LABEL = {
    "esxi": "VMware ESXi",
    "immutable": "OpenShift 節點",
    "storage": "儲存設備",
    "appliance": "設備（不在可納管作業系統清單）",
}

#: SSH banner 自報身分而擋下來的那一類（見本檔最後的 `product_from_banner`）。
#: 它不是 `classify_os` 的結論，所以**刻意不放進 NOT_ONBOARDABLE_LABEL**。
#:
#: 為什麼要給它一個類別：分派結果的「不納管」方塊要拆成各類別的數字，
#: 如果 banner 擋下來的那幾台沒有類別，拆出來的小計就加不回方塊上的總數——
#: 使用者看到「不納管 11」底下只列到 8，只能自己猜剩下 3 台去哪了。
KIND_BANNER = "banner"
_KIND_BANNER_LABEL = "SSH banner 自報的設備"

#: 網路設備：從 appliance 裡再拆出來（2026-10-13 使用者：/adopt 的「SSH 收集」頁簽
#: 混著 Aruba 等網路設備，要獨立一個頁簽看得出幾台）。
#:
#: ⚠️ **不另寫規則**：「這是不是網路設備」全站只有一份——`manage_state._PLATFORM_RULES`
#: 的「網路設備」那一條（首頁平台統計、pipeline 的 OS 類型漏斗都讀它，使用者 2026-08-13
#: 逐條補過 aruba／fortinet／f5／big-ip…）。這裡只是呼叫 `manage_state.platform_of`。
#:
#: 為什麼不改 `classify_os` 讓它直接回 network：classify_os 的 appliance 有很多讀者
#: （pipeline 的 OS 漏斗、批次納管、manage_state），它們各自再細分；在這裡多一個類別
#: 會讓那些讀者突然收到認不得的值。所以只在「不納管的類別」這一層細分——
#: **擋不擋的結論不變**（appliance 本來就擋），變的只是擋下來之後歸哪一類。
#:
#: 也**不**從資產名稱／用途（自由文字）推網路設備：「網管主機」「網路監控」那種
#: 用途寫在一般 Linux 伺服器上很常見，拿來擋會把該納管的伺服器擋掉。
KIND_NETWORK = "network"
_KIND_NETWORK_LABEL = "網路設備"
_ARUBA_NAME = _re.compile(r"aruba|airwave", _re.I)


def is_network_device(text) -> bool:
    """這段文字（作業系統欄／banner 自報的產品名）是不是網路設備。規則見 KIND_NETWORK。"""
    if not text:
        return False
    import manage_state
    return manage_state.platform_of(str(text)) == "網路設備"


def kind_from_banner(product) -> str:
    """SSH banner 自報的產品名 → 不納管的類別。

    banner 認得出來的東西多半有明確歸屬（NetApp 是儲存、Cisco 是網路設備、ESXi 是 ESXi），
    一律丟進「banner」會讓 /adopt 的儲存／網路／ESXi 頁簽漏算這幾台。
    儲存與網路都用全站唯一那條規則判；ESXi 只認產品名寫明 ESXi 的——
    `VMware Avi Load Balancer` 也帶 VMware 字樣，但它是負載平衡器，不是虛擬化平台。
    認不出歸屬的（iDRAC、Avi、FortiGate…）維持 banner。
    """
    p = str(product or "")
    if not p:
        return KIND_BANNER
    import system_stats
    if system_stats.STORAGE_RE.search(p):
        return "storage"
    if _re.search(r"\besxi\b", p, _re.I):
        return "esxi"
    if is_network_device(p):
        return KIND_NETWORK
    return KIND_BANNER


def kind_label(kind) -> str:
    """不納管類別 → 給人看的標籤。

    認不出來的類別**回原字串**，不回空字串也不丟例外：這是顯示用的，
    吞掉未知類別只會讓畫面少一格數字、對不上總數，比印出生字串更難查。
    """
    if kind == KIND_BANNER:
        return _KIND_BANNER_LABEL
    if kind == KIND_NETWORK:
        return _KIND_NETWORK_LABEL
    return NOT_ONBOARDABLE_LABEL.get(kind) or str(kind or "")


#: 自由文字（資產名稱／用途）只採信這幾種**正面認出來**的結論。
#: 不含 appliance——那一類代表「認不出來」，不是證據。
_FROM_FREE_TEXT = ("storage", "esxi", "immutable")

_IPV4 = _re.compile(r"^\d{1,3}(\.\d{1,3}){3}$")


def _name_keys(name) -> set[str]:
    """主機名比對鍵：原字串大寫＋去網域的短名（IP 不去網域，不然 10.x 會變成 10）。"""
    s = str(name or "").strip().upper()
    if not s:
        return set()
    if _IPV4.match(s):
        return {s}
    # [B-03] 以前「見點就砍」（s.split(".")[0]）：堆疊成員「…-254.254-1／-2」會被砍成同一個短名。
    # 改用 system_stats.strip_domain——只有真的網域才去，跟全站「同一台」的判斷同一條。
    import system_stats
    return {s, system_stats.strip_domain(s)}


def esxi_host_names(conn) -> set[str]:
    """vCenter（RVTools）匯入裡被列為 ESXi 主機的名字／IP（正規化後）。
    2.070.x：同一個請求範圍內只掃一次 source_record（fleet_cache.scope_memo；主機履歷一次請求原本掃兩、三次），回拷貝。
    沒有請求範圍、或連線自己寫過時照舊每次重掃。"""
    import fleet_cache

    return set(fleet_cache.scope_memo(conn, "onboard_eligibility.esxi_host_names", lambda: _esxi_host_names(conn)))


def _esxi_host_names(conn) -> set[str]:
    out: set[str] = set()
    try:
        rows = conn.execute(
            "SELECT payload FROM source_record WHERE source = 'vcenter'").fetchall()
    except Exception:  # noqa: BLE001 - 舊 DB 沒有這張表就當沒有證據
        return out
    for r in rows:
        try:
            d = _json.loads(r[0] or "{}")
        except (ValueError, TypeError):
            continue
        if isinstance(d, dict) and d.get("esxi_host"):
            out |= _name_keys(d["esxi_host"])
    return out


def not_onboardable(os_text, hostname=None, ip=None,
                    esxi_names=frozenset(), extra_text=None) -> tuple[str, str, str] | None:
    """回 (類別, 標籤, 依據)；可以試著納管就回 None。

    `extra_text` = 資產名稱＋資產用途（2026-10-13）。
    使用者指著一台 EMC UnityXT480 NAS 問「是 storage 你怎麼抓不出來」——
    它的作業系統欄是 `N/A`，classify_os 只讀 os 欄，所以回 unknown；
    但「EMC UnityXT480 NAS (iSCSI target)」就寫在資產用途裡，證據一直都在，
    只是判定的人沒去看（normalize_model 早就靠這兩欄猜出 "…storage"）。

    ⚠️ 只有 os 欄判不出來（unknown）時才看這兩欄，而且**只採信會擋下來的結論**：
    資產用途寫著 Linux 不能拿來當「可以納管」的憑據——那兩欄是人填的自由文字，
    拿它開門風險不對稱。失敗方向維持「漏標」。
    """
    kind, why = eligibility_os(os_text)
    if kind == "appliance" and is_network_device(os_text):
        # 擋的結論跟 appliance 一樣，只是歸到網路設備這一類（見 KIND_NETWORK）
        return KIND_NETWORK, _KIND_NETWORK_LABEL, f"依據：資產登記的作業系統「{why}」"
    if kind in NOT_ONBOARDABLE_LABEL:
        return kind, NOT_ONBOARDABLE_LABEL[kind], f"依據：資產登記的作業系統「{why}」"
    if kind == "unknown" and extra_text:
        k2, why2 = classify_os(extra_text)
        # 只收**正面認出來**的類別。appliance 的語意是「不在白名單、認不出來」，
        # 套在自由文字上會把「測試機」這種什麼都沒講的用途也判成設備——那是
        # 把「不知道」當成「知道它不是伺服器」，方向相反。
        if k2 in _FROM_FREE_TEXT:
            return k2, NOT_ONBOARDABLE_LABEL[k2], (
                f"依據：作業系統欄沒填，但資產名稱／用途寫著「{why2}」")
    if kind == "unknown":
        # Aruba（Aruba_Airwave 那種 OS 填 N/A 的，2026-10-22）：只收 aruba／airwave 這兩個廠牌字，
        # 不用 is_network_device——那套有 ios／f5 這種短字，套在自由文字上太容易誤中
        for t in (hostname, extra_text):
            if t and _ARUBA_NAME.search(str(t)):
                return KIND_NETWORK, _KIND_NETWORK_LABEL, (
                    f"依據：作業系統欄沒填，但名稱寫著「{t}」（Aruba 網路設備）")
    if esxi_names and ((_name_keys(hostname) | _name_keys(ip)) & set(esxi_names)):
        return "esxi", NOT_ONBOARDABLE_LABEL["esxi"], (
            "依據：vCenter（RVTools）匯入把它列為 ESXi 主機——虛擬化平台本身，不建本機帳號")
    # 主機名稱有 OCP 字樣（2026-10-22 使用者：「這些有 OCP 字眼都應該算在 OCP，不能算納管失敗，
    # 他本來就不能納管」）：公司 OCP 叢集節點的 FQDN 帶 `.ocpt.`／`.ocp.`，作業系統欄卻登記成 Linux。
    # 放在最後：VMware（vCenter 名單、登記 OS）等正面判定優先（天條順序）。
    if is_ocp_name(hostname):
        return "immutable", NOT_ONBOARDABLE_LABEL["immutable"], f"{OCP_NAME_WHY}「{hostname}」"
    return None


#: 名稱裡的 OCP：要是一段的開頭（`.ocpt.`、`ocp-`、`OCP01`），不抓字中間的（`docp`、`mocpx`）
_OCP_NAME = _re.compile(r"(?<![a-z0-9])ocp", _re.I)
OCP_NAME_WHY = "依據：主機名稱有 OCP 字樣（OpenShift 叢集節點）"


def is_ocp_name(name) -> bool:
    return bool(name) and bool(_OCP_NAME.search(str(name)))


# ===== 同一筆資產，一個入口（2026-10-16）=====
#
# 為什麼要有這支：`not_onboardable()` 的證據是**呼叫端自己湊**的，於是三個呼叫點
# 湊出三組不同的證據——
#     collect_dispatch（/adopt）：os + hostname + ip + esxi_names + extra_text
#     api._onboard_block（資產查詢／資產詳細）：os + hostname + ip        ← 少兩項
#     pipeline._onboard_block_for（漏斗）    ：os + hostname + ip        ← 少兩項
# 同一台 EMC UnityXT480（os 欄 `N/A`、用途寫著 NAS）在 /adopt 判成「儲存設備」，
# 在資產查詢卻判成可納管、還掛著「一鍵納管」按鈕。使用者為了分類不一致抱怨兩次。
#
# 根因不是哪一處寫錯，是「湊證據」這件事本來就不該由呼叫端各做一遍。
# 所以把「蒐集證據 ＋ 呼叫判定」收成這一支，呼叫端只要交出資產列就好。
#
# ⚠️ 參數照抄到第四處也只是把洞複製第四次——要加證據就加在這裡，三頁一起變。


def _field(asset, key):
    """從資產列取一欄。dict 與 sqlite3.Row 都吃；沒撈那一欄就當沒填（回 None）。

    為什麼要容忍欄位不存在：三個呼叫點的 SELECT 不一樣（資產查詢是 `SELECT *`，
    漏斗只撈十幾欄）。少一欄就丟 KeyError 的話，這支共用函式會變成「只有某些
    呼叫點敢用」——那就又退回各寫一份的老路。
    """
    if asset is None:
        return None
    try:
        return asset[key]
    except (KeyError, IndexError, TypeError):
        return None


def asset_free_text(asset) -> str | None:
    """資產名稱＋資產用途併成一段自由文字；兩欄都空回 None。

    `not_onboardable(extra_text=...)` 要的就是這個。為什麼是這兩欄：
    作業系統欄填 `N/A` 的設備，身分常常只寫在這兩欄裡（EMC UnityXT480 NAS）。
    """
    parts = [str(_field(asset, k)).strip() for k in ("asset_name", "asset_purpose")
             if _field(asset, k) not in (None, "")]
    return " ".join(p for p in parts if p) or None


def judge_for_asset(conn, asset, ip=None, esxi_names=None):
    """同一筆資產的「能不能納管」判定——**三個呼叫點唯一的入口**。

    回傳跟 `not_onboardable()` 一樣：(類別, 標籤, 依據) 或 None。

    參數：
      conn        資料庫連線；只拿來查 vCenter 的 ESXi 名單。給 None 代表沒得查。
      asset       資產列（dict 或 sqlite3.Row），要有 os／hostname／asset_name／
                  asset_purpose；少撈了哪一欄就當那一欄沒填，不會炸。
      ip          指定要判的 IP；不給就用資產列上的 ip。
      esxi_names  已經查好的 ESXi 名單。**在迴圈裡逐列判時一定要先查好傳進來**——
                  `esxi_host_names()` 每次都全表掃 source_record 再逐列解 JSON，
                  放進迴圈等於 N 次全表掃。
    """
    if esxi_names is None:
        esxi_names = esxi_host_names(conn) if conn is not None else frozenset()
    got = not_onboardable(
        _field(asset, "os"), _field(asset, "hostname"),
        ip if ip is not None else _field(asset, "ip"),
        esxi_names, extra_text=asset_free_text(asset))
    # VMware 設備優先於「認不出來的設備（appliance）」：Photon／vCenter 字樣 classify_os 只會判成
    # appliance，但天條要的是明確的 VMware 類別（下游一律以 kind=="esxi" 擋 SSH 收集）。
    if (got is None or got[0] == "appliance" or got[2].startswith(OCP_NAME_WHY)) and is_vmware_platform(asset):
        return "esxi", NOT_ONBOARDABLE_LABEL["esxi"], VMWARE_PLATFORM_REASON
    return got


#: 2026-10-18 使用者擴大天條（「如果是 VMware 不能跑」「連帳號都不能建立」）：
#: ESXi 之外，vCenter Server Appliance（VCSA，Photon OS）也一律不納管、不收集。
#: 判定**沿用全站唯一一份作業系統大類規則**（os_class_groups.json 的「虛擬化平台」），
#: 不另寫關鍵字清單。跑在 VMware 上的客體 VM（RHEL／Windows）不在此列。
VMWARE_PLATFORM_CLASS = "虛擬化平台"
VMWARE_PLATFORM_REASON = ("依據：作業系統大類為「虛擬化平台」（ESXi／vCenter 等 VMware 設備）"
                          "——不建本機帳號、不經 SSH 收集")


def is_vmware_platform(asset) -> bool:
    """這筆資產依共用的 os_class 規則是不是 VMware 平台本身（ESXi、vCenter／VCSA）。
    2.058.19 審查 P1：規則檔讀不到**不再回 False**（那會把 vCenter 整類放行）——例外照樣往上丟，
    登入前判定（login_targets）接到就「判不出來＝不登入」；其他頁面跟全站 os_class 一樣報錯，不默默算錯。"""
    import os_class
    return os_class.classify(
        _field(asset, "os"), _field(asset, "device_model"),
        _field(asset, "group_name"), _field(asset, "asset_purpose")) == VMWARE_PLATFORM_CLASS


#: manage_state.refresh_collect_status 寫給「原本 collect_ok=1 的 VMware 列」的 collect_error（2.006.24 起 VMware 不再試連、
#: collect_ok 改 0）。只寫給原本是 1 的——從沒納管過的 ESXi 不寫，才不會被當成「天條前已納管、待移除」。
VMWARE_LEGACY_REASON = ("VMware 設備（ESXi／vCenter）不經 SSH 收集；天條前曾被納管，收集帳號待移除"
                        "（資料來源：vCenter／RVTools）")


def legacy_signals(conn) -> dict:
    """「這台曾經被當一般主機納管過」的證據來源，查一次給整批用。"""
    try:
        acct = {r[0]: r[1] for r in conn.execute(
            "SELECT ip, COUNT(*) FROM host_account WHERE gone_at IS NULL GROUP BY ip")}
    except Exception:  # noqa: BLE001 - 舊 DB 沒有 host_account 就當沒有帳號資料
        acct = {}
    # 每個 IP 只看最新一筆納管紀錄（審查 2.006.26）：最新一筆是撤銷＝已清掉；舊的成功紀錄可能是 IP 重用前別台的
    try:
        last = {r[0]: {"ok": r[1], "trigger": r[2], "at": r[3]} for r in conn.execute(
            "SELECT a.target_ip, a.ok, a.trigger, a.created_at FROM onboard_audit a "
            "JOIN (SELECT target_ip, MAX(id) AS id FROM onboard_audit GROUP BY target_ip) m ON m.id = a.id")}
    except Exception:  # noqa: BLE001 - 舊 DB 沒有 onboard_audit
        last = {}
    return {"acct": acct, "last_audit": last}


def _audit_evidence(a, last: dict) -> bool:
    """最新一筆納管紀錄是「成功的納管」（不是撤銷），而且發生在這筆登記建立之後（IP 重用前的紀錄不算）。"""
    import manage_state

    def g(k):
        try:
            return a[k]
        except (KeyError, IndexError):
            return None
    created = str(g("created_at") or "")
    for ip in manage_state.ips_of(g("ip")):
        x = last.get(ip)
        if not x or x["ok"] != 1 or (x["trigger"] or "") == "revoke":
            continue
        if created and str(x["at"] or "") < created:
            continue
        return True
    return False


def had_collector_access(a, sig: dict) -> bool:
    """這筆登記有沒有收集帳號的痕跡：collect_ok=1、主機上有收集到的帳號、collect_error 是「VMware 不試連」
    （2.006.24 起 VMware 列會被寫成 0＋這個原因——不能因此把天條前納管的 ESXi 從待移除清單弄丟），
    或納管紀錄有成功的一次（審查 2.006.25）。"""
    import manage_state

    def g(k):
        try:
            return a[k]
        except (KeyError, IndexError):
            return None
    ips = manage_state.ips_of(g("ip"))
    return (g("collect_ok") == 1 or any(sig["acct"].get(ip) for ip in ips)
            or str(g("collect_error") or "") == VMWARE_LEGACY_REASON
            or _audit_evidence(a, sig["last_audit"]))


def onboarded_esxi(conn) -> list[dict]:
    """已被當成一般主機納管／收集，但登記上其實是 ESXi 的清單（**唯讀，不刪任何東西**）。

    天條（使用者 2026-10-17）：ESXi 不可納管、不可建帳號。引擎從現在起會拒絕，
    但之前已經建好的帳號要由使用者決定是否移除——這支只負責把它們列出來。
    條件：hardware.collect_ok=1，或 host_account 有這個 IP 的在線帳號；且同一支正典判定為 esxi。
    """
    sig = legacy_signals(conn)
    acct = sig["acct"]
    esxi_names = esxi_host_names(conn)
    out = []
    for r in conn.execute("SELECT * FROM hardware"):
        a = dict(r)
        ip = (a.get("ip") or "").strip()
        if not had_collector_access(a, sig):
            continue
        got = judge_for_asset(conn, a, esxi_names=esxi_names)
        if got and got[0] == "esxi":
            out.append({"asset_serial": a.get("asset_serial"), "hostname": a.get("hostname"),
                        "ip": ip, "os": a.get("os"), "accounts": acct.get(ip, 0),
                        "reason": got[2]})
    return out


def block_for_asset(conn, asset, ip=None, esxi_names=None) -> dict | None:
    """`judge_for_asset` 的畫面版：回 {kind,label,reason}，可以納管就回 None。

    api.py 與 pipeline.py 都要把結果塞進 JSON 給前端，轉換寫在這裡，不各寫一遍。
    """
    blk = judge_for_asset(conn, asset, ip=ip, esxi_names=esxi_names)
    return {"kind": blk[0], "label": blk[1], "reason": blk[2]} if blk else None


# ===== SSH banner 自報的身分（2026-09-15）=====
# 使用者看到 10.99.198.21「22 通、但收集帳號進不去」被列在待佈身分，問「這是 VM ESXi 嗎？」
# ——banner 自報 `Avi Cloud Controller；VMware Avi Load Balancer software (Broadcom)`，
# 是 VMware 的負載平衡器（NSX ALB），不是 ESXi，但**一樣不該納管**。
#
# 判斷需要的證據**當下就印在畫面上**（連線失敗訊息帶著 banner），只是程式沒拿來用：
# 資產庫沒登記／os 欄空白的機器，光看 os 判不出來，但 banner 已經自報身分了。
#
# ⚠️ 只認「產品自報」的字樣，不做模糊比對：一般 Linux 的 banner 是 OpenSSH 版本字串，
# 不會出現這些產品名。認不出來就不標——失敗方向是「漏標」（維持原本行為），不是誤標。
_BANNER_PRODUCTS = (
    (r"avi (cloud|load)|nsx\s*alb", "VMware Avi Load Balancer（NSX ALB）"),
    (r"esxi|vsphere", "VMware ESXi"),
    (r"\bvmware\b", "VMware 設備"),
    (r"fortigate|fortios", "FortiGate"),
    (r"big-?ip|f5 networks", "F5 BIG-IP"),
    (r"brocade|fabric os|\bfos\b", "Brocade SAN switch"),
    (r"cisco|nx-?os|ios-xe", "Cisco 網路設備"),
    (r"junos|juniper", "Juniper 網路設備"),
    (r"arubaos|aruba networks", "Aruba 網路設備"),
    (r"idrac|integrated dell remote", "iDRAC 管理卡"),
    (r"\bilo\b|integrated lights-out", "iLO 管理卡"),
    (r"netapp|ontap", "NetApp 儲存"),
    (r"powerstore|unity|isilon|storwize|purestorage", "儲存設備"),
)
_BANNER_RES = tuple((_re.compile(p, _re.I), label) for p, label in _BANNER_PRODUCTS)


def product_from_banner(text) -> str | None:
    """SSH 連線訊息（含 banner）自報的產品名；認不出來回 None。"""
    s = str(text or "")
    if not s:
        return None
    for rx, label in _BANNER_RES:
        if rx.search(s):
            return label
    return None


# ===== 唯讀探測的 VMware 目標過濾（2026-10-28，審查 H1／M4）=====
# 即時檢測（/api/health-check/run）、週六健康基準、納管後第一次健檢共用：
# 目標（IP／主機名稱／FQDN／別名）只要有一個名稱或 DNS 解析出的 IP 對到 VMware，就不連線。

_RESOLVE_TIMEOUT_S = 2.0


def canon_ip(s) -> str | None:
    """IP 字面值 → 標準寫法；不是 IP 字面值回 None（2.058.13 審查 P1，天條）。
    IPv4-mapped IPv6（`::ffff:10.99.0.11`、`::FFFF:…`、`0:0:0:0:0:ffff:a63:b`）折回 IPv4——
    Linux 連這種位址實際上就是連那個 IPv4，不折回的話資產庫的 IP 索引對不到，ESXi 會被當成沒登記的主機登入。
    八進位／十六進位／整數／縮寫（`010.99.0.11`、`0x0a…`、`174260235`、`10.99.11`）一律不是 IP（ipaddress 本身就拒收）。"""
    import ipaddress as _ip

    try:
        a = _ip.ip_address(str(s if s is not None else "").strip())
    except ValueError:
        return None
    m = getattr(a, "ipv4_mapped", None)
    return str(m) if m is not None else str(a)


IPV4_ONLY_ERROR = "只接受 IPv4 位址"


def onboard_ipv4(raw) -> str | None:
    """納管／登入入口唯一的位址判定（2.058.14 審查 P1，天條）：回標準寫法的 IPv4，其他一律 None。
    資產庫全是 IPv4，所以不去一一折回各種 IPv6 內嵌寫法（NAT64 `64:ff9b::`、`::a.b.c.d`、`::ffff:0:…`、6to4 `2002:…`）——
    只有 `::ffff:` 這種 IPv4-mapped 折回 IPv4（canon_ip），其餘 IPv6、zone、括號、`:22`、清單、八進位／十六進位／整數／縮寫都不接受。"""
    import ipaddress as _ip

    c = canon_ip(raw)
    if c is None:
        return None
    return c if _ip.ip_address(c).version == 4 else None


def is_hostname(s) -> bool:
    """像主機名稱（RFC 1123 標籤、最後一段以英文字母開頭、不帶結尾的點）。
    最後一段以字母開頭＝把 `010.99.0.11`、`0x0a63000b`、`174260235`、`10.99.11` 這些「看起來像 IP」的排除掉，
    它們不能拿去 DNS 解析（系統解析器會把它們當成八進位／十六進位 IP，連到哪台不由資產庫決定）。"""
    s = str(s or "")
    if not s or len(s) > 253:
        return False
    labels = s.split(".")
    if not all(_re.fullmatch(r"[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?", lb) for lb in labels):
        return False
    return labels[-1][0].isalpha()


def _login_address(raw, *, allow_hostname: bool = False) -> tuple[str | None, list[str], str | None]:
    """登入目標的位址判定：回 (要連的目標, 要拿去判 VMware 的名稱／IP, 拒絕原因)。
    - IPv4（含 `::ffff:` 折回）→ (標準 IPv4, [IPv4], None)
    - allow_hostname 且是主機名稱 → 必須解析得到 IPv4、而且解析出來的**全部**是 IPv4（解析不到、逾時、混了 IPv6 → 拒絕，
      不退回只用名稱比對；fail-closed，審查 P2-1）→ (檢查過的第一個 IPv4, [主機名稱, 每一個 IPv4], None)。
      2.058.15 審查 P2-3：要連的是**檢查過的那個 IPv4**，不把主機名稱交給 SSH 再解析一次（兩次解析之間 DNS 可能變）；
      主機名稱只留給呼叫端當顯示用。
    - 其他 → (None, [], 「只接受 IPv4 位址」)"""
    s = str(raw or "").strip()
    v4 = onboard_ipv4(s)
    if v4:
        return v4, [v4], None
    if not (allow_hostname and is_hostname(s)):
        return None, [], IPV4_ONLY_ERROR
    addrs = _resolve_ips(s)
    v4s = sorted(a for a in addrs if onboard_ipv4(a))
    if not v4s:
        return None, [], f"主機名稱 {s} 解析不到 IPv4 位址（DNS 失敗或逾時），不登入"
    if len(v4s) != len(addrs):
        return None, [], f"主機名稱 {s} 解析出 IPv4 以外的位址，不登入（{IPV4_ONLY_ERROR}）"
    return v4s[0], [s, *v4s], None


def login_target_refusal(conn, raw, *, allow_hostname: bool = False, retired_map: dict | None = None) -> tuple[str | None, str | None]:
    """所有會登入目標機的入口共用（批次試密碼、預檢、一鍵納管、取消納管、Windows 納管、驗證、憑證測試）：
    回 (要連的目標, None) 或 (None, 拒絕原因)。位址不合格、VMware（ESXi／vCenter，含反解名稱）、
    判定本身出錯（fail-closed）都拒絕；拒絕的一律不連線。"""
    targets, why = login_targets(conn, raw, allow_hostname=allow_hostname, retired_map=retired_map)
    return (targets[0] if targets else None), why


def login_targets(conn, raw, *, allow_hostname: bool = False, ptr_strict: bool = False, retired_map: dict | None = None) -> tuple[list[str], str | None]:
    """**唯一**的登入前判定（2.058.16 審查 P1-A：不要在入口自己拆成「先解析、再只拿 IP 判 VMware」——那樣會把打進來的名稱丟掉）：
    回 (檢查過的 IPv4 清單, None) 或 ([], 拒絕原因)。打進來的名稱**和**解析出的每一個 IPv4 都拿去判 VMware（含 PTR 反解）。
    retired_map：呼叫端已用 retired_targets 對整批 IP 一次判好的結果（批次啟動時用，不用每台各查一次）；None＝這裡自己判。
    ptr_strict：無人在場的排程用——PTR 反查失敗／逾時就拒絕（「反查失敗，下一輪再試」）。
      True／"strict"＝「沒有 PTR」（HOST_NOT_FOUND）不算失敗（只在 DNS 健康檢查通過後用）；
      "all"＝連「沒有 PTR」也拒絕（沒有可以做健康檢查的名稱時：分不出「真的沒有」與「解析器壞了」，2.058.17 審查 P1-2）。"""
    target, names, why = _login_address(raw, allow_hostname=allow_hostname)
    if why:
        return [], why
    try:
        vm = vmware_targets(conn, names, reverse=True, ptr_strict=ptr_strict)
    except PtrLookupFailed:
        return [], PTR_FAIL_ERROR
    except Exception:  # noqa: BLE001 - 判不出來＝當作是，不登入（固定字樣回給呼叫端，例外細節只進 log）
        import logging

        logging.getLogger("onboard_eligibility").exception("VMware 判定出錯（fail-closed）")
        return [], ELIGIBILITY_FAIL_ERROR
    if vm:
        return [], f"VMware 設備不可納管，沒有登入：{next(iter(vm.values()))}"
    ips = [n for n in names if onboard_ipv4(n) == n]
    bad = retired_targets(conn, ips) if retired_map is None else {i: retired_map[i] for i in ips if i in retired_map}
    if bad:
        return [], next(iter(bad.values()))
    return (ips if target in ips else [target, *ips]), None


#: 納管入口只擋「停用、報廢」（明確終止）。「閒置」是可逆狀態、可能是待啟用的新機，**不擋**（2026-11-22 GPT 顧問建議；其他用 lifecycle.RETIRED_STATUS 的統計與報表不動）。
LOGIN_BLOCKED_STATUS = frozenset({"停用", "報廢"})
RETIRED_TARGET_ERROR = "退役／報廢的資產不納管，沒有登入：請先到 CIA 確認資產狀態"
ELIGIBILITY_FAIL_ERROR = "無法確認資格（資格判定失敗），不登入"     # 固定字樣：例外細節只寫伺服器 log，不回給畫面（審查 #11）
_GENERATED_SERIAL_PREFIXES = ("DYN-", "VC-", "AUTO-", "ADOPT-")   # 系統自己建的登記（掃描／vCenter／自動納管），不是 CIA 正本


def _retired_message(statuses) -> str:
    st = "、".join(f"「{s}」" for s in sorted(statuses))
    return f"退役／報廢的資產不納管，沒有登入（資產狀態為{st}）：請先到 CIA 確認資產狀態"


def _is_live_registration(r) -> bool:
    """這筆登記算不算現役證據：明確退役／報廢＝不算；狀態空白的系統自建登記（DYN-／AUTO-…）＝不算（沒有 CIA 值，不能用來反證）；
    其餘（含 CIA 正本狀態空白、未知字樣）＝算現役——大量 CIA 資料狀態欄是空的，不確定就放行（已知限制，審查 #2 不修）。"""
    import lifecycle

    st = (r["asset_status"] or "").strip()
    if st in LOGIN_BLOCKED_STATUS:
        return False
    return bool(st) or not str(r["asset_serial"] or "").startswith(_GENERATED_SERIAL_PREFIXES)


def _hw_rows_by_ips(conn, ips: list[str]) -> list[dict]:
    """IP 欄含這些 IP 的登記（IP 欄可能是「a,b」多值，所以整欄精確比對不夠）。少量 IP 用 LIKE 預篩（每 50 個一次查詢），
    多量就整表讀一次；之後用 manage_state.ips_of 精確確認。SQL 次數是 O(批次數)，不是 O(IP 數)。"""
    import manage_state

    want = set(ips)
    found: dict[str, dict] = {}

    def _take(rows):
        for r in rows:
            d = {"asset_serial": r[0], "hostname": r[1], "ip": r[2], "asset_status": r[3]}
            if want.intersection(manage_state.ips_of(d["ip"]) + [str(d["ip"] or "").strip()]):
                found[d["asset_serial"]] = d

    cols = "SELECT asset_serial, hostname, ip, asset_status FROM hardware"
    if len(ips) > 50:
        _take(conn.execute(cols + " WHERE ip IS NOT NULL AND trim(ip) <> ''").fetchall())
    else:
        for i in range(0, len(ips), 50):
            chunk = ips[i:i + 50]
            _take(conn.execute(cols + " WHERE " + " OR ".join("ip LIKE ?" for _ in chunk),
                               [f"%{x}%" for x in chunk]).fetchall())
    return list(found.values())


def _hw_rows_by_hostnames(conn, names: list[str]) -> list[dict]:
    out: list[dict] = []
    for i in range(0, len(names), 400):
        chunk = names[i:i + 400]
        out += [{"asset_serial": r[0], "hostname": r[1], "ip": r[2], "asset_status": r[3]} for r in conn.execute(
            "SELECT asset_serial, hostname, ip, asset_status FROM hardware "
            f"WHERE lower(trim(hostname)) IN ({','.join('?' * len(chunk))})", chunk)]
    return out


def _blocked_statuses(conn, seeds_by_label: dict) -> dict:
    """{label: 退役狀態字樣集合}：只列「這台機器的全部登記都不是現役、而且至少一筆明確退役／報廢」的。
    『這台機器』＝同一把 system_stats.machine_key（同主機名的多個登記、多 IP 欄、同 serial）的所有登記，不是只看被點的那一列
    （審查 #1／#4：同機有退役正式列＋狀態空白的 DYN-／AUTO- 重複列，用後者進來也要擋）。
    SQL：依主機名一次（分批）撈同機登記，不是每個 IP 一次。"""
    import lifecycle
    import system_stats

    seeds_all = {s["asset_serial"]: s for ss in seeds_by_label.values() for s in ss}
    if not seeds_all:
        return {}
    names = sorted({str(s["hostname"]).strip().lower() for s in seeds_all.values() if str(s["hostname"] or "").strip()})
    pool = dict(seeds_all)
    for r in _hw_rows_by_hostnames(conn, names):
        pool.setdefault(r["asset_serial"], r)
    key = {sn: system_stats.machine_key(r["hostname"], r["ip"], sn) for sn, r in pool.items()}
    by_key: dict[str, list[dict]] = {}
    for sn, r in pool.items():
        by_key.setdefault(key[sn], []).append(r)
    out: dict = {}
    for label, seeds in seeds_by_label.items():
        if not seeds:
            continue
        sib = {r["asset_serial"]: r for s in seeds for r in by_key.get(key[s["asset_serial"]], [s])}
        sib.update({s["asset_serial"]: s for s in seeds})
        if any(_is_live_registration(r) for r in sib.values()):
            continue
        sts = {(r["asset_status"] or "").strip() for r in sib.values()} & set(LOGIN_BLOCKED_STATUS)
        if sts:
            out[label] = sts
    return out


def retired_targets(conn, ips) -> dict[str, str]:
    """{IP: 拒絕原因}：這批 IP 對到的『整台機器』全部登記都是退役／報廢才列（沒登記＝新設備首次納管、有任何現役登記、
    狀態空白的 CIA 登記＝都不擋）。訊息寫實際資產狀態字樣。判定本身出錯＝fail-closed（整批列入固定訊息，例外寫 log）。
    登入前判定（login_targets）與不走 login_targets 的批次探測（batch-probe、precheck）共用；一批 IP 的 SQL 次數是 O(批次數)。"""
    want = list(dict.fromkeys(str(i).strip() for i in (ips or []) if str(i or "").strip()))
    if not want:
        return {}
    try:
        import manage_state

        regs = _hw_rows_by_ips(conn, want)
        seeds: dict[str, list[dict]] = {w: [] for w in want}
        for r in regs:
            tips = set(manage_state.ips_of(r["ip"])) | {str(r["ip"] or "").strip()}
            for w in want:
                if w in tips:
                    seeds[w].append(r)
        blocked = _blocked_statuses(conn, seeds)
        return {w: _retired_message(blocked[w]) for w in want if w in blocked}
    except Exception:  # noqa: BLE001 - 判不出來＝不登入；細節只進伺服器 log
        import logging

        logging.getLogger("onboard_eligibility").exception("退役／報廢判定出錯（fail-closed）")
        return {w: ELIGIBILITY_FAIL_ERROR for w in want}


def asset_retired_reason(conn, asset_serial: str) -> str | None:
    """以序號找這筆登記所屬『整台機器』（含它的每個 IP、同主機名的其他登記），全部都不是現役且有明確退役才回原因；否則 None。
    post_onboard 收集用（不能只看被點的那一列）。判定出錯回固定訊息（fail-closed）。"""
    try:
        import manage_state

        r = conn.execute("SELECT asset_serial, hostname, ip, asset_status FROM hardware WHERE asset_serial = ?",
                         (asset_serial,)).fetchone()
        if r is None:
            return None
        seed = {"asset_serial": r[0], "hostname": r[1], "ip": r[2], "asset_status": r[3]}
        seeds = [seed]
        own_ips = manage_state.ips_of(seed["ip"])
        if own_ips:
            seeds += [x for x in _hw_rows_by_ips(conn, own_ips) if x["asset_serial"] != seed["asset_serial"]]
        blocked = _blocked_statuses(conn, {"a": seeds})
        return _retired_message(blocked["a"]) if "a" in blocked else None
    except Exception:  # noqa: BLE001
        import logging

        logging.getLogger("onboard_eligibility").exception("資產退役／報廢判定出錯（fail-closed）")
        return ELIGIBILITY_FAIL_ERROR


PTR_FAIL_ERROR = "反查失敗，下一輪再試"
DNS_UNHEALTHY_ERROR = "DNS 異常，本輪不納管"


def vcenter_fqdns(conn, limit: int = 3) -> list[str]:
    """vCenter 名單裡的 ESXi 完整名稱（一定要解析得到的名字）——拿來做 DNS 健康檢查。"""
    out: list[str] = []
    try:
        rows = conn.execute("SELECT payload FROM source_record WHERE source = 'vcenter'").fetchall()
    except Exception:  # noqa: BLE001 - 舊 DB 沒有這張表＝沒有名單
        return out
    for r in rows:
        try:
            d = _json.loads(r[0] or "{}")
        except (ValueError, TypeError):
            continue
        h = str(d.get("esxi_host") or "").strip().rstrip(".") if isinstance(d, dict) else ""
        if h and "." in h and onboard_ipv4(h) is None and is_hostname(h) and h not in out:
            out.append(h)
            if len(out) >= limit:
                break
    return out


def _hosts_file_path() -> str:
    import os

    if os.name == "nt":
        return os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "System32", "drivers", "etc", "hosts")
    return "/etc/hosts"


def _local_only_names() -> set[str]:
    """不經 DNS 也解析得到的名字（hosts 檔裡的每個名稱、這台自己的主機名稱——nss files／myhostname）。
    沒有 hosts 檔＝沒有要排除的；其他讀取錯誤往上丟（呼叫端當「分不出來」）。全部小寫、去結尾的點。"""
    import socket

    out: set[str] = set()
    try:
        with open(_hosts_file_path(), encoding="utf-8", errors="replace") as fh:
            for line in fh:
                out.update(t.strip().rstrip(".").lower() for t in line.split("#", 1)[0].split()[1:])
    except FileNotFoundError:
        pass
    for fn in (socket.gethostname, socket.getfqdn):
        try:
            out.add(fn().strip().rstrip(".").lower())
        except Exception:  # noqa: BLE001 - 拿不到自己的名字＝不用排除
            pass
    return out


def resolver_health(conn) -> tuple[str, str | None]:
    """排程自動納管每輪開頭的 DNS 健康檢查（2.058.17 審查 P1-2）：正向解析一個「一定要解析得到」的名字。
    回 ("ok", 名稱)／("fail", 名稱)／("none", None)——沒有可以測的名稱時不測，
    呼叫端改用最嚴格的反查（ptr_strict="all"）。RHEL 的 `hosts: files dns myhostname` 在解析器壞掉時
    也可能回 HOST_NOT_FOUND，所以「沒有 PTR」只有在這裡確認解析器正常後才可以當真。
    2.058.19 審查 P1：寫在 hosts 檔、或是這台自己的名字，不經 DNS 也解析得到（DNS 壞了照樣「通過」）——
    這種名字不拿來測；拿掉「收集器自己的完整名稱」退路（myhostname 一定解得到，等於永遠通過）。
    讀 hosts 檔出錯＝分不出來，回 "none"（走最嚴格）。"""
    try:
        local = _local_only_names()
    except Exception:  # noqa: BLE001 - 分不出哪些名字只靠本機解析＝不測，呼叫端走最嚴格的 "all"
        return "none", None
    names = [n for n in vcenter_fqdns(conn, limit=50) if n.lower() not in local][:3]
    if not names:
        return "none", None
    for n in names:
        if _resolve_ips(n):
            return "ok", n
    return "fail", names[0]


class PtrLookupFailed(Exception):
    """PTR 反查失敗或逾時（不是「沒有 PTR」）。"""


def _resolve_ips(host: str) -> set[str]:
    """主機名稱 → IP（getaddrinfo，最多等 2 秒；解析不到回空集合）。IP 本身直接回（標準寫法，IPv4-mapped 折回 IPv4）。"""
    import concurrent.futures
    import socket

    h = host.strip().rstrip(".")
    c = canon_ip(h)
    if c is not None:
        return {c}
    ex = concurrent.futures.ThreadPoolExecutor(max_workers=1)
    try:
        fut = ex.submit(socket.getaddrinfo, h, None)
        infos = fut.result(timeout=_RESOLVE_TIMEOUT_S)
        return {canon_ip(i[4][0]) or i[4][0] for i in infos if i and i[4]}
    except Exception:  # noqa: BLE001 - 解析不到／逾時：只用名稱比對（下游照樣用 judge_for_asset 判）
        return set()
    finally:
        ex.shutdown(wait=False)


#: gethostbyaddr 的「查無此紀錄」（不是失敗）：h_errno HOST_NOT_FOUND／NO_DATA，Windows 的 WSAHOST_NOT_FOUND／WSANO_DATA
_PTR_NONE_ERRNOS = (1, 4, 11001, 11004)


def _ptr_lookup(ip: str) -> set[str] | None:
    """IP → PTR 名稱（最多等 2 秒）。沒有 PTR 回空集合；查詢失敗或逾時回 None（2.058.16：排程要分得出兩者）。"""
    import concurrent.futures
    import socket

    ex = concurrent.futures.ThreadPoolExecutor(max_workers=1)
    try:
        name, aliases, _ = ex.submit(socket.gethostbyaddr, ip).result(timeout=_RESOLVE_TIMEOUT_S)
        return {n for n in [name, *aliases] if n}
    except socket.herror as exc:
        return set() if exc.errno in _PTR_NONE_ERRNOS else None
    except Exception:  # noqa: BLE001 - 逾時／其他錯誤＝反查失敗（回 None，由呼叫端決定要不要擋）
        return None
    finally:
        ex.shutdown(wait=False)


def _reverse_names(ip: str) -> set[str]:
    """IP → 反解名稱（PTR，最多等 2 秒；解不到或失敗都回空集合）。只給單台指名的路徑用，全機隊不做（逐台等 DNS 太慢）。"""
    return _ptr_lookup(ip) or set()


def _norm_name(n) -> str:
    import system_stats
    return system_stats.strip_domain(str(n or "").strip().rstrip(".")).lower()


def _hw_index(conn) -> tuple[list, dict, dict]:
    """(登記列, 短名稱→列號, IP→列號)，每列只算一次（審查 N3；查表不逐列掃，全機隊幾千個目標也快）。"""
    import manage_state

    rows = conn.execute("SELECT * FROM hardware").fetchall()
    by_name: dict[str, list[int]] = {}
    by_ip: dict[str, list[int]] = {}
    for i, r in enumerate(rows):
        nm = _norm_name(r["hostname"])
        if nm:
            by_name.setdefault(nm, []).append(i)
        for ip in manage_state.ips_of(r["ip"]):
            for k in {ip, canon_ip(ip) or ip}:      # 登記寫成 IPv4-mapped 也對得到（審查 P1）
                by_ip.setdefault(k, []).append(i)
    return rows, by_name, by_ip


def _hw_rows_for(conn, names: set[str], ips: set[str], index: tuple | None = None) -> list:
    """這些名稱／IP 在資產庫的登記：短名稱相同（兩邊都去網域、去結尾的點，FQDN／短名互相對得到），
    或任一 IP（含 DNS 解析出來的）在登記的 IP 欄裡（hardware.ip 可能是「a, b」）。"""
    rows, by_name, by_ip = index if index is not None else _hw_index(conn)
    hit: set[int] = set()
    for n in names:
        hit.update(by_name.get(_norm_name(n), ()))
    for ip in ips:
        hit.update(by_ip.get(ip, ()))
    return [rows[i] for i in sorted(hit)]


def vmware_targets(conn, hosts: list[str], reverse: bool = False, ptr_strict: bool = False) -> dict[str, str]:
    """哪些目標是 VMware 設備（ESXi／vCenter）：回 {目標: 依據}。判定＝onboard_eligibility.judge_for_asset
    （納管、收集同一個入口），ESXi 名單只查一次。
    審查 H1（天條）：目標寫 FQDN、結尾帶點、或是別名時，用短名稱比、並用 DNS 解析出的每一個 IP 比；
    任何一個名稱／IP 對到 VMware 登記或 vCenter ESXi 名單就跳過（寧可漏測，不可對 VMware 發 SSH）。
    審查 N2：目標是「a, b」這種多 IP 字串時逐一拆開（manage_state.ips_of）。"""
    import manage_state

    esxi_names = esxi_host_names(conn)
    index = _hw_index(conn)
    judged: dict = {}          # 同一筆登記在一次呼叫裡只判一次
    out: dict[str, str] = {}
    for h in hosts:
        parts = [x.strip().rstrip(".") for x in (manage_state.ips_of(h) if "," in (h or "") else [h]) if x and x.strip()]
        # 審查 P1（2.058.13）：IP 寫法不同（IPv4-mapped、大小寫）也當同一個——標準寫法一起拿去比
        parts += [c for c in (canon_ip(x) for x in list(parts)) if c and c not in parts]
        ips: set[str] = set()
        for part in parts:
            ips |= _resolve_ips(part)
        if reverse:
            # 單台指名（驗證、指名收集）：IP 反解出的名稱也拿去比（vCenter ESXi 名單常寫 FQDN，資產庫只有 IP 的 AUTO 登記）
            for ip in sorted(ips):
                if ptr_strict:
                    got = _ptr_lookup(ip)
                    if got is None or (ptr_strict == "all" and not got):
                        raise PtrLookupFailed(ip)
                    parts += sorted(got)
                else:
                    parts += sorted(_reverse_names(ip))
        assets = list(_hw_rows_for(conn, set(parts), ips, index))
        for part in parts:
            assets += [{"ip": part, "hostname": part}, {"ip": part, "hostname": _norm_name(part)}]
        assets += [{"ip": ip, "hostname": None} for ip in sorted(ips)]
        for a in assets:
            # 以「值」當鍵（審查 R1：用 id() 會在物件回收後被重用，拿到別的目標的判定）
            key = (("d", a.get("ip"), a.get("hostname")) if isinstance(a, dict) else ("row", a["asset_serial"]))
            if key not in judged:
                judged[key] = judge_for_asset(conn, a, ip=None, esxi_names=esxi_names)
            got = judged[key]
            if got and got[0] == "esxi":
                out[h] = got[2]
                break
    return out
