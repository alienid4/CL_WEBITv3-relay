"""機房搬遷盤點表匯入＋全欄位對帳。

把現場填回來的 Master（.xlsx）讀進來，逐台、逐欄跟系統現有值比對，回一份「校對版」：
Server Master 每格上色——
  綠＝匯入值與系統一致；紅＝不一致（現場校正/與系統不同，值以匯入的為準）；
  藍＝現場沒填、系統有值（幫你補上）；黑／留白＝兩邊都沒有或系統無此欄可比。
所有不一致同時列進「CIA待異動」分頁。**只讀不寫回資料庫**（要不要 Renew 由人另外決定）。

只比「系統也有的欄位」（見 CMP_MAP）；純人事/管理欄（系統沒有獨立來源的）不在比對範圍。
"""
from __future__ import annotations

import io

# Server Master 欄名 → hardware 欄位（只列系統也有、可比對的）
CMP_MAP = {
    "資產狀態": "asset_status", "資產名稱": "asset_name", "主機名稱": "hostname",
    "APID": "api_id", "環境別": "environment", "使用單位": "usage_unit", "擁有者": "owner",
    "保管者": "custodian", "使用者": "user_name", "所屬公司": "owning_company",
    "型號": "device_model", "Serial Number": "hw_serial", "OS": "os",
    "IP(管理/主要)": "ip", "原機房": "physical_location", "原Rack": "rack_no",
}


NOTE_MARK = "【系統對帳不一致】"
UNKNOWN_SHEET = "未知序號"
UNKNOWN_COLS = ["資產序號", "主機名稱", "Server Master 列號", "說明"]


def _norm(v) -> str:
    return str(v).strip().lower() if v not in (None, "") else ""


def _strip_mark(text) -> str:
    """去掉先前回填的系統備註（標記之後整段都是我們寫的），讓重複回填不會疊加。"""
    t = "" if text is None else str(text)
    i = t.find(NOTE_MARK)
    if i < 0:
        return t
    return t[:i].rstrip("；; ")


def _read_history(wb, cols) -> dict:
    """讀既有「CIA待異動」：以（資產序號, 欄位名稱）為鍵，留住人填的處理歷史。"""
    if "CIA待異動" not in wb.sheetnames:
        return {}
    sh = wb["CIA待異動"]
    head = {str(c.value).strip(): i for i, c in enumerate(sh[1]) if c.value}
    if "資產序號" not in head or "欄位名稱" not in head:
        return {}
    out = {}
    for row in sh.iter_rows(min_row=2, values_only=True):
        ser = row[head["資產序號"]] if head["資產序號"] < len(row) else None
        fld = row[head["欄位名稱"]] if head["欄位名稱"] < len(row) else None
        if ser in (None, "") or fld in (None, ""):
            continue                      # 例如「（本次比對沒有不一致）」佔位列
        rec = {c: (row[head[c]] if c in head and head[c] < len(row) else None) for c in cols}
        out[(str(ser).strip(), str(fld).strip())] = rec
    return out


def _has_history(rec) -> bool:
    return bool(rec.get("申請單編號") or rec.get("完成日期")
                or (rec.get("處理狀態") not in (None, "", "待處理")))


def reconcile(conn, file_bytes: bytes) -> tuple[io.BytesIO, dict]:
    from openpyxl import load_workbook
    from openpyxl.styles import Font

    RED = Font(color="C00000")
    GREEN = Font(color="2E7D32")
    BLUE = Font(color="1565C0")

    wb = load_workbook(io.BytesIO(file_bytes))
    if "Server Master" not in wb.sheetnames:
        raise ValueError("這個檔案沒有「Server Master」分頁，請確認是搬遷盤點表")
    ws = wb["Server Master"]

    # 表頭 → 欄位索引
    header = {}
    for c, cell in enumerate(ws[1], 1):
        if cell.value:
            header[str(cell.value).strip()] = c
    if "資產序號" not in header:
        raise ValueError("Server Master 找不到「資產序號」欄")
    serial_c = header["資產序號"]
    note_c = header.get("備註")   # 不一致原因寫進最後一欄「備註」

    # 系統資料：以資產序號為 key
    sys_rows = {r["asset_serial"]: r for r in conn.execute(
        "SELECT * FROM hardware WHERE asset_serial IS NOT NULL")}

    from relocation_export import CIA_DIFF_COLS
    history = _read_history(wb, CIA_DIFF_COLS)

    n_same = n_diff = n_fill = n_unknown = 0
    diffs: list[list] = []
    unknowns: list[list] = []
    for r in range(2, ws.max_row + 1):
        serial = ws.cell(r, serial_c).value
        if serial in (None, ""):
            continue
        hw = sys_rows.get(str(serial).strip())
        host = ws.cell(r, header.get("主機名稱", serial_c)).value or ""
        if hw is None:
            n_unknown += 1
            unknowns.append([str(serial).strip(), host, r, "系統查無此資產序號，未比對"])
            continue
        reasons: list[str] = []
        for col_name, hw_field in CMP_MAP.items():
            c = header.get(col_name)
            if not c:
                continue
            imported = ws.cell(r, c).value
            system = hw[hw_field] if hw_field in hw.keys() else None
            iv, sv = _norm(imported), _norm(system)
            if not iv and not sv:
                continue
            if not iv and sv:                    # 現場沒填、系統有 → 幫補上（藍）
                ws.cell(r, c).value = system
                ws.cell(r, c).font = BLUE
                n_fill += 1
            elif iv and not sv:                  # 現場有、系統沒有 → 保留現場值（不變色）
                continue
            elif iv == sv:                       # 一致（綠）
                ws.cell(r, c).font = GREEN
                n_same += 1
            else:                                # 不一致（紅）→ 值以匯入的為準、記差異
                ws.cell(r, c).font = RED
                n_diff += 1
                diffs.append([serial, host, col_name, system, imported,
                              "不一致", "是", "", "待處理", "", ""])
                reasons.append(f"{col_name}：{system or '(空)'} → {imported}")
        # 這台有不一致 → 在「備註」寫清楚原因（原本→要改成），該列看了就懂。
        # 冪等：先去掉上一輪自己寫的標記段再寫，重複回填不疊加；這輪已一致就把舊標記清掉。
        if note_c:
            cell = ws.cell(r, note_c)
            base = _strip_mark(cell.value)
            if reasons:
                cell.value = (base + "；" if base else "") + NOTE_MARK + "；".join(reasons)
                cell.font = RED
            elif cell.value is not None and NOTE_MARK in str(cell.value):
                cell.value = base or None

    # 寫回 CIA待異動分頁：以（資產序號, 欄位）為鍵合併，保留人填的申請單編號／處理狀態／完成日期／備註
    idx = {c: i for i, c in enumerate(CIA_DIFF_COLS)}
    merged: list[list] = []
    seen = set()
    for d in diffs:
        key = (str(d[0]).strip(), d[2])
        seen.add(key)
        old = history.get(key)
        if old:
            for c in ("申請單編號", "處理狀態", "完成日期", "備註"):
                if old.get(c) not in (None, ""):
                    d[idx[c]] = old[c]
        merged.append(d)
    kept_history = 0
    for key, old in history.items():
        if key in seen or not _has_history(old):
            continue                      # 本次已一致且沒人處理過的舊列就不留了
        row = [old.get(c) for c in CIA_DIFF_COLS]
        row[idx["差異類型"]] = "本次比對已一致（保留處理歷史）"
        merged.append(row)
        kept_history += 1
    if "CIA待異動" in wb.sheetnames:
        cd = wb["CIA待異動"]
        cd.delete_rows(1, cd.max_row)
    else:
        cd = wb.create_sheet("CIA待異動")
    cd.append(CIA_DIFF_COLS)
    for d in merged:
        cd.append(d)
    if not merged:
        cd.append(["（本次比對沒有不一致）"])

    # 未知序號：系統查無的資產序號逐筆列出（每次整張重寫，不疊加）
    if UNKNOWN_SHEET in wb.sheetnames:
        del wb[UNKNOWN_SHEET]
    uk = wb.create_sheet(UNKNOWN_SHEET)
    uk.append(UNKNOWN_COLS)
    for u in unknowns:
        uk.append(u)
    if not unknowns:
        uk.append(["（本次沒有未知序號）"])

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    # 單位：same／diff／filled 是「格」（儲存格比對），unknown_serial 是「列」（Master 的資料列），
    # diff_rows 是 CIA待異動 分頁的「列」，diff_machines 是「台」。
    summary = {"same": n_same, "diff": n_diff, "filled": n_fill, "unknown_serial": n_unknown,
               "diff_rows": len(diffs), "diff_machines": len({str(d[0]).strip() for d in diffs}),
               "history_kept_rows": kept_history,
               "units": {"same": "格", "diff": "格", "filled": "格", "unknown_serial": "列",
                         "diff_rows": "列", "diff_machines": "台", "history_kept_rows": "列"}}
    return buf, summary
