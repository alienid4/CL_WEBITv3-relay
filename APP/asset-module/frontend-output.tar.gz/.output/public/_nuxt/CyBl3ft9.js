import"./DNQOSTJE.js";const s=globalThis.setInterval;export{s};
